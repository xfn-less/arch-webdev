# 验收边界

发布或改动后，按 [TESTING.md](./TESTING.md) 跑通本地回归再上候选，再替正式二进制。

必须成立：

- 面板公网 HTTPS 可用；`site-panel` / `lizhi-socks` active。
- 前端在二进制内：改 `web/` 必须重建并替换 `bin/panel`。
- 更新面板 ≠ 部署目标站、≠ 重启目标 Nginx、≠ 动 APK/证书，除非本轮明确要做。
- 抓取失败只写失败状态行，完整旧数据靠版本选择器；TG 发送成功才记账。
- 手动证书备份不得在 LE 流程里被删；芝麻开门保持宝塔 Nginx。

不承诺：外部 CA/DNS 限流下的 staging 续期演练一定通过；跨机完整灾难恢复（SSH/SOCKS/TG）未作为每轮必测项。

现场机器与目录以 [PROJECT_STATUS.md](./PROJECT_STATUS.md) 为准。

最近完整验收：[2026-11-06 项目收尾](./docs/acceptance/2026-11-06-project-closeout/release.log)。当前 55 站备份已完成同机隔离恢复：数据库、全站文件、主面板 Nginx/TLS/ACME 状态、隔离 HTTPS 反代及 SSH 身份均通过核验，记录见[备份与恢复验收](./docs/acceptance/2026-11-06-backup-retention-and-restore/release.log)。此前 51 站恢复记录仍在 [2026-11-05 封版验收](./docs/FINAL_ACCEPTANCE_2026-11-05.md)。尚未在一台全新空白主机上做完整安装切换；R2 凭据/操作系统与面板版 Nginx 安装需单独托管，TG 未发送演练消息。
