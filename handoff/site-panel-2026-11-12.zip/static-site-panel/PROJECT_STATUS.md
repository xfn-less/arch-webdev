# 当前状态

更新：2026-11-06。

## 是什么

一位管理员用的静态站控制面板：概览全宽（无侧栏），站点原件在主控，目标机靠 SSH 同步。能力范围见 [DESIGN.md](./DESIGN.md)。

## 现场

| 项 | 值 |
|----|-----|
| 主面板 | `45.194.37.198`，目录 `/www/site-panel`，服务 `site-panel`，回环 `8790` |
| 公网 | `https://site-panel.xfnss.top/` |
| 配套 | `lizhi-socks`（`127.0.0.1:17890`）抓荔枝 |
| 备份 | 每日 R2：`config` 小包 + 每站内容寻址整包；清单见 DEPLOY.md |

目标机以面板库里的服务器/站点为准。Debian/Ubuntu 目标用系统 Nginx；**芝麻开门（CentOS）** 继续宝塔 Nginx / `panel-nginx`，不跑 Debian 初始化换 Nginx。

## 运维要点

- 更新面板：先候选验收，再替换 `bin/panel` 并只重启 `site-panel`；不顺带整站部署或重启目标 Nginx。
- SSL 与完整部署分开；手动证书原件保留在主控 `sites/<id>/ssl/`。
- APK：站点开关 + www 根目录源包；处理器随面板二进制下发到站点目录外。
- 验证入口：[TESTING.md](./TESTING.md)、[PRODUCTION_REVIEW.md](./PRODUCTION_REVIEW.md)。

过程性审计、按日验收副本、一次性迁移程序不计入本文件；未切流机器另议。

## SSH 自动恢复更新

发布提交 `161050e`、`feedfda`、`83aa9a6`：SSH 主机密钥变化时自动替换该主机的 `known_hosts` 记录；部署 SSH 接受已变化的主机密钥。密钥认证失败时，部署和终端会尝试使用保存的密码重装面板公钥并重试；保存密码失效时，部署/SSL 当前页面可直接输入新密码修复，终端提供就地密码框并在修复后重连。该逻辑没有对目标机进行现场故障注入。

候选构建 `/tmp/ssp-panel-ssh-recovery`；SSH 相关 Go 测试与 `go vet` 通过，终端回归 4/4、候选浏览器审计 38/38 通过。生产 `site-panel` / `lizhi-socks` active，回环 API 与公网 HTTPS 200；生产 `app.js`、`term.html` 哈希与源码一致。生产二进制 SHA256 `7a1484ee5621f55cd0996f9653006244da59ccf6a9299b60f950c5bdd3a29629`；旧版保留于 `/www/site-panel/bin/panel.before-ssh-auto-recovery-20261106`。只更新主面板，没有部署目标站或改动其 SSH/Nginx。详情见 [SSH 自动恢复发布记录](./docs/acceptance/2026-11-06-ssh-auto-recovery/release.log)。

## 编辑器换行与保存状态修复

发布提交 `7c2f887`：处理手机软键盘只发 `beforeinput` 的换行方式，补当前行缩进与 `{}` 内换行；CodeJar 在内容未变时不再把文件重新标成未保存。旧候选实测未覆盖的两项会失败（软键盘换行、保存完成后松开 Ctrl+S 仍显示未保存），新候选浏览器验收 43/43、文件状态 Node 测试 5/5、Go 构建通过。生产 `site-panel` active，回环与公网 API 200，公网 `app.js` 哈希与源码一致。生产二进制 SHA256 `9725016349cfaff1511981a17a524be091f531b2fa1968bd06094369bfbddc5b`；旧版保留于 `/www/site-panel/bin/panel.before-editor-enter-save-20261107`。仅更新主面板，没有修改目标站。详情见 [编辑器修复发布记录](./docs/acceptance/2026-11-07-editor-keyboard/release.log)。

## 编辑器 Enter 再修复

发布提交 `3020160`：物理 Enter 现在由编辑器捕获并直接插入换行，不再依赖 CodeJar/浏览器默认行为；软键盘 `beforeinput` 同样受理。候选浏览器验收 44/44，覆盖光标中间换行、虚拟键盘换行、缩进和括号换行。生产 `site-panel` active，回环与公网 API 200，公网 `app.js` 哈希与源码一致。生产二进制 SHA256 `146d1156cdb106eacf15f2a3db332bbf1f8c498abff8fd4448d39418477772ef`；旧版保留于 `/www/site-panel/bin/panel.before-editor-enter-direct-20261107`。详情见 [Enter 修复发布记录](./docs/acceptance/2026-11-07-editor-enter-direct/release.log)。

## SSH 瞬时断连重试

发布提交 `6cd427d`：部署/rsync、部署差异预览、SSL、APK 与终端共享连接恢复规则；明确处于认证前的 KEX/banner 断连最多重试 3 次，等待 0.5 秒、1.5 秒后再试。认证失败仍按密钥修复流程处理，远端命令失败不自动重放。针对 `220.167.103.146` 只读检查发现持续公网 SSH 密码喷洒、`MaxStartups 10:30:100`，主面板于 10:05:09 在 KEX 前连接被关闭，10:10:24 同一来源公钥登录成功，符合瞬时握手丢弃特征；没有改该节点。

部署/SSL/API 定向 Go 测试、`go vet` 通过，浏览器候选 43/43。生产 `site-panel` / `lizhi-socks` active，回环与公网 API 200，`app.js` 哈希一致。生产二进制 SHA256 `0a842c243e810d5b4133131ad2f8424245e4b8ac370f6da699d9ac8fe2a1294a`；旧版保留于 `/www/site-panel/bin/panel.before-ssh-handshake-retry-20261107`。只更新主面板，没有对目标机做配置或站点操作。详情见 [SSH 瞬时断连发布记录](./docs/acceptance/2026-11-07-ssh-handshake-retry/release.log)。

## 2026-11-05 封版验收

21 台服务器、51 个站点，最终发布代码 `f1ddbf8`。生产域名 HTTPS、Nginx、APK 定时与完整 R2 下载恢复已检查；主控健康检查纳入备份时效与磁盘。两处额外 TCP 10000 端口已按用户要求放行 UFW：`220.167.104.164` 返回 301（转到该 IP 的 HTTPS），`180.97.221.76` 返回 200；公网连通已验证。详情与证据见 [最终验收](./docs/FINAL_ACCEPTANCE_2026-11-05.md)。

## 概览悬浮菜单更新

发布代码 `fcf3727`：所有屏宽保留「更多」入口，四个站点操作悬浮在表格外，不改变行高；点击外部、滚动、改屏宽或切页收起。10 档 320～1280px 菜单专项 38/38、完整浏览器 47/47、Node 19/19、HTTP API 测试通过；候选与公网资源哈希一致，正式服务正常。二进制 SHA256 `fa9f7208b1beb24843f6120e73a3dfe136ef7af888a2ecc62e775efafa970f86`，旧二进制 `/www/site-panel/bin/panel.before-floating-menu-20261105-200124`。仅更新面板，未部署目标站。

## 手机站点顶栏更新

发布代码 `afa55fe`：手机中间区固定在第二行且不换行，使用短按钮标签，长站名省略；电脑和手机均去掉标题的当前文件后缀。CodeMirror 滚动层补原生惯性与局部 overscroll 设置，未改其内部滚动钳位逻辑，iOS 回弹手感未做真机验证。浏览器 57/57、Node 19/19、HTTP API 测试通过。候选、公网及资源哈希验证通过；二进制 SHA256 `e2c3a645f3f02ca25cbdac8fc1e01f24978eb423041f8de8410a03a0cebe85c9`，旧二进制 `/www/site-panel/bin/panel.before-mobile-header-20261105-201403`。

## 触屏输入字号补齐

发布代码 `81ec030`：统一所有文本输入、select、textarea、contenteditable 的触屏字号为 16px，编辑器同步使用 16px；窄屏或宽屏触屏设备均覆盖，移除原来只列举部分弹窗的规则。其他界面字号保持原样，不限制双指缩放、不添加强制重置 viewport 的脚本。浏览器 67/67、Node 19/19、HTTP API 测试通过；iOS 真机自动缩放行为未实测。候选、公网与资源哈希验证通过。二进制 SHA256 `faff0d95f42accbb36b259516183e28ea57b7781f3d49b9d118a44e1a83b25b5`，旧二进制 `/www/site-panel/bin/panel.before-touch-font-20261105-202524`。

## 电脑概览与主机行调整

发布代码 `b65e8ad`：电脑四个站点操作恢复列右侧悬停/聚焦显示，手机与宽屏触屏保留更多悬浮菜单；电脑表格居中最大 1600px、外侧留白、站点列收紧。主机名称在上行，终端/IP 在下行，IP 14px，名称加深。电脑/手机概览专项 29/29、完整浏览器 67/67、Node 19/19、HTTP API 测试通过。候选、公网及资源哈希验证通过。二进制 SHA256 `2dc3c268f312491376a622b539029643f8c1e02de7829d0ae6deb4bf20e7a957`，旧二进制 `/www/site-panel/bin/panel.before-desktop-overview-20261105-205118`。仅更新主面板。

## 概览全宽与按钮顺序

发布代码 `db95869`：按最新要求取消表格外侧留白与最大宽度限制；上行终端按钮+名称，下行加站点按钮+IP。IP 的 14px 与正文颜色保持不变。概览专项 29/29、完整浏览器 67/67、Node 19/19 通过；候选、公网和资源哈希验证通过。二进制 SHA256 `205c81408be456646ffdfc26281c402880d57069bf3c240cee6f401d13660788`，旧二进制 `/www/site-panel/bin/panel.before-full-width-20261105-205833`。

## 终端标题与操作按钮

发布代码 `4d6cdff`：独立终端页的浏览器标题/页头显示名称与 IP，异步查名称不阻塞连接，断线和重连保留标识；四个站点操作背景透明，去底板/边框/阴影；主机格文字在左，终端/加站点按钮在对应行右侧。Node 23/23（含 4 项终端标题回归）、概览专项 29/29、完整浏览器 67/67、真实本地 SSH WebSocket 测试通过。候选、公网与 app.js/styles.css/term.html 资源哈希验证通过；仅更新面板。二进制 SHA256 `f20a904d555480f74b512370d80bd30c6868af580d31e5d5d3daa013a10578ae`，旧二进制 `/www/site-panel/bin/panel.before-terminal-title-20261105-210505`。

## 手机概览与日志

发布代码 `0d5cdf7`：手机概览隐藏标题和独立统计行，改在「+IP」左侧显示两行「几台 / 几站」；续费表版本入口加下拉图标；手机日志字体缩小、收起高度约两行，展开/收起使用图标并与清空按钮留距。手机 Firefox 专项、续费排序、文件状态、Go 全量测试与 vet 通过。候选与公网 `/styles.css`、`/js/app.js` 哈希一致；生产 `site-panel` 与 `lizhi-socks` active，回环状态及公网 HTTPS 200。仅替换主面板二进制，未部署目标站或重启目标服务。新二进制 SHA256 `e1fd16a81c0dcf10ff9d7cf569d4ef653821a7c7a380b53d2bd49abeeca1bf44`，旧二进制 `/www/site-panel/bin/panel.before-phone-overview-20261106`。iOS 收起键盘后页面放大仍未在真机复现；现有触屏文本字号下限为 16px，未锁定用户缩放或添加未经真机验证的视口重置脚本。

## 最终收口

发布代码 `2176329`：修正窄屏站点页返回按钮被长标题覆盖；手机站点操作浮层恢复透明背景与无阴影，同时保留按钮触控尺寸。移除未被页面使用的旧编辑器下拉菜单和监听，并更新过期的浏览器检查以匹配当前 CodeJar、编辑器工具栏和概览布局。Go test/vet、手机工具栏、浏览器全量 UI 审计 66/66 通过；用户确认 iOS 键盘收起后的放大问题已消失。生产 `/styles.css`、`/js/app.js` 与本地源码哈希一致，`site-panel`、`lizhi-socks` active，回环 API 与公网 HTTPS 返回 200。仅重启主面板；未改目标站、Nginx、证书或备份。二进制 SHA256 `902c8f1919b7ea6b78e1956f9da41489ae286b3d6c3836d054ad3da8075f45e4`，旧二进制 `/www/site-panel/bin/panel.before-final-closeout-20261106`。发布证据见 [最终收口记录](./docs/acceptance/2026-11-06-final-closeout/release.log)。

## 最终项目与备份收尾

发布代码 `a35535f` / `f884030`：站点格选中文字或拖选站点名时不再打开编辑页；IP 与站点表头分别显示服务器数、站点数；续费「版本」使用上下双向展开图标。历史一次性运维命令纳入版本控制并标注仅作历史任务使用，临时验证码移入忽略目录，`bin/` 加入忽略。Go、vet、Node 23/23、备份测试 3/3、健康测试 6/6、全量浏览器 UI 审计 66/66 通过。

生产面板二进制 SHA256 `b6f205ab5f3f5b55e4b34d82a91e8cb8bc9da1f5eb695c0aeeb972bb255391a5`；静态资源与本地源码哈希相同，服务与公网健康检查通过。旧二进制保留为 `/www/site-panel/bin/panel.before-final-ui-closeout-20261106`。

按要求清空专用 R2 桶并重新备份。清空前 374 个旧对象已复制到主机本地 `/root/backups/site-panel/r2-before-reset-20261106/`，Rclone 校验为 374 matching files。新清单 `site-manifests/manifest-20261106-181053-783494074-177a38a3.json`：21 台、53 站、53 个内容寻址站点包；R2 当前共 55 个对象（config 1、site-archives 53、site-manifests 1），旧 `sites-live` 前缀已不存在。新配置包与 R2 对象校验一致，恢复库 `integrity_check=ok`。执行详情见 [项目收尾记录](./docs/acceptance/2026-11-06-project-closeout/release.log)。

## 备注字段与删除确认

发布代码 `6ca7d36`：桌面概览页头移除几台/几站统计；服务器备注改为可选并置于表单末尾，空名称不再显示成重复 IP，旧名称保留为备注且可清空；站点/服务器删除增加对象说明与二次确认，删除确认不能用 Enter，文件删除提示不可恢复。Go 全量测试、vet、Node 23/23、浏览器服务器表单 7/7、概览/删除交互 36/36 通过。生产新二进制 SHA256 `cecd4a4b13d7ae2efd336194c3a75e81bf64382c8420ab4c1579d4350e726cf1`；资源哈希与本地一致，`site-panel` / `lizhi-socks` active，回环与公网 HTTPS 返回 200。旧二进制保留于 `/www/site-panel/bin/panel.before-delete-safety-20261106`。只更新面板；未改目标站点、Nginx、证书或 R2 备份。浏览器完整审计结果见 [发布记录](./docs/acceptance/2026-11-06-delete-safety/release.log)。

## IP/文件选择与续费入口名称

实现提交后发布：无备注时 IP 在主机格中垂直居中；IP 和文件列表文字可选中，选择后点击不触发打开；续费表“打开”在服务器备注为空时显示首个站点名称。Go、vet、Node 23/23、浏览器概览 40/40、全量 UI 68/68 通过。生产核验与旧二进制位置见 [发布记录](./docs/acceptance/2026-11-06-selection-and-billing-label/release.log)。

本次生产二进制 SHA256 `fb7619b077136d3bb483446ecc8afdae05f665869d4cf76a347e4e73a9488d6b`；旧版保留于 `/www/site-panel/bin/panel.before-ip-selection-20261106`。生产资源哈希、服务状态及回归结果见本节发布记录。

选中文字点击保护补正已发布，二进制 SHA256 `005de561b0560c9b178ebace6c3d81cc7057043028ad0aa43dd81f6b98f01be0`，旧版保留在 `/www/site-panel/bin/panel.before-selection-guard-20261106`。回归与生产验证见 [补正发布记录](./docs/acceptance/2026-11-06-selection-click-guard/release.log)。

## Nginx 域名多行格式

新站模板示例和面板域名保存格式改为每行最多 3 个域名，并说明域名可用空格或换行分隔、以分号结束。域名解析兼容旧单行和多行配置，SSL/部署共用该解析结果。Go 全量测试通过，候选浏览器验收 44/44；生产 `site-panel` active，回环 health/API 与公网 HTTPS 返回 200。二进制 SHA256 `5365464c27269e5537eba7d75526c2ebcd9dcb6de44f8751bc289be3b577e108`；旧二进制保留于 `/www/site-panel/bin/panel.before-server-name-multiline-20261107`。仅更新主面板，未改目标站、Nginx 或 R2。详见 [发布记录](./docs/acceptance/2026-11-07-server-name-format/release.log)。

## 上传覆盖提示与解压说明

上传前检查目标目录的同名项目（包括隐藏文件）；冲突时可覆盖普通文件、自动改名保留副本或取消。批量中有同名文件夹或所选文件自身重名时，只允许自动改名或取消；无冲突上传使用后端原子拒绝并发新冲突，避免静默覆盖。解压选择明确说明会合并目录、覆盖同名文件并保留无关文件。Go 全量测试、`go vet`、Node 29/29、候选浏览器验收 44/44 通过。生产 `site-panel` active，回环 health/API 与公网 HTTPS 返回 200；二进制 SHA256 `a9b0cb0605ae867577ee68abc6535b5560378c2a96ea4e58174710bd6a100a5f`，旧版保留于 `/www/site-panel/bin/panel.before-upload-conflict-prompt-20261107`。只更新主面板，未改目标站、Nginx 或 R2。详见 [发布记录](./docs/acceptance/2026-11-07-upload-conflict-prompt/release.log)。

上传等待期间增加日志：预检查、逐文件上传进度、成功、取消和失败均有明确记录；多文件中途失败会刷新已上传内容并保留待部署状态。Go 全量测试、`go vet`、Node 30/30、浏览器验收 44/44 通过。生产 `site-panel` active，回环 health/API 与公网 HTTPS 返回 200；二进制 SHA256 `1a9718edb560133744831a5ef5ff979a1902e4765513b870b8848550e6029d4b`，旧版保留于 `/www/site-panel/bin/panel.before-upload-progress-20261107`。详见 [上传进度发布记录](./docs/acceptance/2026-11-07-upload-progress/release.log)。

## 编辑器多行粘贴修复

CodeJar 原先把纯文本粘贴内容交给 `insertHTML`，HTML 解析会折叠换行。现在粘贴使用文本节点和 Range 插入，保留换行、缩进、选区替换与光标位置。新增浏览器回归：光标位于行内时粘贴 7 行 Nginx 配置；旧逻辑实测 1 行，新逻辑逐字/换行一致。Go 全量测试、`go vet`、Node 30/30、候选浏览器 45/45 通过。生产 `site-panel` active，回环 health/API 与公网 HTTPS 返回 200；二进制 SHA256 `cc6abf8f5928384085b11786ab4afd3db20baa99fcec61f30fd5512e45f40733`，旧版保留于 `/www/site-panel/bin/panel.before-editor-paste-20261107`。只更新主面板，未改目标站、目标 Nginx 或 R2。详情见 [发布记录](./docs/acceptance/2026-11-07-editor-paste/release.log)。

## 配置保存检查、域名格式与编辑器撤销

发布代码 `5723242`：保存 `nginx.conf` 后日志明确显示基础检查通过；这项检查用于发现括号/引号等结构问题，完整 `nginx -t` 仍在目标机部署前运行。新站模板和域名编辑结果改为 `server_name`、每个域名、独立分号各占一行。CodeJar 排除 Shift 修饰键的历史记录，修复撤销后按 Ctrl+Shift+Z 时重做记录可能被清掉的问题。

域名/基础检查 Go 单测通过，Node 30/30、浏览器回归 51/51、资源 diff check 通过。全量 `go test ./...` 此轮因工作区磁盘配额未完成（链接器输出 `disk quota exceeded`，另有 SQLite disk I/O error）；没有记录为全量通过。仅更新主面板，`site-panel` / `lizhi-socks` active，回环 API 与公网 HTTPS 200。二进制 SHA256 `9bbedaede5b66a7c3d32f3c1fb5bff9926d5b2d84fc11b69f5409de3e791520f`，旧版保留于 `/www/site-panel/bin/panel.before-domain-style-editor-undo-20261107`。未改目标站、目标 Nginx 或 R2。详见 [发布记录](./docs/acceptance/2026-11-07-domain-style-editor-undo/release.log)。

## 备份保留与主控恢复验收

备份脚本默认在主机 Asia/Shanghai 时区每天 03:30 运行。R2 和本地 config/清单统一保留最近 3 份；R2 只回收不再被保留清单引用的内容寻址站点包。清理前校验每份清单及其所有归档/config 引用，损坏时停止清理。config 包现还包括主面板 Nginx vhost/WebSocket map、TLS 证书、acme.sh 状态和面板相关 cron；R2 凭据与主机 Nginx 安装仍需单独恢复。

2026-11-06 新备份 `20261106-200514-878115201`：21 台、55 站。R2 共 60 个对象、418,073,935 字节（约 398.6 MiB），其中 2 份完整清单；当前容量明显低于 R2 免费层的 10 GB-month。主机本地 config 和清单各留 3 份。完整恢复演练从这份清单下载并校验 55 个站点归档，SQLite `integrity_check=ok`，恢复版面板 HTTP/资源与隔离 Nginx HTTPS 反代均返回 200；证书私钥权限 600，acme.sh 能识别面板域名，两把恢复 SSH 私钥与公钥匹配，systemd 单元校验通过。未发送真实 TG，也未重启线上 Nginx/面板。详细结果见 [恢复与保留验收](./docs/acceptance/2026-11-06-backup-retention-and-restore/release.log)。

旧 374 对象的本地副本（752,414,017 字节）已在恢复验收通过后删除。主面板现场服务保持 active。只读 SSH 验收中，恢复密钥可连已登记的 `114.66.16.88`；`103.149.201.31` 拒绝同一密钥并返回 `Permission denied (password)`，没有修改该主机。
