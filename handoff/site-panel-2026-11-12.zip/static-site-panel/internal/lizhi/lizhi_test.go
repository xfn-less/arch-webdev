package lizhi

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
)

func providerFixture(t *testing.T, service http.HandlerFunc) Account {
	t.Helper()
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/login":
			if r.Method == "POST" {
				w.Header().Set("Location", "/clientarea")
				w.WriteHeader(302)
				return
			}
			fmt.Fprint(w, `<input name="token" value="fixture">`)
		case "/clientarea":
			fmt.Fprint(w, `<div class="balance-info"><h1>100</h1></div>`)
		case "/service":
			service(w, r)
		default:
			http.NotFound(w, r)
		}
	}))
	t.Cleanup(server.Close)
	return Account{Name: "fixture", Email: "fixture@example.test", BaseURL: server.URL, GroupIDs: []int{305, 306}}
}
func TestSyncAccountRejectsPartialGroupFailure(t *testing.T) {
	a := providerFixture(t, func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Query().Get("groupid") == "306" {
			http.Error(w, "temporary failure", 503)
			return
		}
		fmt.Fprint(w, `var serviceList = [{"dedicatedip":"192.0.2.1"}]; // 当前页列表数据`)
	})
	rows, err := SyncAccount(a, 100, nil, "")
	if err == nil {
		t.Fatalf("partial account falsely accepted: %+v", rows)
	}
}
func TestSyncAccountRejectsUnrecognizedPage(t *testing.T) {
	for _, page := range []string{`maintenance`, `var serviceList = [broken]; productManagement`} {
		t.Run(page, func(t *testing.T) {
			a := providerFixture(t, func(w http.ResponseWriter, r *http.Request) { fmt.Fprint(w, page) })
			if _, err := SyncAccount(a, 100, nil, ""); err == nil {
				t.Fatal("unparsed page accepted as empty account")
			}
		})
	}
}
func TestSyncAccountRecognizesEmptyList(t *testing.T) {
	a := providerFixture(t, func(w http.ResponseWriter, r *http.Request) { fmt.Fprint(w, `var serviceList = []; // 当前页列表数据`) })
	rows, err := SyncAccount(a, 100, nil, "")
	if err != nil || len(rows) != 1 || rows[0].IP != "" {
		t.Fatalf("%+v %v", rows, err)
	}
}

func TestParseBalanceCreditJS(t *testing.T) {
	html := `$(function () { var credit = '108.50元' // 余额 var unpaid = '25.10元' // 未支付`
	got := parseBalance(html)
	if got != "108.50元" {
		t.Fatalf("got %q", got)
	}
	if moneyNumber(got) != "108.50" {
		t.Fatalf("moneyNumber %q", moneyNumber(got))
	}
	// Old markup still wins when present.
	old := `<div class="balance-info"><h1>99.00</h1></div>` + html
	if parseBalance(old) != "99.00" {
		t.Fatalf("old markup should win: %q", parseBalance(old))
	}
}

func TestSyncAccountUsesCreditJSBalance(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/login":
			if r.Method == "POST" {
				w.Header().Set("Location", "/clientarea")
				w.WriteHeader(302)
				return
			}
			fmt.Fprint(w, `<input name="token" value="fixture">`)
		case "/clientarea":
			fmt.Fprint(w, `var credit = '66.60元' // 余额`)
		case "/service":
			fmt.Fprint(w, `var serviceList = [{"dedicatedip":"192.0.2.9","price_desc":"10"}]; // 当前页列表数据`)
		default:
			http.NotFound(w, r)
		}
	}))
	t.Cleanup(server.Close)
	a := Account{Name: "fixture", Email: "fixture@example.test", BaseURL: server.URL, GroupIDs: []int{305}}
	rows, err := SyncAccount(a, 100, nil, "")
	if err != nil || len(rows) != 1 || rows[0].Balance != "66.60" || rows[0].IP != "192.0.2.9" {
		t.Fatalf("%+v %v", rows, err)
	}
}
