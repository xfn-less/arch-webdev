package lizhi

import (
	"bytes"
	"context"
	"crypto/aes"
	"crypto/cipher"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"os"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
	"time"

	"golang.org/x/net/proxy"
)

// Captcha OCR attempts per Login call (fresh /verify each time).
const maxCaptchaAttempts = 5

const DefaultBaseURL = "https://www.lizhidc.cn"

type Account struct {
	Name     string `json:"name"`
	Email    string `json:"email"`
	Phone    string `json:"phone"`
	Password string `json:"password"`
	BaseURL  string `json:"base_url"`
	GroupIDs []int  `json:"group_ids"`
}

func (a Account) LoginID() string {
	if strings.TrimSpace(a.Phone) != "" {
		return strings.TrimSpace(a.Phone)
	}
	return strings.TrimSpace(a.Email)
}

func (a Account) LoginAction() string {
	if strings.TrimSpace(a.Phone) != "" {
		return "phone"
	}
	return "email"
}

func (a Account) Base() string {
	b := strings.TrimSpace(a.BaseURL)
	if b == "" {
		return DefaultBaseURL
	}
	return strings.TrimRight(b, "/")
}

func (a Account) Groups() []int {
	if len(a.GroupIDs) == 0 {
		return []int{305}
	}
	return a.GroupIDs
}

type Telegram struct {
	BotToken string `json:"bot_token"`
	ChatID   string `json:"chat_id"`
	PanelURL string `json:"panel_url"` // e.g. https://site-panel.example/
}

type ConfigFile struct {
	Telegram Telegram  `json:"telegram"`
	Proxy    string    `json:"proxy"` // e.g. socks5://127.0.0.1:17890 — HK 直连荔枝会 PROTOCOL_ERROR
	Accounts []Account `json:"accounts"`
}

// LoadConfig reads accounts JSON: either a bare array, or {telegram,accounts}.
func LoadConfig(path string) (ConfigFile, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return ConfigFile{}, err
	}
	trim := strings.TrimSpace(string(raw))
	if trim == "" {
		return ConfigFile{}, fmt.Errorf("empty config")
	}
	if strings.HasPrefix(trim, "[") {
		var accounts []Account
		if err := json.Unmarshal(raw, &accounts); err != nil {
			return ConfigFile{}, err
		}
		return ConfigFile{Accounts: accounts}, nil
	}
	var cfg ConfigFile
	if err := json.Unmarshal(raw, &cfg); err != nil {
		return ConfigFile{}, err
	}
	return cfg, nil
}

type Asset struct {
	AccountName string
	LoginID     string
	Balance     string
	Product     string
	Note        string
	Status      string
	IP          string
	ExpireAt    string // formatted
	ExpireUnix  int64
	DaysLeft    int
	Fee         string
	Cycle       string
	OS          string
	Bandwidth   string
	Region      string
}

type Client struct {
	http *http.Client
	base string
}

func NewClient(base, proxyURL string) (*Client, error) {
	jar, err := cookiejar.New(nil)
	if err != nil {
		return nil, err
	}
	if base == "" {
		base = DefaultBaseURL
	}
	base = strings.TrimRight(base, "/")
	tr := http.DefaultTransport.(*http.Transport).Clone()
	if p := strings.TrimSpace(proxyURL); p != "" {
		u, err := url.Parse(p)
		if err != nil {
			return nil, fmt.Errorf("proxy: %w", err)
		}
		switch strings.ToLower(u.Scheme) {
		case "socks5", "socks5h":
			var auth *proxy.Auth
			if u.User != nil {
				pw, _ := u.User.Password()
				auth = &proxy.Auth{User: u.User.Username(), Password: pw}
			}
			d, err := proxy.SOCKS5("tcp", u.Host, auth, proxy.Direct)
			if err != nil {
				return nil, fmt.Errorf("socks5: %w", err)
			}
			if cd, ok := d.(proxy.ContextDialer); ok {
				tr.DialContext = cd.DialContext
			} else {
				tr.DialContext = func(ctx context.Context, network, addr string) (net.Conn, error) {
					return d.Dial(network, addr)
				}
			}
			tr.Proxy = nil
		default:
			tr.Proxy = http.ProxyURL(u)
		}
	}
	return &Client{
		base: base,
		http: &http.Client{
			Jar:       jar,
			Timeout:   45 * time.Second,
			Transport: tr,
			CheckRedirect: func(req *http.Request, via []*http.Request) error {
				return http.ErrUseLastResponse
			},
		},
	}, nil
}

func (c *Client) Login(a Account) error {
	action := a.LoginAction()
	scene := captchaScene(action)
	var last error
	for attempt := 1; attempt <= maxCaptchaAttempts; attempt++ {
		last = c.loginOnce(a, action, scene)
		if last == nil {
			return nil
		}
	}
	if last == nil {
		return fmt.Errorf("login failed")
	}
	return fmt.Errorf("after %d captcha tries: %w", maxCaptchaAttempts, last)
}

func (c *Client) loginOnce(a Account, action, scene string) error {
	loginURL := c.base + "/login?action=" + action
	html, err := c.getFollow(loginURL)
	if err != nil {
		return err
	}
	token, err := extractToken(html)
	if err != nil {
		return err
	}
	password := a.Password
	// Lizhi login form uses data-login-encrypt="1": AES-CBC before POST (same as public.js encrypt()).
	if loginEncryptEnabled(html) {
		password, err = encryptLoginPassword(a.Password)
		if err != nil {
			return fmt.Errorf("encrypt password: %w", err)
		}
	}
	form := url.Values{}
	form.Set("token", token)
	form.Set("password", password)
	if action == "phone" {
		form.Set("phone", a.Phone)
	} else {
		form.Set("email", a.Email)
	}
	if loginCaptchaRequired(html) {
		png, err := c.fetchCaptcha(scene)
		if err != nil {
			return fmt.Errorf("captcha image: %w", err)
		}
		code, err := ocrCaptcha(png)
		if err != nil {
			return fmt.Errorf("captcha ocr: %w", err)
		}
		if code == "" {
			return fmt.Errorf("captcha ocr empty")
		}
		form.Set("captcha", code)
	}
	req, err := http.NewRequest(http.MethodPost, loginURL, strings.NewReader(form.Encode()))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Origin", c.base)
	req.Header.Set("Referer", loginURL)
	req.Header.Set("User-Agent", ua)
	res, err := c.http.Do(req)
	if err != nil {
		return err
	}
	body, _ := io.ReadAll(io.LimitReader(res.Body, 1<<20))
	res.Body.Close()
	if res.StatusCode != 302 && res.StatusCode != 303 {
		msg := ""
		var j map[string]any
		if json.Unmarshal(body, &j) == nil {
			if m, ok := j["msg"].(string); ok {
				msg = m
			}
		}
		if msg == "" {
			msg = strings.TrimSpace(string(body))
			if len(msg) > 120 {
				msg = msg[:120]
			}
		}
		return fmt.Errorf("login HTTP %d %s", res.StatusCode, msg)
	}
	loc := res.Header.Get("Location")
	if strings.Contains(loc, "login") {
		return fmt.Errorf("still on login page")
	}
	return nil
}

func captchaScene(action string) string {
	if action == "phone" {
		return "allow_login_phone_captcha"
	}
	return "allow_login_email_captcha"
}

func loginCaptchaRequired(html string) bool {
	return strings.Contains(html, `name="captcha"`) || strings.Contains(html, "图形验证码")
}

func (c *Client) fetchCaptcha(name string) ([]byte, error) {
	u := c.base + "/verify?name=" + url.QueryEscape(name)
	cli := &http.Client{Jar: c.http.Jar, Timeout: 45 * time.Second, Transport: c.http.Transport}
	req, err := http.NewRequest(http.MethodGet, u, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", ua)
	req.Header.Set("Accept", "image/png,image/*;q=0.8,*/*;q=0.5")
	req.Header.Set("Referer", c.base+"/login")
	res, err := cli.Do(req)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	b, err := io.ReadAll(io.LimitReader(res.Body, 1<<20))
	if err != nil {
		return nil, err
	}
	if res.StatusCode >= 400 {
		return nil, fmt.Errorf("HTTP %d", res.StatusCode)
	}
	if len(b) < 32 || bytes.Contains(b[:min(64, len(b))], []byte("400")) {
		return nil, fmt.Errorf("invalid captcha response")
	}
	return b, nil
}

// ocrCaptcha runs panel ddddocr script. Override with LIZHI_OCR_PYTHON / LIZHI_OCR_SCRIPT.
func ocrCaptcha(png []byte) (string, error) {
	py := strings.TrimSpace(os.Getenv("LIZHI_OCR_PYTHON"))
	if py == "" {
		py = "/www/site-panel/.venv-lizhi/bin/python"
	}
	script := strings.TrimSpace(os.Getenv("LIZHI_OCR_SCRIPT"))
	if script == "" {
		script = "/www/site-panel/scripts/lizhi-ocr.py"
	}
	cmd := exec.Command(py, script)
	cmd.Stdin = bytes.NewReader(png)
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	out, err := cmd.Output()
	if err != nil {
		msg := strings.TrimSpace(stderr.String())
		if msg == "" {
			msg = err.Error()
		}
		return "", fmt.Errorf("%s", msg)
	}
	return strings.TrimSpace(string(out)), nil
}

func (c *Client) FetchBalance() (string, error) {
	html, err := c.FetchClientAreaHTML()
	if err != nil {
		return "", err
	}
	return parseBalance(html), nil
}

// FetchClientAreaHTML returns the logged-in clientarea page body (for balance parsing / debug).
func (c *Client) FetchClientAreaHTML() (string, error) {
	html, err := c.getFollow(c.base + "/clientarea")
	if err != nil {
		return "", err
	}
	if isLoginPage(html) {
		return "", fmt.Errorf("session lost")
	}
	return html, nil
}

func (c *Client) FetchGroup(groupID, limit int) (string, error) {
	u := fmt.Sprintf("%s/service?groupid=%d&page=1&limit=%d", c.base, groupID, limit)
	html, err := c.getFollow(u)
	if err != nil {
		return "", err
	}
	if isLoginPage(html) {
		return "", fmt.Errorf("session lost")
	}
	return html, nil
}

// SyncAccount logs in and returns assets for all groups.
func SyncAccount(a Account, limit int, log func(string), proxyURL string) ([]Asset, error) {
	if limit <= 0 {
		limit = 100
	}
	cli, err := NewClient(a.Base(), proxyURL)
	if err != nil {
		return nil, err
	}
	if err := cli.Login(a); err != nil {
		return nil, fmt.Errorf("login: %w", err)
	}
	bal, err := cli.FetchBalance()
	if err != nil {
		return nil, err
	}
	bal = moneyNumber(bal)
	var out []Asset
	for _, gid := range a.Groups() {
		html, err := cli.FetchGroup(gid, limit)
		if err != nil {
			if log != nil {
				log(fmt.Sprintf("[失败] %s groupid=%d: %v", a.Name, gid, err))
			}
			return nil, fmt.Errorf("groupid=%d: %w", gid, err)
		}
		rows, err := parseServices(a, bal, html)
		if err != nil {
			return nil, fmt.Errorf("groupid=%d: %w", gid, err)
		}
		out = append(out, rows...)
		if log != nil {
			log(fmt.Sprintf("[成功] %s groupid=%d: %d 条", a.Name, gid, len(rows)))
		}
	}
	if len(out) == 0 {
		out = append(out, Asset{
			AccountName: a.Name,
			LoginID:     a.LoginID(),
			Balance:     bal,
		})
		if log != nil {
			log(fmt.Sprintf("[空] %s: 0 台", a.Name))
		}
	}
	return out, nil
}

const ua = "Mozilla/5.0 (X11; Linux x86_64; rv:126.0) Gecko/20100101 Firefox/126.0"

func (c *Client) getFollow(rawURL string) (string, error) {
	// temporary client that follows redirects for GET (must keep proxy Transport)
	jar := c.http.Jar
	cli := &http.Client{Jar: jar, Timeout: 45 * time.Second, Transport: c.http.Transport}
	req, err := http.NewRequest(http.MethodGet, rawURL, nil)
	if err != nil {
		return "", err
	}
	req.Header.Set("User-Agent", ua)
	req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	res, err := cli.Do(req)
	if err != nil {
		return "", err
	}
	defer res.Body.Close()
	b, err := io.ReadAll(io.LimitReader(res.Body, 4<<20))
	if err != nil {
		return "", err
	}
	if res.StatusCode >= 400 {
		return "", fmt.Errorf("HTTP %d", res.StatusCode)
	}
	return string(b), nil
}

var (
	tokenRe       = regexp.MustCompile(`(?i)name=["']token["']\s+value=["']([^"']+)["']`)
	tokenRe2      = regexp.MustCompile(`(?i)value=["']([^"']+)["']\s+name=["']token["']`)
	// Trailing marker used to be productManagement; site now ends with ]; // 当前页列表数据
	serviceListRe = regexp.MustCompile(`(?s)var\s+serviceList\s*=\s*(\[.*?\]);`)
	balanceRe     = regexp.MustCompile(`(?s)class="[^"]*balance-info[^"]*"[^>]*>.*?<h1[^>]*>([^<]+)</h1>`)
	balanceRe2    = regexp.MustCompile(`(?s)class="[^"]*cost-balanceDetails[^"]*"[^>]*>.*?<h1[^>]*>([^<]+)</h1>`)
	// New clientarea chart: var credit = '108.50元' // 余额
	balanceCreditRe = regexp.MustCompile(`(?i)var\s+credit\s*=\s*['"]([^'"]+)['"]`)
)

func extractToken(html string) (string, error) {
	if m := tokenRe.FindStringSubmatch(html); len(m) == 2 {
		return m[1], nil
	}
	if m := tokenRe2.FindStringSubmatch(html); len(m) == 2 {
		return m[1], nil
	}
	return "", fmt.Errorf("token not found")
}

func loginEncryptEnabled(html string) bool {
	return strings.Contains(html, `data-login-encrypt="1"`) ||
		strings.Contains(html, `data-login-encrypt='1'`)
}

// encryptLoginPassword matches themes/.../public.js encrypt():
// AES-CBC, key/iv Utf8 "idcsmart.finance" / "9311019310287172", PKCS7, Base64 ciphertext.
func encryptLoginPassword(plain string) (string, error) {
	key := []byte("idcsmart.finance")
	iv := []byte("9311019310287172")
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}
	src := pkcs7Pad([]byte(plain), block.BlockSize())
	dst := make([]byte, len(src))
	cipher.NewCBCEncrypter(block, iv).CryptBlocks(dst, src)
	return base64.StdEncoding.EncodeToString(dst), nil
}

func pkcs7Pad(b []byte, blockSize int) []byte {
	n := blockSize - len(b)%blockSize
	if n == 0 {
		n = blockSize
	}
	out := make([]byte, len(b)+n)
	copy(out, b)
	for i := len(b); i < len(out); i++ {
		out[i] = byte(n)
	}
	return out
}

func isLoginPage(html string) bool {
	return strings.Contains(html, "login?action=email") ||
		strings.Contains(html, "login?action=phone") ||
		strings.Contains(html, "邮箱登录") ||
		(strings.Contains(html, "手机号") && strings.Contains(html, `name="phone"`))
}

func parseBalance(html string) string {
	if m := balanceRe.FindStringSubmatch(html); len(m) == 2 {
		return strings.TrimSpace(m[1])
	}
	if m := balanceRe2.FindStringSubmatch(html); len(m) == 2 {
		return strings.TrimSpace(m[1])
	}
	if m := balanceCreditRe.FindStringSubmatch(html); len(m) == 2 {
		return strings.TrimSpace(m[1])
	}
	return ""
}

func parseServices(a Account, bal, html string) ([]Asset, error) {
	if m := serviceListRe.FindStringSubmatch(html); len(m) == 2 {
		var list []map[string]any
		if err := json.Unmarshal([]byte(m[1]), &list); err == nil {
			out := make([]Asset, 0, len(list))
			for _, item := range list {
				out = append(out, assetFromJSON(a, bal, item))
			}
			return out, nil
		}
	}
	return nil, fmt.Errorf("serviceList missing or invalid")
}

func assetFromJSON(a Account, bal string, item map[string]any) Asset {
	due := int64Any(item["nextduedate"])
	product := strings.TrimPrefix(strAny(item["productname"]), "ECS - ")
	status := strAny(item["domainstatus_desc"])
	if status == "" {
		status = strAny(item["domainstatus"])
	}
	days := 0
	expireAt := ""
	if due > 0 {
		t := time.Unix(due, 0)
		expireAt = t.Format("2006-01-02 15:04:05")
		days = daysUntilDate(t)
	}
	return Asset{
		AccountName: a.Name,
		LoginID:     a.LoginID(),
		Balance:     bal,
		Product:     product,
		Note:        strAny(item["notes"]),
		Status:      status,
		IP:          strAny(item["dedicatedip"]),
		ExpireAt:    expireAt,
		ExpireUnix:  due,
		DaysLeft:    days,
		Fee:         moneyNumber(strAny(item["price_desc"])),
		Cycle:       strAny(item["cycle_desc"]),
		OS:          stripSplit(strAny(item["os"])),
		Bandwidth:   strAny(item["bw"]),
		Region:      stripSplit(strAny(item["area"])),
	}
}

func daysUntilDate(t time.Time) int {
	today := time.Now().In(t.Location())
	ty, tm, td := today.Date()
	ey, em, ed := t.Date()
	a := time.Date(ty, tm, td, 0, 0, 0, 0, time.UTC)
	b := time.Date(ey, em, ed, 0, 0, 0, 0, time.UTC)
	return int(b.Sub(a).Hours() / 24)
}

func moneyNumber(v string) string {
	text := strings.Map(func(r rune) rune {
		switch r {
		case ',', '，', ' ', '\t', '−':
			if r == '−' {
				return '-'
			}
			return -1
		default:
			return r
		}
	}, v)
	re := regexp.MustCompile(`[-+]?\d+(?:\.\d+)?`)
	if m := re.FindString(text); m != "" {
		return m
	}
	return ""
}

func stripSplit(s string) string {
	if i := strings.Index(s, "^"); i >= 0 {
		return s[i+1:]
	}
	return s
}

func strAny(v any) string {
	if v == nil {
		return ""
	}
	switch x := v.(type) {
	case string:
		return x
	case float64:
		if x == float64(int64(x)) {
			return strconv.FormatInt(int64(x), 10)
		}
		return strconv.FormatFloat(x, 'f', -1, 64)
	case json.Number:
		return x.String()
	default:
		return fmt.Sprint(v)
	}
}

func int64Any(v any) int64 {
	switch x := v.(type) {
	case float64:
		return int64(x)
	case json.Number:
		n, _ := x.Int64()
		return n
	case string:
		n, _ := strconv.ParseInt(x, 10, 64)
		return n
	case int64:
		return x
	case int:
		return int64(x)
	default:
		return 0
	}
}

// NormIP trims and strips brackets/ports for matching.
func NormIP(s string) string {
	s = strings.TrimSpace(s)
	s = strings.TrimPrefix(s, "[")
	if i := strings.Index(s, "]"); i >= 0 {
		s = s[:i]
	}
	if i := strings.LastIndex(s, ":"); i > 0 && strings.Count(s, ":") == 1 {
		// host:port IPv4
		s = s[:i]
	}
	return s
}

func ParseMoney(s string) float64 {
	f, _ := strconv.ParseFloat(moneyNumber(s), 64)
	return f
}
