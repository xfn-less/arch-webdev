package lizhi

import "testing"

func TestEncryptLoginPasswordMatchesCryptoJS(t *testing.T) {
	// cryptography / CryptoJS AES-CBC PKCS7 Base64 for plaintext "testpass"
	const want = "vaFsJdnXGcLJEQzhQxxwBQ=="
	got, err := encryptLoginPassword("testpass")
	if err != nil {
		t.Fatal(err)
	}
	if got != want {
		t.Fatalf("got %q want %q", got, want)
	}
}

func TestLoginEncryptEnabled(t *testing.T) {
	if !loginEncryptEnabled(`<form data-login-encrypt="1" onsubmit="return passwordLoginSubmit`) {
		t.Fatal("expected encrypt enabled")
	}
	if loginEncryptEnabled(`<form method="post">`) {
		t.Fatal("expected encrypt disabled")
	}
}

func TestCaptchaSceneAndRequired(t *testing.T) {
	if captchaScene("phone") != "allow_login_phone_captcha" {
		t.Fatal("phone scene")
	}
	if captchaScene("email") != "allow_login_email_captcha" {
		t.Fatal("email scene")
	}
	if !loginCaptchaRequired(`<input name="captcha" />`) {
		t.Fatal("expected captcha required")
	}
	if loginCaptchaRequired(`<form method="post">`) {
		t.Fatal("expected captcha not required")
	}
}
