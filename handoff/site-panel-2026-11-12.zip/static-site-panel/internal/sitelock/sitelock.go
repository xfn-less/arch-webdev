package sitelock

import "sync"

var mu sync.Mutex
var locks = map[string]*sync.Mutex{}

// Acquire returns an unlock function for a site-scoped lock (deploy/ssl/remote delete).
func Acquire(name string) (unlock func()) {
	mu.Lock()
	m, ok := locks[name]
	if !ok {
		m = &sync.Mutex{}
		locks[name] = m
	}
	mu.Unlock()
	m.Lock()
	return m.Unlock
}
