package deploy

import (
	"strings"
	"testing"
)

func TestDefaultCatchAllSnippet(t *testing.T) {
	s := DefaultCatchAllSnippet()
	for _, want := range []string{
		"listen 80 default_server",
		"return 444",
		"ssl_reject_handshake on",
		"server_name _",
	} {
		if !strings.Contains(s, want) {
			t.Fatalf("snippet missing %q:\n%s", want, s)
		}
	}
}

func TestDefaultCatchAllInstallScript(t *testing.T) {
	script := defaultCatchAllInstallScript()
	for _, want := range []string{
		RemoteDefaultCatchAll,
		"00-ssp-default.conf",
		"sites-enabled/default",
		"ssp-default:",
		"reload_nginx",
	} {
		if !strings.Contains(script, want) {
			t.Fatalf("script missing %q", want)
		}
	}
	if strings.Contains(script, "exit 0") {
		t.Fatal("script must not exit 0 early (embedded in InstallNginx)")
	}
}
