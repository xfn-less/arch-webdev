package deploy

import (
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"github.com/xfn/static-site-panel/internal/store"
)

func TestSSHHandshakeDropRetriesAndSucceeds(t *testing.T) {
	calls := 0
	var logs []string
	err := retrySSHHandshake(context.Background(), func(line string) { logs = append(logs, line) }, func() error {
		calls++
		if calls == 1 {
			return errors.New("exit status 255: kex_exchange_identification: read: Connection reset by peer")
		}
		return nil
	})
	if err != nil || calls != 2 || len(logs) != 1 {
		t.Fatalf("err=%v calls=%d logs=%v", err, calls, logs)
	}
}

func TestDirectFallbackDropsJumpOnlyForConnectErrors(t *testing.T) {
	r, err := newSSHRunner(store.Server{Host: "10.1.1.1", AuthType: "key", ViaJump: true})
	if err != nil {
		t.Fatal(err)
	}
	alt := r.directFallback(nil, errors.New("channel 0: open failed: connect failed: Connection refused"))
	if alt == nil || alt.server.ViaJump {
		t.Fatal("expected direct runner")
	}
	if strings.Contains(strings.Join(alt.sshBase, " "), "ProxyCommand") {
		t.Fatal(alt.sshBase)
	}
	if r.directFallback(nil, errors.New("nginx -t failed")) != nil {
		t.Fatal("remote command errors must not fall back")
	}
	plain, err := newSSHRunner(store.Server{Host: "10.1.1.1", AuthType: "key"})
	if err != nil {
		t.Fatal(err)
	}
	if plain.directFallback(nil, errors.New("connection refused")) != nil {
		t.Fatal("direct sessions must not fall back again")
	}
}

func TestViaJumpRemoteShellRoundTrips(t *testing.T) {
	r, err := newSSHRunner(store.Server{
		Host: "10.0.0.8", Port: 22, User: "root", AuthType: "key", ViaJump: true,
	})
	if err != nil {
		t.Fatal(err)
	}
	shell := r.sshRemoteShell()
	if strings.Contains(shell, "ed25519'") || strings.Contains(shell, `\'`) {
		t.Fatalf("nested quotes: %s", shell)
	}
	cmd := exec.Command("bash", "-lc", "set -- "+shell+"; printf '%s\\n' \"$@\"")
	out, err := cmd.Output()
	if err != nil {
		t.Fatal(err, shell)
	}
	var proxy string
	for _, line := range strings.Split(string(out), "\n") {
		if strings.HasPrefix(line, "ProxyCommand=") {
			proxy = strings.TrimPrefix(line, "ProxyCommand=")
		}
	}
	if proxy == "" || strings.ContainsAny(proxy, "'\"") {
		t.Fatalf("proxy=%q shell=%s", proxy, shell)
	}
	if !strings.Contains(proxy, "-i /www/site-panel/.ssh/lizhi-socks_ed25519 ") {
		t.Fatal(proxy)
	}
	if !strings.Contains(proxy, " root@183.56.236.235") {
		t.Fatal(proxy)
	}
}

func TestSSHConnectionTimeoutRetriesAndSucceeds(t *testing.T) {
	calls := 0
	err := retrySSHHandshake(context.Background(), func(string) {}, func() error {
		calls++
		if calls < 3 {
			return errors.New("exit status 255: ssh: connect to host 180.97.215.102 port 22: Connection timed out")
		}
		return nil
	})
	if err != nil || calls != 3 {
		t.Fatalf("err=%v calls=%d", err, calls)
	}
}

func TestSSHHandshakeRetryDoesNotRepeatRemoteCommandErrors(t *testing.T) {
	calls := 0
	want := errors.New("exit status 1: nginx -t failed")
	err := retrySSHHandshake(context.Background(), nil, func() error {
		calls++
		return want
	})
	if !errors.Is(err, want) || calls != 1 {
		t.Fatalf("err=%v calls=%d", err, calls)
	}
}

func TestSSHHandshakeRetryStopsAfterAttempts(t *testing.T) {
	calls := 0
	want := fmt.Errorf("ssh_exchange_identification: Connection closed by remote host")
	err := retrySSHHandshake(context.Background(), nil, func() error {
		calls++
		return want
	})
	if !errors.Is(err, want) || calls != sshHandshakeAttempts {
		t.Fatalf("err=%v calls=%d", err, calls)
	}
}

func fakeSSH(t *testing.T, script string) string {
	t.Helper()
	bin := t.TempDir()
	if err := os.WriteFile(filepath.Join(bin, "ssh"), []byte("#!/bin/sh\n"+script), 0755); err != nil {
		t.Fatal(err)
	}
	t.Setenv("PATH", bin+string(os.PathListSeparator)+os.Getenv("PATH"))
	capture := filepath.Join(t.TempDir(), "capture")
	t.Setenv("SSP_TEST_CAPTURE", capture)
	return capture
}

func TestFailedBootstrapUploadPreservesMasterConf(t *testing.T) {
	capture := fakeSSH(t, "case \"$*\" in *'cat '*) printf master;; esac\n")
	bin := strings.Split(os.Getenv("PATH"), string(os.PathListSeparator))[0]
	// Simulate SSH transfer failure after reading the configuration being sent.
	script := `#!/bin/sh
for arg do
 if [ -f "$arg" ]; then cat "$arg" > "$SSP_TEST_CAPTURE"; exit 1; fi
done
exit 0
`
	if err := os.WriteFile(filepath.Join(bin, "rsync"), []byte(script), 0755); err != nil {
		t.Fatal(err)
	}
	root := t.TempDir()
	site := filepath.Join(root, "demo")
	if err := os.MkdirAll(filepath.Join(site, "www"), 0755); err != nil {
		t.Fatal(err)
	}
	conf := filepath.Join(site, "nginx.conf")
	if err := os.WriteFile(conf, []byte("master"), 0644); err != nil {
		t.Fatal(err)
	}
	bootstrap := "temporary HTTP config"
	_, err := Sync(context.Background(), Options{SitesRoot: root, SiteName: "demo", RemoteWWW: "/www/demo", RemoteConf: "/etc/nginx/conf.d/demo.conf", Server: store.Server{Host: "test.invalid", AuthType: "key"}, ConfBody: &bootstrap}, func(string) {})
	if err == nil {
		t.Fatal("transfer failure not reported")
	}
	sent, err := os.ReadFile(capture)
	if err != nil || string(sent) != bootstrap {
		t.Fatalf("sent=%q err=%v", sent, err)
	}
	master, err := os.ReadFile(conf)
	if err != nil || string(master) != "master" {
		t.Fatalf("master=%q err=%v", master, err)
	}
}

func TestApkObfuscateOffRemovesTimer(t *testing.T) {
	capture := fakeSSH(t, "printf '%s\\n' \"$@\" > \"$SSP_TEST_CAPTURE\"\n")
	err := SyncApkTimer(context.Background(), store.Server{Host: "test.invalid", AuthType: "key"}, t.TempDir(), "demo", false, func(string) {})
	if err != nil {
		t.Fatal(err)
	}
	command, err := os.ReadFile(capture)
	got := string(command)
	if err != nil || !strings.Contains(got, "rm -f '/etc/cron.d/ssp-apk-demo'") {
		t.Fatalf("command=%q err=%v", got, err)
	}
}

func TestEmbeddedApkProcessorPresent(t *testing.T) {
	if !strings.Contains(apkProcessorScript, "APK Processor") || len(apkProcessorScript) < 1000 {
		t.Fatal("embedded apk_processor.py missing or truncated")
	}
}

func TestIsApkFile(t *testing.T) {
	if !IsApkFile("app.apk") || IsApkFile("app-out.apk") || IsApkFile(".ssp-apk-xxxx.apk") {
		t.Fatal("IsApkFile mismatch")
	}
}
