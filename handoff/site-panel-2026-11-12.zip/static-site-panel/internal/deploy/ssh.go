package deploy

import (
	"context"
	"os/exec"

	"github.com/xfn/static-site-panel/internal/store"
)

// Runner runs remote commands / rsync over SSH (key or password).
// It shares handshake retry + password-assisted key repair with deploy Sync.
type Runner struct {
	inner  *sshRunner
	Target string
}

func NewRunner(s store.Server) (*Runner, error) {
	r, err := newSSHRunner(s)
	if err != nil {
		return nil, err
	}
	return &Runner{inner: r, Target: targetOf(s)}, nil
}

func (r *Runner) Run(ctx context.Context, log func(string), remoteCmd string) error {
	return r.inner.run(ctx, log, r.Target, remoteCmd)
}

func (r *Runner) Output(ctx context.Context, remoteCmd string) (string, error) {
	b, err := r.inner.remoteOutput(ctx, nil, r.Target, remoteCmd)
	if err != nil {
		return "", err
	}
	return string(b), nil
}

func (r *Runner) Rsync(ctx context.Context, log func(string), src, dst string, extra ...string) error {
	return r.inner.rsync(ctx, log, src, dst, extra...)
}

// LookPath helper for tests/docs.
func LookPath(bin string) error {
	_, err := exec.LookPath(bin)
	return err
}

func ShellQuote(s string) string { return shellQuote(s) }
