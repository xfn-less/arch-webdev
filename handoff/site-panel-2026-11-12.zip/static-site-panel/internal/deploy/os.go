package deploy

import (
	"context"
	"fmt"
	"strings"
)

// OSInfo is a minimal remote /etc/os-release snapshot.
type OSInfo struct {
	ID      string // debian, ubuntu, centos, rhel, …
	IDLike  string
	Version string
	Pretty  string
}

// Family returns debian | rhel | other.
func (o OSInfo) Family() string {
	id := strings.ToLower(o.ID)
	like := strings.ToLower(o.IDLike)
	switch id {
	case "debian", "ubuntu":
		return "debian"
	case "centos", "rhel", "rocky", "almalinux", "fedora", "amzn":
		return "rhel"
	}
	if strings.Contains(like, "debian") || strings.Contains(like, "ubuntu") {
		return "debian"
	}
	if strings.Contains(like, "rhel") || strings.Contains(like, "centos") || strings.Contains(like, "fedora") {
		return "rhel"
	}
	return "other"
}

// SupportsPanelInit is true only for Debian/Ubuntu — apt stack for nginx/fail2ban.
func (o OSInfo) SupportsPanelInit() bool {
	return o.Family() == "debian"
}

// CanPkgInstallCertbot is true when apt or yum/dnf can install certbot.
func (o OSInfo) CanPkgInstallCertbot() bool {
	f := o.Family()
	return f == "debian" || f == "rhel"
}

// ProbeOS reads remote os-release via an existing runner.
func ProbeOS(ctx context.Context, runner *Runner) (OSInfo, error) {
	out, err := runner.Output(ctx, "bash -lc "+ShellQuote(`
set -e
if [ ! -f /etc/os-release ]; then echo "missing=/etc/os-release"; exit 0; fi
. /etc/os-release
printf 'id=%s\n' "${ID:-}"
printf 'id_like=%s\n' "${ID_LIKE:-}"
printf 'version=%s\n' "${VERSION_ID:-}"
printf 'pretty=%s\n' "${PRETTY_NAME:-}"
`))
	if err != nil {
		return OSInfo{}, err
	}
	var info OSInfo
	for _, line := range strings.Split(out, "\n") {
		k, v, ok := strings.Cut(strings.TrimSpace(line), "=")
		if !ok {
			continue
		}
		switch k {
		case "id":
			info.ID = v
		case "id_like":
			info.IDLike = v
		case "version":
			info.Version = v
		case "pretty":
			info.Pretty = v
		case "missing":
			return OSInfo{}, fmt.Errorf("remote %s", v)
		}
	}
	if info.ID == "" && info.Pretty == "" {
		return OSInfo{}, fmt.Errorf("empty os-release")
	}
	return info, nil
}
