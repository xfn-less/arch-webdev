package deploy

import (
	"context"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"testing"
	"time"

	"github.com/xfn/static-site-panel/internal/store"
)

// Optional integration against an actual, unprivileged local Nginx. No live SSH.
func TestLocalNginxDeployFailureRetryDisable(t *testing.T) {
	nginx := os.Getenv("SSP_TEST_NGINX")
	if nginx == "" {
		t.Skip("set SSP_TEST_NGINX to a local nginx binary")
	}
	root := t.TempDir()
	remote := filepath.Join(root, "remote")
	bin := filepath.Join(root, "bin")
	confDir := filepath.Join(root, "conf")
	source := filepath.Join(root, "master", "audit-demo")
	for _, dir := range []string{remote, bin, confDir, filepath.Join(source, "www"), filepath.Join(root, "logs")} {
		if err := os.MkdirAll(dir, 0755); err != nil {
			t.Fatal(err)
		}
	}
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	port := listener.Addr().(*net.TCPAddr).Port
	listener.Close()
	mainConf := filepath.Join(root, "nginx.conf")
	os.WriteFile(mainConf, []byte(fmt.Sprintf("daemon off; pid %s; error_log stderr; events {} http { client_body_temp_path %s/body; proxy_temp_path %s/proxy; fastcgi_temp_path %s/fastcgi; uwsgi_temp_path %s/uwsgi; scgi_temp_path %s/scgi; access_log off; include %s/*.conf; }\n", filepath.Join(root, "nginx.pid"), root, root, root, root, root, confDir)), 0644)
	process := exec.Command(nginx, "-p", root+"/", "-c", mainConf)
	process.Stderr = os.Stderr
	if err := process.Start(); err != nil {
		t.Fatal(err)
	}
	defer func() { process.Process.Signal(syscall.SIGQUIT); process.Wait() }()
	for i := 0; i < 100; i++ {
		if _, err := os.Stat(filepath.Join(root, "nginx.pid")); err == nil {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Setenv("SSP_LOCAL_ROOT", root)
	t.Setenv("SSP_REAL_NGINX", nginx)
	// The transport executes only in t.TempDir and rewrites fixed product paths.
	ssh := `#!/bin/bash
set -eu
while [ "$#" -gt 0 ]; do
 case "$1" in root@fixture.invalid|fixture.invalid) shift; break;; esac
 shift
done
command="$*"
command=${command//\/run\/lock\/site-panel-nginx.lock/$SSP_LOCAL_ROOT/nginx.lock}
command=${command//\/etc\/cron.d\/ssp-apk-audit-demo/$SSP_LOCAL_ROOT/apk.cron}
command=${command//\/www\/sites\/audit-demo/$SSP_LOCAL_ROOT/remote}
command=${command//bash -lc/bash -c}
exec bash -c "$command"
`
	os.WriteFile(filepath.Join(bin, "ssh"), []byte(ssh), 0755)
	os.WriteFile(filepath.Join(bin, "nginx"), []byte("#!/bin/sh\nexec \"$SSP_REAL_NGINX\" -p \"$SSP_LOCAL_ROOT/\" -c \"$SSP_LOCAL_ROOT/nginx.conf\" \"$@\"\n"), 0755)
	os.WriteFile(filepath.Join(bin, "systemctl"), []byte("#!/bin/sh\nexit 1\n"), 0755)
	os.WriteFile(filepath.Join(bin, "service"), []byte("#!/bin/sh\nexit 1\n"), 0755)
	t.Setenv("PATH", bin+string(os.PathListSeparator)+os.Getenv("PATH"))
	localConf := filepath.Join(source, "nginx.conf")
	good := fmt.Sprintf("server { listen 127.0.0.1:%d; location / { return 200 'accepted'; } }\n", port)
	os.WriteFile(localConf, []byte(good), 0644)
	os.WriteFile(filepath.Join(source, "www", "index.html"), []byte("master"), 0644)
	opt := Options{SitesRoot: filepath.Dir(source), SiteName: "audit-demo", RemoteWWW: filepath.Join(remote, "www"), RemoteConf: filepath.Join(confDir, "audit-demo.conf"), Server: store.Server{User: "root", Host: "fixture.invalid", AuthType: "key"}}
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	log := func(line string) { t.Log(line) }
	if _, err := Sync(ctx, opt, log); err != nil {
		t.Fatal(err)
	}
	client := &http.Client{Timeout: time.Second}
	url := fmt.Sprintf("http://127.0.0.1:%d/", port)
	response, err := client.Get(url)
	if err != nil {
		t.Fatal(err)
	}
	response.Body.Close()
	if response.StatusCode != 200 {
		t.Fatal(response.Status)
	}
	same, err := Sync(ctx, opt, log)
	if err != nil || !same.SkippedConf {
		t.Fatalf("repeat: %+v %v", same, err)
	}
	// A cron-like lock holder must block receiver writes until it finishes.
	holder := exec.Command("flock", "-x", filepath.Join(remote, ".apk.lock"), "sh", "-c", "printf ready; cat >/dev/null")
	gate, _ := holder.StdinPipe()
	ready, _ := holder.StdoutPipe()
	if err := holder.Start(); err != nil {
		t.Fatal(err)
	}
	defer func() { gate.Close(); holder.Wait() }()
	if _, err := io.ReadFull(ready, make([]byte, 5)); err != nil {
		t.Fatal(err)
	}
	os.WriteFile(filepath.Join(source, "www", "index.html"), []byte("new-source"), 0644)
	finished := make(chan error, 1)
	go func() { _, err := Sync(ctx, opt, log); finished <- err }()
	select {
	case err := <-finished:
		t.Fatalf("receiver ignored processor lock: %v", err)
	case <-time.After(150 * time.Millisecond):
	}
	before, _ := os.ReadFile(filepath.Join(opt.RemoteWWW, "index.html"))
	if string(before) != "master" {
		t.Fatal("upload raced processor")
	}
	gate.Close()
	select {
	case err := <-finished:
		if err != nil {
			t.Fatal(err)
		}
	case <-ctx.Done():
		t.Fatal("receiver never resumed")
	}
	published, _ := os.ReadFile(filepath.Join(opt.RemoteWWW, "index.html"))
	if string(published) != "new-source" {
		t.Fatal("source update missing")
	}
	os.WriteFile(localConf, []byte("server { invalid_directive; }\n"), 0644)
	if _, err := Sync(ctx, opt, log); err == nil {
		t.Fatal("invalid nginx config accepted")
	}
	retained, _ := os.ReadFile(opt.RemoteConf)
	if string(retained) != good {
		t.Fatal("last valid config lost")
	}
	original, _ := os.ReadFile(localConf)
	if !strings.Contains(string(original), "invalid_directive") {
		t.Fatal("failed deploy changed master")
	}
	os.WriteFile(localConf, []byte(good), 0644)
	if _, err := Sync(ctx, opt, log); err != nil {
		t.Fatal(err)
	}
	if err := DisableSite(ctx, opt, log); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(opt.RemoteConf); !os.IsNotExist(err) {
		t.Fatal("disabled config still present")
	}
	if data, err := os.ReadFile(filepath.Join(opt.RemoteWWW, "index.html")); err != nil || string(data) != "new-source" {
		t.Fatal("disable lost files", err)
	}
	if _, err := Sync(ctx, opt, log); err != nil {
		t.Fatal("enable retry", err)
	}
}
