#!/bin/bash
# One executor for deployment and the fixed 30-minute task.
# In-place: processor writes a temp file, then replaces the same *.apk name.
set -euo pipefail
www=$1
mode=$2
shift 2
cd "$www"
exec 9>../.apk.lock
flock -x 9
processor=../apk_processor.py
test -f "$processor"

if [ "$#" -eq 0 ]; then
  shopt -s nullglob
  set -- *.apk
fi

tmp=
trap 'test -z "$tmp" || rm -f -- "$tmp"' EXIT
for source in "$@"; do
  case "$source" in
    *-out.apk) continue;;          # leftover from old -out workflow
    .ssp-apk-*.apk) continue;;
  esac
  [[ "$source" =~ ^[a-zA-Z0-9][a-zA-Z0-9._+-]*\.apk$ ]] || { echo "Invalid APK: $source" >&2; exit 1; }
  test -f "$source"
  # mode kept for call-site compatibility; always re-run so packages keep updating.
  :
  tmp=$(mktemp "./.ssp-apk-XXXXXX.apk")
  /usr/bin/python3 "$processor" "$source" -o "$tmp"
  test -s "$tmp" || { echo "Empty APK output: $source" >&2; exit 1; }
  chmod 644 "$tmp"
  mv -f -- "$tmp" "$source"
  tmp=
  echo "apk ready: $source"
done
