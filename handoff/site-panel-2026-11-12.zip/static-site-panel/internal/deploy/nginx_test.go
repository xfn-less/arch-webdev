package deploy

import (
	"strings"
	"testing"
)

func TestNginxInstallScriptHardening(t *testing.T) {
	script := nginxInstallScript()
	for _, need := range []string{
		"fail2ban",
		"01-site-panel-harden.conf",
		"MaxAuthTries 4",
		"MaxStartups 10:30:60",
		"[sshd]",
		"backend = systemd",
		"python3-systemd",
	} {
		if !strings.Contains(script, need) {
			t.Fatalf("script missing %q", need)
		}
	}
	if strings.Contains(script, "ufw") {
		t.Fatal("init must not manage ufw; ports are opened ad-hoc")
	}
	if strings.Contains(script, "PasswordAuthentication no") {
		t.Fatal("init must keep password auth available for panel key re-install")
	}
}

func TestDisableSiteScriptKeepsWWW(t *testing.T) {
	script := disableSiteScript(Options{
		SiteName:   "s1",
		RemoteConf: "/etc/nginx/conf.d/s1.conf",
		RemoteWWW:  "/www/sites/s1/www",
	})
	for _, need := range []string{
		"/etc/nginx/conf.d/s1.conf",
		"rm -f",
		"nginx -t",
		RemoteApkTimerPath("s1"),
	} {
		if !strings.Contains(script, need) {
			t.Fatalf("disable script missing %q", need)
		}
	}
	for _, bad := range []string{"rm -rf", "/www/sites/s1/www"} {
		if strings.Contains(script, bad) {
			t.Fatalf("disable must not touch www: found %q", bad)
		}
	}
}
