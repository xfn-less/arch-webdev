package deploy

import (
	"strings"
	"testing"
)

func TestOSInfoFamilyAndCapabilities(t *testing.T) {
	cases := []struct {
		id, like      string
		family        string
		init, certPkg bool
	}{
		{"debian", "debian", "debian", true, true},
		{"ubuntu", "debian", "debian", true, true},
		{"centos", "rhel fedora", "rhel", false, true},
		{"rocky", "rhel centos fedora", "rhel", false, true},
		{"arch", "", "other", false, false},
	}
	for _, tc := range cases {
		o := OSInfo{ID: tc.id, IDLike: tc.like}
		if o.Family() != tc.family {
			t.Fatalf("%s family=%s want %s", tc.id, o.Family(), tc.family)
		}
		if o.SupportsPanelInit() != tc.init {
			t.Fatalf("%s init=%v want %v", tc.id, o.SupportsPanelInit(), tc.init)
		}
		if o.CanPkgInstallCertbot() != tc.certPkg {
			t.Fatalf("%s certPkg=%v want %v", tc.id, o.CanPkgInstallCertbot(), tc.certPkg)
		}
	}
}

func TestNginxInstallScriptRefusesNonDebian(t *testing.T) {
	script := nginxInstallScript()
	if !strings.Contains(script, "debian|ubuntu") || !strings.Contains(script, "初始化仅支持 Debian/Ubuntu") {
		t.Fatal("install script must refuse non-Debian with clear message")
	}
}
