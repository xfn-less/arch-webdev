package deploy

import (
	"context"
	"github.com/xfn/static-site-panel/internal/store"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestManualCertificateReinstallReloadsIdenticalConf(t *testing.T) {
	capture := fakeSSH(t, "printf '%s\\n' \"$*\" >> \"$SSP_TEST_CAPTURE\"\ncase \"$*\" in *'cat '*) printf '%s' \"$SSP_TEST_CONF\";; esac\n")
	bin := strings.Split(os.Getenv("PATH"), string(os.PathListSeparator))[0]
	os.WriteFile(filepath.Join(bin, "rsync"), []byte("#!/bin/sh\nexit 0\n"), 0755)
	root := t.TempDir()
	site := filepath.Join(root, "demo")
	os.MkdirAll(filepath.Join(site, "www"), 0755)
	os.MkdirAll(filepath.Join(site, "ssl"), 0700)
	conf := "ssl_certificate /etc/nginx/ssl/demo/fullchain.pem;\n"
	os.WriteFile(filepath.Join(site, "nginx.conf"), []byte(conf), 0644)
	for _, file := range []string{".manual", "fullchain.pem", "privkey.pem"} {
		os.WriteFile(filepath.Join(site, "ssl", file), []byte("synthetic certificate fixture"), 0600)
	}
	t.Setenv("SSP_TEST_CONF", conf)
	res, err := SyncConf(context.Background(), Options{SitesRoot: root, SiteName: "demo", RemoteWWW: "/www/sites/demo/www", RemoteConf: "/etc/nginx/conf.d/demo.conf", Server: store.Server{Host: "dummy.invalid", AuthType: "key"}}, func(string) {})
	if err != nil {
		t.Fatal(err)
	}
	calls, _ := os.ReadFile(capture)
	if !res.Reloaded || !strings.Contains(string(calls), "nginx -t") {
		t.Fatal("certificate replaced on disk but nginx still serves old certificate")
	}
}
