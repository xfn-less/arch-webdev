package deploy

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"github.com/xfn/static-site-panel/internal/store"
)

func TestAPKRunnerInPlaceRetry(t *testing.T) {
	root := t.TempDir()
	www := filepath.Join(root, "www")
	if err := os.Mkdir(www, 0755); err != nil {
		t.Fatal(err)
	}
	runner := filepath.Join(root, apkRunnerName)
	if err := os.WriteFile(runner, []byte(apkRunnerScript), 0755); err != nil {
		t.Fatal(err)
	}
	// A harmless stand-in verifies orchestration, never the real APK transformation.
	processor := `import pathlib, sys
source = pathlib.Path(sys.argv[1]).read_bytes()
target = pathlib.Path(sys.argv[3])
with pathlib.Path('../calls').open('a') as calls: calls.write('run\n')
if source == b'fail':
 target.write_bytes(b'partial')
 raise SystemExit(1)
target.write_bytes(b'' if source == b'empty' else b'ready:' + source)
`
	if err := os.WriteFile(filepath.Join(root, ApkProcessorName), []byte(processor), 0644); err != nil {
		t.Fatal(err)
	}
	apk := filepath.Join(www, "app.apk")
	run := func(wantOK bool) {
		t.Helper()
		out, err := exec.Command("bash", runner, www, "force", "app.apk").CombinedOutput()
		if (err == nil) != wantOK {
			t.Fatalf("err=%v log=%s", err, out)
		}
	}
	os.WriteFile(apk, []byte("first"), 0644)
	run(true)
	got, _ := os.ReadFile(apk)
	if string(got) != "ready:first" {
		t.Fatalf("in-place publish failed: %q", got)
	}
	run(true) // force always re-runs so packages keep updating
	calls, _ := os.ReadFile(filepath.Join(root, "calls"))
	if strings.Count(string(calls), "run") != 2 {
		t.Fatal("force did not re-process")
	}
	got, _ = os.ReadFile(apk)
	if string(got) != "ready:ready:first" {
		t.Fatalf("re-process should mutate in place: %q", got)
	}
	// Failure must not mv partial over the public name.
	os.WriteFile(apk, []byte("keep-me"), 0644)
	run(true) // → ready:keep-me
	os.WriteFile(apk, []byte("fail"), 0644)
	run(false)
	afterFail, _ := os.ReadFile(apk)
	if string(afterFail) != "fail" {
		t.Fatalf("failed run should leave pre-mv bytes: %q", afterFail)
	}
	partials, _ := filepath.Glob(filepath.Join(www, ".ssp-apk-*"))
	if len(partials) != 0 {
		t.Fatal("temporary outputs left behind", partials)
	}
	// Prove partial never replaced a good product: poison after successful product via
	// processor that fails before writing when reading the current product is awkward
	// in-place; instead ensure empty output also leaves file untouched.
	os.WriteFile(apk, []byte("empty"), 0644)
	run(false)
	emptyLeft, _ := os.ReadFile(apk)
	if string(emptyLeft) != "empty" {
		t.Fatalf("empty output mutated file: %q", emptyLeft)
	}
	os.WriteFile(apk, []byte("retry"), 0644)
	run(true)
	restored, _ := os.ReadFile(apk)
	if string(restored) != "ready:retry" {
		t.Fatal("retry did not publish new output")
	}
}

func TestAPKTimerHasNoCronPercentExpansion(t *testing.T) {
	body := apkTimerBody("demo")
	if strings.Contains(body, "%") {
		t.Fatal("cron would interpret unescaped percent as newline")
	}
	if _, err := exec.Command("bash", "-n", "-c", apkRunnerScript).CombinedOutput(); err != nil {
		t.Fatal(err)
	}
}

func TestSSLConfigDoesNotDeployFilesOrRunAPK(t *testing.T) {
	capture := fakeSSH(t, "printf '%s\\n' \"$*\" >> \"$SSP_TEST_CAPTURE\"\ncase \"$*\" in *'cat '*) printf master;; esac\n")
	root := t.TempDir()
	www := filepath.Join(root, "demo", "www")
	os.MkdirAll(www, 0755)
	os.WriteFile(filepath.Join(root, "demo", "nginx.conf"), []byte("master"), 0644)
	os.WriteFile(filepath.Join(www, ApkProcessorName), []byte("must not execute"), 0644)
	_, err := SyncConf(context.Background(), Options{SitesRoot: root, SiteName: "demo", RemoteWWW: "/www/demo", RemoteConf: "/etc/nginx/conf.d/demo.conf", Server: store.Server{Host: "dummy.invalid", AuthType: "key"}, ApkObfuscate: true}, func(string) {})
	if err != nil {
		t.Fatal(err)
	}
	raw, _ := os.ReadFile(capture)
	if strings.Contains(string(raw), apkRunnerName) || strings.Contains(string(raw), "ssp-apk") {
		t.Fatal("SSL invoked APK setup/processing")
	}
}
