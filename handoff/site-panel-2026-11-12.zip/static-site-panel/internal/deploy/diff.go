package deploy

import (
	"bytes"
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

type TextDiff struct {
	Same          bool   `json:"same"`
	MissingLocal  bool   `json:"missingLocal,omitempty"`
	MissingRemote bool   `json:"missingRemote,omitempty"`
	Diff          string `json:"diff,omitempty"`
}

type DiffResult struct {
	Conf    TextDiff `json:"conf"`
	WWW     []string `json:"www"` // rsync -ni itemize lines
	Changed bool     `json:"changed"`
}

func Diff(ctx context.Context, opt Options) (DiffResult, error) {
	var out DiffResult
	localConf := filepath.Join(opt.SitesRoot, opt.SiteName, "nginx.conf")
	localWWW := filepath.Join(opt.SitesRoot, opt.SiteName, "www") + string(os.PathSeparator)

	sshRunner, err := newSSHRunner(opt.Server)
	if err != nil {
		return out, err
	}
	target := targetOf(opt.Server)

	confLocal, err := os.ReadFile(localConf)
	if err != nil {
		return out, fmt.Errorf("local conf: %w", err)
	}
	confRemote, confErr := sshRunner.remoteCat(ctx, nil, target, opt.RemoteConf)
	out.Conf = textDiff(confLocal, confRemote, confErr != nil, "nginx.conf", "remote:"+opt.RemoteConf)

	wwwLines, err := sshRunner.rsyncDryRun(ctx, localWWW, target+":"+ensureSlash(opt.RemoteWWW))
	if err != nil {
		return out, fmt.Errorf("www dry-run: %w", err)
	}
	out.WWW = wwwLines

	out.Changed = !out.Conf.Same || len(out.WWW) > 0
	return out, nil
}

func textDiff(local, remote []byte, missingRemote bool, localName, remoteName string) TextDiff {
	if missingRemote {
		d := TextDiff{MissingRemote: true, Same: false}
		if len(bytes.TrimSpace(local)) == 0 {
			d.Same = true
			return d
		}
		d.Diff = unifiedDiff(local, nil, localName, remoteName)
		return d
	}
	if bytes.Equal(bytes.TrimSpace(local), bytes.TrimSpace(remote)) {
		return TextDiff{Same: true}
	}
	return TextDiff{Same: false, Diff: unifiedDiff(local, remote, localName, remoteName)}
}

func unifiedDiff(a, b []byte, aname, bname string) string {
	dir, err := os.MkdirTemp("", "ssp-diff-*")
	if err != nil {
		return fmt.Sprintf("changed (%d → %d bytes)\n", len(a), len(b))
	}
	defer os.RemoveAll(dir)
	pa := filepath.Join(dir, "a")
	pb := filepath.Join(dir, "b")
	_ = os.WriteFile(pa, a, 0o644)
	_ = os.WriteFile(pb, b, 0o644)
	cmd := exec.Command("diff", "-u", "--label", aname, "--label", bname, pa, pb)
	var buf bytes.Buffer
	cmd.Stdout = &buf
	cmd.Stderr = &buf
	_ = cmd.Run() // exit 1 = differ
	out := buf.String()
	if out == "" {
		return fmt.Sprintf("changed (%d → %d bytes)\n", len(a), len(b))
	}
	const max = 12000
	if len(out) > max {
		return out[:max] + "\n…(truncated)\n"
	}
	return out
}

func (r *sshRunner) rsyncDryRun(ctx context.Context, src, dst string) ([]string, error) {
	sshE := r.sshRemoteShell()
	argv := []string{"rsync", "-e", sshE, "-ani", "--delete"}
	argv = append(argv, RsyncApkExcludes()...)
	argv = append(argv, src, dst)
	var stdout, stderr bytes.Buffer
	operation := func() error {
		stdout.Reset()
		stderr.Reset()
		cmd := exec.CommandContext(ctx, argv[0], argv[1:]...)
		if len(r.env) > 0 {
			cmd.Env = r.env
		}
		cmd.Stdout = &stdout
		cmd.Stderr = &stderr
		if err := cmd.Run(); err != nil {
			return fmt.Errorf("%w: %s", err, strings.TrimSpace(stderr.String()))
		}
		return nil
	}
	if err := retrySSHHandshake(ctx, nil, operation); err != nil {
		if alt := r.directFallback(nil, err); alt != nil {
			return alt.rsyncDryRun(ctx, src, dst)
		}
		return nil, err
	}
	var lines []string
	for _, line := range strings.Split(stdout.String(), "\n") {
		line = strings.TrimRight(line, "\r")
		if line == "" {
			continue
		}
		lines = append(lines, line)
	}
	return lines, nil
}
