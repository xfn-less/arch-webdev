package deploy

import (
	"context"
	"encoding/base64"
	"fmt"
	"strings"
)

// writeRemoteFile writes in the destination directory and replaces only after completion.
func writeRemoteFile(ctx context.Context, runner *Runner, path, body string, mode int, log func(string)) error {
	payload := base64.StdEncoding.EncodeToString([]byte(body))
	script := fmt.Sprintf(`set -euo pipefail
tmp=$(mktemp %s)
trap 'rm -f "$tmp"' EXIT
printf '%%s' %s | base64 -d > "$tmp"
chmod %o "$tmp"
mv -f "$tmp" %s
`, shellQuote(path+".tmp-XXXXXX"), shellQuote(payload), mode, shellQuote(path))
	log("write remote → " + path)
	return runner.Run(ctx, func(line string) {
		if !strings.HasPrefix(line, "$ ") {
			log(line)
		}
	}, "bash -lc "+shellQuote(script))
}
