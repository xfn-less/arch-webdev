package deploy

import (
	"context"
	"fmt"
	"strings"
	"time"
)

const sshHandshakeAttempts = 4

var sshHandshakeBackoff = [...]time.Duration{
	1 * time.Second,
	3 * time.Second,
	6 * time.Second,
}

// retrySSHHandshake retries transient pre-auth SSH/rsync failures (KEX drops,
// TCP timeouts to flaky NAT hosts). It does not retry remote command errors.
func retrySSHHandshake(ctx context.Context, log func(string), operation func() error) error {
	var err error
	for attempt := 1; attempt <= sshHandshakeAttempts; attempt++ {
		err = operation()
		if err == nil || !isSSHTransient(err) || attempt == sshHandshakeAttempts {
			return err
		}
		delay := sshHandshakeBackoff[attempt-1]
		if log != nil {
			log(fmt.Sprintf("SSH 暂时连不上，%.0f 秒后重试（%d/%d）", delay.Seconds(), attempt+1, sshHandshakeAttempts))
		}
		timer := time.NewTimer(delay)
		select {
		case <-ctx.Done():
			timer.Stop()
			return fmt.Errorf("SSH 重试已取消: %w", ctx.Err())
		case <-timer.C:
		}
	}
	return err
}

func isSSHTransient(err error) bool {
	if err == nil {
		return false
	}
	msg := strings.ToLower(err.Error())
	if strings.Contains(msg, "permission denied") ||
		strings.Contains(msg, "unable to authenticate") ||
		strings.Contains(msg, "nginx -t") {
		return false
	}
	return strings.Contains(msg, "kex_exchange_identification") ||
		strings.Contains(msg, "ssh_exchange_identification") ||
		strings.Contains(msg, "banner exchange") ||
		strings.Contains(msg, "connection timed out") ||
		(strings.Contains(msg, "connect to host") && strings.Contains(msg, "timed out")) ||
		strings.Contains(msg, "connection reset by peer") ||
		strings.Contains(msg, "connection refused") ||
		strings.Contains(msg, "no route to host") ||
		strings.Contains(msg, "network is unreachable") ||
		strings.Contains(msg, "temporary failure") ||
		strings.Contains(msg, "broken pipe") ||
		strings.Contains(msg, "connection closed by remote host")
}

// Deprecated name kept for older call sites/tests in the same package.
func isSSHHandshakeDrop(err error) bool { return isSSHTransient(err) }
