"""
APK Processor - APK自动化免杀处理工具 (跨平台版, macOS/Linux/Windows)
功能：DEX拆分重组、垃圾文件注入、ZIP路径欺骗、重签名(V1+V2+V3)
依赖：pip3 install cryptography
无需 Java / apt-get / apksigner / zipalign 等系统工具

核心设计：全内存操作，不解压到文件系统，避免macOS大小写不敏感文件系统的冲突
"""

import argparse
import base64
import binascii
import datetime
import hashlib
import io
import math
import os
import random
import re
import string
import struct
import sys
import tempfile
import zipfile
import zlib
from collections import OrderedDict


# ============================================================
# 工具函数
# ============================================================

def random_string(length, charset=None):
    """生成随机字符串"""
    if charset is None:
        charset = string.ascii_letters + string.digits
    return ''.join(random.choice(charset) for _ in range(length))


def log(msg, level="INFO"):
    """日志输出"""
    colors = {
        "INFO": "\033[36m",
        "OK": "\033[32m",
        "WARN": "\033[33m",
        "ERROR": "\033[31m",
    }
    reset = "\033[0m"
    color = colors.get(level, "")
    print(f"{color}[{level}]{reset} {msg}")


# ============================================================
# 模块1：DEX 拆分重组
# ============================================================

class DexSplitter:
    """DEX文件拆分重组，改变哈希特征"""

    @staticmethod
    def _encode_uleb128(value):
        """编码ULEB128"""
        result = bytearray()
        while True:
            byte = value & 0x7f
            value >>= 7
            if value != 0:
                byte |= 0x80
            result.append(byte)
            if value == 0:
                break
        return bytes(result)

    @staticmethod
    def fix_dex_checksum_and_signature(data: bytearray) -> bytearray:
        """修复DEX文件的SHA1签名和Adler32校验和"""
        sha1 = hashlib.sha1(data[32:]).digest()
        data[12:32] = sha1
        checksum = zlib.adler32(bytes(data[12:])) & 0xFFFFFFFF
        struct.pack_into('<I', data, 8, checksum)
        return data

    @staticmethod
    def generate_valid_dex(num_classes=None, package_prefix=None) -> bytes:
        """生成一个包含指定数量空类的合法DEX文件"""
        if num_classes is None:
            num_classes = random.randint(200, 600)
        if package_prefix is None:
            pkg_parts = [random_string(random.randint(3, 6), string.ascii_lowercase) for _ in range(3)]
            package_prefix = '/'.join(['com'] + pkg_parts)

        class_names = []
        for i in range(num_classes):
            cls_name = f"L{package_prefix}/C{i:04d};"
            class_names.append(cls_name)

        object_type = "Ljava/lang/Object;"
        all_strings = sorted(set(class_names + [object_type]))
        string_to_idx = {s: i for i, s in enumerate(all_strings)}

        num_strings = len(all_strings)
        num_types = len(all_strings)

        header_size = 0x70
        string_ids_off = header_size
        string_ids_size_bytes = num_strings * 4
        type_ids_off = string_ids_off + string_ids_size_bytes
        type_ids_size_bytes = num_types * 4
        class_defs_off = type_ids_off + type_ids_size_bytes
        class_defs_size_bytes = num_classes * 32
        data_off = (class_defs_off + class_defs_size_bytes + 3) & ~3

        string_data_items = []
        current_data_offset = data_off
        for s in all_strings:
            encoded = s.encode('utf-8')
            size_bytes = DexSplitter._encode_uleb128(len(s))
            item = size_bytes + encoded + b'\x00'
            string_data_items.append((current_data_offset, item))
            current_data_offset += len(item)

        map_list_off = (current_data_offset + 3) & ~3
        map_entries = [
            (0x0000, 1, 0),
            (0x0001, num_strings, string_ids_off),
            (0x0002, num_types, type_ids_off),
            (0x0006, num_classes, class_defs_off),
            (0x2002, num_strings, data_off),
            (0x1000, 1, map_list_off),
        ]
        map_list_size = 4 + len(map_entries) * 12
        file_size = map_list_off + map_list_size
        data_size = file_size - data_off

        buf = bytearray(file_size)
        buf[0:8] = b'dex\n035\x00'
        struct.pack_into('<I', buf, 32, file_size)
        struct.pack_into('<I', buf, 36, header_size)
        struct.pack_into('<I', buf, 40, 0x12345678)
        struct.pack_into('<I', buf, 44, 0)
        struct.pack_into('<I', buf, 48, 0)
        struct.pack_into('<I', buf, 52, map_list_off)
        struct.pack_into('<I', buf, 56, num_strings)
        struct.pack_into('<I', buf, 60, string_ids_off)
        struct.pack_into('<I', buf, 64, num_types)
        struct.pack_into('<I', buf, 68, type_ids_off)
        struct.pack_into('<I', buf, 72, 0)
        struct.pack_into('<I', buf, 76, 0)
        struct.pack_into('<I', buf, 80, 0)
        struct.pack_into('<I', buf, 84, 0)
        struct.pack_into('<I', buf, 88, 0)
        struct.pack_into('<I', buf, 92, 0)
        struct.pack_into('<I', buf, 96, num_classes)
        struct.pack_into('<I', buf, 100, class_defs_off)
        struct.pack_into('<I', buf, 104, data_size)
        struct.pack_into('<I', buf, 108, data_off)

        for i, (offset, item) in enumerate(string_data_items):
            struct.pack_into('<I', buf, string_ids_off + i * 4, offset)

        for i in range(num_types):
            struct.pack_into('<I', buf, type_ids_off + i * 4, i)

        object_type_idx = string_to_idx[object_type]
        for i in range(num_classes):
            cls_type_idx = string_to_idx[class_names[i]]
            off = class_defs_off + i * 32
            struct.pack_into('<I', buf, off + 0, cls_type_idx)
            struct.pack_into('<I', buf, off + 4, 0x00000001)
            struct.pack_into('<I', buf, off + 8, object_type_idx)
            struct.pack_into('<I', buf, off + 12, 0)
            struct.pack_into('<I', buf, off + 16, 0xFFFFFFFF)
            struct.pack_into('<I', buf, off + 20, 0)
            struct.pack_into('<I', buf, off + 24, 0)
            struct.pack_into('<I', buf, off + 28, 0)

        for offset, item in string_data_items:
            buf[offset:offset + len(item)] = item

        struct.pack_into('<I', buf, map_list_off, len(map_entries))
        for i, (type_code, size, offset) in enumerate(map_entries):
            entry_off = map_list_off + 4 + i * 12
            struct.pack_into('<H', buf, entry_off + 0, type_code)
            struct.pack_into('<H', buf, entry_off + 2, 0)
            struct.pack_into('<I', buf, entry_off + 4, size)
            struct.pack_into('<I', buf, entry_off + 8, offset)

        buf = DexSplitter.fix_dex_checksum_and_signature(buf)
        return bytes(buf)

    @staticmethod
    def mutate_dex(dex_data: bytes) -> bytes:
        """
        DEX安全检查版：
        - 不修改DEX内容
        - 只检查DEX头部结构
        - 遇到异常DEX直接跳过，避免 struct.pack_into 越界
        """
        data = bytearray(dex_data)
        data_len = len(data)

        if data_len < 0x70:
            log(f"  跳过DEX：文件太小，仅 {data_len} bytes", "WARN")
            return dex_data

        magic = bytes(data[0:8])
        if not magic.startswith(b'dex\n'):
            log(f"  跳过DEX：非标准DEX magic={magic!r}", "WARN")
            return dex_data

        try:
            file_size = struct.unpack('<I', data[32:36])[0]
            header_size = struct.unpack('<I', data[36:40])[0]
            endian_tag = struct.unpack('<I', data[40:44])[0]
            class_defs_size = struct.unpack('<I', data[96:100])[0]
            class_defs_off = struct.unpack('<I', data[100:104])[0]
        except Exception as e:
            log(f"  跳过DEX：读取DEX头部失败 {e}", "WARN")
            return dex_data

        if header_size != 0x70:
            log(f"  跳过DEX：header_size异常 header_size={header_size}", "WARN")
            return dex_data

        if endian_tag != 0x12345678:
            log(f"  跳过DEX：endian_tag异常 endian_tag=0x{endian_tag:08x}", "WARN")
            return dex_data

        if file_size <= 0 or file_size > data_len:
            log(f"  跳过DEX：file_size异常 file_size={file_size}, actual={data_len}", "WARN")
            return dex_data

        if class_defs_size > 0:
            if class_defs_off <= 0:
                log(f"  跳过DEX：class_defs_off异常 class_defs_off={class_defs_off}", "WARN")
                return dex_data

            class_defs_end = class_defs_off + class_defs_size * 32

            if class_defs_off >= data_len or class_defs_end > data_len:
                log(
                    f"  跳过DEX：class_defs区域越界 "
                    f"class_defs_off={class_defs_off}, "
                    f"class_defs_size={class_defs_size}, "
                    f"class_defs_end={class_defs_end}, "
                    f"actual={data_len}",
                    "WARN"
                )
                return dex_data

        log(
            f"  DEX检查通过：file_size={file_size}, "
            f"class_defs_size={class_defs_size}, "
            f"class_defs_off={class_defs_off}"
        )

        return dex_data

# ============================================================
# 模块2：签名 (纯Python实现V1+V2+V3)
# ============================================================

class PythonApkSigner:
    """纯Python实现的APK签名工具"""

    SIGNATURE_ALGORITHM_RSA_PKCS1_V1_5_WITH_SHA256 = 0x0103

    @staticmethod
    def _ensure_cryptography():
        try:
            from cryptography.hazmat.primitives.asymmetric import rsa
            return True
        except ImportError:
            log("缺少 cryptography 库，请运行: pip3 install cryptography", "ERROR")
            return False

    @staticmethod
    def generate_key_and_cert():
        """生成RSA密钥对和自签名X.509证书"""
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.primitives import hashes
        from cryptography import x509
        from cryptography.x509.oid import NameOID

        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )

        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, "Unknown"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Unknown"),
            x509.NameAttribute(NameOID.ORGANIZATIONAL_UNIT_NAME, "Unknown"),
            x509.NameAttribute(NameOID.LOCALITY_NAME, "Unknown"),
            x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, "Unknown"),
            x509.NameAttribute(NameOID.COUNTRY_NAME, "CN"),
        ])

        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(private_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(datetime.datetime.utcnow())
            .not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=10000))
            .sign(private_key, hashes.SHA256())
        )

        return private_key, cert

    @staticmethod
    def _create_pkcs7_signature(data: bytes, private_key, cert) -> bytes:
        """创建PKCS#7格式的签名"""
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding as asym_padding

        try:
            from cryptography.hazmat.primitives.serialization import pkcs7
            options = [pkcs7.PKCS7Options.Binary]
            pkcs7_data = (
                pkcs7.PKCS7SignatureBuilder()
                .set_data(data)
                .add_signer(cert, private_key, hashes.SHA256())
                .sign(serialization.Encoding.DER, options)
            )
            return pkcs7_data
        except Exception:
            signature = private_key.sign(
                data,
                asym_padding.PKCS1v15(),
                hashes.SHA256(),
            )
            cert_der = cert.public_bytes(serialization.Encoding.DER)
            return cert_der + signature

    @staticmethod
    def _find_eocd(data: bytearray) -> int:
        """查找End of Central Directory记录"""
        eocd_sig = b'\x50\x4b\x05\x06'
        search_start = max(0, len(data) - 65557)
        for i in range(len(data) - 22, search_start - 1, -1):
            if data[i:i+4] == eocd_sig:
                return i
        return None

    @staticmethod
    def _compute_content_digests(zip_entries, central_dir, eocd, original_cd_offset):
        """
        计算V2/V3签名所需的内容摘要。
        按照Android官方算法：将APK分为3个section，每个section按1MB分块，
        每块加前缀0xa5+长度做SHA256，最后拼接所有块摘要加前缀0x5a+块数做SHA256。
        """
        CHUNK_SIZE = 1024 * 1024

        # EOCD中的CD offset需要指向signing block之前的位置
        modified_eocd = bytearray(eocd)
        struct.pack_into('<I', modified_eocd, 16, len(zip_entries))

        sections = [zip_entries, central_dir, bytes(modified_eocd)]

        total_chunks = 0
        for section in sections:
            if len(section) == 0:
                total_chunks += 1
            else:
                total_chunks += (len(section) + CHUNK_SIZE - 1) // CHUNK_SIZE

        all_chunk_digests = b''
        for section in sections:
            if len(section) == 0:
                chunk_header = struct.pack('<BI', 0xa5, 0)
                all_chunk_digests += hashlib.sha256(chunk_header).digest()
            else:
                offset = 0
                while offset < len(section):
                    chunk = section[offset:offset + CHUNK_SIZE]
                    chunk_header = struct.pack('<BI', 0xa5, len(chunk))
                    all_chunk_digests += hashlib.sha256(chunk_header + chunk).digest()
                    offset += CHUNK_SIZE

        final_header = struct.pack('<BI', 0x5a, total_chunks)
        content_digest = hashlib.sha256(final_header + all_chunk_digests).digest()
        return content_digest

    # ---- V2 签名构建 ----

    @staticmethod
    def _build_v2_signed_data_bytes(content_digest, cert):
        """
        构建V2 signed data (不含长度前缀)。
        格式：digests_seq + certs_seq + additional_attrs_seq
        
        每个 "length-prefixed sequence of length-prefixed X" 的格式是：
          uint32(total_inner_bytes) + [uint32(item_len) + item]*
        """
        from cryptography.hazmat.primitives import serialization

        # digests sequence: length-prefixed sequence of length-prefixed digests
        # one_digest_record = algo_id(uint32) + length-prefixed digest_bytes
        one_digest_record = struct.pack('<I', 0x0103) + struct.pack('<I', len(content_digest)) + content_digest
        # 每个record需要带长度前缀
        one_digest_lp = struct.pack('<I', len(one_digest_record)) + one_digest_record
        # 序列 = uint32(total_inner) + all_records_lp
        digests_seq = struct.pack('<I', len(one_digest_lp)) + one_digest_lp

        # certificates sequence: length-prefixed sequence of length-prefixed cert_der
        cert_der = cert.public_bytes(serialization.Encoding.DER)
        one_cert_lp = struct.pack('<I', len(cert_der)) + cert_der
        certs_seq = struct.pack('<I', len(one_cert_lp)) + one_cert_lp

        # additional attributes: empty sequence
        attrs_seq = struct.pack('<I', 0)

        signed_data = digests_seq + certs_seq + attrs_seq
        return signed_data

    @staticmethod
    def _build_v3_signed_data_bytes(content_digest, cert, min_sdk=24, max_sdk=2147483647):
        """
        构建V3 signed data (不含长度前缀)。
        格式：digests_seq + certs_seq + minSDK + maxSDK + additional_attrs_seq
        """
        from cryptography.hazmat.primitives import serialization

        # digests sequence
        one_digest_record = struct.pack('<I', 0x0103) + struct.pack('<I', len(content_digest)) + content_digest
        one_digest_lp = struct.pack('<I', len(one_digest_record)) + one_digest_record
        digests_seq = struct.pack('<I', len(one_digest_lp)) + one_digest_lp

        # certificates sequence
        cert_der = cert.public_bytes(serialization.Encoding.DER)
        one_cert_lp = struct.pack('<I', len(cert_der)) + cert_der
        certs_seq = struct.pack('<I', len(one_cert_lp)) + one_cert_lp

        # minSDK + maxSDK (在certs之后，attrs之前)
        sdk_fields = struct.pack('<II', min_sdk, max_sdk)

        # additional attributes: empty sequence
        attrs_seq = struct.pack('<I', 0)

        signed_data = digests_seq + certs_seq + sdk_fields + attrs_seq
        return signed_data

    @staticmethod
    def _build_v2_signer(signed_data_bytes, signature, pub_key_der):
        """
        构建V2 signer block。
        格式：len(signed_data) + signed_data + len(sigs_inner) + sigs_inner + len(pubkey) + pubkey
        
        sigs_inner = [uint32(record_len) + record]*
        record = uint32(algo_id) + uint32(sig_len) + sig_bytes
        """
        # length-prefixed signed_data
        lp_signed_data = struct.pack('<I', len(signed_data_bytes)) + signed_data_bytes

        # signatures sequence: length-prefixed sequence of length-prefixed signature records
        one_sig_record = struct.pack('<I', 0x0103) + struct.pack('<I', len(signature)) + signature
        one_sig_lp = struct.pack('<I', len(one_sig_record)) + one_sig_record
        sigs_seq = struct.pack('<I', len(one_sig_lp)) + one_sig_lp

        # length-prefixed public key
        lp_pubkey = struct.pack('<I', len(pub_key_der)) + pub_key_der

        signer = lp_signed_data + sigs_seq + lp_pubkey
        return signer

    @staticmethod
    def _build_v3_signer(signed_data_bytes, signature, pub_key_der, min_sdk=24, max_sdk=2147483647):
        """
        构建V3 signer block。
        格式：len(signed_data) + signed_data + minSDK + maxSDK + len(sigs_inner) + sigs_inner + len(pubkey) + pubkey
        """
        # length-prefixed signed_data
        lp_signed_data = struct.pack('<I', len(signed_data_bytes)) + signed_data_bytes

        # minSDK + maxSDK (在signed_data之后，signatures之前)
        sdk_fields = struct.pack('<II', min_sdk, max_sdk)

        # signatures sequence: length-prefixed sequence of length-prefixed signature records
        one_sig_record = struct.pack('<I', 0x0103) + struct.pack('<I', len(signature)) + signature
        one_sig_lp = struct.pack('<I', len(one_sig_record)) + one_sig_record
        sigs_seq = struct.pack('<I', len(one_sig_lp)) + one_sig_lp

        # length-prefixed public key
        lp_pubkey = struct.pack('<I', len(pub_key_der)) + pub_key_der

        signer = lp_signed_data + sdk_fields + sigs_seq + lp_pubkey
        return signer

    @staticmethod
    def _build_apk_signing_block(v2_pair_value, v3_pair_value):
        """
        构建APK Signing Block。
        格式：
          uint64(block_size) + [id-value pairs] + uint64(block_size) + magic
        每个id-value pair：
          uint64(pair_size) + uint32(id) + value
          其中 pair_size = 4 + len(value)
        """
        def make_pair(block_id, value):
            pair_size = 4 + len(value)  # uint32(id) + value
            return struct.pack('<QI', pair_size, block_id) + value

        v2_pair = make_pair(0x7109871a, v2_pair_value)
        v3_pair = make_pair(0xf05368c0, v3_pair_value)

        pairs_data = v2_pair + v3_pair

        # block_size = len(pairs_data) + 8(second size field) + 16(magic)
        block_size = len(pairs_data) + 8 + 16
        magic = b'APK Sig Block 42'

        signing_block = struct.pack('<Q', block_size) + pairs_data + struct.pack('<Q', block_size) + magic
        return signing_block

    @staticmethod
    def sign_apk_v2v3(apk_path: str, private_key, cert) -> bool:
        """
        实现V2+V3签名。
        
        关键点：
        - 签名是对 length-prefixed signed_data 做的（即对 uint32(len) + signed_data 做签名）
        - signer block中的signed_data也是带长度前缀的
        - pair value = length-prefixed sequence of signers = uint32(len_all_signers) + [uint32(len_signer) + signer]
        """
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding as asym_padding

        try:
            with open(apk_path, 'rb') as f:
                apk_data = bytearray(f.read())

            eocd_offset = PythonApkSigner._find_eocd(apk_data)
            if eocd_offset is None:
                log("无法找到EOCD记录", "ERROR")
                return False

            cd_offset = struct.unpack('<I', apk_data[eocd_offset + 16:eocd_offset + 20])[0]

            zip_entries = bytes(apk_data[:cd_offset])
            central_dir = bytes(apk_data[cd_offset:eocd_offset])
            eocd = bytearray(apk_data[eocd_offset:])

            # 计算内容摘要
            content_digest = PythonApkSigner._compute_content_digests(
                zip_entries, central_dir, eocd, cd_offset
            )

            # 获取公钥DER
            pub_key_der = cert.public_key().public_bytes(
                serialization.Encoding.DER,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            )

            # ---- V2签名 ----
            v2_signed_data = PythonApkSigner._build_v2_signed_data_bytes(content_digest, cert)
            # 签名是对 signed_data 内容做的（不含长度前缀）
            v2_signature = private_key.sign(
                v2_signed_data, asym_padding.PKCS1v15(), hashes.SHA256(),
            )
            v2_signer = PythonApkSigner._build_v2_signer(v2_signed_data, v2_signature, pub_key_der)
            # pair value = length-prefixed sequence of signers
            v2_lp_signer = struct.pack('<I', len(v2_signer)) + v2_signer
            v2_pair_value = struct.pack('<I', len(v2_lp_signer)) + v2_lp_signer

            # ---- V3签名 ----
            min_sdk = 24
            max_sdk = 2147483647
            v3_signed_data = PythonApkSigner._build_v3_signed_data_bytes(content_digest, cert, min_sdk, max_sdk)
            # 签名是对 signed_data 内容做的（不含长度前缀）
            v3_signature = private_key.sign(
                v3_signed_data, asym_padding.PKCS1v15(), hashes.SHA256(),
            )
            v3_signer = PythonApkSigner._build_v3_signer(v3_signed_data, v3_signature, pub_key_der, min_sdk, max_sdk)
            # pair value = length-prefixed sequence of signers
            v3_lp_signer = struct.pack('<I', len(v3_signer)) + v3_signer
            v3_pair_value = struct.pack('<I', len(v3_lp_signer)) + v3_lp_signer

            # 构建signing block
            signing_block = PythonApkSigner._build_apk_signing_block(v2_pair_value, v3_pair_value)

            # 更新EOCD中的CD offset
            new_cd_offset = len(zip_entries) + len(signing_block)
            struct.pack_into('<I', eocd, 16, new_cd_offset)

            # 写入文件
            with open(apk_path, 'wb') as f:
                f.write(zip_entries)
                f.write(signing_block)
                f.write(central_dir)
                f.write(eocd)

            log("V2 + V3 签名完成", "OK")
            return True

        except Exception as e:
            log(f"V2+V3签名失败: {e}", "ERROR")
            import traceback
            traceback.print_exc()
            return False


# ============================================================
# 主处理器 (全内存操作)
# ============================================================

class ApkProcessor:
    """APK自动化处理主类 - 全内存操作，不解压到文件系统"""

    def __init__(self, input_apk: str, output_apk: str = None, config: dict = None):
        self.input_apk = os.path.abspath(input_apk)

        if output_apk is None:
            base, ext = os.path.splitext(self.input_apk)
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            self.output_apk = f"{base}_{timestamp}{ext}"
        else:
            self.output_apk = os.path.abspath(output_apk)

        self.config = config or {}
        self.junk_entries = []
        self.trick_entries = []

        # 核心数据结构：内存中的文件映射
        self.entries = OrderedDict()

        log(f"输入APK: {self.input_apk}")
        log(f"输出APK: {self.output_apk}")

    def process(self):
        """执行完整的APK处理流程：安全修复版"""
        try:
            log("=" * 60)
            log("开始APK处理流程 (安全修复模式)")
            log("=" * 60)

            # Step 1: 读取原始APK到内存
            log("\n[Step 1/6] 读取原始APK到内存...")
            self._load_apk()

            # Step 2: 跳过包名替换
            # 你的日志里曾误识别到 com.dmcbig.mediapicker.，这更像三方库包名。
            # UniApp / HBuilderX 的APK容易误识别包名，所以这里默认保持原包名不变。
            log("\n[Step 2/6] 包名替换...")
            log("  已跳过包名替换，保持原APK包名不变", "WARN")

            # Step 3: DEX安全检查
            log("\n[Step 3/6] DEX安全检查...")
            self._process_dex()

            # Step 4: 跳过垃圾文件和路径欺骗
            log("\n[Step 4/6] 注入垃圾数据和路径欺骗...")
            self._inject_junk()

            # Step 5: 重新打包 (带V1签名和对齐)
            log("\n[Step 5/6] 重新打包APK (带V1签名和对齐)...")
            self._repack_and_sign_v1()

            # Step 6: V2+V3签名
            if not self.config.get('no_sign', False):
                log("\n[Step 6/6] V2+V3签名...")
                self._sign_v2v3()
            else:
                log("\n[Step 6/6] 跳过签名（--no-sign）")

            log("\n" + "=" * 60)
            log(f"处理完成！输出文件: {self.output_apk}", "OK")
            log("=" * 60)

            self._print_summary()

        except Exception as e:
            log(f"处理过程中发生错误: {e}", "ERROR")
            import traceback
            traceback.print_exc()
            raise
    def _generate_random_package_name(self, length_hint: int) -> str:
        """
        生成与原始包名等长的随机包名。
        格式: com.xxxxx.xxxxx.xxx (保持合法的Java包名格式)
        """
        import string
        chars = string.ascii_lowercase
        
        # 生成随机段，总长度等于length_hint
        # 格式: com.seg1.seg2[.seg3]
        target_len = length_hint
        prefix = "com."
        remaining = target_len - len(prefix)
        
        # 随机分割成2-3段
        segments = []
        while remaining > 0:
            if len(segments) >= 2 and remaining <= 8:
                seg_len = remaining
            else:
                seg_len = random.randint(3, min(8, remaining))
            segments.append(''.join(random.choices(chars, k=seg_len)))
            remaining -= seg_len + 1  # +1 for dot
            if remaining <= 0:
                break
        
        result = prefix + '.'.join(segments)
        # 确保长度精确匹配
        if len(result) < target_len:
            # 补充最后一段
            diff = target_len - len(result)
            result += ''.join(random.choices(chars, k=diff))
        elif len(result) > target_len:
            result = result[:target_len]
            # 确保不以.结尾
            while result.endswith('.'):
                result = result[:-1] + random.choice(chars)
        
        return result

    def _detect_package_name(self) -> str:
        """
        从AndroidManifest.xml中检测原始包名。
        二进制manifest中包名通常在字符串池中，且是第一个类似包名格式的字符串。
        """
        manifest_data = self.entries.get('AndroidManifest.xml', {}).get('data', b'')
        if not manifest_data:
            return None
        
        # 尝试用androguard解析
        try:
            from androguard.core.apk import APK
            import tempfile, os
            # 需要完整APK来解析
            apk = APK(self.input_apk)
            pkg = apk.get_package()
            if pkg:
                log(f"  检测到包名 (androguard): {pkg}")
                return pkg
        except Exception:
            pass
        
        # 备用方案：在二进制manifest中搜索包名模式
        # 包名通常是UTF-16LE编码的，格式为 com.xxx.xxx
        import re
        # 搜索所有UTF-16LE编码的包名模式
        pattern = rb'c\x00o\x00m\x00\.\x00[a-z\x00]{2,}'
        matches = re.finditer(pattern, manifest_data)
        candidates = []
        for m in matches:
            raw = manifest_data[m.start():m.start()+200]
            # 解码直到遇到非包名字符
            decoded = ''
            for i in range(0, len(raw), 2):
                ch = raw[i:i+2]
                if len(ch) < 2:
                    break
                c = ch[0]
                if ch[1] != 0:
                    break
                if c == 0:
                    break
                char = chr(c)
                if char in 'abcdefghijklmnopqrstuvwxyz0123456789._':
                    decoded += char
                else:
                    break
            if decoded.count('.') >= 2 and len(decoded) >= 10:
                candidates.append(decoded)
        
        if candidates:
            # 选择最可能的包名（通常是最长的或出现次数最多的）
            from collections import Counter
            counter = Counter(candidates)
            pkg = counter.most_common(1)[0][0]
            log(f"  检测到包名 (heuristic): {pkg}")
            return pkg
        
        return None

    def _patch_package_name(self):
        """
        替换包名：同时修改 AndroidManifest.xml 和 resources.arsc。
        
        策略：
        1. manifest中：搜索原始包名的UTF-16LE编码，替换为等长的新包名
        2. arsc中：在Package header的固定256字节UTF-16LE字段中替换
        """
        new_pkg = self.config.get('new_package_name', None)
        
        # 检测原始包名
        orig_pkg = self._detect_package_name()
        if not orig_pkg:
            log("  无法检测原始包名，跳过包名替换", "WARN")
            return
        
        # 生成新包名（等长）
        if not new_pkg:
            new_pkg = self._generate_random_package_name(len(orig_pkg))
        
        # 确保新包名长度不超过原始包名
        if len(new_pkg) > len(orig_pkg):
            new_pkg = new_pkg[:len(orig_pkg)]
            while new_pkg.endswith('.'):
                new_pkg = new_pkg[:-1] + 'x'
        
        log(f"  原始包名: {orig_pkg}")
        log(f"  新包名:   {new_pkg}")
        
        # --- 修改 AndroidManifest.xml ---
        manifest_data = bytearray(self.entries['AndroidManifest.xml']['data'])
        orig_pkg_utf16 = orig_pkg.encode('utf-16-le')
        new_pkg_utf16 = new_pkg.encode('utf-16-le')
        
        # 等长替换（如果新包名短，用null填充）
        if len(new_pkg_utf16) < len(orig_pkg_utf16):
            new_pkg_utf16_padded = new_pkg_utf16 + b'\x00' * (len(orig_pkg_utf16) - len(new_pkg_utf16))
        else:
            new_pkg_utf16_padded = new_pkg_utf16[:len(orig_pkg_utf16)]
        
        manifest_replacements = 0
        pos = 0
        while True:
            pos = manifest_data.find(orig_pkg_utf16, pos)
            if pos == -1:
                break
            manifest_data[pos:pos+len(orig_pkg_utf16)] = new_pkg_utf16_padded
            manifest_replacements += 1
            pos += len(orig_pkg_utf16)
        
        self.entries['AndroidManifest.xml']['data'] = bytes(manifest_data)
        log(f"  Manifest: 替换了 {manifest_replacements} 处包名")
        
        # --- 修改 resources.arsc ---
        arsc_data = bytearray(self.entries.get('resources.arsc', {}).get('data', b''))
        if arsc_data:
            # 找到Package header中的包名字段
            # 格式: ResTable_header(12) + StringPool(sp_size) + Package_header
            # Package header中包名在offset+12处，固定256字节UTF-16LE
            
            sp_size = struct.unpack('<I', arsc_data[16:20])[0]  # global string pool size
            pkg_offset = 12 + sp_size
            
            if pkg_offset + 288 <= len(arsc_data):
                pkg_type = struct.unpack('<H', arsc_data[pkg_offset:pkg_offset+2])[0]
                if pkg_type == 0x0200:  # RES_TABLE_PACKAGE_TYPE
                    pkg_name_offset = pkg_offset + 12
                    # 读取当前包名验证
                    current_name = arsc_data[pkg_name_offset:pkg_name_offset+256].decode('utf-16-le').rstrip('\x00')
                    log(f"  ARSC当前包名: {current_name}")
                    
                    # 写入新包名（UTF-16LE，256字节固定字段，剩余填0）
                    new_name_utf16 = new_pkg.encode('utf-16-le')
                    new_name_padded = new_name_utf16 + b'\x00' * (256 - len(new_name_utf16))
                    arsc_data[pkg_name_offset:pkg_name_offset+256] = new_name_padded
                    
                    self.entries['resources.arsc']['data'] = bytes(arsc_data)
                    log(f"  ARSC: 包名已替换为 '{new_pkg}'")
                else:
                    log(f"  ARSC: Package header类型不匹配 (0x{pkg_type:04x})，跳过", "WARN")
            else:
                log("  ARSC: 文件结构异常，跳过", "WARN")
        else:
            log("  未找到resources.arsc", "WARN")
        
        self._new_package_name = new_pkg
        self._orig_package_name = orig_pkg

    def _load_apk(self):
        """
        将原始APK的所有条目读入内存字典。
        关键：使用zipfile直接读取bytes，不解压到文件系统，
        完美保留大小写敏感的文件名。
        """
        with zipfile.ZipFile(self.input_apk, 'r') as zf:
            for info in zf.infolist():
                # 跳过目录条目
                if info.filename.endswith('/'):
                    continue

                # 只跳过旧的签名相关文件（精确匹配）
                if info.filename.upper().startswith('META-INF/'):
                    basename = info.filename.split('/')[-1].upper()
                    if (basename.endswith('.SF') or basename.endswith('.RSA') or
                        basename.endswith('.DSA') or basename.endswith('.EC') or
                        basename == 'MANIFEST.MF'):
                        continue

                self.entries[info.filename] = {
                    'data': zf.read(info.filename),
                    'compress_type': info.compress_type,
                }

        log(f"已读取 {len(self.entries)} 个文件到内存")

        dex_count = sum(1 for k in self.entries if k.endswith('.dex'))
        res_count = sum(1 for k in self.entries if k.startswith('res/'))
        so_count = sum(1 for k in self.entries if k.endswith('.so'))
        log(f"  DEX: {dex_count}, 资源: {res_count}, SO: {so_count}")

    def _process_dex(self):
        """在内存中安全检查DEX文件，不修改DEX，不新增DEX"""
        dex_names = sorted([k for k in self.entries if k.endswith('.dex')])
        log(f"发现 {len(dex_names)} 个DEX文件")

        for dex_name in dex_names:
            old_data = self.entries[dex_name]['data']

            try:
                checked_data = DexSplitter.mutate_dex(old_data)
            except Exception as e:
                log(f"  {dex_name}: DEX检查失败，已保留原文件，原因: {e}", "WARN")
                checked_data = old_data

            self.entries[dex_name]['data'] = checked_data

            old_md5 = hashlib.md5(old_data).hexdigest()[:8]
            new_md5 = hashlib.md5(checked_data).hexdigest()[:8]

            if checked_data == old_data:
                log(f"  {dex_name}: {len(old_data)} bytes, MD5 {old_md5}.. -> {new_md5}.. (未修改)")
            else:
                log(f"  {dex_name}: {len(old_data)} bytes, MD5 {old_md5}.. -> {new_md5}.. (已处理)")

        log("  已跳过额外DEX生成，避免改变APK代码结构", "WARN")
    def _inject_junk(self):
        """
        安全修复版：
        - 不注入垃圾文件
        - 不生成ZIP路径欺骗
        - 保持原APK文件结构尽量不变
        """
        self.junk_entries = []
        self.trick_entries = []

        log("  已跳过垃圾文件注入", "WARN")
        log("  已跳过ZIP路径欺骗", "WARN")
    def _repack_and_sign_v1(self):
        """
        一次性完成：V1签名生成 + 对齐打包。
        
        流程：
        1. 收集所有条目数据
        2. 生成V1签名文件（MANIFEST.MF, APP.SF, APP.RSA）
        3. 手动构建ZIP二进制，确保STORED文件4字节对齐、.so文件4096字节对齐
        """
        do_v1 = not self.config.get('no_sign', False) and PythonApkSigner._ensure_cryptography()

        # --- 生成V1签名 ---
        v1_entries = OrderedDict()

        if do_v1:
            log("  生成V1签名...")
            self._v1_private_key, self._v1_cert = PythonApkSigner.generate_key_and_cert()

            entry_digests = {}
            for name in sorted(self.entries.keys()):
                digest = hashlib.sha256(self.entries[name]['data']).digest()
                entry_digests[name] = base64.b64encode(digest).decode('ascii')

            trick_digests = {}
            for path, trick_data in self.trick_entries:
                digest = hashlib.sha256(trick_data).digest()
                trick_digests[path] = base64.b64encode(digest).decode('ascii')

            # MANIFEST.MF
            manifest_lines = ["Manifest-Version: 1.0", "Built-By: APK Processor",
                             "Created-By: 1.0 (APK Processor)", ""]
            all_names = sorted(list(entry_digests.keys()) + list(trick_digests.keys()))
            combined_digests = {**entry_digests, **trick_digests}
            for name in all_names:
                manifest_lines.append(f"Name: {name}")
                manifest_lines.append(f"SHA-256-Digest: {combined_digests[name]}")
                manifest_lines.append("")
            manifest_bytes = '\r\n'.join(manifest_lines).encode('utf-8')

            # APP.SF
            manifest_digest = base64.b64encode(hashlib.sha256(manifest_bytes).digest()).decode('ascii')
            sf_lines = ["Signature-Version: 1.0", f"SHA-256-Digest-Manifest: {manifest_digest}",
                       "Created-By: 1.0 (APK Processor)", ""]
            for name in all_names:
                section = f"Name: {name}\r\nSHA-256-Digest: {combined_digests[name]}\r\n\r\n"
                section_digest = base64.b64encode(hashlib.sha256(section.encode('utf-8')).digest()).decode('ascii')
                sf_lines.append(f"Name: {name}")
                sf_lines.append(f"SHA-256-Digest: {section_digest}")
                sf_lines.append("")
            sf_bytes = '\r\n'.join(sf_lines).encode('utf-8')

            # APP.RSA
            rsa_bytes = PythonApkSigner._create_pkcs7_signature(sf_bytes, self._v1_private_key, self._v1_cert)

            v1_entries['META-INF/MANIFEST.MF'] = {'data': manifest_bytes, 'compress_type': 8}
            v1_entries['META-INF/APP.SF'] = {'data': sf_bytes, 'compress_type': 8}
            v1_entries['META-INF/APP.RSA'] = {'data': rsa_bytes, 'compress_type': 0}
            log("  V1签名文件已生成")

        # --- 手动ZIP写入（一次性对齐打包） ---
        with open(self.output_apk, 'wb') as out:
            local_headers = []

            def write_zip_entry(arcname, data, compress_type):
                """写入一个ZIP条目，带对齐"""
                crc = binascii.crc32(data) & 0xFFFFFFFF
                if compress_type == 8:
                    comp_data = zlib.compress(data, 6)[2:-4]  # raw deflate
                else:
                    comp_data = data

                fname_bytes = arcname.encode('utf-8')

                # 对齐计算：STORED文件需要对齐
                if compress_type == 0:
                    current_pos = out.tell()
                    header_size = 30 + len(fname_bytes)
                    data_start = current_pos + header_size
                    alignment = 4096 if arcname.endswith('.so') else 4
                    padding = (alignment - (data_start % alignment)) % alignment
                    extra = b'\x00' * padding
                else:
                    extra = b''

                header_offset = out.tell()

                # Local File Header
                out.write(struct.pack('<I', 0x04034b50))   # signature
                out.write(struct.pack('<H', 20))            # version needed
                out.write(struct.pack('<H', 0))             # flags
                out.write(struct.pack('<H', compress_type)) # compression
                out.write(struct.pack('<H', 0x4A21))        # mod time
                out.write(struct.pack('<H', 0x5915))        # mod date
                out.write(struct.pack('<I', crc))           # crc32
                out.write(struct.pack('<I', len(comp_data)))# compressed size
                out.write(struct.pack('<I', len(data)))     # uncompressed size
                out.write(struct.pack('<H', len(fname_bytes)))  # filename length
                out.write(struct.pack('<H', len(extra)))    # extra length
                out.write(fname_bytes)
                out.write(extra)
                out.write(comp_data)

                local_headers.append((arcname, header_offset, compress_type, crc,
                                      len(comp_data), len(data)))

            # 1. 先写V1签名文件
            for name in ['META-INF/MANIFEST.MF', 'META-INF/APP.SF', 'META-INF/APP.RSA']:
                if name in v1_entries:
                    e = v1_entries[name]
                    write_zip_entry(name, e['data'], e['compress_type'])

            # 2. 写所有原始文件（保持原始顺序！）
            for arcname, entry in self.entries.items():
                write_zip_entry(arcname, entry['data'], entry['compress_type'])

            # 3. 写trick entries
            for path, trick_data in self.trick_entries:
                crc = binascii.crc32(trick_data) & 0xFFFFFFFF
                fname_bytes = path.encode('utf-8')
                header_offset = out.tell()

                out.write(struct.pack('<I', 0x04034b50))
                out.write(struct.pack('<H', 20))
                out.write(struct.pack('<H', 0))
                out.write(struct.pack('<H', 0))  # STORED
                out.write(struct.pack('<H', 0x4A21))
                out.write(struct.pack('<H', 0x5915))
                out.write(struct.pack('<I', crc))
                out.write(struct.pack('<I', len(trick_data)))
                out.write(struct.pack('<I', len(trick_data)))
                out.write(struct.pack('<H', len(fname_bytes)))
                out.write(struct.pack('<H', 0))
                out.write(fname_bytes)
                out.write(trick_data)

                local_headers.append((path, header_offset, 0, crc,
                                      len(trick_data), len(trick_data)))
                log(f"  写入欺骗路径: {path}")

            # Central Directory
            cd_offset = out.tell()
            for arcname, header_offset, compress_type, crc, comp_size, uncomp_size in local_headers:
                fname_bytes = arcname.encode('utf-8')
                out.write(struct.pack('<I', 0x02014b50))    # signature
                out.write(struct.pack('<H', 20))             # version made by
                out.write(struct.pack('<H', 20))             # version needed
                out.write(struct.pack('<H', 0))              # flags
                out.write(struct.pack('<H', compress_type))  # compression
                out.write(struct.pack('<H', 0x4A21))         # mod time
                out.write(struct.pack('<H', 0x5915))         # mod date
                out.write(struct.pack('<I', crc))            # crc32
                out.write(struct.pack('<I', comp_size))      # compressed size
                out.write(struct.pack('<I', uncomp_size))    # uncompressed size
                out.write(struct.pack('<H', len(fname_bytes)))  # filename length
                out.write(struct.pack('<H', 0))              # extra length
                out.write(struct.pack('<H', 0))              # comment length
                out.write(struct.pack('<H', 0))              # disk number
                out.write(struct.pack('<H', 0))              # internal attrs
                out.write(struct.pack('<I', 0))              # external attrs
                out.write(struct.pack('<I', header_offset))  # local header offset
                out.write(fname_bytes)

            cd_size = out.tell() - cd_offset

            # EOCD
            out.write(struct.pack('<I', 0x06054b50))
            out.write(struct.pack('<H', 0))
            out.write(struct.pack('<H', 0))
            out.write(struct.pack('<H', len(local_headers)))
            out.write(struct.pack('<H', len(local_headers)))
            out.write(struct.pack('<I', cd_size))
            out.write(struct.pack('<I', cd_offset))
            out.write(struct.pack('<H', 0))

        size = os.path.getsize(self.output_apk)
        log(f"已对齐打包APK: {size:,} bytes", "OK")

    def _sign_v2v3(self):
        """V2+V3签名"""
        if not PythonApkSigner._ensure_cryptography():
            log("签名跳过：缺少 cryptography 库", "ERROR")
            return

        if hasattr(self, '_v1_private_key') and self._v1_private_key:
            private_key = self._v1_private_key
            cert = self._v1_cert
            log("复用V1签名的密钥和证书")
        else:
            log("生成RSA密钥和自签名证书...")
            private_key, cert = PythonApkSigner.generate_key_and_cert()

        PythonApkSigner.sign_apk_v2v3(self.output_apk, private_key, cert)

    def _print_summary(self):
        """打印处理摘要"""
        log("\n" + "=" * 60)
        log("处理摘要")
        log("=" * 60)

        orig_size = os.path.getsize(self.input_apk)
        new_size = os.path.getsize(self.output_apk)

        with open(self.input_apk, 'rb') as f:
            orig_md5 = hashlib.md5(f.read()).hexdigest()
        with open(self.output_apk, 'rb') as f:
            new_md5 = hashlib.md5(f.read()).hexdigest()

        print(f"\n  {'项目':<20} {'原始APK':<35} {'处理后APK':<35}")
        print(f"  {'-'*90}")
        
        # 包名信息
        orig_pkg = getattr(self, '_orig_package_name', '未检测')
        new_pkg = getattr(self, '_new_package_name', '未修改')
        print(f"  {'包名':<20} {orig_pkg:<35} {new_pkg:<35}")
        
        print(f"  {'文件大小':<20} {orig_size:>15,} bytes{'':<10} {new_size:>15,} bytes")
        print(f"  {'MD5':<20} {orig_md5:<35} {new_md5:<35}")
        print(f"  {'垃圾文件数':<20} {'0':<35} {len(self.junk_entries):<35}")
        print(f"  {'欺骗路径数':<20} {'0':<35} {len(self.trick_entries):<35}")

        dex_count_orig = 0
        with zipfile.ZipFile(self.input_apk, 'r') as zf:
            dex_count_orig = sum(1 for n in zf.namelist() if n.endswith('.dex'))
        dex_count_new = sum(1 for k in self.entries if k.endswith('.dex'))
        print(f"  {'DEX文件数':<20} {dex_count_orig:<35} {dex_count_new:<35}")

        print()


# ============================================================
# 命令行入口
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="APK Processor - APK自动化处理工具 (跨平台, 无需Java)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python3 apk_processor.py input.apk
  python3 apk_processor.py input.apk -o output.apk
  python3 apk_processor.py input.apk --junk-count 30 --extra-dex 2

环境要求:
  pip3 install cryptography        # 必须 (签名用)
        """
    )

    parser.add_argument("input", help="输入APK文件路径")
    parser.add_argument("-o", "--output", help="输出APK文件路径（默认: 输入文件名_时间戳.apk）")
    parser.add_argument("--junk-count", type=int, default=None,
                        help="垃圾文件数量（默认20-40随机）")
    parser.add_argument("--extra-dex", type=int, default=1,
                        help="额外生成的DEX文件数量（默认1）")
    parser.add_argument("--no-sign", action="store_true",
                        help="不进行签名（仅打包）")

    args = parser.parse_args()

    if not os.path.exists(args.input):
        log(f"输入文件不存在: {args.input}", "ERROR")
        sys.exit(1)

    try:
        import cryptography
        log(f"cryptography 版本: {cryptography.__version__}")
    except ImportError:
        log("缺少必要依赖 cryptography，请运行: pip3 install cryptography", "ERROR")
        sys.exit(1)

    config = {
        'extra_dex_count': args.extra_dex,
        'no_sign': args.no_sign,
    }

    if args.junk_count:
        config['junk_count'] = args.junk_count

    processor = ApkProcessor(args.input, args.output, config)
    processor.process()


if __name__ == "__main__":
    main()
