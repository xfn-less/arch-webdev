package deploy

import (
	"context"
	"encoding/base64"
	"fmt"
	"strings"

	"github.com/xfn/static-site-panel/internal/store"
)

// InstallNginx initializes the Debian/Ubuntu stack without rewriting apt sources.
// Non-Debian hosts are refused up front (CentOS/RHEL are not full-init targets).
func InstallNginx(ctx context.Context, s store.Server, log func(string)) error {
	runner, err := NewRunner(s)
	if err != nil {
		return err
	}
	osInfo, err := ProbeOS(ctx, runner)
	if err != nil {
		return fmt.Errorf("探测系统: %w", err)
	}
	label := osInfo.Pretty
	if label == "" {
		label = osInfo.ID + " " + osInfo.Version
	}
	log("os: " + strings.TrimSpace(label) + " (family=" + osInfo.Family() + ")")
	if !osInfo.SupportsPanelInit() {
		return fmt.Errorf("初始化仅支持 Debian/Ubuntu，当前为 %s — 请换 Debian 系机器，或迁站机不要点「初始化」", label)
	}
	script := nginxInstallScript()
	b64 := base64.StdEncoding.EncodeToString([]byte(script))
	log("initialize: nginx + rsync + python3 + SSH fail2ban/limits")
	return runner.Run(ctx, log, "echo "+shellQuote(b64)+" | base64 -d | bash")
}

func nginxInstallScript() string {
	return `set -euo pipefail
. /etc/os-release
case "$ID" in debian|ubuntu) ;; *)
  echo "初始化仅支持 Debian/Ubuntu（当前 ID=$ID）" >&2
  exit 1
;; esac
[ "$(id -u)" = 0 ] || { echo "Initialization requires root" >&2; exit 1; }
export DEBIAN_FRONTEND=noninteractive
timeout 180 apt-get -o Acquire::Retries=3 update -qq
timeout 300 apt-get -o Acquire::Retries=3 install -y -qq \
  nginx rsync curl ca-certificates python3 python3-cryptography python3-systemd fail2ban
systemctl enable --now nginx
nginx -t

# Mild sshd limits: cut spray noise without locking out password re-install from the panel.
# Do not manage host firewall; only harden SSH here.
mkdir -p /etc/ssh/sshd_config.d
cat >/etc/ssh/sshd_config.d/01-site-panel-harden.conf <<'EOF'
MaxAuthTries 4
LoginGraceTime 30
MaxStartups 10:30:60
EOF
sshd -t
systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null \
  || service ssh reload 2>/dev/null || service sshd reload 2>/dev/null || true

mkdir -p /etc/fail2ban/jail.d
cat >/etc/fail2ban/jail.d/sshd.local <<'EOF'
[sshd]
backend = systemd
enabled = true
maxretry = 4
findtime = 10m
bantime = 1h
EOF
systemctl enable --now fail2ban
systemctl reload fail2ban 2>/dev/null || systemctl restart fail2ban

# Unknown-Host catch-all (same file as deploy EnsureDefaultCatchAll).
` + defaultCatchAllInstallScript() + `
echo "nginx + rsync + python3 ready; fail2ban+sshd limits applied"
`
}

// ProbeNginx returns a short remote status line for UI.
func ProbeNginx(ctx context.Context, s store.Server) (string, error) {
	runner, err := NewRunner(s)
	if err != nil {
		return "", err
	}
	osInfo, _ := ProbeOS(ctx, runner)
	osPart := "os=unknown"
	if osInfo.ID != "" {
		osPart = fmt.Sprintf("os=%s family=%s init=%v", osInfo.ID, osInfo.Family(), osInfo.SupportsPanelInit())
	}
	out, err := runner.Output(ctx, "bash -lc "+shellQuote(`
if ! command -v nginx >/dev/null 2>&1; then echo "nginx=missing"; exit 0; fi
ver=$(nginx -v 2>&1 | head -n1)
active=no
systemctl is-active nginx >/dev/null 2>&1 && active=yes || true
systemctl is-active panel-nginx >/dev/null 2>&1 && active=yes || true
f2b=no
systemctl is-active fail2ban >/dev/null 2>&1 && f2b=yes || true
echo "nginx=ok active=$active fail2ban=$f2b $ver"
`))
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(osPart + " " + strings.TrimSpace(out)), nil
}
