package deploy

import (
	"context"
	_ "embed"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"github.com/xfn/static-site-panel/internal/store"
)

const (
	ApkProcessorName = "apk_processor.py"
	ApkLogName       = "apk-process.log"
	apkRunnerName    = ".panel-apk-run"
)

var (
	siteNameRe = regexp.MustCompile(`^[a-zA-Z0-9_-]+$`)
	apkNameRe  = regexp.MustCompile(`^[a-zA-Z0-9][a-zA-Z0-9._+-]*\.apk$`)
)

//go:embed apk-run.sh
var apkRunnerScript string

//go:embed apk_processor.py
var apkProcessorScript string

func RemoteApkTimerPath(siteName string) string {
	return "/etc/cron.d/ssp-apk-" + siteName
}

func remoteWWW(siteName string) string {
	return "/www/sites/" + siteName + "/www"
}

func remoteApkLog(siteName string) string {
	return "/www/sites/" + siteName + "/" + ApkLogName
}

func remoteSiteProcessor(siteName string) string {
	return "/www/sites/" + siteName + "/" + ApkProcessorName
}

// IsApkFile reports whether basename is a processable www-root APK.
func IsApkFile(name string) bool {
	base := filepath.Base(name)
	if !apkNameRe.MatchString(base) {
		return false
	}
	lower := strings.ToLower(base)
	if strings.HasSuffix(lower, "-out.apk") {
		return false
	}
	if strings.HasPrefix(base, ".ssp-apk-") {
		return false
	}
	return true
}

// ListLocalApkFiles returns www-root *.apk names suitable for obfuscation.
func ListLocalApkFiles(sitesRoot, siteName string) []string {
	www := filepath.Join(sitesRoot, siteName, "www")
	ents, err := os.ReadDir(www)
	if err != nil {
		return nil
	}
	var out []string
	for _, e := range ents {
		if e.IsDir() {
			continue
		}
		if IsApkFile(e.Name()) {
			out = append(out, e.Name())
		}
	}
	return out
}

// RsyncApkExcludes keeps process logs / temps / processor off the public tree sync.
// Old *-out.apk is intentionally NOT excluded so --delete can clear leftovers.
// Master www may still contain a leftover apk_processor.py; never publish it.
func RsyncApkExcludes() []string {
	return []string{
		"--exclude=" + ApkLogName,
		"--exclude=" + ApkLogName + ".panel-tmp",
		"--exclude=.ssp-apk-*",
		"--exclude=/" + ApkProcessorName,
	}
}

func remoteApkRunner(site string) string { return "/www/sites/" + site + "/" + apkRunnerName }

func apkTimerBody(site string) string {
	// No shell expansion lives in cron: percent signs are interpreted by cron even inside quotes.
	return "SHELL=/bin/bash\nPATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\n*/30 * * * * root " +
		shellQuote(remoteApkRunner(site)) + " " + shellQuote(remoteWWW(site)) + " force >>" + shellQuote(remoteApkLog(site)) + " 2>&1\n"
}

// SyncApkTimer installs or removes the remote 30m APK timer from the site obfuscation flag.
// Processor is always the binary-embedded copy (not from site www).
func SyncApkTimer(ctx context.Context, s store.Server, sitesRoot, siteName string, enabled bool, log func(string)) error {
	if !siteNameRe.MatchString(siteName) {
		return fmt.Errorf("bad site name")
	}
	runner, err := NewRunner(s)
	if err != nil {
		return err
	}
	remote := RemoteApkTimerPath(siteName)
	if !enabled {
		log("apk obfuscate off — remove timer + runner")
		if err := runner.Run(ctx, log, "rm -f "+shellQuote(remote)+" "+shellQuote(remoteApkRunner(siteName))+" "+shellQuote(remoteSiteProcessor(siteName))+" "+shellQuote(remoteWWW(siteName)+"/"+ApkProcessorName)); err != nil {
			return err
		}
		log("apk timer removed — remote will not auto-run")
		return nil
	}
	if err := writeRemoteFile(ctx, runner, remoteSiteProcessor(siteName), apkProcessorScript, 0600, log); err != nil {
		return err
	}
	// Processor must not be served from the public web root.
	if err := runner.Run(ctx, log, "rm -f "+shellQuote(remoteWWW(siteName)+"/"+ApkProcessorName)); err != nil {
		return err
	}
	if err := writeRemoteFile(ctx, runner, remoteApkRunner(siteName), apkRunnerScript, 0755, log); err != nil {
		return err
	}
	log("apk obfuscate on — install 30m timer (embedded processor)")
	if err := writeRemoteFile(ctx, runner, remote, apkTimerBody(siteName), 0644, log); err != nil {
		return err
	}
	log("apk timer ok — cron */30m force-run until toggle off + redeploy")
	return nil
}

// RemoveApkTimer removes cron + runner + embedded processor copy (keeps remote www apks as-is).
func RemoveApkTimer(ctx context.Context, s store.Server, siteName string, log func(string)) error {
	if !siteNameRe.MatchString(siteName) {
		return nil
	}
	runner, err := NewRunner(s)
	if err != nil {
		return err
	}
	log("rm apk timer")
	return runner.Run(ctx, log, "rm -f "+shellQuote(RemoteApkTimerPath(siteName))+" "+shellQuote(remoteApkRunner(siteName))+" "+shellQuote(remoteSiteProcessor(siteName)))
}

// ProcessApkFiles runs the remote obfuscator in-place for every local www-root apk.
// Only the remote tree is modified; master www/*.apk are never opened for write.
func ProcessApkFiles(ctx context.Context, s store.Server, sitesRoot, siteName string, log func(string)) error {
	if !siteNameRe.MatchString(siteName) {
		return fmt.Errorf("bad site name")
	}
	files := ListLocalApkFiles(sitesRoot, siteName)
	if len(files) == 0 {
		log("no apk files — skip obfuscate (timer still installed if enabled)")
		return nil
	}
	runner, err := NewRunner(s)
	if err != nil {
		return err
	}
	log("obfuscate apk in-place on remote only (force); master apk untouched — " + strings.Join(files, ", "))
	command := shellQuote(remoteApkRunner(siteName)) + " " + shellQuote(remoteWWW(siteName)) + " force >>" + shellQuote(remoteApkLog(siteName)) + " 2>&1"
	if err := runner.Run(ctx, log, command); err != nil {
		return fmt.Errorf("APK 混淆失败（详见 apk-process.log）: %w", err)
	}
	log(fmt.Sprintf("apk process ok — %d file(s): %s (this deploy); remote cron keeps re-running every 30m", len(files), strings.Join(files, ", ")))
	return nil
}
