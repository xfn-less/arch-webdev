package deploy

import (
	"bytes"
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"

	"github.com/xfn/static-site-panel/internal/sshutil"
	"github.com/xfn/static-site-panel/internal/store"
)

type Result struct {
	SkippedConf bool
	SkippedWWW  bool
	Reloaded    bool
	Lines       []string
}

type Options struct {
	SitesRoot  string
	SiteName   string
	RemoteWWW  string
	RemoteConf string
	Server     store.Server
	// ApkObfuscate enables in-place remote APK obfuscation + 30m cron after file sync.
	ApkObfuscate bool
	// ConfBody supplies a temporary remote configuration without changing the master copy.
	ConfBody *string
}

// Sync publishes the master site and prepares its optional APK job.
func Sync(ctx context.Context, opt Options, log func(string)) (Result, error) {
	return syncSite(ctx, opt, log, true)
}

// SyncConf applies only configuration/certificates. SSL never republishes site files or runs APK jobs.
func SyncConf(ctx context.Context, opt Options, log func(string)) (Result, error) {
	return syncSite(ctx, opt, log, false)
}

func syncSite(ctx context.Context, opt Options, log func(string), files bool) (Result, error) {
	var res Result
	localWWW := filepath.Join(opt.SitesRoot, opt.SiteName, "www") + string(os.PathSeparator)
	localConf := filepath.Join(opt.SitesRoot, opt.SiteName, "nginx.conf")
	if _, err := os.Stat(localWWW); err != nil {
		return res, fmt.Errorf("local www: %w", err)
	}
	if _, err := os.Stat(localConf); err != nil {
		return res, fmt.Errorf("local conf: %w", err)
	}

	if opt.ConfBody != nil {
		staged, err := stageConf(*opt.ConfBody)
		if err != nil {
			return res, err
		}
		defer os.Remove(staged)
		localConf = staged
	}

	sshRunner, err := newSSHRunner(opt.Server)
	if err != nil {
		return res, err
	}
	target := fmt.Sprintf("%s@%s", opt.Server.User, opt.Server.Host)
	if opt.Server.User == "" {
		target = "root@" + opt.Server.Host
	}

	log("mkdir remote paths")
	mkdirCmd := "mkdir -p " + shellQuote(filepath.Dir(opt.RemoteConf)) + " " + shellQuote(strings.TrimRight(opt.RemoteWWW, "/"))
	if err := sshRunner.run(ctx, log, target, mkdirCmd); err != nil {
		return res, fmt.Errorf("mkdir remote: %w", err)
	}
	if err := ensureDefaultCatchAllSSH(ctx, sshRunner, target, log); err != nil {
		return res, fmt.Errorf("default catch-all: %w", err)
	}

	remoteConfBody, err := sshRunner.remoteCat(ctx, log, target, opt.RemoteConf)
	localBody, err2 := os.ReadFile(localConf)
	if err2 != nil {
		return res, err2
	}
	confSame := err == nil && bytes.Equal(bytes.TrimSpace(remoteConfBody), bytes.TrimSpace(localBody))

	if files {
		log("rsync www → " + opt.RemoteWWW)
		// Serialize receiver writes with the APK cron's existing lock, so a
		// running processor cannot replace a freshly uploaded source with old output.
		rsyncExtra := append([]string{"--delete", "--info=stats2",
			"--rsync-path=flock -x " + shellQuote(filepath.Join(filepath.Dir(strings.TrimRight(opt.RemoteWWW, "/")), ".apk.lock")) + " rsync"}, RsyncApkExcludes()...)
		if err := sshRunner.rsync(ctx, log, localWWW, target+":"+ensureSlash(opt.RemoteWWW), rsyncExtra...); err != nil {
			return res, err
		}
	}
	if strings.Contains(string(localBody), ManualSSLDir(opt.SiteName)+"/") {
		if err := syncManualCert(ctx, opt, log); err != nil {
			return res, err
		}
		// PEM bytes can change while their paths and nginx.conf stay identical.
		// Always validate/reload after synchronizing a manual certificate.
		confSame = false
	}

	if confSame {
		res.SkippedConf = true
		log("conf identical — skip push/reload")
	} else {
		if err != nil {
			log("conf missing or unread on remote — will upload: " + err.Error())
		}
		staged := opt.RemoteConf + ".panel-new"
		bak := opt.RemoteConf + ".panel-bak"
		log("stage conf → " + staged)
		if err := sshRunner.rsync(ctx, log, localConf, target+":"+staged); err != nil {
			return res, err
		}
		log("nginx -t (atomic install) && reload")
		cmd := strings.Join([]string{
			"set -e",
			"exec 9>/run/lock/site-panel-nginx.lock",
			"flock -x 9",
			"NEW=" + shellQuote(staged),
			"CONF=" + shellQuote(opt.RemoteConf),
			"BAK=" + shellQuote(bak),
			`if [ -f "$CONF" ]; then cp -a "$CONF" "$BAK"; else rm -f "$BAK"; fi`,
			`mv -f "$NEW" "$CONF"`,
			`if ! nginx -t; then`,
			`  if [ -f "$BAK" ]; then mv -f "$BAK" "$CONF"; else rm -f "$CONF"; fi`,
			`  echo "nginx -t failed; conf restored" >&2`,
			`  exit 1`,
			`fi`,
			`reload_nginx() {`,
			`  if systemctl is-active --quiet panel-nginx; then systemctl reload panel-nginx || nginx -s reload;`,
			`  else systemctl reload nginx || service nginx reload || nginx -s reload; fi`,
			`}`,
			`if ! reload_nginx; then`,
			`  if [ -f "$BAK" ]; then mv -f "$BAK" "$CONF"; else rm -f "$CONF"; fi`,
			`  nginx -t && reload_nginx || true`,
			`  echo "nginx reload failed; conf restored" >&2`,
			`  exit 1`,
			`fi`,
			`rm -f "$BAK"`,
		}, "\n")
		if err := sshRunner.run(ctx, log, target, "bash -lc "+shellQuote(cmd)); err != nil {
			return res, err
		}
		res.Reloaded = true
	}

	if !files {
		return res, nil
	}

	if err := SyncApkTimer(ctx, opt.Server, opt.SitesRoot, opt.SiteName, opt.ApkObfuscate, log); err != nil {
		return res, fmt.Errorf("apk timer: %w", err)
	}
	if opt.ApkObfuscate {
		if err := ProcessApkFiles(ctx, opt.Server, opt.SitesRoot, opt.SiteName, log); err != nil {
			return res, fmt.Errorf("apk obfuscate: %w", err)
		}
	}
	return res, nil
}

// DisableSite removes remote nginx conf + APK timer but keeps www files.
// The site stops serving until Sync/SyncConf pushes conf again.
func DisableSite(ctx context.Context, opt Options, log func(string)) error {
	sshRunner, err := newSSHRunner(opt.Server)
	if err != nil {
		return err
	}
	target := targetOf(opt.Server)
	cmd := disableSiteScript(opt)
	log("remote disable " + opt.SiteName + " (remove conf, keep www)")
	return sshRunner.run(ctx, log, target, "bash -lc "+shellQuote(cmd))
}

func disableSiteScript(opt Options) string {
	return strings.Join([]string{
		"set -e",
		"exec 9>/run/lock/site-panel-nginx.lock",
		"flock -x 9",
		"CONF=" + shellQuote(opt.RemoteConf),
		`rm -f "$CONF" "$CONF.panel-new" "$CONF.panel-bak"`,
		`rm -f ` + shellQuote(RemoteApkTimerPath(opt.SiteName)),
		`if command -v nginx >/dev/null 2>&1; then nginx -t && { if systemctl is-active --quiet panel-nginx; then systemctl reload panel-nginx || nginx -s reload; else systemctl reload nginx || service nginx reload || nginx -s reload; fi; }; fi`,
	}, "\n")
}

// RemoveSite deletes remote www + conf and reloads nginx when conf changed.
func RemoveSite(ctx context.Context, opt Options, log func(string)) error {
	sshRunner, err := newSSHRunner(opt.Server)
	if err != nil {
		return err
	}
	target := targetOf(opt.Server)
	www := strings.TrimRight(opt.RemoteWWW, "/")
	siteRoot := filepath.Dir(www)
	cmd := strings.Join([]string{
		"set -e",
		"CONF=" + shellQuote(opt.RemoteConf),
		"WWW=" + shellQuote(www),
		"ROOT=" + shellQuote(siteRoot),
		`rm -f "$CONF" "$CONF.panel-new" "$CONF.panel-bak"`,
		`rm -f ` + shellQuote(RemoteApkTimerPath(opt.SiteName)),
		`rm -f ` + shellQuote(filepath.Join(siteRoot, apkRunnerName)) + ` ` + shellQuote(filepath.Join(siteRoot, ApkProcessorName)),
		`rm -rf "$WWW"`,
		`rmdir "$ROOT" 2>/dev/null || true`,
		`if command -v nginx >/dev/null 2>&1; then nginx -t && { if systemctl is-active --quiet panel-nginx; then systemctl reload panel-nginx || nginx -s reload; else systemctl reload nginx || service nginx reload || nginx -s reload; fi; }; fi`,
	}, "\n")
	log("remote remove " + opt.SiteName)
	return sshRunner.run(ctx, log, target, "bash -lc "+shellQuote(cmd))
}

func targetOf(s store.Server) string {
	user := s.User
	if user == "" {
		user = "root"
	}
	return user + "@" + s.Host
}

type sshRunner struct {
	sshBase []string
	env     []string
	server  store.Server
}

func newSSHRunner(s store.Server) (*sshRunner, error) {
	port := s.Port
	if port == 0 {
		port = 22
	}
	args := []string{
		"ssh",
		"-F", "/dev/null",
		"-p", fmt.Sprintf("%d", port),
		// The panel is single-user and its registered machines may be rebuilt;
		// accept changed keys in deployment SSH too, matching sshutil's recovery.
		"-o", "StrictHostKeyChecking=no",
		"-o", "ConnectTimeout=15",
		"-o", "ServerAliveInterval=10",
		"-o", "ServerAliveCountMax=3",
	}
	if s.ViaJump {
		args = append(args, "-o", "ProxyCommand="+sshutil.JumpFromEnv().CLIProxyCommand())
	}
	env := os.Environ()
	usePassword := s.AuthType == "password" || (s.AuthType != "key" && s.Password != "")
	if !usePassword && s.AuthType == "key" {
		key := s.AuthValue
		if key == "" {
			key = "/www/site-panel/.ssh/id_ed25519"
		}
		if _, err := os.Stat(key); err != nil && s.Password != "" {
			usePassword = true
		}
	}
	if usePassword {
		if s.Password == "" {
			return nil, fmt.Errorf("ssh password empty")
		}
		if _, err := exec.LookPath("sshpass"); err != nil {
			return nil, fmt.Errorf("sshpass not installed on panel host")
		}
		args = append([]string{"sshpass", "-e"}, args...)
		args = append(args, "-o", "PreferredAuthentications=password", "-o", "PubkeyAuthentication=no", "-o", "NumberOfPasswordPrompts=1")
		env = append(env, "SSHPASS="+s.Password)
	} else {
		args = append(args, "-o", "BatchMode=yes")
		key := s.AuthValue
		if key == "" {
			key = "/www/site-panel/.ssh/id_ed25519"
		}
		if _, err := os.Stat(key); err == nil {
			args = append(args, "-i", key)
		}
	}
	return &sshRunner{sshBase: args, env: env, server: s}, nil
}

func (r *sshRunner) run(ctx context.Context, log func(string), target, remoteCmd string) error {
	err := r.runOnce(ctx, log, target, remoteCmd)
	if alt := r.directFallback(log, err); alt != nil {
		return alt.runOnce(ctx, log, target, remoteCmd)
	}
	return err
}

// directFallback switches a failed jump session to a plain connection.
// Jump and direct fail at different times on these hosts; the other path is
// only used when the jump never established SSH.
func (r *sshRunner) directFallback(log func(string), err error) *sshRunner {
	if err == nil || !r.server.ViaJump || !isSSHTransient(err) {
		return nil
	}
	if log != nil {
		log("跳板连不上，改为直连")
	}
	s := r.server
	s.ViaJump = false
	alt, ferr := newSSHRunner(s)
	if ferr != nil {
		if log != nil {
			log("直连准备失败: " + ferr.Error())
		}
		return nil
	}
	return alt
}

func (r *sshRunner) runOnce(ctx context.Context, log func(string), target, remoteCmd string) error {
	argv := append(append([]string{}, r.sshBase...), target, remoteCmd)
	operation := func() error { return runEnv(ctx, log, r.env, argv...) }
	err := retrySSHHandshake(ctx, log, operation)
	if err == nil {
		return nil
	}
	repaired, repairErr := r.repairAfterAuthFailure(log, err)
	if repairErr != nil || !repaired {
		return repairErrOrOriginal(repairErr, err)
	}
	log("SSH 密钥已自动修复，正在重试操作…")
	return retrySSHHandshake(ctx, log, operation)
}

func (r *sshRunner) remoteCat(ctx context.Context, log func(string), target, path string) ([]byte, error) {
	return r.remoteOutput(ctx, log, target, "cat "+shellQuote(path))
}

func (r *sshRunner) remoteOutput(ctx context.Context, log func(string), target, remoteCmd string) ([]byte, error) {
	argv := append(append([]string{}, r.sshBase...), target, remoteCmd)
	var stdout, stderr bytes.Buffer
	operation := func() error {
		stdout.Reset()
		stderr.Reset()
		cmd := exec.CommandContext(ctx, argv[0], argv[1:]...)
		cmd.Env = r.env
		cmd.Stdout = &stdout
		cmd.Stderr = &stderr
		if err := cmd.Run(); err != nil {
			return fmt.Errorf("%w: %s", err, strings.TrimSpace(stderr.String()))
		}
		return nil
	}
	if err := retrySSHHandshake(ctx, log, operation); err != nil {
		repaired, repairErr := r.repairAfterAuthFailure(log, err)
		if repairErr != nil || !repaired {
			if alt := r.directFallback(log, repairErrOrOriginal(repairErr, err)); alt != nil {
				return alt.remoteOutput(ctx, log, target, remoteCmd)
			}
			return nil, repairErrOrOriginal(repairErr, err)
		}
		if log != nil {
			log("SSH 密钥已自动修复，正在重试操作…")
		}
		if retryErr := retrySSHHandshake(ctx, log, operation); retryErr != nil {
			if alt := r.directFallback(log, retryErr); alt != nil {
				return alt.remoteOutput(ctx, log, target, remoteCmd)
			}
			return nil, retryErr
		}
	}
	return stdout.Bytes(), nil
}

func (r *sshRunner) sshRemoteShell() string {
	parts := make([]string, 0, len(r.sshBase))
	for _, p := range r.sshBase {
		parts = append(parts, shellQuote(p))
	}
	return strings.Join(parts, " ")
}

func (r *sshRunner) rsync(ctx context.Context, log func(string), src, dst string, extra ...string) error {
	sshE := r.sshRemoteShell()
	argv := []string{"rsync", "-e", sshE, "-az"}
	argv = append(argv, extra...)
	argv = append(argv, src, dst)
	operation := func() error { return runEnv(ctx, log, r.env, argv...) }
	err := retrySSHHandshake(ctx, log, operation)
	if err == nil {
		return nil
	}
	repaired, repairErr := r.repairAfterAuthFailure(log, err)
	if repairErr != nil || !repaired {
		cause := repairErrOrOriginal(repairErr, err)
		if alt := r.directFallback(log, cause); alt != nil {
			return alt.rsync(ctx, log, src, dst, extra...)
		}
		return cause
	}
	log("SSH 密钥已自动修复，正在重试文件同步…")
	if retryErr := retrySSHHandshake(ctx, log, operation); retryErr != nil {
		if alt := r.directFallback(log, retryErr); alt != nil {
			return alt.rsync(ctx, log, src, dst, extra...)
		}
		return retryErr
	}
	return nil
}

func (r *sshRunner) repairAfterAuthFailure(log func(string), cause error) (bool, error) {
	if !sshutil.IsAuthFailure(cause) {
		return false, nil
	}
	if r.server.AuthType != "key" || r.server.Password == "" {
		return false, &sshutil.AuthFailureError{
			Msg: "SSH 认证失败，保存的密码可能已变更；请更新服务器密码后重试",
			Err: cause,
		}
	}
	if log != nil {
		log("SSH 密钥认证失败，正在使用保存的密码自动重装面板密钥…")
	}
	keyPath := r.server.AuthValue
	if keyPath == "" {
		keyPath = sshutil.DefaultKeyPath
	}
	keyPath, err := sshutil.EnsurePanelKey(keyPath)
	if err != nil {
		return false, &sshutil.AuthFailureError{Msg: "自动修复 SSH 密钥失败", Err: err}
	}
	if err := sshutil.InstallPublicKey(r.server, keyPath); err != nil {
		return false, &sshutil.AuthFailureError{
			Msg: "SSH 认证失败，自动重装密钥未成功；保存的密码可能已变更",
			Err: err,
		}
	}
	return true, nil
}

func repairErrOrOriginal(repairErr, original error) error {
	if repairErr != nil {
		return repairErr
	}
	if sshutil.IsAuthFailure(original) {
		return &sshutil.AuthFailureError{Msg: "SSH 认证失败", Err: original}
	}
	return original
}

func runEnv(ctx context.Context, log func(string), env []string, argv ...string) error {
	log("$ " + redactArgv(argv))
	cmd := exec.CommandContext(ctx, argv[0], argv[1:]...)
	if len(env) > 0 {
		cmd.Env = env
	}
	var buf bytes.Buffer
	cmd.Stdout = &buf
	cmd.Stderr = &buf
	err := cmd.Run()
	out := strings.TrimRight(buf.String(), "\n")
	if out != "" {
		for _, line := range strings.Split(out, "\n") {
			log(line)
		}
	}
	if err != nil && out != "" {
		return fmt.Errorf("%w: %s", err, out)
	}
	return err
}

func redactArgv(argv []string) string {
	out := make([]string, len(argv))
	copy(out, argv)
	for i := 0; i < len(out)-1; i++ {
		if out[i] == "-p" && i > 0 && out[i-1] == "sshpass" {
			out[i+1] = "***"
		}
	}
	return strings.Join(out, " ")
}

func ensureSlash(p string) string {
	if strings.HasSuffix(p, "/") {
		return p
	}
	return p + "/"
}

func shellQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'"
}

func stageConf(body string) (string, error) {
	f, err := os.CreateTemp("", "ssp-deploy-conf-*")
	if err != nil {
		return "", err
	}
	_, writeErr := f.WriteString(body)
	closeErr := f.Close()
	if writeErr != nil {
		os.Remove(f.Name())
		return "", writeErr
	}
	if closeErr != nil {
		os.Remove(f.Name())
		return "", closeErr
	}
	return f.Name(), nil
}
