package deploy

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
)

func ManualSSLDir(site string) string { return "/etc/nginx/ssl/" + site }

// Manual certificates are part of the master copy, so ordinary deployment can restore them too.
func syncManualCert(ctx context.Context, opt Options, log func(string)) error {
	dir := filepath.Join(opt.SitesRoot, opt.SiteName, "ssl")
	if _, err := os.Stat(filepath.Join(dir, ".manual")); os.IsNotExist(err) {
		return nil
	} else if err != nil {
		return err
	}
	runner, err := NewRunner(opt.Server)
	if err != nil {
		return err
	}
	remote := ManualSSLDir(opt.SiteName)
	if err := runner.Run(ctx, log, "install -d -m 700 "+shellQuote(remote)); err != nil {
		return err
	}
	for _, file := range []struct {
		name string
		mode int
	}{{"fullchain.pem", 0644}, {"privkey.pem", 0600}} {
		body, err := os.ReadFile(filepath.Join(dir, file.name))
		if err != nil {
			return fmt.Errorf("manual certificate %s: %w", file.name, err)
		}
		// Do not include PEM/private-key contents in operation logs.
		if err := writeRemoteFile(ctx, runner, remote+"/"+file.name, string(body), file.mode, func(string) {}); err != nil {
			return fmt.Errorf("upload certificate %s: %w", file.name, err)
		}
	}
	log("manual certificate synchronized")
	return nil
}
