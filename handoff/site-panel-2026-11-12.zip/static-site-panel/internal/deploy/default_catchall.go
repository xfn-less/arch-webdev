package deploy

import (
	"context"
	"encoding/base64"
	"fmt"
	"strings"

	"github.com/xfn/static-site-panel/internal/store"
)

// RemoteDefaultCatchAll is the fixed unknown-Host catch-all on every target.
const RemoteDefaultCatchAll = "/etc/nginx/conf.d/00-ssp-default.conf"

const defaultCatchAllHTTP = `server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    return 444;
}
`

const defaultCatchAllHTTPSReject = `server {
    listen 443 ssl default_server;
    listen [::]:443 ssl default_server;
    server_name _;
    ssl_reject_handshake on;
}
`

const defaultCatchAllHTTPS444 = `server {
    listen 443 ssl default_server;
    listen [::]:443 ssl default_server;
    server_name _;
    return 444;
}
`

// EnsureDefaultCatchAll writes 00-ssp-default.conf (444 / ssl_reject_handshake),
// clears competing default_server flags, nginx -t, and reloads when needed.
func EnsureDefaultCatchAll(ctx context.Context, s store.Server, log func(string)) error {
	runner, err := NewRunner(s)
	if err != nil {
		return err
	}
	return ensureDefaultCatchAllRunner(ctx, runner, log)
}

func ensureDefaultCatchAllRunner(ctx context.Context, runner *Runner, log func(string)) error {
	if log != nil {
		log("ensure unknown-host catch-all " + RemoteDefaultCatchAll)
	}
	b64 := base64.StdEncoding.EncodeToString([]byte(defaultCatchAllInstallScript()))
	return runner.Run(ctx, log, "echo "+shellQuote(b64)+" | base64 -d | bash")
}

func ensureDefaultCatchAllSSH(ctx context.Context, r *sshRunner, target string, log func(string)) error {
	if log != nil {
		log("ensure unknown-host catch-all " + RemoteDefaultCatchAll)
	}
	b64 := base64.StdEncoding.EncodeToString([]byte(defaultCatchAllInstallScript()))
	return r.run(ctx, log, target, "echo "+shellQuote(b64)+" | base64 -d | bash")
}

func defaultCatchAllInstallScript() string {
	httpB64 := base64.StdEncoding.EncodeToString([]byte(defaultCatchAllHTTP))
	rejectB64 := base64.StdEncoding.EncodeToString([]byte(defaultCatchAllHTTPSReject))
	fallbackB64 := base64.StdEncoding.EncodeToString([]byte(defaultCatchAllHTTPS444))
	return fmt.Sprintf(`set -euo pipefail
CONF_DIR=/etc/nginx/conf.d
DEST=%s
mkdir -p "$CONF_DIR"

# Debian stock site often owns default_server — remove so ours wins.
rm -f /etc/nginx/sites-enabled/default

strip_default() {
  local f
  for f in "$CONF_DIR"/*.conf /etc/nginx/sites-enabled/*; do
    [ -e "$f" ] || continue
    [ "$(basename "$f")" = "00-ssp-default.conf" ] && continue
    if grep -q 'default_server' "$f" 2>/dev/null; then
      sed -i 's/[[:space:]]*default_server//g' "$f"
    fi
  done
}
strip_default

HTTP_B64=%s
REJECT_B64=%s
FALLBACK_B64=%s
HTTP=$(printf '%%s' "$HTTP_B64" | base64 -d)
REJECT=$(printf '%%s' "$REJECT_B64" | base64 -d)
FALLBACK=$(printf '%%s' "$FALLBACK_B64" | base64 -d)

write_body() {
  { printf '%%s' "$HTTP"; printf '\n'; printf '%%s' "$1"; } >"$DEST"
}

reload_nginx() {
  if systemctl is-active --quiet panel-nginx 2>/dev/null; then
    systemctl reload panel-nginx || nginx -s reload
  else
    systemctl reload nginx 2>/dev/null || service nginx reload 2>/dev/null || nginx -s reload
  fi
}

want=$(printf '%%s%%s' "$HTTP" "$REJECT")
if [ -f "$DEST" ] && [ "$(cat "$DEST")" = "$want" ] && nginx -t >/dev/null 2>&1; then
  echo "ssp-default: unchanged"
else
  write_body "$REJECT"
  if ! nginx -t >/dev/null 2>&1; then
    write_body "$FALLBACK"
    nginx -t
  fi
  reload_nginx
  echo "ssp-default: installed"
fi
`, shellQuote(RemoteDefaultCatchAll), shellQuote(httpB64), shellQuote(rejectB64), shellQuote(fallbackB64))
}

// DefaultCatchAllSnippet is exported for tests / docs.
func DefaultCatchAllSnippet() string {
	return strings.TrimSpace(defaultCatchAllHTTP + "\n" + defaultCatchAllHTTPSReject)
}
