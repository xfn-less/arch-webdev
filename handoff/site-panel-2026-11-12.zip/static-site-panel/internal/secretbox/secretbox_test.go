package secretbox

import (
	"os"
	"path/filepath"
	"testing"
)

func TestRoundTripKeyReuseAndWrongKey(t *testing.T) {
	path := filepath.Join(t.TempDir(), "ssh.aes")
	box, err := LoadOrCreate(path)
	if err != nil {
		t.Fatal(err)
	}
	original, _ := os.ReadFile(path)
	sealed := box.Seal("test-password-中文")
	if sealed == "test-password-中文" {
		t.Fatal("password stored in plaintext")
	}
	same, err := LoadOrCreate(path)
	if err != nil {
		t.Fatal(err)
	}
	got, err := same.Open(sealed)
	if err != nil || got != "test-password-中文" {
		t.Fatalf("%q %v", got, err)
	}
	after, _ := os.ReadFile(path)
	if string(after) != string(original) {
		t.Fatal("opening replaced key")
	}
	other, err := LoadOrCreate(filepath.Join(t.TempDir(), "other.aes"))
	if err != nil {
		t.Fatal(err)
	}
	if _, err := other.Open(sealed); err == nil {
		t.Fatal("wrong key accepted")
	}
	for _, bad := range []string{"plaintext", "enc:v1:!", "enc:v1:AA"} {
		if _, err := box.Open(bad); err == nil {
			t.Fatal("invalid stored secret accepted")
		}
	}
}
func TestCorruptExistingKeyIsNotReplaced(t *testing.T) {
	path := filepath.Join(t.TempDir(), "ssh.aes")
	os.WriteFile(path, []byte("damaged"), 0600)
	if _, err := LoadOrCreate(path); err == nil {
		t.Fatal("corrupt key accepted")
	}
	got, _ := os.ReadFile(path)
	if string(got) != "damaged" {
		t.Fatal("corrupt key overwritten; recovery evidence lost")
	}
}
