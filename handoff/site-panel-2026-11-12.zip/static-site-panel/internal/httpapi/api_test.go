package httpapi

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/xfn/static-site-panel/internal/auth"
	"github.com/xfn/static-site-panel/internal/store"
	"github.com/xfn/static-site-panel/web"
)

type apiFixture struct {
	handler           http.Handler
	st                *store.Store
	root, token, csrf string
	t                 *testing.T
}

func TestUploadConflictPreflightAndPolicies(t *testing.T) {
	f := newRegressionFixture(t)
	base := filepath.Join(f.root, "demo", "www")
	if err := os.MkdirAll(base, 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(base, "index.html"), []byte("old"), 0644); err != nil {
		t.Fatal(err)
	}
	code, result := f.req("POST", "/api/sites/demo/upload-conflicts", map[string]any{
		"dir": "www", "names": []string{"index.html", "new.html"},
	}, true, f.csrf)
	if code != http.StatusOK {
		t.Fatalf("preflight=%d %v", code, result)
	}
	conflicts, ok := result["conflicts"].([]any)
	if !ok || len(conflicts) != 1 || conflicts[0].(map[string]any)["name"] != "index.html" {
		t.Fatalf("unexpected conflicts: %#v", result["conflicts"])
	}

	upload := func(policy string) (int, map[string]any) {
		var body bytes.Buffer
		form := multipart.NewWriter(&body)
		_ = form.WriteField("dir", "www")
		_ = form.WriteField("conflict", policy)
		part, err := form.CreateFormFile("file", "index.html")
		if err != nil {
			t.Fatal(err)
		}
		_, _ = part.Write([]byte("new"))
		if err := form.Close(); err != nil {
			t.Fatal(err)
		}
		r := httptest.NewRequest("POST", "/api/sites/demo/upload", &body)
		r.Header.Set("Content-Type", form.FormDataContentType())
		r.Header.Set("X-CSRF", f.csrf)
		r.AddCookie(&http.Cookie{Name: "ssp_session", Value: f.token})
		w := httptest.NewRecorder()
		f.handler.ServeHTTP(w, r)
		out := map[string]any{}
		_ = json.Unmarshal(w.Body.Bytes(), &out)
		return w.Code, out
	}
	code, _ = upload("reject")
	if code != http.StatusConflict {
		t.Fatalf("default conflicting upload status=%d, want 409", code)
	}
	code, result = upload("rename")
	if code != http.StatusOK || result["path"] != "www/index (2).html" {
		t.Fatalf("renamed upload=%d %v", code, result)
	}
	old, _ := os.ReadFile(filepath.Join(base, "index.html"))
	copy, _ := os.ReadFile(filepath.Join(base, "index (2).html"))
	if string(old) != "old" || string(copy) != "new" {
		t.Fatalf("old=%q copy=%q", old, copy)
	}
}

func newRegressionFixture(t *testing.T) *apiFixture {
	t.Helper()
	root := t.TempDir()
	st, err := store.Open(filepath.Join(root, "data/panel.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { st.Close() })
	manager := auth.New(st, false)
	if err := manager.SetPassword(context.Background(), "test-only-password"); err != nil {
		t.Fatal(err)
	}
	login, err := manager.Login(context.Background(), httptest.NewRequest("POST", "/api/login", nil), "test-only-password", true, false)
	if err != nil {
		t.Fatal(err)
	}
	tpl, _ := os.ReadFile("../../templates/spa.nginx.conf")
	sites := filepath.Join(root, "sites")
	os.MkdirAll(sites, 0755)
	return &apiFixture{handler: New(Config{Frontend: web.FS, Store: st, Auth: manager, SitesRoot: sites, NginxTemplate: string(tpl)}), st: st, root: sites, token: login.Token, csrf: login.CSRF, t: t}
}
func (f *apiFixture) req(method, path string, body any, authorized bool, csrf string) (int, map[string]any) {
	f.t.Helper()
	var raw []byte
	if body != nil {
		raw, _ = json.Marshal(body)
	}
	r := httptest.NewRequest(method, path, bytes.NewReader(raw))
	r.Header.Set("Content-Type", "application/json")
	if authorized {
		r.AddCookie(&http.Cookie{Name: "ssp_session", Value: f.token})
	}
	r.Header.Set("X-CSRF", csrf)
	w := httptest.NewRecorder()
	f.handler.ServeHTTP(w, r)
	out := map[string]any{}
	json.Unmarshal(w.Body.Bytes(), &out)
	return w.Code, out
}
func TestRegressionAPIAuthAndCSRF(t *testing.T) {
	f := newRegressionFixture(t)
	for _, path := range []string{"/api/tree", "/api/servers", "/api/sites/demo/conf", "/api/servers/1/term"} {
		code, _ := f.req("GET", path, nil, false, "")
		if code != 401 {
			t.Errorf("anonymous %s = %d", path, code)
		}
	}
	codeApk, _ := f.req("POST", "/api/sites/demo/apk-obfuscate", map[string]any{"enabled": true}, false, "")
	if codeApk != 401 {
		t.Errorf("anonymous apk-obfuscate = %d", codeApk)
	}
	codeDis, _ := f.req("POST", "/api/sites/demo/disabled", map[string]any{"disabled": true}, false, "")
	if codeDis != 401 {
		t.Errorf("anonymous disabled = %d", codeDis)
	}
	code, _ := f.req("POST", "/api/servers", map[string]any{"host": "test.invalid"}, true, "wrong")
	if code != 403 {
		t.Fatalf("bad csrf=%d", code)
	}
	servers, _ := f.st.ListServers(context.Background())
	if len(servers) != 0 {
		t.Fatal("CSRF mutated database")
	}
}
func TestRegressionAPISiteAndFileLifecycle(t *testing.T) {
	f := newRegressionFixture(t)
	ctx := context.Background()
	server, err := f.st.UpsertServer(ctx, store.Server{Name: "fixture", Host: "dummy.invalid"})
	if err != nil {
		t.Fatal(err)
	}
	code, site := f.req("POST", "/api/sites", map[string]any{"title": "sample", "serverId": server.ID}, true, f.csrf)
	if code != 200 {
		t.Fatal(code, site)
	}
	name := site["name"].(string)
	code, _ = f.req("PUT", "/api/sites/"+name+"/domains", map[string]any{"domains": []string{"a.example.test", "b.example.test"}}, true, f.csrf)
	if code != 200 {
		t.Fatal(code)
	}
	code, _ = f.req("PUT", "/api/sites/"+name+"/file", map[string]any{"path": "www/assets/index.txt", "content": "preserve me"}, true, f.csrf)
	if code != 200 {
		t.Fatal(code)
	}
	code, _ = f.req("PUT", "/api/sites/"+name+"/file", map[string]any{"path": "../outside", "content": "bad"}, true, f.csrf)
	if code != 400 {
		t.Fatalf("path escape=%d", code)
	}
	outside := t.TempDir()
	os.Symlink(outside, filepath.Join(f.root, name, "www/link"))
	code, _ = f.req("PUT", "/api/sites/"+name+"/file", map[string]any{"path": "www/link/new.txt", "content": "bad"}, true, f.csrf)
	if code != 400 {
		t.Fatalf("symlink escape=%d", code)
	}
	os.Remove(filepath.Join(f.root, name, "www/link"))
	code, _ = f.req("POST", "/api/sites/"+name+"/rename-path", map[string]any{"from": "www/assets/index.txt", "to": "www/assets/renamed.txt"}, true, f.csrf)
	if code != 200 {
		t.Fatal(code)
	}
	code, _ = f.req("POST", "/api/sites/"+name+"/rename", map[string]any{"title": "renamed display"}, true, f.csrf)
	if code != 200 {
		t.Fatal(code)
	}
	body, err := os.ReadFile(filepath.Join(f.root, name, "www/assets/renamed.txt"))
	if err != nil || string(body) != "preserve me" {
		t.Fatal("file lost after rename", err)
	}
	code, copied := f.req("POST", "/api/sites/"+name+"/copy", map[string]any{"title": "copy", "serverId": server.ID}, true, f.csrf)
	if code != 200 {
		t.Fatal(code, copied)
	}
	copyName := copied["name"].(string)
	body, err = os.ReadFile(filepath.Join(f.root, copyName, "www/assets/renamed.txt"))
	if err != nil || string(body) != "preserve me" {
		t.Fatal("copy lost data", err)
	}
	code, dis := f.req("POST", "/api/sites/"+name+"/disabled", map[string]any{"disabled": true}, true, f.csrf)
	if code != 502 {
		t.Fatalf("bound disable against dummy host want 502 got %d %v", code, dis)
	}
	got, err := f.st.GetSiteByName(ctx, name)
	if err != nil || got.Disabled {
		t.Fatal("failed remote disable must not flip flag", got, err)
	}
	code, _ = f.req("POST", "/api/sites/"+name, map[string]any{"serverId": 0}, true, f.csrf)
	if code != 200 {
		t.Fatal(code)
	}
	code, dis = f.req("POST", "/api/sites/"+name+"/disabled", map[string]any{"disabled": true}, true, f.csrf)
	if code != 200 || dis["ok"] != true {
		t.Fatal("unbind disable", code, dis)
	}
	got, err = f.st.GetSiteByName(ctx, name)
	if err != nil || !got.Disabled {
		t.Fatal("disabled flag", got, err)
	}
	code, _ = f.req("POST", "/api/sites/"+name, map[string]any{"serverId": server.ID}, true, f.csrf)
	if code != 200 {
		t.Fatal(code)
	}
	code, dep := f.req("POST", "/api/sites/"+name+"/deploy", map[string]any{}, true, f.csrf)
	if code != 400 || !strings.Contains(fmt.Sprint(dep["error"]), "disabled") {
		t.Fatalf("deploy while disabled=%d %v", code, dep)
	}
	code, _ = f.req("POST", "/api/sites/"+name, map[string]any{"serverId": 0}, true, f.csrf)
	if code != 200 {
		t.Fatal(code)
	}
	code, dis = f.req("POST", "/api/sites/"+name+"/disabled", map[string]any{"disabled": false}, true, f.csrf)
	if code != 200 || dis["ok"] != true {
		t.Fatal("enable unbound", code, dis)
	}
	got, err = f.st.GetSiteByName(ctx, name)
	if err != nil || got.Disabled {
		t.Fatal("enabled flag", got, err)
	}
	for _, n := range []string{name, copyName} {
		code, _ = f.req("POST", "/api/sites/"+n, map[string]any{"serverId": 0}, true, f.csrf)
		if code != 200 {
			t.Fatal(code)
		}
		code, _ = f.req("DELETE", "/api/sites/"+n, nil, true, f.csrf)
		if code != 200 {
			t.Fatal(code)
		}
		if _, err := os.Stat(filepath.Join(f.root, n)); !os.IsNotExist(err) {
			t.Fatal("delete left directory", n)
		}
	}
}
func TestRegressionAPIMissingServerAndMalformedInput(t *testing.T) {
	f := newRegressionFixture(t)
	code, _ := f.req("POST", "/api/sites", map[string]any{"title": "bad", "serverId": 99999}, true, f.csrf)
	if code != 400 {
		t.Fatal(code)
	}
	code, _ = f.req("POST", "/api/sites", map[string]any{"serverId": 0}, true, f.csrf)
	if code != 400 {
		t.Fatal(code)
	}
	code, _ = f.req("GET", "/api/sites/missing/conf", nil, true, f.csrf)
	if code != 404 {
		t.Fatal(code)
	}
}

func TestBothConfSaveRoutesRejectInvalidConfig(t *testing.T) {
	f := newRegressionFixture(t)
	if err := os.MkdirAll(filepath.Join(f.root, "demo", "www"), 0755); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(f.root, "demo", "nginx.conf")
	original := "server {\nlisten 8080;\n}\n"
	os.WriteFile(path, []byte(original), 0644)
	for _, endpoint := range []string{"conf", "file"} {
		code, body := f.req("PUT", "/api/sites/demo/"+endpoint, map[string]any{"path": "nginx.conf", "content": "server {\nserver_name ;\n}\n", "conf": "server {\nserver_name ;\n}\n"}, true, f.csrf)
		if code != 400 {
			t.Errorf("%s accepted invalid conf: %d %v", endpoint, code, body)
		}
		got, _ := os.ReadFile(path)
		if string(got) != original {
			t.Errorf("%s damaged master conf", endpoint)
		}
	}
}

func TestPendingDeployFlag(t *testing.T) {
	f := newRegressionFixture(t)
	ctx := context.Background()
	server, err := f.st.UpsertServer(ctx, store.Server{Name: "fixture", Host: "dummy.invalid"})
	if err != nil {
		t.Fatal(err)
	}
	code, created := f.req("POST", "/api/sites", map[string]any{"title": "pending-demo", "serverId": server.ID}, true, f.csrf)
	if code != 200 {
		t.Fatal(code, created)
	}
	name := created["name"].(string)
	if created["pendingDeploy"] != true {
		t.Fatalf("new site should need deploy: %v", created)
	}
	code, write := f.req("PUT", "/api/sites/"+name+"/file", map[string]any{"path": "www/hi.txt", "content": "x"}, true, f.csrf)
	if code != 200 || write["pendingDeploy"] != true {
		t.Fatalf("write should mark pending: %d %v", code, write)
	}
	code, site := f.req("GET", "/api/sites/"+name, nil, true, f.csrf)
	if code != 200 {
		t.Fatal(code, site)
	}
	meta, _ := site["meta"].(map[string]any)
	if meta == nil || meta["pendingDeploy"] != true {
		t.Fatalf("getSite meta.pendingDeploy: %v", site)
	}
	if _, err := f.st.SetSitePendingDeploy(ctx, name, false); err != nil {
		t.Fatal(err)
	}
	code, site = f.req("GET", "/api/sites/"+name, nil, true, f.csrf)
	meta, _ = site["meta"].(map[string]any)
	if code != 200 || meta == nil || meta["pendingDeploy"] != false {
		t.Fatalf("cleared pending should stick: %d %v", code, site)
	}
}

func TestBindingChangeAndFailedDeployStayPending(t *testing.T) {
	f := newRegressionFixture(t)
	ctx := context.Background()
	first, _ := f.st.UpsertServer(ctx, store.Server{Name: "first", Host: "fixture.invalid"})
	second, _ := f.st.UpsertServer(ctx, store.Server{Name: "second", Host: "fixture.invalid"})
	code, created := f.req("POST", "/api/sites", map[string]any{"title": "binding", "serverId": first.ID}, true, f.csrf)
	if code != 200 {
		t.Fatal(code, created)
	}
	name := created["name"].(string)
	if _, err := f.st.SetSitePendingDeploy(ctx, name, false); err != nil {
		t.Fatal(err)
	}
	code, same := f.req("POST", "/api/sites/"+name, map[string]any{"serverId": first.ID, "note": "note only"}, true, f.csrf)
	if code != 200 || same["pendingDeploy"] != false {
		t.Fatal("note should not need deploy", code, same)
	}
	code, changed := f.req("POST", "/api/sites/"+name, map[string]any{"serverId": second.ID}, true, f.csrf)
	if code != 200 || changed["pendingDeploy"] != true {
		t.Fatal("new destination needs deploy", code, changed)
	}
	code, _ = f.req("POST", "/api/sites/"+name, map[string]any{"serverId": 999999}, true, f.csrf)
	meta, _ := f.st.GetSiteByName(ctx, name)
	if code != 400 || meta.ServerID != second.ID {
		t.Fatal("invalid binding must preserve destination", code, meta.ServerID)
	}
	if _, err := f.st.SetSitePendingDeploy(ctx, name, false); err != nil {
		t.Fatal(err)
	}
	bin := t.TempDir()
	if err := os.WriteFile(filepath.Join(bin, "ssh"), []byte("#!/bin/sh\nexit 1\n"), 0755); err != nil {
		t.Fatal(err)
	}
	t.Setenv("PATH", bin+string(os.PathListSeparator)+os.Getenv("PATH"))
	code, failed := f.req("POST", "/api/sites/"+name+"/deploy", nil, true, f.csrf)
	meta, _ = f.st.GetSiteByName(ctx, name)
	if code != 200 || failed["ok"] != false || !meta.PendingDeploy {
		t.Fatal("failed deploy must persist reminder", code, failed, meta.PendingDeploy)
	}
}
