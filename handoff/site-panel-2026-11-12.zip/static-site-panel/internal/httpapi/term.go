package httpapi

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"time"

	"github.com/coder/websocket"

	"github.com/xfn/static-site-panel/internal/sshterm"
	"github.com/xfn/static-site-panel/internal/store"
)

type termMsg struct {
	Type string `json:"type"` // resize | data (binary preferred for data)
	Cols int    `json:"cols,omitempty"`
	Rows int    `json:"rows,omitempty"`
	Data string `json:"data,omitempty"`
}

func (a *API) serverTermWS(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if id <= 0 {
		writeErr(w, 400, "bad server id")
		return
	}
	srv, err := a.cfg.Store.GetServer(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, 404, "server not found")
		return
	}
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}

	c, err := websocket.Accept(w, r, &websocket.AcceptOptions{
		CompressionMode: websocket.CompressionDisabled,
	})
	if err != nil {
		return
	}
	defer c.Close(websocket.StatusNormalClosure, "")

	ctx, cancel := context.WithCancel(r.Context())
	defer cancel()
	c.SetReadLimit(256 << 10)

	client, err := sshterm.Dial(srv)
	if err != nil {
		_ = writeTermErr(ctx, c, "ssh dial: "+err.Error())
		return
	}
	defer client.Close()

	cols, rows := 120, 36
	sess, stdin, stdout, err := sshterm.StartShell(client, cols, rows)
	if err != nil {
		_ = writeTermErr(ctx, c, "ssh shell: "+err.Error())
		return
	}
	defer sess.Close()

	errCh := make(chan error, 2)

	// ssh → ws
	go func() {
		buf := make([]byte, 32*1024)
		for {
			n, readErr := stdout.Read(buf)
			if n > 0 {
				if werr := c.Write(ctx, websocket.MessageBinary, buf[:n]); werr != nil {
					errCh <- werr
					return
				}
			}
			if readErr != nil {
				errCh <- readErr
				return
			}
		}
	}()

	// ws → ssh
	go func() {
		for {
			typ, data, readErr := c.Read(ctx)
			if readErr != nil {
				errCh <- readErr
				return
			}
			if typ == websocket.MessageBinary {
				if _, werr := stdin.Write(data); werr != nil {
					errCh <- werr
					return
				}
				continue
			}
			var msg termMsg
			if json.Unmarshal(data, &msg) != nil {
				// treat as raw text input
				if _, werr := stdin.Write(data); werr != nil {
					errCh <- werr
					return
				}
				continue
			}
			switch msg.Type {
			case "resize":
				if msg.Cols > 0 && msg.Rows > 0 {
					_ = sess.WindowChange(msg.Rows, msg.Cols)
				}
			case "data":
				if msg.Data != "" {
					if _, werr := stdin.Write([]byte(msg.Data)); werr != nil {
						errCh <- werr
						return
					}
				}
			}
		}
	}()

	select {
	case <-ctx.Done():
	case <-errCh:
	case <-time.After(4 * time.Hour):
	}
	cancel()
}

func writeTermErr(ctx context.Context, c *websocket.Conn, msg string) error {
	payload, _ := json.Marshal(termMsg{Type: "error", Data: msg})
	return c.Write(ctx, websocket.MessageText, payload)
}
