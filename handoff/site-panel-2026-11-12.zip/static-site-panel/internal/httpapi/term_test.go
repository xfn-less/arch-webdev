package httpapi

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/coder/websocket"
	"github.com/xfn/static-site-panel/internal/store"
	"golang.org/x/crypto/ssh"
)

func TestTerminalWebSocketLocalSSH(t *testing.T) {
	t.Setenv("HOME", t.TempDir())
	_, private, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	signer, err := ssh.NewSignerFromKey(private)
	if err != nil {
		t.Fatal(err)
	}
	cfg := &ssh.ServerConfig{PasswordCallback: func(_ ssh.ConnMetadata, password []byte) (*ssh.Permissions, error) {
		if string(password) != "test-only" {
			return nil, fmt.Errorf("bad password")
		}
		return nil, nil
	}}
	cfg.AddHostKey(signer)
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer listener.Close()
	done := make(chan struct{})
	resize := make(chan bool, 4)
	go func() {
		defer close(done)
		conn, err := listener.Accept()
		if err != nil {
			return
		}
		defer conn.Close()
		client, channels, requests, err := ssh.NewServerConn(conn, cfg)
		if err != nil {
			return
		}
		defer client.Close()
		go ssh.DiscardRequests(requests)
		for next := range channels {
			channel, requests, err := next.Accept()
			if err != nil {
				return
			}
			go func() {
				defer channel.Close()
				for request := range requests {
					switch request.Type {
					case "pty-req":
						request.Reply(true, nil)
					case "window-change":
						resize <- true
					case "shell":
						request.Reply(true, nil)
						go func() { io.Copy(channel, channel); channel.Close() }()
					default:
						request.Reply(false, nil)
					}
				}
			}()
		}
	}()
	host, rawPort, _ := net.SplitHostPort(listener.Addr().String())
	port, _ := strconv.Atoi(rawPort)
	f := newRegressionFixture(t)
	srv, err := f.st.UpsertServer(context.Background(), store.Server{Name: "local SSH fixture", Host: host, Port: port, User: "test", AuthType: "password", Password: "test-only"})
	if err != nil {
		t.Fatal(err)
	}
	panel := httptest.NewServer(f.handler)
	defer panel.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	target := "ws" + strings.TrimPrefix(panel.URL, "http") + fmt.Sprintf("/api/servers/%d/term", srv.ID)
	headers := http.Header{"Cookie": []string{"ssp_session=" + f.token}, "Origin": []string{"https://unrelated.example"}}
	bad, response, err := websocket.Dial(ctx, target, &websocket.DialOptions{HTTPHeader: headers})
	if bad != nil {
		bad.CloseNow()
	}
	if err == nil || response == nil || response.StatusCode != 403 {
		t.Fatal("cross-origin terminal accepted", err)
	}
	headers.Set("Origin", panel.URL)
	ws, _, err := websocket.Dial(ctx, target, &websocket.DialOptions{HTTPHeader: headers})
	if err != nil {
		t.Fatal(err)
	}
	defer ws.CloseNow()
	if err := ws.Write(ctx, websocket.MessageText, []byte(`{"type":"resize","cols":90,"rows":28}`)); err != nil {
		t.Fatal(err)
	}
	if err := ws.Write(ctx, websocket.MessageBinary, []byte("safe-local-echo\n")); err != nil {
		t.Fatal(err)
	}
	_, body, err := ws.Read(ctx)
	if err != nil || !strings.Contains(string(body), "safe-local-echo") {
		t.Fatalf("terminal echo=%q err=%v", body, err)
	}
	select {
	case <-resize:
	case <-ctx.Done():
		t.Fatal("resize not forwarded")
	}
	ws.CloseNow()
	select {
	case <-done:
	case <-ctx.Done():
		t.Fatal("closed websocket leaked SSH connection")
	}
}
