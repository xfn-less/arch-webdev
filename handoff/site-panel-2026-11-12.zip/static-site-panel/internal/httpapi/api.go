package httpapi

import (
	"context"
	"encoding/csv"
	"encoding/json"
	"errors"
	"io"
	"io/fs"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/xfn/static-site-panel/internal/auth"
	"github.com/xfn/static-site-panel/internal/billing"
	"github.com/xfn/static-site-panel/internal/confcheck"
	"github.com/xfn/static-site-panel/internal/confmark"
	"github.com/xfn/static-site-panel/internal/deploy"
	"github.com/xfn/static-site-panel/internal/dnscheck"
	"github.com/xfn/static-site-panel/internal/lizhi"
	"github.com/xfn/static-site-panel/internal/sitelock"
	"github.com/xfn/static-site-panel/internal/sitesfs"
	"github.com/xfn/static-site-panel/internal/sshutil"
	"github.com/xfn/static-site-panel/internal/sslcert"
	"github.com/xfn/static-site-panel/internal/store"
)

type Config struct {
	Frontend          fs.FS
	Store             *store.Store
	Auth              *auth.Manager
	SitesRoot         string
	NginxTemplate     string // fallback body if path unread
	NginxTemplatePath string // preferred: re-read on each new site
	Billing           *billing.Service
}

type API struct {
	cfg Config
}

func New(cfg Config) http.Handler {
	a := &API{cfg: cfg}
	mux := http.NewServeMux()
	mux.HandleFunc("GET /api/status", a.status)
	mux.HandleFunc("GET /api/captcha", a.captcha)
	mux.HandleFunc("POST /api/setup", a.setup)
	mux.HandleFunc("POST /api/login", a.login)
	mux.HandleFunc("POST /api/logout", a.withAuth(a.logout))
	mux.HandleFunc("POST /api/password", a.withAuth(a.changePassword))
	mux.HandleFunc("GET /api/tree", a.withAuth(a.tree))
	mux.HandleFunc("GET /api/servers", a.withAuth(a.listServers))
	mux.HandleFunc("POST /api/servers", a.withAuth(a.saveServer))
	mux.HandleFunc("DELETE /api/servers/{id}", a.withAuth(a.deleteServer))
	mux.HandleFunc("POST /api/servers/{id}/install-key", a.withAuth(a.installServerKey))
	mux.HandleFunc("POST /api/servers/{id}/install-nginx", a.withAuth(a.installServerNginx))
	mux.HandleFunc("GET /api/servers/{id}/nginx-status", a.withAuth(a.nginxStatus))
	mux.HandleFunc("GET /api/servers/{id}/term", a.withAuth(a.serverTermWS))
	mux.HandleFunc("GET /api/sites/{name}", a.withAuth(a.getSite))
	mux.HandleFunc("POST /api/sites", a.withAuth(a.createSite))
	mux.HandleFunc("POST /api/sites/{name}", a.withAuth(a.saveSite))
	mux.HandleFunc("POST /api/sites/{name}/copy", a.withAuth(a.copySite))
	mux.HandleFunc("POST /api/sites/{name}/rename", a.withAuth(a.renameSite))
	mux.HandleFunc("DELETE /api/sites/{name}", a.withAuth(a.deleteSite))
	mux.HandleFunc("GET /api/sites/{name}/conf", a.withAuth(a.getConf))
	mux.HandleFunc("PUT /api/sites/{name}/conf", a.withAuth(a.putConf))
	mux.HandleFunc("PUT /api/sites/{name}/domains", a.withAuth(a.putDomains))
	mux.HandleFunc("GET /api/sites/{name}/files", a.withAuth(a.listSiteFiles))
	mux.HandleFunc("GET /api/sites/{name}/file", a.withAuth(a.readSiteFile))
	mux.HandleFunc("PUT /api/sites/{name}/file", a.withAuth(a.writeSiteFile))
	mux.HandleFunc("GET /api/sites/{name}/file-history", a.withAuth(a.listSiteFileHistory))
	mux.HandleFunc("GET /api/sites/{name}/file-history/content", a.withAuth(a.readSiteFileHistory))
	mux.HandleFunc("POST /api/sites/{name}/mkdir", a.withAuth(a.mkdirSitePath))
	mux.HandleFunc("POST /api/sites/{name}/touch", a.withAuth(a.touchSiteFile))
	mux.HandleFunc("POST /api/sites/{name}/rename-path", a.withAuth(a.renameSitePath))
	mux.HandleFunc("POST /api/sites/{name}/paste", a.withAuth(a.pasteSitePaths))
	mux.HandleFunc("DELETE /api/sites/{name}/path", a.withAuth(a.deleteSitePath))
	mux.HandleFunc("POST /api/sites/{name}/upload-conflicts", a.withAuth(a.uploadSiteConflicts))
	mux.HandleFunc("POST /api/sites/{name}/upload", a.withAuth(a.uploadSiteFile))
	mux.HandleFunc("GET /api/sites/{name}/download", a.withAuth(a.downloadSiteFile))
	mux.HandleFunc("POST /api/sites/{name}/zip", a.withAuth(a.zipSitePaths))
	mux.HandleFunc("GET /api/sites/{name}/zip-list", a.withAuth(a.listZipSitePath))
	mux.HandleFunc("POST /api/sites/{name}/unzip", a.withAuth(a.unzipSitePath))
	mux.HandleFunc("GET /api/sites/{name}/deploy-diff", a.withAuth(a.deployDiff))
	mux.HandleFunc("POST /api/sites/{name}/deploy", a.withAuth(a.deploySite))
	mux.HandleFunc("POST /api/sites/{name}/apk-obfuscate", a.withAuth(a.setApkObfuscate))
	mux.HandleFunc("POST /api/sites/{name}/disabled", a.withAuth(a.setSiteDisabled))
	mux.HandleFunc("POST /api/sites/{name}/dns-check", a.withAuth(a.dnsCheckSite))
	mux.HandleFunc("POST /api/sites/{name}/ssl-preflight", a.withAuth(a.sslPreflight))
	mux.HandleFunc("GET /api/sites/{name}/ssl-pem", a.withAuth(a.sslPem))
	mux.HandleFunc("POST /api/sites/{name}/ssl", a.withAuth(a.sslSite))
	mux.HandleFunc("POST /api/sites/{name}/ssl-manual", a.withAuth(a.sslManual))
	mux.HandleFunc("GET /api/billing", a.withAuth(a.billingList))
	mux.HandleFunc("POST /api/billing/sync", a.withAuth(a.billingSync))
	mux.HandleFunc("POST /api/billing/sync-failed", a.withAuth(a.billingSyncFailed))
	mux.HandleFunc("GET /api/billing/export", a.withAuth(a.billingExport))
	mux.HandleFunc("POST /api/billing/remind", a.withAuth(a.billingRemind))
	mux.HandleFunc("POST /api/billing/restore", a.withAuth(a.billingRestore))
	mux.HandleFunc("GET /api/billing/accounts", a.withAuth(a.billingGetAccounts))
	mux.HandleFunc("PUT /api/billing/accounts", a.withAuth(a.billingPutAccounts))

	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if strings.HasPrefix(r.URL.Path, "/api/") {
			http.NotFound(w, r)
			return
		}
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}
		path := strings.TrimPrefix(r.URL.Path, "/")
		if path == "" || strings.HasSuffix(path, "/") {
			path = "index.html"
		}
		path = pathClean(path)
		if path == "" || strings.Contains(path, "..") {
			http.NotFound(w, r)
			return
		}
		data, err := fs.ReadFile(cfg.Frontend, path)
		if err != nil {
			data, err = fs.ReadFile(cfg.Frontend, "index.html")
			if err != nil {
				http.NotFound(w, r)
				return
			}
			path = "index.html"
		}
		ctype := contentType(path)
		w.Header().Set("Content-Type", ctype)
		w.Header().Set("Cache-Control", "no-cache")
		if r.Method == http.MethodHead {
			w.WriteHeader(http.StatusOK)
			return
		}
		_, _ = w.Write(data)
	})
	return mux
}

func pathClean(p string) string {
	p = strings.ReplaceAll(p, "\\", "/")
	parts := strings.Split(p, "/")
	out := make([]string, 0, len(parts))
	for _, part := range parts {
		if part == "" || part == "." {
			continue
		}
		if part == ".." {
			if len(out) > 0 {
				out = out[:len(out)-1]
			}
			continue
		}
		out = append(out, part)
	}
	return strings.Join(out, "/")
}

func contentType(path string) string {
	switch {
	case strings.HasSuffix(path, ".html"):
		return "text/html; charset=utf-8"
	case strings.HasSuffix(path, ".js"):
		return "text/javascript; charset=utf-8"
	case strings.HasSuffix(path, ".css"):
		return "text/css; charset=utf-8"
	case strings.HasSuffix(path, ".svg"):
		return "image/svg+xml"
	case strings.HasSuffix(path, ".png"):
		return "image/png"
	case strings.HasSuffix(path, ".ico"):
		return "image/x-icon"
	case strings.HasSuffix(path, ".json"):
		return "application/json"
	case strings.HasSuffix(path, ".woff2"):
		return "font/woff2"
	default:
		return "application/octet-stream"
	}
}

func (a *API) withAuth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		csrf, err := a.cfg.Auth.Authenticate(r)
		if err != nil {
			writeErr(w, http.StatusUnauthorized, "unauthorized")
			return
		}
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			if r.Header.Get("X-CSRF") != csrf {
				writeErr(w, http.StatusForbidden, "csrf")
				return
			}
		}
		w.Header().Set("X-CSRF", csrf)
		next(w, r)
	}
}

func (a *API) status(w http.ResponseWriter, r *http.Request) {
	has, err := a.cfg.Auth.HasPassword(r.Context())
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	authed := false
	csrf := ""
	if c, err := a.cfg.Auth.Authenticate(r); err == nil {
		authed = true
		csrf = c
		w.Header().Set("X-CSRF", csrf)
	}
	writeJSON(w, map[string]any{
		"hasPassword":   has,
		"authenticated": authed,
		"csrf":          csrf,
		"sitesRoot":     a.cfg.SitesRoot,
	})
}

func (a *API) captcha(w http.ResponseWriter, r *http.Request) {
	issue, err := a.cfg.Auth.IssueCaptcha()
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	writeJSON(w, issue)
}

func (a *API) setup(w http.ResponseWriter, r *http.Request) {
	has, err := a.cfg.Auth.HasPassword(r.Context())
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	if has {
		writeErr(w, 400, "already set up")
		return
	}
	var body struct {
		Password     string `json:"password"`
		CaptchaID    string `json:"captchaId"`
		CaptchaNonce int64  `json:"captchaNonce"`
	}
	if err := readJSON(r, &body); err != nil || body.Password == "" {
		writeErr(w, 400, "password required")
		return
	}
	if err := a.cfg.Auth.VerifyCaptcha(body.CaptchaID, body.CaptchaNonce); err != nil {
		writeErr(w, 400, "captcha failed")
		return
	}
	if err := a.cfg.Auth.SetPassword(r.Context(), body.Password); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	res, err := a.cfg.Auth.Login(r.Context(), r, body.Password, true, false)
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	a.cfg.Auth.WriteCookie(w, r, res.Token)
	w.Header().Set("X-CSRF", res.CSRF)
	writeJSON(w, map[string]any{"ok": true, "csrf": res.CSRF})
}

func (a *API) login(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Password     string `json:"password"`
		CaptchaID    string `json:"captchaId"`
		CaptchaNonce int64  `json:"captchaNonce"`
		Kick         bool   `json:"kick"`
		Confirm      bool   `json:"confirm"`
	}
	if err := readJSON(r, &body); err != nil {
		writeErr(w, 400, "bad json")
		return
	}
	// Check proof first without consuming — busy→kick reuses the same PoW.
	if err := a.cfg.Auth.CheckCaptcha(body.CaptchaID, body.CaptchaNonce); err != nil {
		writeErr(w, 401, "captcha failed")
		return
	}
	res, err := a.cfg.Auth.Login(r.Context(), r, body.Password, body.Kick, body.Confirm)
	if errors.Is(err, auth.ErrBusy) {
		writeJSONStatus(w, http.StatusConflict, map[string]any{"busy": true})
		return
	}
	if errors.Is(err, auth.ErrRateLimited) {
		writeJSONStatus(w, http.StatusTooManyRequests, map[string]any{
			"error":       "too many attempts",
			"needConfirm": true,
		})
		return
	}
	if errors.Is(err, auth.ErrBadPassword) {
		_ = a.cfg.Auth.ConsumeCaptcha(body.CaptchaID, body.CaptchaNonce)
		writeErr(w, 401, err.Error())
		return
	}
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	_ = a.cfg.Auth.ConsumeCaptcha(body.CaptchaID, body.CaptchaNonce)
	a.cfg.Auth.WriteCookie(w, r, res.Token)
	w.Header().Set("X-CSRF", res.CSRF)
	writeJSON(w, map[string]any{"ok": true, "csrf": res.CSRF})
}

func (a *API) logout(w http.ResponseWriter, r *http.Request) {
	_ = a.cfg.Auth.Logout(r.Context())
	a.cfg.Auth.ClearCookie(w, r)
	writeJSON(w, map[string]any{"ok": true})
}

func (a *API) changePassword(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Old string `json:"old"`
		New string `json:"new"`
	}
	if err := readJSON(r, &body); err != nil || body.Old == "" || body.New == "" {
		writeErr(w, 400, "old/new required")
		return
	}
	if err := a.cfg.Auth.ChangePassword(r.Context(), body.Old, body.New); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

func publicServer(s store.Server) map[string]any {
	return map[string]any{
		"id":          s.ID,
		"name":        s.Name,
		"host":        s.Host,
		"port":        s.Port,
		"user":        s.User,
		"authType":    s.AuthType,
		"authValue":   s.AuthValue,
		"password":    s.Password, // decrypted; only via authenticated APIs
		"hasPassword": s.Password != "",
		"publicIP":    s.PublicIP,
		"note":        s.Note,
		"viaJump":     s.ViaJump,
	}
}

func publicServers(list []store.Server) []map[string]any {
	out := make([]map[string]any, 0, len(list))
	for _, s := range list {
		out = append(out, publicServer(s))
	}
	return out
}

func (a *API) tree(w http.ResponseWriter, r *http.Request) {
	servers, err := a.cfg.Store.ListServers(r.Context())
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	sitesMeta, err := a.cfg.Store.ListSites(r.Context())
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	metaByName := map[string]store.Site{}
	for _, s := range sitesMeta {
		metaByName[s.Name] = s
	}
	disk, err := sitesfs.List(a.cfg.SitesRoot)
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	type siteNode struct {
		sitesfs.Info
		Title    string `json:"title"`
		ServerID int64  `json:"serverId"`
		Note     string `json:"note"`
		Disabled bool   `json:"disabled"`
	}
	byServer := map[int64][]siteNode{}
	unassigned := []siteNode{}
	for _, d := range disk {
		n := siteNode{Info: d, Title: d.Name}
		if m, ok := metaByName[d.Name]; ok {
			n.ServerID = m.ServerID
			n.Note = m.Note
			n.Disabled = m.Disabled
			if m.Title != "" {
				n.Title = m.Title
			}
		}
		if n.ServerID == 0 {
			unassigned = append(unassigned, n)
		} else {
			byServer[n.ServerID] = append(byServer[n.ServerID], n)
		}
	}
	writeJSON(w, map[string]any{
		"servers":    publicServers(servers),
		"byServer":   byServer,
		"unassigned": unassigned,
		"sitesRoot":  a.cfg.SitesRoot,
	})
}

func (a *API) listServers(w http.ResponseWriter, r *http.Request) {
	list, err := a.cfg.Store.ListServers(r.Context())
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	writeJSON(w, publicServers(list))
}

func (a *API) saveServer(w http.ResponseWriter, r *http.Request) {
	var body store.Server
	if err := readJSON(r, &body); err != nil {
		writeErr(w, 400, "bad json")
		return
	}
	probeChanged := true
	if body.ID != 0 {
		if prev, err := a.cfg.Store.GetServer(r.Context(), body.ID); err == nil {
			probeChanged = serverProbeIdentity(prev) != serverProbeIdentity(body)
		}
	}
	out, err := a.cfg.Store.UpsertServer(r.Context(), body)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	if probeChanged {
		a.invalidateServerHealth()
	}
	writeJSON(w, publicServer(out))
}

func (a *API) deleteServer(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err := a.cfg.Store.DeleteServer(r.Context(), id); err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	a.invalidateServerHealth()
	writeJSON(w, map[string]any{"ok": true})
}

// host/port/public IP / jump identity used by health-lizhi SSH probes.
func serverProbeIdentity(s store.Server) string {
	port := s.Port
	if port == 0 {
		port = 22
	}
	via := "0"
	if s.ViaJump {
		via = "1"
	}
	return strings.TrimSpace(s.Host) + "\t" + strconv.Itoa(port) + "\t" + strings.TrimSpace(s.PublicIP) + "\t" + via
}

func (a *API) invalidateServerHealth() {
	billing.InvalidateHealthStamp(context.Background(), a.cfg.Store)
	billing.ScheduleHealthRecheck()
}

func (a *API) installServerKey(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.ParseInt(r.PathValue("id"), 10, 64)
	srv, err := a.cfg.Store.GetServer(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, 404, "server not found")
		return
	}
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	var body struct {
		Password string `json:"password"`
	}
	_ = readJSON(r, &body)
	if body.Password != "" {
		srv.Password = body.Password
	}
	if srv.Password == "" {
		writeErr(w, 400, "ssh password required")
		return
	}
	keyPath, err := sshutil.EnsurePanelKey(sshutil.DefaultKeyPath)
	if err != nil {
		writeErr(w, 500, "ensure key: "+err.Error())
		return
	}
	if err := sshutil.InstallPublicKey(srv, keyPath); err != nil {
		writeErr(w, 502, err.Error())
		return
	}
	srv.AuthType = "key"
	srv.AuthValue = keyPath
	// keep password stored for re-install
	saved, err := a.cfg.Store.UpsertServer(r.Context(), srv)
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	writeJSON(w, map[string]any{"ok": true, "server": publicServer(saved), "keyPath": keyPath})
}

func (a *API) installServerNginx(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.ParseInt(r.PathValue("id"), 10, 64)
	srv, err := a.cfg.Store.GetServer(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, 404, "server not found")
		return
	}
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	var body struct {
		Password string `json:"password"`
	}
	_ = readJSON(r, &body)
	if body.Password != "" {
		srv.Password = body.Password
	}
	ctx, cancel := context.WithTimeout(r.Context(), 10*time.Minute)
	defer cancel()
	var lines []string
	log := func(s string) { lines = append(lines, s) }
	err = deploy.InstallNginx(ctx, srv, log)
	writeJSON(w, map[string]any{
		"ok":    err == nil,
		"error": errString(err),
		"lines": lines,
	})
}

func (a *API) nginxStatus(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.ParseInt(r.PathValue("id"), 10, 64)
	srv, err := a.cfg.Store.GetServer(r.Context(), id)
	if err != nil {
		writeErr(w, 404, "server not found")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 20*time.Second)
	defer cancel()
	status, err := deploy.ProbeNginx(ctx, srv)
	writeJSON(w, map[string]any{
		"ok":     err == nil,
		"status": status,
		"error":  errString(err),
	})
}

// markPendingDeploy records that master disk changed and still needs a full deploy.
func (a *API) markPendingDeploy(ctx context.Context, name string) {
	if name == "" || a.cfg.Store == nil {
		return
	}
	_, _ = a.cfg.Store.SetSitePendingDeploy(ctx, name, true)
}

func (a *API) clearPendingDeploy(ctx context.Context, name string) {
	if name == "" || a.cfg.Store == nil {
		return
	}
	_, _ = a.cfg.Store.SetSitePendingDeploy(ctx, name, false)
}

func (a *API) getSite(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	info, err := sitesfs.Inspect(a.cfg.SitesRoot, name)
	if err != nil {
		writeErr(w, 404, err.Error())
		return
	}
	meta, err := a.cfg.Store.GetSiteByName(r.Context(), name)
	if errors.Is(err, store.ErrNotFound) {
		meta = store.Site{Name: name}
	} else if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	writeJSON(w, map[string]any{"disk": info, "meta": meta})
}

func (a *API) createSite(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Title    string `json:"title"`
		ServerID int64  `json:"serverId"`
	}
	if err := readJSON(r, &body); err != nil {
		writeErr(w, 400, "bad json")
		return
	}
	title := strings.TrimSpace(body.Title)
	if title == "" {
		writeErr(w, 400, "title required")
		return
	}
	if body.ServerID == 0 {
		writeErr(w, 400, "serverId required")
		return
	}
	if _, err := a.cfg.Store.GetServer(r.Context(), body.ServerID); err != nil {
		writeErr(w, 400, "server not found")
		return
	}
	tpl := a.cfg.NginxTemplate
	if a.cfg.NginxTemplatePath != "" {
		if raw, err := os.ReadFile(a.cfg.NginxTemplatePath); err == nil && len(raw) > 0 {
			tpl = string(raw)
		}
	}
	if tpl == "" {
		writeErr(w, 500, "nginx template missing")
		return
	}
	site, err := a.cfg.Store.AllocSite(r.Context(), title, body.ServerID)
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	if err := sitesfs.CreateSkeleton(a.cfg.SitesRoot, site.Name, tpl); err != nil {
		_ = a.cfg.Store.DeleteSite(r.Context(), site.Name)
		writeErr(w, 400, err.Error())
		return
	}
	site, _ = a.cfg.Store.SetSitePendingDeploy(r.Context(), site.Name, true)
	writeJSON(w, site)
}

func (a *API) saveSite(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	var body struct {
		ServerID int64  `json:"serverId"`
		Note     string `json:"note"`
	}
	if err := readJSON(r, &body); err != nil {
		writeErr(w, 400, "bad json")
		return
	}
	if body.ServerID != 0 {
		if _, err := a.cfg.Store.GetServer(r.Context(), body.ServerID); err != nil {
			writeErr(w, 400, "server not found")
			return
		}
	}
	site, err := a.cfg.Store.UpsertSite(r.Context(), store.Site{Name: name, ServerID: body.ServerID, Note: body.Note})
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, site)
}

func (a *API) copySite(w http.ResponseWriter, r *http.Request) {
	src := r.PathValue("name")
	var body struct {
		NewName  string `json:"newName"` // treated as display title
		Title    string `json:"title"`
		ServerID int64  `json:"serverId"`
	}
	if err := readJSON(r, &body); err != nil {
		writeErr(w, 400, "bad json")
		return
	}
	title := strings.TrimSpace(body.Title)
	if title == "" {
		title = strings.TrimSpace(body.NewName)
	}
	if title == "" {
		writeErr(w, 400, "title required")
		return
	}
	meta, err := a.cfg.Store.GetSiteByName(r.Context(), src)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, 404, "source site not in db")
		return
	}
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	serverID := body.ServerID
	if serverID == 0 {
		serverID = meta.ServerID
	}
	if serverID == 0 {
		writeErr(w, 400, "serverId required")
		return
	}
	if _, err := a.cfg.Store.GetServer(r.Context(), serverID); err != nil {
		if errors.Is(err, store.ErrNotFound) {
			writeErr(w, 400, "target server not found")
			return
		}
		writeErr(w, 500, err.Error())
		return
	}
	site, err := a.cfg.Store.AllocSite(r.Context(), title, serverID)
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	if err := sitesfs.Copy(a.cfg.SitesRoot, src, site.Name); err != nil {
		_ = a.cfg.Store.DeleteSite(r.Context(), site.Name)
		writeErr(w, 400, err.Error())
		return
	}
	if meta.ApkObfuscate {
		if site, err = a.cfg.Store.SetSiteApkObfuscate(r.Context(), site.Name, true); err != nil {
			writeErr(w, 500, err.Error())
			return
		}
	}
	site, _ = a.cfg.Store.SetSitePendingDeploy(r.Context(), site.Name, true)
	writeJSON(w, site)
}

func (a *API) renameSite(w http.ResponseWriter, r *http.Request) {
	// 「改名」= 只改显示名 title，不动目录 / 远端路径
	name := r.PathValue("name")
	var body struct {
		NewName string `json:"newName"`
		Title   string `json:"title"`
	}
	if err := readJSON(r, &body); err != nil {
		writeErr(w, 400, "bad json")
		return
	}
	title := strings.TrimSpace(body.Title)
	if title == "" {
		title = strings.TrimSpace(body.NewName)
	}
	if title == "" {
		writeErr(w, 400, "title required")
		return
	}
	site, err := a.cfg.Store.SetSiteTitle(r.Context(), name, title)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, map[string]any{"ok": true, "site": site})
}

func (a *API) deleteSite(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	unlock := sitelock.Acquire(name)
	defer unlock()
	meta, _ := a.cfg.Store.GetSiteByName(r.Context(), name)
	var lines []string
	if meta.ServerID != 0 {
		if srv, err := a.cfg.Store.GetServer(r.Context(), meta.ServerID); err == nil {
			ctx, cancel := context.WithTimeout(r.Context(), 2*time.Minute)
			defer cancel()
			log := func(s string) { lines = append(lines, s) }
			if err := deploy.RemoveSite(ctx, deploy.Options{
				SiteName:   name,
				RemoteWWW:  "/www/sites/" + name + "/www",
				RemoteConf: "/etc/nginx/conf.d/" + name + ".conf",
				Server:     srv,
			}, log); err != nil {
				writeJSONStatus(w, 502, map[string]any{
					"ok":    false,
					"error": "remote delete failed: " + err.Error(),
					"lines": lines,
				})
				return
			}
		}
	}
	if err := sitesfs.Remove(a.cfg.SitesRoot, name); err != nil && !os.IsNotExist(err) {
		writeErr(w, 500, err.Error())
		return
	}
	if err := a.cfg.Store.DeleteSite(r.Context(), name); err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	writeJSON(w, map[string]any{"ok": true, "lines": lines})
}

func (a *API) getConf(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	body, err := sitesfs.ReadConf(a.cfg.SitesRoot, name)
	if err != nil {
		writeErr(w, 404, err.Error())
		return
	}
	domains, _ := confmark.Domains(body)
	writeJSON(w, map[string]any{"conf": body, "domains": domains})
}

func (a *API) putConf(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	var body struct {
		Conf string `json:"conf"`
	}
	if err := readJSON(r, &body); err != nil {
		writeErr(w, 400, "bad json")
		return
	}
	body.Conf = confmark.EnsureListen80ForDomains(confmark.EnsureMarkers(body.Conf))
	check := confcheck.Check(body.Conf)
	if !check.OK {
		writeJSONStatus(w, 400, map[string]any{"ok": false, "error": "nginx.conf 检查未通过", "confCheck": check})
		return
	}
	if prev, _, err := sitesfs.ReadFile(a.cfg.SitesRoot, name, "nginx.conf", 2<<20); err == nil {
		if string(prev) != body.Conf {
			_ = sitesfs.PushFileHistory(a.cfg.SitesRoot, name, "nginx.conf", prev)
		}
	}
	if err := sitesfs.WriteConf(a.cfg.SitesRoot, name, body.Conf); err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	a.markPendingDeploy(r.Context(), name)
	domains, _ := confmark.Domains(body.Conf)
	writeJSON(w, map[string]any{"ok": true, "domains": domains, "conf": body.Conf, "pendingDeploy": true})
}

func (a *API) listSiteFiles(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	path := r.URL.Query().Get("path")
	ents, err := sitesfs.ListDir(a.cfg.SitesRoot, name, path)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, map[string]any{"path": path, "entries": ents})
}

func (a *API) readSiteFile(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	path := r.URL.Query().Get("path")
	b, clean, err := sitesfs.ReadFile(a.cfg.SitesRoot, name, path, 2<<20)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, map[string]any{"path": clean, "content": string(b)})
}

func (a *API) writeSiteFile(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	var body struct {
		Path    string `json:"path"`
		Content string `json:"content"`
	}
	if err := readJSON(r, &body); err != nil || body.Path == "" {
		writeErr(w, 400, "path required")
		return
	}
	content := body.Content
	isNginx := body.Path == "nginx.conf" || strings.HasSuffix(body.Path, "/nginx.conf")
	var check confcheck.Result
	if isNginx {
		content = confmark.EnsureListen80ForDomains(confmark.EnsureMarkers(content))
		check = confcheck.Check(content)
		if !check.OK {
			writeJSONStatus(w, 400, map[string]any{
				"ok":        false,
				"error":     "nginx.conf 检查未通过",
				"confCheck": check,
			})
			return
		}
	}
	if prev, _, err := sitesfs.ReadFile(a.cfg.SitesRoot, name, body.Path, 2<<20); err == nil {
		if string(prev) != content {
			_ = sitesfs.PushFileHistory(a.cfg.SitesRoot, name, body.Path, prev)
		}
	}
	if err := sitesfs.WriteFile(a.cfg.SitesRoot, name, body.Path, []byte(content)); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	a.markPendingDeploy(r.Context(), name)
	out := map[string]any{"ok": true, "path": body.Path, "pendingDeploy": true}
	if isNginx {
		domains, _ := confmark.Domains(content)
		out["domains"] = domains
		out["confCheck"] = check
		out["content"] = content
	}
	writeJSON(w, out)
}

func (a *API) listSiteFileHistory(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	path := r.URL.Query().Get("path")
	if path == "" {
		writeErr(w, 400, "path required")
		return
	}
	list, err := sitesfs.ListFileHistory(a.cfg.SitesRoot, name, path)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, map[string]any{"path": path, "items": list})
}

func (a *API) readSiteFileHistory(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	path := r.URL.Query().Get("path")
	id := r.URL.Query().Get("id")
	if path == "" || id == "" {
		writeErr(w, 400, "path and id required")
		return
	}
	b, err := sitesfs.ReadFileHistory(a.cfg.SitesRoot, name, path, id, 2<<20)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, map[string]any{"path": path, "id": id, "content": string(b)})
}

func (a *API) mkdirSitePath(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	var body struct {
		Path string `json:"path"`
	}
	if err := readJSON(r, &body); err != nil || body.Path == "" {
		writeErr(w, 400, "path required")
		return
	}
	if err := sitesfs.Mkdir(a.cfg.SitesRoot, name, body.Path); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	a.markPendingDeploy(r.Context(), name)
	writeJSON(w, map[string]any{"ok": true, "pendingDeploy": true})
}

func (a *API) touchSiteFile(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	var body struct {
		Path string `json:"path"`
	}
	if err := readJSON(r, &body); err != nil || body.Path == "" {
		writeErr(w, 400, "path required")
		return
	}
	if err := sitesfs.CreateEmpty(a.cfg.SitesRoot, name, body.Path); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	a.markPendingDeploy(r.Context(), name)
	writeJSON(w, map[string]any{"ok": true, "path": body.Path, "pendingDeploy": true})
}

func (a *API) renameSitePath(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	var body struct {
		From string `json:"from"`
		To   string `json:"to"`
	}
	if err := readJSON(r, &body); err != nil || body.From == "" || body.To == "" {
		writeErr(w, 400, "from/to required")
		return
	}
	if err := sitesfs.RenamePath(a.cfg.SitesRoot, name, body.From, body.To); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	a.markPendingDeploy(r.Context(), name)
	writeJSON(w, map[string]any{"ok": true, "path": body.To, "pendingDeploy": true})
}

func (a *API) pasteSitePaths(w http.ResponseWriter, r *http.Request) {
	toSite := r.PathValue("name")
	var body struct {
		FromSite string   `json:"fromSite"`
		Paths    []string `json:"paths"`
		Dest     string   `json:"dest"`
		Mode     string   `json:"mode"`
		Conflict string   `json:"conflict"`
	}
	if err := readJSON(r, &body); err != nil || body.FromSite == "" || len(body.Paths) == 0 {
		writeErr(w, 400, "fromSite and paths required")
		return
	}
	// lock sites in name order to avoid A↔B deadlock
	aName, bName := body.FromSite, toSite
	if aName > bName {
		aName, bName = bName, aName
	}
	unlockA := sitelock.Acquire(aName)
	defer unlockA()
	if bName != aName {
		unlockB := sitelock.Acquire(bName)
		defer unlockB()
	}
	if err := sitesfs.TransferPaths(a.cfg.SitesRoot, body.FromSite, toSite, body.Paths, body.Dest, body.Mode, body.Conflict); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	a.markPendingDeploy(r.Context(), toSite)
	if body.Mode == "cut" || body.Mode == "move" {
		a.markPendingDeploy(r.Context(), body.FromSite)
	}
	writeJSON(w, map[string]any{"ok": true, "pendingDeploy": true})
}

func (a *API) deleteSitePath(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	path := r.URL.Query().Get("path")
	if path == "" {
		writeErr(w, 400, "path required")
		return
	}
	if err := sitesfs.RemovePath(a.cfg.SitesRoot, name, path); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	a.markPendingDeploy(r.Context(), name)
	writeJSON(w, map[string]any{"ok": true, "pendingDeploy": true})
}

func (a *API) uploadSiteFile(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	const maxUpload = 200 << 20 // 200 MiB
	r.Body = http.MaxBytesReader(w, r.Body, maxUpload+1<<20)
	if err := r.ParseMultipartForm(32 << 20); err != nil {
		writeErr(w, 400, "bad multipart / file too large")
		return
	}
	dir := r.FormValue("dir")
	file, hdr, err := r.FormFile("file")
	if err != nil {
		writeErr(w, 400, "file required")
		return
	}
	defer file.Close()
	if hdr.Size > maxUpload {
		writeErr(w, 400, "file too large (max 200MiB)")
		return
	}
	rel := filepath.Base(hdr.Filename)
	if rel == "." || rel == "" {
		writeErr(w, 400, "bad filename")
		return
	}
	if dir != "" {
		rel = strings.TrimSuffix(dir, "/") + "/" + rel
	}
	policy := r.FormValue("conflict")
	if policy == "" {
		policy = "reject"
	}
	finalPath, err := sitesfs.WriteUploadStream(a.cfg.SitesRoot, name, rel, file, maxUpload, policy)
	if err != nil {
		if errors.Is(err, sitesfs.ErrUploadConflict) {
			writeErr(w, http.StatusConflict, "目标已出现同名文件，请刷新后重试")
			return
		}
		if strings.Contains(err.Error(), "too large") {
			writeErr(w, 400, "file too large (max 200MiB)")
			return
		}
		writeErr(w, 400, err.Error())
		return
	}
	a.markPendingDeploy(r.Context(), name)
	writeJSON(w, map[string]any{"ok": true, "path": finalPath, "pendingDeploy": true})
}

func (a *API) uploadSiteConflicts(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Dir   string   `json:"dir"`
		Names []string `json:"names"`
	}
	if err := readJSON(r, &body); err != nil || len(body.Names) == 0 || len(body.Names) > 1000 {
		writeErr(w, http.StatusBadRequest, "dir and 1-1000 names required")
		return
	}
	conflicts, err := sitesfs.UploadConflicts(a.cfg.SitesRoot, r.PathValue("name"), body.Dir, body.Names)
	if err != nil {
		writeErr(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, map[string]any{"conflicts": conflicts})
}

func (a *API) downloadSiteFile(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	path := r.URL.Query().Get("path")
	abs, clean, err := sitesfs.Resolve(a.cfg.SitesRoot, name, path)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	st, err := os.Stat(abs)
	if err != nil || st.IsDir() {
		writeErr(w, 400, "not a file")
		return
	}
	w.Header().Set("Content-Type", "application/octet-stream")
	w.Header().Set("Content-Disposition", `attachment; filename="`+filepath.Base(clean)+`"`)
	http.ServeFile(w, r, abs)
}

func (a *API) zipSitePaths(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	var body struct {
		Paths []string `json:"paths"`
		Out   string   `json:"out"`
	}
	if err := readJSON(r, &body); err != nil || len(body.Paths) == 0 || body.Out == "" {
		writeErr(w, 400, "paths/out required")
		return
	}
	if err := sitesfs.ZipPaths(a.cfg.SitesRoot, name, body.Paths, body.Out); err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	a.markPendingDeploy(r.Context(), name)
	writeJSON(w, map[string]any{"ok": true, "path": body.Out, "pendingDeploy": true})
}

func (a *API) listZipSitePath(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	path := r.URL.Query().Get("path")
	ents, err := sitesfs.ListZip(a.cfg.SitesRoot, name, path)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	writeJSON(w, map[string]any{"path": path, "entries": ents})
}

func (a *API) unzipSitePath(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	var body struct {
		Path string `json:"path"`
		Dest string `json:"dest"`
		Mode string `json:"mode"` // folder | flat | "" (legacy auto)
	}
	if err := readJSON(r, &body); err != nil || body.Path == "" {
		writeErr(w, 400, "path required")
		return
	}
	info, err := sitesfs.Unzip(a.cfg.SitesRoot, name, body.Path, body.Dest, body.Mode)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	a.markPendingDeploy(r.Context(), name)
	writeJSON(w, map[string]any{"ok": true, "mode": info.Mode, "dest": info.Dest, "strip": info.Strip, "pendingDeploy": true})
}

func (a *API) putDomains(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	var body struct {
		Domains []string `json:"domains"`
	}
	if err := readJSON(r, &body); err != nil {
		writeErr(w, 400, "bad json")
		return
	}
	conf, err := sitesfs.ReadConf(a.cfg.SitesRoot, name)
	if err != nil {
		writeErr(w, 404, err.Error())
		return
	}
	conf = confmark.EnsureMarkers(conf)
	next, err := confmark.SetDomains(conf, body.Domains)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	if err := sitesfs.WriteConf(a.cfg.SitesRoot, name, next); err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	a.markPendingDeploy(r.Context(), name)
	domains, _ := confmark.Domains(next)
	writeJSON(w, map[string]any{"ok": true, "domains": domains, "conf": next, "pendingDeploy": true})
}

func (a *API) siteDeployOpts(w http.ResponseWriter, r *http.Request) (deploy.Options, bool) {
	return a.siteDeployOptsAllowDisabled(w, r, false)
}

func (a *API) siteDeployOptsAllowDisabled(w http.ResponseWriter, r *http.Request, allowDisabled bool) (deploy.Options, bool) {
	name := r.PathValue("name")
	meta, err := a.cfg.Store.GetSiteByName(r.Context(), name)
	if errors.Is(err, store.ErrNotFound) || meta.ServerID == 0 {
		writeErr(w, 400, "bind a server first")
		return deploy.Options{}, false
	}
	if err != nil {
		writeErr(w, 500, err.Error())
		return deploy.Options{}, false
	}
	if meta.Disabled && !allowDisabled {
		writeErr(w, 400, "site is disabled; enable it first")
		return deploy.Options{}, false
	}
	srv, err := a.cfg.Store.GetServer(r.Context(), meta.ServerID)
	if err != nil {
		writeErr(w, 400, "server not found")
		return deploy.Options{}, false
	}
	return deploy.Options{
		SitesRoot:    a.cfg.SitesRoot,
		SiteName:     name,
		RemoteWWW:    "/www/sites/" + name + "/www",
		RemoteConf:   "/etc/nginx/conf.d/" + name + ".conf",
		Server:       srv,
		ApkObfuscate: meta.ApkObfuscate,
	}, true
}

func (a *API) deployDiff(w http.ResponseWriter, r *http.Request) {
	opt, ok := a.siteDeployOpts(w, r)
	if !ok {
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 2*time.Minute)
	defer cancel()
	diff, err := deploy.Diff(ctx, opt)
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	writeJSON(w, diff)
}

func (a *API) deploySite(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	unlock := sitelock.Acquire(name)
	defer unlock()
	opt, ok := a.siteDeployOpts(w, r)
	if !ok {
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 5*time.Minute)
	defer cancel()
	var lines []string
	log := func(s string) { lines = append(lines, s) }
	// A failed/interrupted deploy may already have changed remote files.
	// Persist before SSH starts; only a complete success clears the reminder.
	a.markPendingDeploy(r.Context(), name)
	res, err := deploy.Sync(ctx, opt, log)
	if err == nil {
		a.clearPendingDeploy(r.Context(), name)
	}
	writeJSON(w, map[string]any{
		"ok":            err == nil,
		"error":         errString(err),
		"errorCode":     errorCode(err),
		"result":        res,
		"lines":         lines,
		"pendingDeploy": err != nil,
	})
}

func (a *API) setApkObfuscate(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	var body struct {
		Enabled bool `json:"enabled"`
	}
	if err := readJSON(r, &body); err != nil {
		writeErr(w, 400, "bad json")
		return
	}
	site, err := a.cfg.Store.SetSiteApkObfuscate(r.Context(), name, body.Enabled)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, 404, "site not found")
		return
	}
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	// Flag only; install/remove remote timer and in-place obfuscate happen on deploy.
	site, _ = a.cfg.Store.SetSitePendingDeploy(r.Context(), name, true)
	writeJSON(w, map[string]any{"ok": true, "meta": site})
}

func (a *API) setSiteDisabled(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	var body struct {
		Disabled bool `json:"disabled"`
	}
	if err := readJSON(r, &body); err != nil {
		writeErr(w, 400, "bad json")
		return
	}
	unlock := sitelock.Acquire(name)
	defer unlock()

	meta, err := a.cfg.Store.GetSiteByName(r.Context(), name)
	if errors.Is(err, store.ErrNotFound) {
		writeErr(w, 404, "site not found")
		return
	}
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	if meta.Disabled == body.Disabled {
		writeJSON(w, map[string]any{"ok": true, "meta": meta, "lines": []string{}})
		return
	}

	var lines []string
	log := func(s string) { lines = append(lines, s) }

	if body.Disabled {
		if meta.ServerID != 0 {
			srv, err := a.cfg.Store.GetServer(r.Context(), meta.ServerID)
			if err != nil {
				writeErr(w, 400, "server not found")
				return
			}
			ctx, cancel := context.WithTimeout(r.Context(), 2*time.Minute)
			defer cancel()
			if err := deploy.DisableSite(ctx, deploy.Options{
				SitesRoot:  a.cfg.SitesRoot,
				SiteName:   name,
				RemoteWWW:  "/www/sites/" + name + "/www",
				RemoteConf: "/etc/nginx/conf.d/" + name + ".conf",
				Server:     srv,
			}, log); err != nil {
				writeJSONStatus(w, 502, map[string]any{
					"ok":    false,
					"error": "remote disable failed: " + err.Error(),
					"lines": lines,
				})
				return
			}
		} else {
			log("no server bound — flag only")
		}
		site, err := a.cfg.Store.SetSiteDisabled(r.Context(), name, true)
		if err != nil {
			writeErr(w, 500, err.Error())
			return
		}
		writeJSON(w, map[string]any{"ok": true, "meta": site, "lines": lines})
		return
	}

	// Enable: push conf (+ files) so the site serves again.
	if meta.ServerID != 0 {
		opt, ok := a.siteDeployOptsAllowDisabled(w, r, true)
		if !ok {
			return
		}
		ctx, cancel := context.WithTimeout(r.Context(), 5*time.Minute)
		defer cancel()
		res, err := deploy.Sync(ctx, opt, log)
		if err != nil {
			writeJSONStatus(w, 502, map[string]any{
				"ok":     false,
				"error":  "remote enable failed: " + err.Error(),
				"result": res,
				"lines":  lines,
			})
			return
		}
		a.clearPendingDeploy(r.Context(), name)
	} else {
		log("no server bound — flag only")
	}
	site, err := a.cfg.Store.SetSiteDisabled(r.Context(), name, false)
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	writeJSON(w, map[string]any{"ok": true, "meta": site, "lines": lines})
}

func (a *API) dnsCheckSite(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	conf, err := sitesfs.ReadConf(a.cfg.SitesRoot, name)
	if err != nil {
		writeErr(w, 404, err.Error())
		return
	}
	domains, err := confmark.Domains(conf)
	if err != nil {
		writeErr(w, 400, err.Error())
		return
	}
	expect := ""
	var siteMeta store.Site
	meta, merr := a.cfg.Store.GetSiteByName(r.Context(), name)
	if merr == nil {
		siteMeta = meta
		if meta.ServerID != 0 {
			if srv, err := a.cfg.Store.GetServer(r.Context(), meta.ServerID); err == nil {
				expect = srv.PublicIP
				if expect == "" {
					expect = srv.Host
				}
			}
		}
	}
	items := dnscheck.CheckDomains(r.Context(), domains, expect)
	allOK := len(items) > 0
	for _, it := range items {
		if !it.OK {
			allOK = false
			break
		}
	}
	if len(items) == 0 {
		allOK = false
	}
	sslConfigured := confmark.SSLConfigured(conf)
	certHosts := sslcert.CertHostnames(domains)
	sslMissing := sslcert.MissingHostnames(strings.Split(siteMeta.SSLDomains, ","), certHosts)
	sslCoversAll := len(certHosts) > 0 && sslConfigured &&
		siteMeta.SSLServerID == siteMeta.ServerID &&
		siteMeta.SSLDomains != "" &&
		len(sslMissing) == 0 &&
		siteMeta.SSLNotAfter > time.Now().Unix()
	writeJSON(w, map[string]any{
		"ok":            allOK,
		"expected":      expect,
		"items":         items,
		"domains":       domains,
		"sslConfigured": sslConfigured,
		"sslCoversAll":  sslCoversAll,
		"sslMissing":    sslMissing,
	})
}

func (a *API) sslPreflight(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	meta, err := a.cfg.Store.GetSiteByName(r.Context(), name)
	if errors.Is(err, store.ErrNotFound) || meta.ServerID == 0 {
		writeErr(w, 400, "bind a server first")
		return
	}
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	if meta.Disabled {
		writeErr(w, 400, "site is disabled; enable it first")
		return
	}
	srv, err := a.cfg.Store.GetServer(r.Context(), meta.ServerID)
	if err != nil {
		writeErr(w, 400, "server not found")
		return
	}
	var body struct {
		SkipDNS  bool            `json:"skipDns"`
		DNSItems []dnscheck.Item `json:"dnsItems"`
	}
	_ = json.NewDecoder(r.Body).Decode(&body)
	ctx, cancel := context.WithTimeout(r.Context(), 45*time.Second)
	defer cancel()
	pre := sslcert.Preflight(ctx, sslcert.Options{
		SitesRoot:     a.cfg.SitesRoot,
		SiteName:      name,
		RemoteWWW:     "/www/sites/" + name + "/www",
		RemoteConf:    "/etc/nginx/conf.d/" + name + ".conf",
		Server:        srv,
		Site:          meta,
		SkipDNS:       body.SkipDNS,
		ReuseDNSItems: body.DNSItems,
	})
	writeJSON(w, pre)
}

func (a *API) sslSite(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	unlock := sitelock.Acquire(name)
	defer unlock()
	var body struct {
		Force         bool            `json:"force"`
		SkipPreflight bool            `json:"skipPreflight"`
		SkipDNS       bool            `json:"skipDns"`
		SyncExisting  bool            `json:"syncExisting"`
		DNSItems      []dnscheck.Item `json:"dnsItems"`
	}
	_ = json.NewDecoder(r.Body).Decode(&body)

	meta, err := a.cfg.Store.GetSiteByName(r.Context(), name)
	if errors.Is(err, store.ErrNotFound) || meta.ServerID == 0 {
		writeErr(w, 400, "bind a server first")
		return
	}
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	if meta.Disabled {
		writeErr(w, 400, "site is disabled; enable it first")
		return
	}
	srv, err := a.cfg.Store.GetServer(r.Context(), meta.ServerID)
	if err != nil {
		writeErr(w, 400, "server not found")
		return
	}

	ctx, cancel := context.WithTimeout(r.Context(), 8*time.Minute)
	defer cancel()

	opt := sslcert.Options{
		SitesRoot:     a.cfg.SitesRoot,
		SiteName:      name,
		RemoteWWW:     "/www/sites/" + name + "/www",
		RemoteConf:    "/etc/nginx/conf.d/" + name + ".conf",
		Server:        srv,
		Site:          meta,
		Force:         body.Force,
		SkipDNS:       body.SkipPreflight && body.SkipDNS,
		ReuseDNSItems: body.DNSItems,
	}

	// Deploy/migrate path: only adopt a remote cert that already covers every name.
	if body.SyncExisting {
		res, synced, syncErr := sslcert.TrySyncExisting(ctx, opt, nil)
		var bookErr error
		if syncErr == nil && synced {
			confBody, _ := sitesfs.ReadConf(a.cfg.SitesRoot, name)
			domains, _ := confmark.Domains(confBody)
			notAfter := int64(0)
			if !res.NotAfter.IsZero() {
				notAfter = res.NotAfter.Unix()
			}
			bookErr = a.cfg.Store.SetSiteSSL(ctx, name, srv.ID, sslcert.DomainsKey(domains), notAfter)
			if bookErr != nil {
				res.Lines = append(res.Lines, "SSL 记账写入失败: "+bookErr.Error())
			}
		}
		outErr := syncErr
		if outErr == nil {
			outErr = bookErr
		}
		conf, _ := sitesfs.ReadConf(a.cfg.SitesRoot, name)
		domains, _ := confmark.Domains(conf)
		writeJSON(w, map[string]any{
			"ok":        outErr == nil,
			"synced":    synced && bookErr == nil,
			"error":     errString(outErr),
			"errorCode": errorCode(outErr),
			"result":    res,
			"lines":     res.Lines,
			"conf":      conf,
			"domains":   domains,
		})
		return
	}

	// Dialog already ran preflight; skip unless caller wants a fresh check.
	if !body.SkipPreflight {
		pre := sslcert.Preflight(ctx, opt)
		if !pre.OK && !body.Force {
			writeJSON(w, map[string]any{
				"ok":        false,
				"error":     "ssl preflight failed",
				"preflight": pre,
				"lines":     pre.Lines,
			})
			return
		}
	}

	res, err := sslcert.Issue(ctx, opt, nil)

	if err == nil {
		confBody, _ := sitesfs.ReadConf(a.cfg.SitesRoot, name)
		domains, _ := confmark.Domains(confBody)
		notAfter := int64(0)
		if !res.NotAfter.IsZero() {
			notAfter = res.NotAfter.Unix()
		}
		if bookErr := a.cfg.Store.SetSiteSSL(ctx, name, srv.ID, sslcert.DomainsKey(domains), notAfter); bookErr != nil {
			err = bookErr
			res.Lines = append(res.Lines, "SSL 记账写入失败: "+bookErr.Error())
		}
	}

	conf, _ := sitesfs.ReadConf(a.cfg.SitesRoot, name)
	domains, _ := confmark.Domains(conf)
	writeJSON(w, map[string]any{
		"ok":        err == nil,
		"error":     errString(err),
		"errorCode": errorCode(err),
		"result":    res,
		"lines":     res.Lines,
		"conf":      conf,
		"domains":   domains,
	})
}

func (a *API) sslPem(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	if _, err := a.cfg.Store.GetSiteByName(r.Context(), name); errors.Is(err, store.ErrNotFound) {
		writeErr(w, 404, "site not found")
		return
	} else if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	fullchain, key := sslcert.ReadStoredPEM(a.cfg.SitesRoot, name)
	writeJSON(w, map[string]any{
		"fullchain": fullchain,
		"key":       key,
		"manual":    sslcert.HasManualCert(a.cfg.SitesRoot, name),
	})
}

func (a *API) sslManual(w http.ResponseWriter, r *http.Request) {
	name := r.PathValue("name")
	unlock := sitelock.Acquire(name)
	defer unlock()
	var body struct {
		Fullchain     string `json:"fullchain"`
		Key           string `json:"key"`
		Force         bool   `json:"force"`
		SkipPreflight bool   `json:"skipPreflight"`
	}
	if err := readJSON(r, &body); err != nil {
		writeErr(w, 400, "invalid json")
		return
	}
	if strings.TrimSpace(body.Fullchain) == "" || strings.TrimSpace(body.Key) == "" {
		writeErr(w, 400, "需要 fullchain 与 key（PEM）")
		return
	}

	meta, err := a.cfg.Store.GetSiteByName(r.Context(), name)
	if errors.Is(err, store.ErrNotFound) || meta.ServerID == 0 {
		writeErr(w, 400, "bind a server first")
		return
	}
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	if meta.Disabled {
		writeErr(w, 400, "site is disabled; enable it first")
		return
	}
	srv, err := a.cfg.Store.GetServer(r.Context(), meta.ServerID)
	if err != nil {
		writeErr(w, 400, "server not found")
		return
	}

	ctx, cancel := context.WithTimeout(r.Context(), 3*time.Minute)
	defer cancel()

	if !body.SkipPreflight {
		pre := sslcert.Preflight(ctx, sslcert.Options{
			SitesRoot:  a.cfg.SitesRoot,
			SiteName:   name,
			RemoteWWW:  "/www/sites/" + name + "/www",
			RemoteConf: "/etc/nginx/conf.d/" + name + ".conf",
			Server:     srv,
			Site:       meta,
		})
		if !pre.OK && !body.Force {
			writeJSON(w, map[string]any{
				"ok":        false,
				"error":     "ssl preflight failed",
				"preflight": pre,
				"lines":     pre.Lines,
			})
			return
		}
	}

	res, err := sslcert.InstallManual(ctx, sslcert.Options{
		SitesRoot:  a.cfg.SitesRoot,
		SiteName:   name,
		RemoteWWW:  "/www/sites/" + name + "/www",
		RemoteConf: "/etc/nginx/conf.d/" + name + ".conf",
		Server:     srv,
		Site:       meta,
		Force:      body.Force,
	}, body.Fullchain, body.Key, nil)

	if err == nil {
		confBody, _ := sitesfs.ReadConf(a.cfg.SitesRoot, name)
		domains, _ := confmark.Domains(confBody)
		notAfter := int64(0)
		if !res.NotAfter.IsZero() {
			notAfter = res.NotAfter.Unix()
		}
		if bookErr := a.cfg.Store.SetSiteSSL(ctx, name, srv.ID, sslcert.DomainsKey(domains), notAfter); bookErr != nil {
			err = bookErr
			res.Lines = append(res.Lines, "SSL 记账写入失败: "+bookErr.Error())
		}
	}

	conf, _ := sitesfs.ReadConf(a.cfg.SitesRoot, name)
	domains, _ := confmark.Domains(conf)
	writeJSON(w, map[string]any{
		"ok":        err == nil,
		"error":     errString(err),
		"errorCode": errorCode(err),
		"result":    res,
		"lines":     res.Lines,
		"conf":      conf,
		"domains":   domains,
	})
}

func (a *API) billingList(w http.ResponseWriter, r *http.Request) {
	if a.cfg.Billing == nil {
		writeErr(w, 503, "billing not configured")
		return
	}
	snapID, _ := strconv.ParseInt(r.URL.Query().Get("snapshot"), 10, 64)
	rows, synced, snaps, err := a.cfg.Billing.List(r.Context(), snapID)
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	writeJSON(w, map[string]any{
		"rows":         rows,
		"syncedAt":     synced,
		"snapshotId":   snapID,
		"snapshots":    snaps,
		"accountsPath": a.cfg.Billing.AccountsPath,
	})
}

func (a *API) billingSync(w http.ResponseWriter, r *http.Request) {
	if a.cfg.Billing == nil {
		writeErr(w, 503, "billing not configured")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 10*time.Minute)
	defer cancel()
	var lines []string
	log := func(s string) { lines = append(lines, s) }
	err := a.cfg.Billing.Sync(ctx, log)
	writeJSON(w, map[string]any{
		"ok":    err == nil,
		"error": errString(err),
		"lines": lines,
	})
}

func (a *API) billingSyncFailed(w http.ResponseWriter, r *http.Request) {
	if a.cfg.Billing == nil {
		writeErr(w, 503, "billing not configured")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 10*time.Minute)
	defer cancel()
	var lines []string
	log := func(s string) { lines = append(lines, s) }
	err := a.cfg.Billing.SyncFailed(ctx, log)
	writeJSON(w, map[string]any{
		"ok":    err == nil,
		"error": errString(err),
		"lines": lines,
	})
}

func (a *API) billingRemind(w http.ResponseWriter, r *http.Request) {
	if a.cfg.Billing == nil {
		writeErr(w, 503, "billing not configured")
		return
	}
	var lines []string
	err := a.cfg.Billing.RemindManual(r.Context(), func(s string) { lines = append(lines, s) })
	writeJSON(w, map[string]any{"ok": err == nil, "error": errString(err), "lines": lines})
}

func (a *API) billingRestore(w http.ResponseWriter, r *http.Request) {
	if a.cfg.Billing == nil {
		writeErr(w, 503, "billing not configured")
		return
	}
	var body struct {
		ID int64 `json:"id"`
	}
	if err := readJSON(r, &body); err != nil || body.ID <= 0 {
		writeErr(w, 400, "id required")
		return
	}
	var lines []string
	err := a.cfg.Billing.RestoreSnapshot(r.Context(), body.ID, func(s string) { lines = append(lines, s) })
	writeJSON(w, map[string]any{"ok": err == nil, "error": errString(err), "lines": lines})
}

func (a *API) billingGetAccounts(w http.ResponseWriter, r *http.Request) {
	if a.cfg.Billing == nil {
		writeErr(w, 503, "billing not configured")
		return
	}
	cfg, err := a.cfg.Billing.ConfigForEdit()
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	writeJSON(w, cfg)
}

func (a *API) billingPutAccounts(w http.ResponseWriter, r *http.Request) {
	if a.cfg.Billing == nil {
		writeErr(w, 503, "billing not configured")
		return
	}
	var body lizhi.ConfigFile
	if err := readJSON(r, &body); err != nil {
		writeErr(w, 400, "bad json")
		return
	}
	if err := a.cfg.Billing.SaveConfig(body); err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

func (a *API) billingExport(w http.ResponseWriter, r *http.Request) {
	if a.cfg.Billing == nil {
		writeErr(w, 503, "billing not configured")
		return
	}
	snapID, _ := strconv.ParseInt(r.URL.Query().Get("snapshot"), 10, 64)
	rows, _, _, err := a.cfg.Billing.List(r.Context(), snapID)
	if err != nil {
		writeErr(w, 500, err.Error())
		return
	}
	w.Header().Set("Content-Type", "text/csv; charset=utf-8")
	w.Header().Set("Content-Disposition", `attachment; filename="billing.csv"`)
	_, _ = w.Write([]byte("\ufeff"))
	cw := csv.NewWriter(w)
	_ = cw.Write([]string{
		"序号", "账号", "余额", "ip", "费用", "到期", "天", "cycle", "备注", "status", "带宽", "地区", "product", "os", "面板",
	})
	for _, row := range rows {
		panel := ""
		if row.InPanel {
			panel = row.PanelName
		}
		_ = cw.Write([]string{
			row.AccountName, row.LoginID, row.Balance, row.IP, row.Fee, row.ExpireAt,
			strconv.Itoa(row.DaysLeft), row.Cycle, row.Note, row.Status, row.Bandwidth, row.Region,
			row.Product, row.OS, panel,
		})
	}
	cw.Flush()
}

func errString(err error) string {
	if err == nil {
		return ""
	}
	return err.Error()
}

func errorCode(err error) string {
	if err == nil {
		return ""
	}
	if sshutil.IsAuthFailure(err) {
		return "ssh_auth"
	}
	return ""
}

func readJSON(r *http.Request, dst any) error {
	defer r.Body.Close()
	b, err := io.ReadAll(io.LimitReader(r.Body, 8<<20))
	if err != nil {
		return err
	}
	return json.Unmarshal(b, dst)
}

func writeJSON(w http.ResponseWriter, v any) {
	writeJSONStatus(w, 200, v)
}

func writeJSONStatus(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, code int, msg string) {
	writeJSONStatus(w, code, map[string]any{"error": msg})
}

// AbsSitesRoot resolves and creates sites root.
func AbsSitesRoot(p string) (string, error) {
	abs, err := filepath.Abs(p)
	if err != nil {
		return "", err
	}
	if err := os.MkdirAll(abs, 0o755); err != nil {
		return "", err
	}
	return abs, nil
}
