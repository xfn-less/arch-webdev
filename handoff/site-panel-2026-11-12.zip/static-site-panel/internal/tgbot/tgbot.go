package tgbot

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

type SendResult struct {
	MessageID int64
}

func Send(ctx context.Context, botToken, chatID, text string) (SendResult, error) {
	return SendOpts(ctx, botToken, chatID, text, false, false)
}

func SendHTML(ctx context.Context, botToken, chatID, text string, html bool) (SendResult, error) {
	return SendOpts(ctx, botToken, chatID, text, html, false)
}

// SendOpts sends a message. silent=true sets disable_notification (no sound/vibration).
func SendOpts(ctx context.Context, botToken, chatID, text string, html, silent bool) (SendResult, error) {
	botToken = strings.TrimSpace(botToken)
	chatID = strings.TrimSpace(chatID)
	if botToken == "" || chatID == "" || text == "" {
		return SendResult{}, fmt.Errorf("tg not configured")
	}
	api := "https://api.telegram.org/bot" + botToken + "/sendMessage"
	form := url.Values{}
	form.Set("chat_id", chatID)
	form.Set("text", text)
	form.Set("disable_web_page_preview", "true")
	if html {
		form.Set("parse_mode", "HTML")
	}
	if silent {
		form.Set("disable_notification", "true")
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, api, strings.NewReader(form.Encode()))
	if err != nil {
		return SendResult{}, err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	cli := &http.Client{Timeout: 20 * time.Second}
	res, err := cli.Do(req)
	if err != nil {
		return SendResult{}, err
	}
	defer res.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(res.Body, 1<<20))
	if res.StatusCode >= 300 {
		return SendResult{}, fmt.Errorf("tg HTTP %d: %s", res.StatusCode, strings.TrimSpace(string(body)))
	}
	var out struct {
		OK          bool   `json:"ok"`
		Description string `json:"description"`
		Result      struct {
			MessageID int64 `json:"message_id"`
		} `json:"result"`
	}
	_ = json.Unmarshal(body, &out)
	if !out.OK {
		return SendResult{}, fmt.Errorf("tg: %s", out.Description)
	}
	return SendResult{MessageID: out.Result.MessageID}, nil
}

func Delete(ctx context.Context, botToken, chatID string, messageID int64) error {
	botToken = strings.TrimSpace(botToken)
	chatID = strings.TrimSpace(chatID)
	if botToken == "" || chatID == "" || messageID <= 0 {
		return nil
	}
	api := "https://api.telegram.org/bot" + botToken + "/deleteMessage"
	form := url.Values{}
	form.Set("chat_id", chatID)
	form.Set("message_id", fmt.Sprintf("%d", messageID))
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, api, strings.NewReader(form.Encode()))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	cli := &http.Client{Timeout: 15 * time.Second}
	res, err := cli.Do(req)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	io.Copy(io.Discard, io.LimitReader(res.Body, 1<<16))
	return nil
}

func EscapeHTML(s string) string {
	r := strings.NewReplacer(
		"&", "&amp;",
		"<", "&lt;",
		">", "&gt;",
		`"`, "&quot;",
	)
	return r.Replace(s)
}
