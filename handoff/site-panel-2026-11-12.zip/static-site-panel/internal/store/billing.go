package store

import (
	"context"
	"database/sql"
	"time"
)

type BillingAsset struct {
	ID          int64  `json:"id"`
	AccountName string `json:"accountName"`
	LoginID     string `json:"loginId"`
	Balance     string `json:"balance"`
	Product     string `json:"product"`
	Note        string `json:"note"`
	Status      string `json:"status"`
	IP          string `json:"ip"`
	IPNorm      string `json:"ipNorm"`
	ExpireAt    string `json:"expireAt"`
	ExpireUnix  int64  `json:"expireUnix"`
	DaysLeft    int    `json:"daysLeft"`
	Fee         string `json:"fee"`
	Cycle       string `json:"cycle"`
	OS          string `json:"os"`
	Bandwidth   string `json:"bandwidth"`
	Region      string `json:"region"`
	SyncedAt    int64  `json:"syncedAt"`
}

func (s *Store) ensureBillingTables() error {
	_, err := s.db.Exec(`
CREATE TABLE IF NOT EXISTS billing_assets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  account_name TEXT NOT NULL DEFAULT '',
  login_id TEXT NOT NULL DEFAULT '',
  balance TEXT NOT NULL DEFAULT '',
  product TEXT NOT NULL DEFAULT '',
  note TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT '',
  ip TEXT NOT NULL DEFAULT '',
  ip_norm TEXT NOT NULL DEFAULT '',
  expire_at TEXT NOT NULL DEFAULT '',
  expire_unix INTEGER NOT NULL DEFAULT 0,
  days_left INTEGER NOT NULL DEFAULT 0,
  fee TEXT NOT NULL DEFAULT '',
  cycle TEXT NOT NULL DEFAULT '',
  os TEXT NOT NULL DEFAULT '',
  bandwidth TEXT NOT NULL DEFAULT '',
  region TEXT NOT NULL DEFAULT '',
  synced_at INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_billing_ip_norm ON billing_assets(ip_norm);
CREATE INDEX IF NOT EXISTS idx_billing_expire ON billing_assets(expire_unix);
`)
	if err != nil {
		return err
	}
	return s.ensureBillingSnapshotTable()
}

func (s *Store) ReplaceBillingAssets(ctx context.Context, rows []BillingAsset) error {
	if err := s.ensureBillingTables(); err != nil {
		return err
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `DELETE FROM billing_assets`); err != nil {
		return err
	}
	now := time.Now().Unix()
	for _, r := range rows {
		if r.SyncedAt == 0 {
			r.SyncedAt = now
		}
		_, err := tx.ExecContext(ctx, `
INSERT INTO billing_assets(
  account_name, login_id, balance, product, note, status, ip, ip_norm,
  expire_at, expire_unix, days_left, fee, cycle, os, bandwidth, region, synced_at
) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
			r.AccountName, r.LoginID, r.Balance, r.Product, r.Note, r.Status, r.IP, r.IPNorm,
			r.ExpireAt, r.ExpireUnix, r.DaysLeft, r.Fee, r.Cycle, r.OS, r.Bandwidth, r.Region, r.SyncedAt)
		if err != nil {
			return err
		}
	}
	return tx.Commit()
}

func (s *Store) ListBillingAssets(ctx context.Context) ([]BillingAsset, error) {
	if err := s.ensureBillingTables(); err != nil {
		return nil, err
	}
	rows, err := s.db.QueryContext(ctx, `
SELECT id, account_name, login_id, balance, product, note, status, ip, ip_norm,
       expire_at, expire_unix, days_left, fee, cycle, os, bandwidth, region, synced_at
FROM billing_assets
ORDER BY CASE WHEN expire_unix=0 THEN 1 ELSE 0 END, expire_unix ASC, account_name, ip`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []BillingAsset
	for rows.Next() {
		var r BillingAsset
		if err := rows.Scan(
			&r.ID, &r.AccountName, &r.LoginID, &r.Balance, &r.Product, &r.Note, &r.Status, &r.IP, &r.IPNorm,
			&r.ExpireAt, &r.ExpireUnix, &r.DaysLeft, &r.Fee, &r.Cycle, &r.OS, &r.Bandwidth, &r.Region, &r.SyncedAt,
		); err != nil {
			return nil, err
		}
		out = append(out, r)
	}
	return out, rows.Err()
}

func (s *Store) BillingSyncedAt(ctx context.Context) (int64, error) {
	if err := s.ensureBillingTables(); err != nil {
		return 0, err
	}
	var v sql.NullInt64
	err := s.db.QueryRowContext(ctx, `SELECT MAX(synced_at) FROM billing_assets`).Scan(&v)
	if err != nil {
		return 0, err
	}
	if !v.Valid {
		return 0, nil
	}
	return v.Int64, nil
}
