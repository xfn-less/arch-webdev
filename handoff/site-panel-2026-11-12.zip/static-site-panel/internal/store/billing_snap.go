package store

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"time"
)

const MaxBillingSnapshots = 10

type BillingSnapshotMeta struct {
	ID        int64  `json:"id"`
	CreatedAt int64  `json:"createdAt"`
	Label     string `json:"label"`
	RowCount  int    `json:"rowCount"`
}

func (s *Store) ensureBillingSnapshotTable() error {
	_, err := s.db.Exec(`
CREATE TABLE IF NOT EXISTS billing_snapshots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at INTEGER NOT NULL,
  label TEXT NOT NULL DEFAULT '',
  row_count INTEGER NOT NULL DEFAULT 0,
  payload TEXT NOT NULL
);
`)
	return err
}

// ArchiveBillingAssets copies current assets into a snapshot, then prunes old ones.
func (s *Store) ArchiveBillingAssets(ctx context.Context, label string) (BillingSnapshotMeta, error) {
	if err := s.ensureBillingSnapshotTable(); err != nil {
		return BillingSnapshotMeta{}, err
	}
	rows, err := s.ListBillingAssets(ctx)
	if err != nil {
		return BillingSnapshotMeta{}, err
	}
	if len(rows) == 0 {
		return BillingSnapshotMeta{}, nil
	}
	payload, err := json.Marshal(rows)
	if err != nil {
		return BillingSnapshotMeta{}, err
	}
	now := time.Now().Unix()
	if label == "" {
		label = time.Unix(now, 0).Format("2006-01-02 15:04:05")
	}
	res, err := s.db.ExecContext(ctx, `
INSERT INTO billing_snapshots(created_at, label, row_count, payload) VALUES(?,?,?,?)`,
		now, label, len(rows), string(payload))
	if err != nil {
		return BillingSnapshotMeta{}, err
	}
	id, _ := res.LastInsertId()
	_ = s.pruneBillingSnapshots(ctx, MaxBillingSnapshots)
	return BillingSnapshotMeta{ID: id, CreatedAt: now, Label: label, RowCount: len(rows)}, nil
}

func (s *Store) pruneBillingSnapshots(ctx context.Context, keep int) error {
	rows, err := s.db.QueryContext(ctx, `
SELECT id FROM billing_snapshots ORDER BY id DESC`)
	if err != nil {
		return err
	}
	defer rows.Close()
	var ids []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return err
		}
		ids = append(ids, id)
	}
	if len(ids) <= keep {
		return nil
	}
	for _, id := range ids[keep:] {
		if _, err := s.db.ExecContext(ctx, `DELETE FROM billing_snapshots WHERE id=?`, id); err != nil {
			return err
		}
	}
	return nil
}

func (s *Store) ListBillingSnapshots(ctx context.Context) ([]BillingSnapshotMeta, error) {
	if err := s.ensureBillingSnapshotTable(); err != nil {
		return nil, err
	}
	rows, err := s.db.QueryContext(ctx, `
SELECT id, created_at, label, row_count FROM billing_snapshots ORDER BY id DESC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []BillingSnapshotMeta
	for rows.Next() {
		var m BillingSnapshotMeta
		if err := rows.Scan(&m.ID, &m.CreatedAt, &m.Label, &m.RowCount); err != nil {
			return nil, err
		}
		out = append(out, m)
	}
	return out, rows.Err()
}

func (s *Store) GetBillingSnapshotAssets(ctx context.Context, id int64) ([]BillingAsset, BillingSnapshotMeta, error) {
	if err := s.ensureBillingSnapshotTable(); err != nil {
		return nil, BillingSnapshotMeta{}, err
	}
	var m BillingSnapshotMeta
	var payload string
	err := s.db.QueryRowContext(ctx, `
SELECT id, created_at, label, row_count, payload FROM billing_snapshots WHERE id=?`, id).
		Scan(&m.ID, &m.CreatedAt, &m.Label, &m.RowCount, &payload)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, BillingSnapshotMeta{}, ErrNotFound
	}
	if err != nil {
		return nil, BillingSnapshotMeta{}, err
	}
	var assets []BillingAsset
	if err := json.Unmarshal([]byte(payload), &assets); err != nil {
		return nil, BillingSnapshotMeta{}, err
	}
	return assets, m, nil
}

func (s *Store) RestoreBillingSnapshot(ctx context.Context, id int64) error {
	assets, _, err := s.GetBillingSnapshotAssets(ctx, id)
	if err != nil {
		return err
	}
	// archive current first so restore is also reversible
	if _, err := s.ArchiveBillingAssets(ctx, "restore前自动备份"); err != nil {
		return err
	}
	return s.ReplaceBillingAssets(ctx, assets)
}
