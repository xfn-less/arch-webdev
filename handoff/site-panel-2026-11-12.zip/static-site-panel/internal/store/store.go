package store

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	_ "modernc.org/sqlite"
)

var ErrNotFound = errors.New("not found")

type PasswordCodec interface {
	Seal(plain string) string
	Open(stored string) (string, error)
}

type Store struct {
	db  *sql.DB
	box PasswordCodec
}

type Server struct {
	ID        int64  `json:"id"`
	Name      string `json:"name"`
	Host      string `json:"host"`
	Port      int    `json:"port"`
	User      string `json:"user"`
	AuthType  string `json:"authType"`  // key | password
	AuthValue string `json:"authValue"` // private key path when authType=key
	Password  string `json:"password"`  // ssh password (also used to install key)
	PublicIP  string `json:"publicIP"`
	Note      string `json:"note"`
	ViaJump   bool   `json:"viaJump"` // SSH via panel CN jump (flaky HK→mainland)
}

type Site struct {
	ID            int64  `json:"id"`
	Name          string `json:"name"`  // stable folder id under sites root (never “改名”)
	Title         string `json:"title"` // display label / 备注名
	ServerID      int64  `json:"serverId"`
	Note          string `json:"note"`
	SSLServerID   int64  `json:"sslServerId"`
	SSLDomains    string `json:"sslDomains"`
	SSLNotAfter   int64  `json:"sslNotAfter"`   // unix seconds
	ApkObfuscate  bool   `json:"apkObfuscate"`  // .apk文件自动混淆
	Disabled      bool   `json:"disabled"`      // 停用：远端 conf 不加载，本机文件保留
	PendingDeploy bool   `json:"pendingDeploy"` // 本机已保存改动，尚未成功部署
}

func Open(path string) (*Store, error) {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return nil, err
	}
	db, err := sql.Open("sqlite", path)
	if err != nil {
		return nil, err
	}
	db.SetMaxOpenConns(1)
	_, _ = db.Exec(`PRAGMA busy_timeout=5000`)
	_, _ = db.Exec(`PRAGMA journal_mode=WAL`)
	s := &Store{db: db}
	if err := s.migrate(); err != nil {
		_ = db.Close()
		return nil, err
	}
	return s, nil
}

func (s *Store) Close() error { return s.db.Close() }

func (s *Store) SetPasswordCodec(box PasswordCodec) { s.box = box }

func (s *Store) sealPassword(p string) string {
	if s.box == nil || p == "" {
		return p
	}
	return s.box.Seal(p)
}

func (s *Store) openPassword(p string) string {
	if p == "" {
		return ""
	}
	if s.box == nil {
		return p // tests without codec
	}
	out, err := s.box.Open(p)
	if err != nil {
		return ""
	}
	return out
}

func (s *Store) migrate() error {
	_, err := s.db.Exec(`
CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS servers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  host TEXT NOT NULL,
  port INTEGER NOT NULL DEFAULT 22,
  user TEXT NOT NULL DEFAULT 'root',
  auth_type TEXT NOT NULL DEFAULT 'key',
  auth_value TEXT NOT NULL DEFAULT '',
  password TEXT NOT NULL DEFAULT '',
  public_ip TEXT NOT NULL DEFAULT '',
  note TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS sites (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  server_id INTEGER NOT NULL DEFAULT 0,
  note TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS session (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  token_hash BLOB NOT NULL,
  csrf TEXT NOT NULL,
  expires_at INTEGER NOT NULL
);
`)
	if err != nil {
		return err
	}
	// additive migration for existing DBs
	_, _ = s.db.Exec(`ALTER TABLE servers ADD COLUMN password TEXT NOT NULL DEFAULT ''`)
	_, _ = s.db.Exec(`ALTER TABLE sites ADD COLUMN ssl_server_id INTEGER NOT NULL DEFAULT 0`)
	_, _ = s.db.Exec(`ALTER TABLE sites ADD COLUMN ssl_domains TEXT NOT NULL DEFAULT ''`)
	_, _ = s.db.Exec(`ALTER TABLE sites ADD COLUMN ssl_not_after INTEGER NOT NULL DEFAULT 0`)
	_, _ = s.db.Exec(`ALTER TABLE sites ADD COLUMN title TEXT NOT NULL DEFAULT ''`)
	_, _ = s.db.Exec(`ALTER TABLE sites ADD COLUMN apk_obfuscate INTEGER NOT NULL DEFAULT 0`)
	_, _ = s.db.Exec(`ALTER TABLE sites ADD COLUMN disabled INTEGER NOT NULL DEFAULT 0`)
	_, _ = s.db.Exec(`ALTER TABLE sites ADD COLUMN pending_deploy INTEGER NOT NULL DEFAULT 0`)
	_, _ = s.db.Exec(`ALTER TABLE session ADD COLUMN max_expires_at INTEGER NOT NULL DEFAULT 0`)
	_, _ = s.db.Exec(`ALTER TABLE servers ADD COLUMN via_jump INTEGER NOT NULL DEFAULT 0`)
	if err := s.ensureBillingTables(); err != nil {
		return err
	}
	return nil
}

func (s *Store) Meta(ctx context.Context, key string) (string, error) {
	var v string
	err := s.db.QueryRowContext(ctx, `SELECT value FROM meta WHERE key = ?`, key).Scan(&v)
	if errors.Is(err, sql.ErrNoRows) {
		return "", ErrNotFound
	}
	return v, err
}

func (s *Store) SetMeta(ctx context.Context, key, value string) error {
	_, err := s.db.ExecContext(ctx, `
INSERT INTO meta(key, value) VALUES(?, ?)
ON CONFLICT(key) DO UPDATE SET value = excluded.value`, key, value)
	return err
}

func (s *Store) DeleteMeta(ctx context.Context, key string) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM meta WHERE key=?`, key)
	return err
}

func (s *Store) ListServers(ctx context.Context) ([]Server, error) {
	rows, err := s.db.QueryContext(ctx, `
SELECT id, name, host, port, user, auth_type, auth_value, password, public_ip, note, via_jump
FROM servers ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Server
	for rows.Next() {
		var r Server
		var via int
		if err := rows.Scan(&r.ID, &r.Name, &r.Host, &r.Port, &r.User, &r.AuthType, &r.AuthValue, &r.Password, &r.PublicIP, &r.Note, &via); err != nil {
			return nil, err
		}
		r.ViaJump = via != 0
		r.Password = s.openPassword(r.Password)
		out = append(out, r)
	}
	return out, rows.Err()
}

func (s *Store) GetServer(ctx context.Context, id int64) (Server, error) {
	var r Server
	var via int
	err := s.db.QueryRowContext(ctx, `
SELECT id, name, host, port, user, auth_type, auth_value, password, public_ip, note, via_jump
FROM servers WHERE id = ?`, id).Scan(
		&r.ID, &r.Name, &r.Host, &r.Port, &r.User, &r.AuthType, &r.AuthValue, &r.Password, &r.PublicIP, &r.Note, &via)
	if errors.Is(err, sql.ErrNoRows) {
		return Server{}, ErrNotFound
	}
	if err != nil {
		return Server{}, err
	}
	r.ViaJump = via != 0
	r.Password = s.openPassword(r.Password)
	return r, nil
}

func (s *Store) UpsertServer(ctx context.Context, r Server) (Server, error) {
	if r.Port == 0 {
		r.Port = 22
	}
	if r.User == "" {
		r.User = "root"
	}
	if r.AuthType == "" {
		r.AuthType = "key"
	}
	via := 0
	if r.ViaJump {
		via = 1
	}
	plain := r.Password
	if r.ID == 0 {
		sealed := s.sealPassword(plain)
		res, err := s.db.ExecContext(ctx, `
INSERT INTO servers(name, host, port, user, auth_type, auth_value, password, public_ip, note, via_jump)
VALUES(?,?,?,?,?,?,?,?,?,?)`, r.Name, r.Host, r.Port, r.User, r.AuthType, r.AuthValue, sealed, r.PublicIP, r.Note, via)
		if err != nil {
			return Server{}, err
		}
		r.ID, _ = res.LastInsertId()
		r.Password = plain
		return r, nil
	}
	if plain == "" {
		cur, err := s.GetServer(ctx, r.ID)
		if err != nil {
			return Server{}, err
		}
		plain = cur.Password
	}
	sealed := s.sealPassword(plain)
	_, err := s.db.ExecContext(ctx, `
UPDATE servers SET name=?, host=?, port=?, user=?, auth_type=?, auth_value=?, password=?, public_ip=?, note=?, via_jump=?
WHERE id=?`, r.Name, r.Host, r.Port, r.User, r.AuthType, r.AuthValue, sealed, r.PublicIP, r.Note, via, r.ID)
	r.Password = plain
	return r, err
}

func (s *Store) DeleteServer(ctx context.Context, id int64) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `UPDATE sites SET server_id=0 WHERE server_id=?`, id); err != nil {
		return err
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM servers WHERE id=?`, id); err != nil {
		return err
	}
	return tx.Commit()
}

func (s *Store) ListSites(ctx context.Context) ([]Site, error) {
	rows, err := s.db.QueryContext(ctx, `
SELECT id, name, title, server_id, note, ssl_server_id, ssl_domains, ssl_not_after, apk_obfuscate, disabled, pending_deploy FROM sites ORDER BY name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Site
	for rows.Next() {
		var r Site
		var apk, disabled, pending int
		if err := rows.Scan(&r.ID, &r.Name, &r.Title, &r.ServerID, &r.Note, &r.SSLServerID, &r.SSLDomains, &r.SSLNotAfter, &apk, &disabled, &pending); err != nil {
			return nil, err
		}
		r.ApkObfuscate = apk != 0
		r.Disabled = disabled != 0
		r.PendingDeploy = pending != 0
		out = append(out, r)
	}
	return out, rows.Err()
}

func (s *Store) GetSiteByName(ctx context.Context, name string) (Site, error) {
	var r Site
	var apk, disabled, pending int
	err := s.db.QueryRowContext(ctx, `
SELECT id, name, title, server_id, note, ssl_server_id, ssl_domains, ssl_not_after, apk_obfuscate, disabled, pending_deploy FROM sites WHERE name=?`, name).Scan(
		&r.ID, &r.Name, &r.Title, &r.ServerID, &r.Note, &r.SSLServerID, &r.SSLDomains, &r.SSLNotAfter, &apk, &disabled, &pending)
	if errors.Is(err, sql.ErrNoRows) {
		return Site{}, ErrNotFound
	}
	r.ApkObfuscate = apk != 0
	r.Disabled = disabled != 0
	r.PendingDeploy = pending != 0
	return r, err
}

func (s *Store) UpsertSite(ctx context.Context, r Site) (Site, error) {
	if r.Name == "" {
		return Site{}, fmt.Errorf("site name required")
	}
	existing, err := s.GetSiteByName(ctx, r.Name)
	if err == nil {
		r.ID = existing.ID
		title := r.Title
		if title == "" {
			title = existing.Title
		}
		// A different destination has not received this site's master copy yet.
		r.PendingDeploy = existing.PendingDeploy || r.ServerID != existing.ServerID
		_, err = s.db.ExecContext(ctx, `UPDATE sites SET server_id=?, note=?, title=?, pending_deploy=? WHERE id=?`, r.ServerID, r.Note, title, r.PendingDeploy, r.ID)
		r.Title = title
		r.SSLServerID = existing.SSLServerID
		r.SSLDomains = existing.SSLDomains
		r.SSLNotAfter = existing.SSLNotAfter
		r.ApkObfuscate = existing.ApkObfuscate
		r.Disabled = existing.Disabled
		return r, err
	}
	if !errors.Is(err, ErrNotFound) {
		return Site{}, err
	}
	if r.Title == "" {
		r.Title = r.Name
	}
	res, err := s.db.ExecContext(ctx, `
INSERT INTO sites(name, title, server_id, note) VALUES(?,?,?,?)`, r.Name, r.Title, r.ServerID, r.Note)
	if err != nil {
		return Site{}, err
	}
	r.ID, _ = res.LastInsertId()
	return r, nil
}

// AllocSite creates a DB row and assigns stable folder id s{N}.
func (s *Store) AllocSite(ctx context.Context, title string, serverID int64) (Site, error) {
	title = strings.TrimSpace(title)
	if title == "" {
		return Site{}, fmt.Errorf("title required")
	}
	tmp := fmt.Sprintf("_alloc_%d", time.Now().UnixNano())
	res, err := s.db.ExecContext(ctx, `
INSERT INTO sites(name, title, server_id, note) VALUES(?,?,?,?)`, tmp, title, serverID, "")
	if err != nil {
		return Site{}, err
	}
	id, _ := res.LastInsertId()
	name := fmt.Sprintf("s%d", id)
	if _, err := s.db.ExecContext(ctx, `UPDATE sites SET name=? WHERE id=?`, name, id); err != nil {
		_, _ = s.db.ExecContext(ctx, `DELETE FROM sites WHERE id=?`, id)
		return Site{}, err
	}
	return s.GetSiteByName(ctx, name)
}

// SetSiteTitle changes display label only; folder name stays put.
func (s *Store) SetSiteTitle(ctx context.Context, name, title string) (Site, error) {
	title = strings.TrimSpace(title)
	if title == "" {
		return Site{}, fmt.Errorf("title required")
	}
	res, err := s.db.ExecContext(ctx, `UPDATE sites SET title=? WHERE name=?`, title, name)
	if err != nil {
		return Site{}, err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		// disk-only site: create meta row
		return s.UpsertSite(ctx, Site{Name: name, Title: title})
	}
	return s.GetSiteByName(ctx, name)
}

func (s *Store) SetSiteSSL(ctx context.Context, name string, serverID int64, domainsKey string, notAfterUnix int64) error {
	_, err := s.db.ExecContext(ctx, `
UPDATE sites SET ssl_server_id=?, ssl_domains=?, ssl_not_after=? WHERE name=?`,
		serverID, domainsKey, notAfterUnix, name)
	return err
}

// SetSiteApkObfuscate toggles in-place remote APK obfuscation for a site.
func (s *Store) SetSiteApkObfuscate(ctx context.Context, name string, on bool) (Site, error) {
	v := 0
	if on {
		v = 1
	}
	res, err := s.db.ExecContext(ctx, `UPDATE sites SET apk_obfuscate=? WHERE name=?`, v, name)
	if err != nil {
		return Site{}, err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return Site{}, ErrNotFound
	}
	return s.GetSiteByName(ctx, name)
}

// SetSiteDisabled marks a site stopped/running in DB. Remote conf is handled by the API/deploy layer.
func (s *Store) SetSiteDisabled(ctx context.Context, name string, disabled bool) (Site, error) {
	v := 0
	if disabled {
		v = 1
	}
	res, err := s.db.ExecContext(ctx, `UPDATE sites SET disabled=? WHERE name=?`, v, name)
	if err != nil {
		return Site{}, err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return Site{}, ErrNotFound
	}
	return s.GetSiteByName(ctx, name)
}

// SetSitePendingDeploy marks whether master disk is ahead of the last successful deploy.
// Disk-only sites get a meta row created so the flag can stick.
func (s *Store) SetSitePendingDeploy(ctx context.Context, name string, pending bool) (Site, error) {
	if name == "" {
		return Site{}, fmt.Errorf("site name required")
	}
	v := 0
	if pending {
		v = 1
	}
	res, err := s.db.ExecContext(ctx, `UPDATE sites SET pending_deploy=? WHERE name=?`, v, name)
	if err != nil {
		return Site{}, err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		if _, err := s.UpsertSite(ctx, Site{Name: name, Title: name}); err != nil {
			return Site{}, err
		}
		if _, err := s.db.ExecContext(ctx, `UPDATE sites SET pending_deploy=? WHERE name=?`, v, name); err != nil {
			return Site{}, err
		}
	}
	return s.GetSiteByName(ctx, name)
}

func (s *Store) DeleteSite(ctx context.Context, name string) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM sites WHERE name=?`, name)
	return err
}

func (s *Store) RenameSite(ctx context.Context, oldName, newName string) (Site, error) {
	if newName == "" {
		return Site{}, fmt.Errorf("new name required")
	}
	if _, err := s.GetSiteByName(ctx, newName); err == nil {
		return Site{}, fmt.Errorf("site name already exists")
	} else if !errors.Is(err, ErrNotFound) {
		return Site{}, err
	}
	res, err := s.db.ExecContext(ctx, `UPDATE sites SET name=? WHERE name=?`, newName, oldName)
	if err != nil {
		return Site{}, err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		// allow rename of disk-only sites by inserting after fs rename
		return Site{}, ErrNotFound
	}
	return s.GetSiteByName(ctx, newName)
}

type SessionRow struct {
	TokenHash    []byte
	CSRF         string
	ExpiresAt    time.Time // idle deadline (sliding)
	MaxExpiresAt time.Time // absolute cap from login
}

func (s *Store) GetSession(ctx context.Context) (SessionRow, error) {
	var row SessionRow
	var exp, maxExp int64
	err := s.db.QueryRowContext(ctx, `SELECT token_hash, csrf, expires_at, max_expires_at FROM session WHERE id=1`).Scan(
		&row.TokenHash, &row.CSRF, &exp, &maxExp)
	if errors.Is(err, sql.ErrNoRows) {
		return SessionRow{}, ErrNotFound
	}
	if err != nil {
		return SessionRow{}, err
	}
	row.ExpiresAt = time.Unix(exp, 0)
	if maxExp > 0 {
		row.MaxExpiresAt = time.Unix(maxExp, 0)
	} else {
		// Pre-migration rows: treat expires_at as the hard cap too.
		row.MaxExpiresAt = row.ExpiresAt
	}
	return row, nil
}

func (s *Store) PutSession(ctx context.Context, tokenHash []byte, csrf string, idleExpires, maxExpires time.Time) error {
	_, err := s.db.ExecContext(ctx, `
INSERT INTO session(id, token_hash, csrf, expires_at, max_expires_at) VALUES(1,?,?,?,?)
ON CONFLICT(id) DO UPDATE SET
  token_hash=excluded.token_hash,
  csrf=excluded.csrf,
  expires_at=excluded.expires_at,
  max_expires_at=excluded.max_expires_at`,
		tokenHash, csrf, idleExpires.Unix(), maxExpires.Unix())
	return err
}

// TouchSession slides the idle deadline without changing the absolute max.
func (s *Store) TouchSession(ctx context.Context, idleExpires time.Time) error {
	_, err := s.db.ExecContext(ctx, `UPDATE session SET expires_at=? WHERE id=1`, idleExpires.Unix())
	return err
}

func (s *Store) ClearSession(ctx context.Context) error {
	_, err := s.db.ExecContext(ctx, `DELETE FROM session WHERE id=1`)
	return err
}
