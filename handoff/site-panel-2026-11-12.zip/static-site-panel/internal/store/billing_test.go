package store

import (
	"context"
	"path/filepath"
	"testing"
)

func TestBillingSnapshotPruneAndRestore(t *testing.T) {
	st, err := Open(filepath.Join(t.TempDir(), "panel.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer st.Close()
	ctx := context.Background()
	for i := 0; i < 15; i++ {
		if err := st.ReplaceBillingAssets(ctx, []BillingAsset{{IP: "192.0.2.1", DaysLeft: i}}); err != nil {
			t.Fatal(err)
		}
		if _, err := st.ArchiveBillingAssets(ctx, ""); err != nil {
			t.Fatal(err)
		}
	}
	snapshots, err := st.ListBillingSnapshots(ctx)
	if err != nil || len(snapshots) != MaxBillingSnapshots {
		t.Fatal("snapshot cap", len(snapshots), err)
	}
	oldest := snapshots[len(snapshots)-1]
	if err := st.RestoreBillingSnapshot(ctx, oldest.ID); err != nil {
		t.Fatal(err)
	}
	rows, err := st.ListBillingAssets(ctx)
	if err != nil || len(rows) != 1 || rows[0].DaysLeft != 5 {
		t.Fatal("restore", rows, err)
	}
}

func TestBillingRestoreStopsWhenArchiveFails(t *testing.T) {
	st, err := Open(filepath.Join(t.TempDir(), "panel.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer st.Close()
	ctx := context.Background()
	st.ReplaceBillingAssets(ctx, []BillingAsset{{IP: "192.0.2.1"}})
	snapshot, err := st.ArchiveBillingAssets(ctx, "")
	if err != nil {
		t.Fatal(err)
	}
	st.ReplaceBillingAssets(ctx, []BillingAsset{{IP: "192.0.2.2"}})
	_, err = st.db.Exec(`CREATE TRIGGER audit_archive_failure BEFORE INSERT ON billing_snapshots BEGIN SELECT RAISE(ABORT,'simulated archive failure'); END;`)
	if err != nil {
		t.Fatal(err)
	}
	if err := st.RestoreBillingSnapshot(ctx, snapshot.ID); err == nil {
		t.Fatal("restore silently overwrote current data despite failed archive")
	}
	rows, err := st.ListBillingAssets(ctx)
	if err != nil || len(rows) != 1 || rows[0].IP != "192.0.2.2" {
		t.Fatal("current data lost", rows, err)
	}
}
