package store

import (
	"context"
	"path/filepath"
	"testing"
)

func TestSetSitePendingDeploy(t *testing.T) {
	st, err := Open(filepath.Join(t.TempDir(), "panel.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = st.Close() })
	ctx := context.Background()

	site, err := st.AllocSite(ctx, "demo", 0)
	if err != nil {
		t.Fatal(err)
	}
	if site.PendingDeploy {
		t.Fatal("new alloc should start clear until marked")
	}

	got, err := st.SetSitePendingDeploy(ctx, site.Name, true)
	if err != nil || !got.PendingDeploy {
		t.Fatalf("mark pending: %+v %v", got, err)
	}
	got, err = st.GetSiteByName(ctx, site.Name)
	if err != nil || !got.PendingDeploy {
		t.Fatalf("persist pending: %+v %v", got, err)
	}

	got, err = st.SetSitePendingDeploy(ctx, site.Name, false)
	if err != nil || got.PendingDeploy {
		t.Fatalf("clear pending: %+v %v", got, err)
	}

	// Disk-only name: create meta row on demand.
	orphan, err := st.SetSitePendingDeploy(ctx, "sorphan", true)
	if err != nil || !orphan.PendingDeploy || orphan.Name != "sorphan" {
		t.Fatalf("orphan mark: %+v %v", orphan, err)
	}
}
