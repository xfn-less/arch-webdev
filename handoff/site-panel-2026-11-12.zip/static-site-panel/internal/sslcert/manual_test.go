package sslcert

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"math/big"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestParseLeafAndKeyMatch(t *testing.T) {
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	tmpl := &x509.Certificate{
		SerialNumber: big.NewInt(1),
		Subject:      pkix.Name{CommonName: "example.test"},
		DNSNames:     []string{"example.test"},
		NotBefore:    time.Now().Add(-time.Hour),
		NotAfter:     time.Now().Add(24 * time.Hour),
	}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &key.PublicKey, key)
	if err != nil {
		t.Fatal(err)
	}
	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	keyDER, err := x509.MarshalECPrivateKey(key)
	if err != nil {
		t.Fatal(err)
	}
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: keyDER})

	leaf, err := parseLeafCert(string(certPEM))
	if err != nil {
		t.Fatal(err)
	}
	if leaf.Subject.CommonName != "example.test" {
		t.Fatalf("cn=%s", leaf.Subject.CommonName)
	}
	if !HasManualCert("/no/such", "x") {
		// expected false
	} else {
		t.Fatal("expected no manual cert")
	}
	if _, err := tls.X509KeyPair(certPEM, keyPEM); err != nil {
		t.Fatal(err)
	}

	root := t.TempDir()
	dir := localSSLDir(root, "s1")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, "fullchain.pem"), certPEM, 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, "privkey.pem"), keyPEM, 0o600); err != nil {
		t.Fatal(err)
	}
	fc, k := ReadStoredPEM(root, "s1")
	if fc != string(certPEM) || k != string(keyPEM) {
		t.Fatalf("ReadStoredPEM mismatch fc=%d key=%d", len(fc), len(k))
	}
	emptyFC, emptyKey := ReadStoredPEM(root, "missing")
	if emptyFC != "" || emptyKey != "" {
		t.Fatal("expected empty for missing site")
	}
}
