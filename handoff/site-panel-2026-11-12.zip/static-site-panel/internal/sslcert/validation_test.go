package sslcert

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"github.com/xfn/static-site-panel/internal/confmark"
	"github.com/xfn/static-site-panel/internal/store"
	"math/big"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestRegressionRejectsExpiredManualCertificate(t *testing.T) {
	key, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	tmpl := &x509.Certificate{SerialNumber: big.NewInt(7), Subject: pkix.Name{CommonName: "example.test"}, DNSNames: []string{"example.test"}, NotBefore: time.Now().Add(-48 * time.Hour), NotAfter: time.Now().Add(-24 * time.Hour)}
	der, _ := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &key.PublicKey, key)
	keyDER, _ := x509.MarshalECPrivateKey(key)
	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: keyDER})
	root := t.TempDir()
	os.MkdirAll(filepath.Join(root, "demo", "www"), 0755)
	conf := "server {\n listen 80;\n" + confmark.ServerNameBegin + "\n server_name example.test;\n" + confmark.ServerNameEnd + "\n" + confmark.SSLBegin + "\n" + confmark.SSLEnd + "\n}\n"
	os.WriteFile(filepath.Join(root, "demo", "nginx.conf"), []byte(conf), 0644)
	bin := t.TempDir()
	for _, name := range []string{"ssh", "rsync"} {
		os.WriteFile(filepath.Join(bin, name), []byte("#!/bin/sh\nexit 0\n"), 0755)
	}
	t.Setenv("PATH", bin+string(os.PathListSeparator)+os.Getenv("PATH"))
	result, err := InstallManual(context.Background(), Options{SitesRoot: root, SiteName: "demo", RemoteWWW: "/www/demo", RemoteConf: "/etc/nginx/conf.d/demo.conf", Server: store.Server{Host: "dummy.invalid", AuthType: "key"}}, string(certPEM), string(keyPEM), nil)
	if err == nil {
		t.Fatalf("expired certificate accepted as issued=%v days=%d", result.Issued, result.DaysLeft)
	}
}
