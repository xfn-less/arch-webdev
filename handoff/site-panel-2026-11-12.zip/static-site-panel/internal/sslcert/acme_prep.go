package sslcert

import (
	"fmt"
	"strings"

	"github.com/xfn/static-site-panel/internal/confmark"
)

// prepareACMEConf keeps the live vhost (proxy, sub_filter, custom locations)
// and only ensures HTTP ACME can run. When needPauseTLS is true (no readable
// cert files yet), listen 443 / SSL body / HTTPS redirect are paused so nginx
// still loads — never replace the whole server with a stripped bootstrap.
func prepareACMEConf(conf, wwwRoot string, needPauseTLS bool) (string, error) {
	if strings.ContainsAny(wwwRoot, "\r\n\x00") {
		return "", fmt.Errorf("invalid ACME webroot")
	}
	next := confmark.EnsureMarkers(conf)
	next = confmark.EnsureListen80ForDomains(next)
	if needPauseTLS {
		next = confmark.PauseTLSServing(next)
	}
	next = confmark.EnsureACMEChallenge(next, wwwRoot)
	return next, nil
}
