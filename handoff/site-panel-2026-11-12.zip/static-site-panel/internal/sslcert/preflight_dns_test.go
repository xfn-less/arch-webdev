package sslcert

import (
	"testing"

	"github.com/xfn/static-site-panel/internal/dnscheck"
)

func TestDNSItemsCoverHosts(t *testing.T) {
	items := []dnscheck.Item{
		{Domain: "a.example", OK: true},
		{Domain: "b.example", OK: false},
	}
	if !dnsItemsCoverHosts([]string{"a.example", "b.example"}, items) {
		t.Fatal("expected cover")
	}
	if dnsItemsCoverHosts([]string{"a.example", "c.example"}, items) {
		t.Fatal("missing c should not cover")
	}
	allOK := []dnscheck.Item{
		{Domain: "a.example", OK: true},
		{Domain: "b.example", OK: true},
	}
	if !dnsItemsAllOK([]string{"a.example", "b.example"}, allOK) {
		t.Fatal("all ok should pass")
	}
	if dnsItemsAllOK([]string{"a.example", "b.example"}, items) {
		t.Fatal("failed item must not pass")
	}
	if !dnsItemsCoverHosts(nil, nil) {
		t.Fatal("empty hosts ok")
	}
}
