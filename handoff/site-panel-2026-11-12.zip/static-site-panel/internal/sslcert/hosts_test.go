package sslcert

import "testing"

func TestCertHostnamesSkipsIPs(t *testing.T) {
	got := CertHostnames([]string{
		"wmx.pojaax.cn",
		"220.167.103.189",
		"::1",
		"vie.pojaax.cn",
		"220.167.103.189",
		"",
		"#还没发",
		"host#bad",
	})
	if len(got) != 2 || got[0] != "wmx.pojaax.cn" || got[1] != "vie.pojaax.cn" {
		t.Fatalf("got %#v", got)
	}
	if !IsIPLiteral("220.167.103.189") || IsIPLiteral("wmx.pojaax.cn") {
		t.Fatal("IsIPLiteral")
	}
}

func TestDomainsKeyIgnoresIP(t *testing.T) {
	withIP := DomainsKey([]string{"b.example", "10.0.0.1", "a.example"})
	without := DomainsKey([]string{"a.example", "b.example"})
	if withIP != without || withIP != "a.example,b.example" {
		t.Fatalf("got %q want a.example,b.example", withIP)
	}
}

func TestMissingHostnamesSubsetAndIP(t *testing.T) {
	have := []string{"a.example", "b.example", "103.236.63.214"}
	if m := MissingHostnames(have, []string{"b.example", "a.example"}); len(m) != 0 {
		t.Fatalf("subset should be covered, got %#v", m)
	}
	if m := MissingHostnames(have, []string{"a.example", "c.example", "1.2.3.4"}); len(m) != 1 || m[0] != "c.example" {
		t.Fatalf("only c.example missing, got %#v", m)
	}
	if !domainsCovered(have, []string{"a.example", "10.0.0.1"}) {
		t.Fatal("IP in want must not break coverage")
	}
}
