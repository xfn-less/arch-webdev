package sslcert

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/xfn/static-site-panel/internal/confmark"
	"github.com/xfn/static-site-panel/internal/deploy"
	"github.com/xfn/static-site-panel/internal/sitesfs"
)

const manualMarker = ".manual"

func localSSLDir(sitesRoot, site string) string {
	return filepath.Join(sitesRoot, site, "ssl")
}

func remoteSSLDir(site string) string {
	return deploy.ManualSSLDir(site)
}

func HasManualCert(sitesRoot, site string) bool {
	_, err := os.Stat(filepath.Join(localSSLDir(sitesRoot, site), manualMarker))
	return err == nil
}

// ReadStoredPEM returns master-side ssl/fullchain.pem and privkey.pem when present
// (empty string per file if missing). Used to prefill the SSL dialog.
func ReadStoredPEM(sitesRoot, site string) (fullchain, key string) {
	if b, err := os.ReadFile(filepath.Join(localSSLDir(sitesRoot, site), "fullchain.pem")); err == nil {
		fullchain = string(b)
	}
	if b, err := os.ReadFile(filepath.Join(localSSLDir(sitesRoot, site), "privkey.pem")); err == nil {
		key = string(b)
	}
	return fullchain, key
}

// InstallManual stores uploaded PEM on the master, pushes to the server, and updates nginx SSL markers.
func InstallManual(ctx context.Context, opt Options, fullchainPEM, keyPEM string, log func(string)) (Result, error) {
	var res Result
	logLine := func(s string) {
		res.Lines = append(res.Lines, s)
		if log != nil {
			log(s)
		}
	}

	fullchainPEM = strings.TrimSpace(fullchainPEM) + "\n"
	keyPEM = strings.TrimSpace(keyPEM) + "\n"
	leaf, err := parseLeafCert(fullchainPEM)
	if err != nil {
		return res, fmt.Errorf("证书 PEM: %w", err)
	}
	if _, err := tls.X509KeyPair([]byte(fullchainPEM), []byte(keyPEM)); err != nil {
		return res, fmt.Errorf("证书与私钥不匹配: %w", err)
	}

	conf, err := sitesfs.ReadConf(opt.SitesRoot, opt.SiteName)
	if err != nil {
		return res, err
	}
	allDomains, err := confmark.Domains(conf)
	if err != nil {
		return res, err
	}
	domains := CertHostnames(allDomains)
	if len(domains) == 0 {
		return res, fmt.Errorf("conf 中无可校验的 DNS 域名（IP 不参与证书名）")
	}
	primary := domains[0]
	res.Primary = primary
	res.NotAfter = leaf.NotAfter
	res.DaysLeft = int(time.Until(leaf.NotAfter).Hours() / 24)
	now := time.Now()
	if now.Before(leaf.NotBefore) || !now.Before(leaf.NotAfter) {
		return res, fmt.Errorf("证书尚未生效或已过期")
	}
	for _, domain := range domains {
		if err := leaf.VerifyHostname(domain); err != nil {
			return res, fmt.Errorf("证书未覆盖域名 %s: %w", domain, err)
		}
	}

	dir := localSSLDir(opt.SitesRoot, opt.SiteName)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return res, err
	}
	if err := os.Chmod(dir, 0700); err != nil {
		return res, err
	}
	keyPath := filepath.Join(dir, "privkey.pem")
	if err := sitesfs.WriteFile(opt.SitesRoot, opt.SiteName, "ssl/fullchain.pem", []byte(fullchainPEM)); err != nil {
		return res, err
	}
	if err := sitesfs.WriteFile(opt.SitesRoot, opt.SiteName, "ssl/privkey.pem", []byte(keyPEM)); err != nil {
		return res, err
	}
	if err := os.WriteFile(filepath.Join(dir, manualMarker), []byte("manual\n"), 0o644); err != nil {
		return res, err
	}
	if err := os.Chmod(keyPath, 0600); err != nil {
		return res, err
	}
	logLine("已保存主控 ssl/fullchain.pem + privkey.pem")

	remoteDir := remoteSSLDir(opt.SiteName)
	remoteCert := remoteDir + "/fullchain.pem"
	remoteKey := remoteDir + "/privkey.pem"

	next, err := confmark.ApplyIssuedSSLPaths(conf, remoteCert, remoteKey)
	if err != nil {
		return res, err
	}
	next = confmark.EnsureACMEChallenge(next, strings.TrimRight(opt.RemoteWWW, "/"))
	if err := sitesfs.WriteConf(opt.SitesRoot, opt.SiteName, next); err != nil {
		return res, err
	}
	res.ConfWrote = true
	logLine("wrote SSL block → 手动证书路径")
	logLine("push conf + reload")
	if _, err := deploy.SyncConf(ctx, deploy.Options{
		SitesRoot:  opt.SitesRoot,
		SiteName:   opt.SiteName,
		RemoteWWW:  opt.RemoteWWW,
		RemoteConf: opt.RemoteConf,
		Server:     opt.Server,
	}, logLine); err != nil {
		logLine("push failed; master HTTPS config saved — retry deploy")
		return res, err
	}
	res.Issued = true
	logLine(fmt.Sprintf("手动证书已安装（剩余约 %d 天）", res.DaysLeft))
	return res, nil
}

func parseLeafCert(fullchainPEM string) (*x509.Certificate, error) {
	rest := []byte(fullchainPEM)
	for {
		var block *pem.Block
		block, rest = pem.Decode(rest)
		if block == nil {
			return nil, fmt.Errorf("未找到 CERTIFICATE 块")
		}
		if block.Type != "CERTIFICATE" {
			continue
		}
		cert, err := x509.ParseCertificate(block.Bytes)
		if err != nil {
			return nil, err
		}
		return cert, nil
	}
}
