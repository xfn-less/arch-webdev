package sslcert

import (
	"context"

	"github.com/xfn/static-site-panel/internal/deploy"
)

func ensureRenewal(ctx context.Context, runner *deploy.Runner, log func(string)) error {
	log("ensure certbot, renewal timer and nginx reload hook")
	return runner.Run(ctx, log, "bash -lc "+deploy.ShellQuote(`set -euo pipefail
if ! command -v certbot >/dev/null 2>&1; then
  if command -v apt-get >/dev/null 2>&1; then
    export DEBIAN_FRONTEND=noninteractive
    timeout 120 apt-get update -qq
    timeout 180 apt-get install -y -qq certbot
  elif command -v yum >/dev/null 2>&1; then
    timeout 180 yum install -y certbot
  elif command -v dnf >/dev/null 2>&1; then
    timeout 180 dnf install -y certbot
  else
    echo "certbot missing and no apt/yum/dnf to install it" >&2
    exit 1
  fi
  command -v certbot >/dev/null 2>&1 || { echo "certbot install failed" >&2; exit 1; }
fi
install -d -m 755 /etc/letsencrypt/renewal-hooks/deploy
hook=$(mktemp /etc/letsencrypt/renewal-hooks/deploy/.site-panel-XXXXXX)
trap 'rm -f "$hook"' EXIT
cat > "$hook" <<'HOOK'
#!/bin/sh
set -e
if systemctl is-active --quiet panel-nginx; then
  nginx -t
  systemctl reload panel-nginx || nginx -s reload
else
  nginx -t
  systemctl reload nginx || service nginx reload || nginx -s reload
fi
HOOK
chmod 755 "$hook"
mv -f "$hook" /etc/letsencrypt/renewal-hooks/deploy/site-panel-nginx
if systemctl cat certbot.timer >/dev/null 2>&1; then
  systemctl enable --now certbot.timer
  systemctl is-active --quiet certbot.timer
elif systemctl cat certbot-renew.timer >/dev/null 2>&1; then
  systemctl enable --now certbot-renew.timer
  systemctl is-active --quiet certbot-renew.timer
else
  # pip/manual certbot: ship a daily timer
  cat >/etc/systemd/system/certbot-renew.service <<'EOF'
[Unit]
Description=Certbot Renewal (site-panel)
[Service]
Type=oneshot
ExecStart=/usr/bin/env certbot renew --quiet --no-random-sleep-on-renew
EOF
  cat >/etc/systemd/system/certbot-renew.timer <<'EOF'
[Unit]
Description=Certbot Renewal Timer (site-panel)
[Timer]
OnCalendar=daily
RandomizedDelaySec=1h
Persistent=true
[Install]
WantedBy=timers.target
EOF
  systemctl daemon-reload
  systemctl enable --now certbot-renew.timer
  systemctl is-active --quiet certbot-renew.timer
fi
`))
}
