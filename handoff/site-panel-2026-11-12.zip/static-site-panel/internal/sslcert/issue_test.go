package sslcert

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/xfn/static-site-panel/internal/confmark"
	"github.com/xfn/static-site-panel/internal/deploy"
	"github.com/xfn/static-site-panel/internal/store"
)

func TestIssueAndReuseLEPreserveCustomConfig(t *testing.T) {
	for _, force := range []bool{false, true} {
		t.Run(fmt.Sprint(force), func(t *testing.T) {
			root := t.TempDir()
			site := filepath.Join(root, "demo")
			os.MkdirAll(filepath.Join(site, "www"), 0755)
			os.MkdirAll(filepath.Join(site, "ssl"), 0700)
			os.WriteFile(filepath.Join(site, "ssl", manualMarker), []byte("manual"), 0600)
			os.WriteFile(filepath.Join(site, "ssl", "fullchain.pem"), []byte("KEEP-FULLCHAIN\n"), 0644)
			os.WriteFile(filepath.Join(site, "ssl", "privkey.pem"), []byte("KEEP-PRIVKEY\n"), 0600)
			conf := "server {\n listen 80;\n listen 8099;\n" + confmark.ServerNameBegin + "\n server_name localhost;\n" + confmark.ServerNameEnd + "\n" + confmark.SSLBegin + "\n" + confmark.SSLEnd + "\n location /custom { return 204; }\n}\n"
			os.WriteFile(filepath.Join(site, "nginx.conf"), []byte(conf), 0644)
			bin := t.TempDir()
			capture := filepath.Join(t.TempDir(), "ssh-calls")
			t.Setenv("SSP_TLS_CAPTURE", capture)
			date := time.Now().Add(90 * 24 * time.Hour).UTC().Format("Jan 2 15:04:05 2006 GMT")
			script := fmt.Sprintf("#!/bin/sh\nprintf '%%s\\n' \"$*\" >> \"$SSP_TLS_CAPTURE\"\ncase \"$*\" in\n *'openssl x509'*) printf 'notAfter=%s\\nDNS:localhost\\n';;\n *'test -s'*) exit 1;;\nesac\n", date)
			os.WriteFile(filepath.Join(bin, "ssh"), []byte(script), 0755)
			os.WriteFile(filepath.Join(bin, "rsync"), []byte("#!/bin/sh\nexit 0\n"), 0755)
			t.Setenv("PATH", bin+string(os.PathListSeparator)+os.Getenv("PATH"))
			result, err := Issue(context.Background(), Options{SitesRoot: root, SiteName: "demo", RemoteWWW: "/www/demo", RemoteConf: "/etc/nginx/conf.d/demo.conf", Server: store.Server{ID: 1, Host: "dummy.invalid", PublicIP: "127.0.0.1", AuthType: "key"}, Force: force}, nil)
			if err != nil {
				t.Fatal(err)
			}
			if force && !result.Issued || !force && !result.Skipped {
				t.Fatalf("unexpected result: %+v", result)
			}
			raw, _ := os.ReadFile(filepath.Join(site, "nginx.conf"))
			next := string(raw)
			if !strings.Contains(next, "location /custom") || !strings.Contains(next, "listen 8099") || !strings.Contains(next, "/etc/letsencrypt/live/localhost/fullchain.pem") {
				t.Fatal("custom config or LE path lost", next)
			}
			if !HasManualCert(root, "demo") {
				t.Fatal("LE cleared manual marker; backup should remain")
			}
			fc, key := ReadStoredPEM(root, "demo")
			if fc != "KEEP-FULLCHAIN\n" || key != "KEEP-PRIVKEY\n" {
				t.Fatal("LE deleted manual PEM backup")
			}
			calls, _ := os.ReadFile(capture)
			if strings.Contains(string(calls), "ssp-apk") {
				t.Fatal("SSL ran APK deployment")
			}
			if force && !strings.Contains(string(calls), "--cert-name") {
				t.Fatal("certificate identity was not pinned")
			}
		})
	}
}

func TestTrySyncExistingAdoptsRemoteCert(t *testing.T) {
	root := t.TempDir()
	site := filepath.Join(root, "demo")
	os.MkdirAll(filepath.Join(site, "www"), 0755)
	conf := "server {\n listen 80;\n" + confmark.ServerNameBegin + "\n server_name a.example b.example;\n" + confmark.ServerNameEnd + "\n" + confmark.SSLBegin + "\n" + confmark.SSLEnd + "\n location /keep { return 204; }\n}\n"
	os.WriteFile(filepath.Join(site, "nginx.conf"), []byte(conf), 0644)
	bin := t.TempDir()
	date := time.Now().Add(90 * 24 * time.Hour).UTC().Format("Jan 2 15:04:05 2006 GMT")
	script := fmt.Sprintf("#!/bin/sh\ncase \"$*\" in *'openssl x509'*) printf 'notAfter=%s\\nDNS:a.example\\nDNS:b.example\\n';; esac\n", date)
	os.WriteFile(filepath.Join(bin, "ssh"), []byte(script), 0755)
	os.WriteFile(filepath.Join(bin, "rsync"), []byte("#!/bin/sh\nexit 0\n"), 0755)
	t.Setenv("PATH", bin+string(os.PathListSeparator)+os.Getenv("PATH"))

	res, synced, err := TrySyncExisting(context.Background(), Options{
		SitesRoot:  root,
		SiteName:   "demo",
		RemoteWWW:  "/www/sites/demo/www",
		RemoteConf: "/etc/nginx/conf.d/demo.conf",
		Server:     store.Server{ID: 1, Host: "dummy.invalid", PublicIP: "127.0.0.1", AuthType: "key"},
	}, nil)
	if err != nil || !synced || !res.Skipped || res.DaysLeft < 80 {
		t.Fatalf("sync=%v err=%v res=%+v", synced, err, res)
	}
	raw, _ := os.ReadFile(filepath.Join(site, "nginx.conf"))
	next := string(raw)
	if !strings.Contains(next, "location /keep") || !strings.Contains(next, "/etc/letsencrypt/live/a.example/fullchain.pem") {
		t.Fatal(next)
	}

	// Missing SAN → do not sync / do not issue.
	scriptMiss := fmt.Sprintf("#!/bin/sh\ncase \"$*\" in *'openssl x509'*) printf 'notAfter=%s\\nDNS:a.example\\n';; esac\n", date)
	os.WriteFile(filepath.Join(bin, "ssh"), []byte(scriptMiss), 0755)
	_, synced2, err2 := TrySyncExisting(context.Background(), Options{
		SitesRoot:  root,
		SiteName:   "demo",
		RemoteWWW:  "/www/sites/demo/www",
		RemoteConf: "/etc/nginx/conf.d/demo.conf",
		Server:     store.Server{ID: 1, Host: "dummy.invalid", PublicIP: "127.0.0.1", AuthType: "key"},
	}, nil)
	if err2 != nil || synced2 {
		t.Fatalf("expected no sync on SAN miss: sync=%v err=%v", synced2, err2)
	}
}

func TestRemoteCertificateProbeWorksWithoutOpenSSLExtFlag(t *testing.T) {
	bin := t.TempDir()
	date := time.Now().Add(30 * 24 * time.Hour).UTC().Format("Jan 2 15:04:05 2006 GMT")
	script := fmt.Sprintf("#!/bin/sh\ncase \"$*\" in *' -ext '*) echo 'unknown option -ext' >&2; exit 1;; esac\nprintf 'notAfter=%s\\nX509v3 Subject Alternative Name:\\n DNS:example.test\\n'\n", date)
	os.WriteFile(filepath.Join(bin, "ssh"), []byte(script), 0755)
	t.Setenv("PATH", bin+string(os.PathListSeparator)+os.Getenv("PATH"))
	runner, err := deploy.NewRunner(store.Server{Host: "fixture.invalid", AuthType: "key"})
	if err != nil {
		t.Fatal(err)
	}
	days, sans, _, err := remoteCertInfo(context.Background(), runner, "example.test")
	if err != nil || days < 28 || len(sans) != 1 || sans[0] != "example.test" {
		t.Fatalf("older OpenSSL certificate probe: %d %v %v", days, sans, err)
	}
}

func TestManualToLEKeepsHTTPSDuringIssuance(t *testing.T) {
	root := t.TempDir()
	site := filepath.Join(root, "demo")
	os.MkdirAll(filepath.Join(site, "www"), 0755)
	os.MkdirAll(filepath.Join(site, "ssl"), 0700)
	for _, file := range []string{manualMarker, "fullchain.pem", "privkey.pem"} {
		os.WriteFile(filepath.Join(site, "ssl", file), []byte("synthetic fixture"), 0600)
	}
	base := "server {\n listen 80;\n" + confmark.ServerNameBegin + "\n server_name localhost;\n" + confmark.ServerNameEnd + "\n" + confmark.SSLBegin + "\n" + confmark.SSLEnd + "\n location /custom { return 204; }\n}\n"
	conf, err := confmark.ApplyIssuedSSLPaths(base, deploy.ManualSSLDir("demo")+"/fullchain.pem", deploy.ManualSSLDir("demo")+"/privkey.pem")
	if err != nil {
		t.Fatal(err)
	}
	os.WriteFile(filepath.Join(site, "nginx.conf"), []byte(conf), 0644)
	bin := t.TempDir()
	capture := filepath.Join(t.TempDir(), "first-conf")
	t.Setenv("SSP_FIRST_CONF", capture)
	date := time.Now().Add(90 * 24 * time.Hour).UTC().Format("Jan 2 15:04:05 2006 GMT")
	script := fmt.Sprintf("#!/bin/sh\ncase \"$*\" in *'openssl x509'*) printf 'notAfter=%s\\nDNS:localhost\\n';; *'test -s'*) exit 1;; esac\n", date)
	os.WriteFile(filepath.Join(bin, "ssh"), []byte(script), 0755)
	os.WriteFile(filepath.Join(bin, "rsync"), []byte("#!/bin/sh\nif [ ! -e \"$SSP_FIRST_CONF\" ]; then for f do if [ -f \"$f\" ]; then cp \"$f\" \"$SSP_FIRST_CONF\"; break; fi; done; fi\n"), 0755)
	t.Setenv("PATH", bin+string(os.PathListSeparator)+os.Getenv("PATH"))
	_, err = Issue(context.Background(), Options{SitesRoot: root, SiteName: "demo", RemoteWWW: "/www/sites/demo/www", RemoteConf: "/etc/nginx/conf.d/demo.conf", Server: store.Server{ID: 1, Host: "fixture.invalid", PublicIP: "127.0.0.1", AuthType: "key"}, Force: true}, nil)
	if err != nil {
		t.Fatal(err)
	}
	first, _ := os.ReadFile(capture)
	if !strings.Contains(string(first), "listen 443") || !strings.Contains(string(first), deploy.ManualSSLDir("demo")) || !strings.Contains(string(first), "location /custom") {
		t.Fatalf("issuance interrupted live HTTPS: %s", first)
	}
}

func TestBaotaTLSStaysAvailableDuringIssuance(t *testing.T) {
	root := t.TempDir()
	site := filepath.Join(root, "demo")
	os.MkdirAll(filepath.Join(site, "www"), 0755)
	os.MkdirAll(filepath.Join(site, "ssl"), 0700)
	for _, file := range []string{manualMarker, "fullchain.pem", "privkey.pem"} {
		os.WriteFile(filepath.Join(site, "ssl", file), []byte("synthetic fixture"), 0600)
	}
	base := "server {\n listen 80;\n" + confmark.ServerNameBegin + "\n server_name localhost;\n" + confmark.ServerNameEnd + "\n" + confmark.SSLBegin + "\n" + confmark.SSLEnd + "\n location /custom { return 204; }\n}\n"
	conf, err := confmark.ApplyIssuedSSLPaths(base, "/www/server/panel/vhost/cert/localhost/fullchain.pem", "/www/server/panel/vhost/cert/localhost/privkey.pem")
	if err != nil {
		t.Fatal(err)
	}
	os.WriteFile(filepath.Join(site, "nginx.conf"), []byte(conf), 0644)
	bin := t.TempDir()
	capture := filepath.Join(t.TempDir(), "first-conf")
	t.Setenv("SSP_FIRST_CONF", capture)
	date := time.Now().Add(90 * 24 * time.Hour).UTC().Format("Jan 2 15:04:05 2006 GMT")
	script := fmt.Sprintf("#!/bin/sh\ncase \"$*\" in *'openssl x509'*) printf 'notAfter=%s\\nDNS:localhost\\n';; *'test -s'*'/etc/letsencrypt/'*) exit 1;; esac\n", date)
	os.WriteFile(filepath.Join(bin, "ssh"), []byte(script), 0755)
	os.WriteFile(filepath.Join(bin, "rsync"), []byte("#!/bin/sh\nif [ ! -e \"$SSP_FIRST_CONF\" ]; then for f do if [ -f \"$f\" ]; then cp \"$f\" \"$SSP_FIRST_CONF\"; break; fi; done; fi\n"), 0755)
	t.Setenv("PATH", bin+string(os.PathListSeparator)+os.Getenv("PATH"))
	_, err = Issue(context.Background(), Options{SitesRoot: root, SiteName: "demo", RemoteWWW: "/www/sites/demo/www", RemoteConf: "/etc/nginx/conf.d/demo.conf", Server: store.Server{ID: 1, Host: "fixture.invalid", PublicIP: "127.0.0.1", AuthType: "key"}, Force: true}, nil)
	if err != nil {
		t.Fatal(err)
	}
	first, _ := os.ReadFile(capture)
	if !strings.Contains(string(first), "listen 443") || !strings.Contains(string(first), "/www/server/panel/vhost/cert/localhost") || !strings.Contains(string(first), "location /custom") {
		t.Fatalf("issuance interrupted live HTTPS: %s", first)
	}
}

func TestResolveRemoteCertPrefersLiveNameFromConf(t *testing.T) {
	root := t.TempDir()
	site := filepath.Join(root, "demo")
	os.MkdirAll(filepath.Join(site, "www"), 0755)
	conf := "server {\n listen 80;\n" + confmark.ServerNameBegin + "\n server_name a.example b.example;\n" + confmark.ServerNameEnd + "\n" + confmark.SSLBegin + "\n    ssl_certificate /etc/letsencrypt/live/old-primary/fullchain.pem;\n    ssl_certificate_key /etc/letsencrypt/live/old-primary/privkey.pem;\n" + confmark.SSLEnd + "\n}\n"
	os.WriteFile(filepath.Join(site, "nginx.conf"), []byte(conf), 0644)
	bin := t.TempDir()
	date := time.Now().Add(90 * 24 * time.Hour).UTC().Format("Jan 2 15:04:05 2006 GMT")
	script := fmt.Sprintf("#!/bin/sh\ncase \"$*\" in *'/etc/letsencrypt/live/old-primary/'*) printf 'notAfter=%s\\nDNS:a.example\\nDNS:b.example\\n';; *'openssl x509'*) echo miss >&2; exit 1;; esac\n", date)
	os.WriteFile(filepath.Join(bin, "ssh"), []byte(script), 0755)
	os.WriteFile(filepath.Join(bin, "rsync"), []byte("#!/bin/sh\nexit 0\n"), 0755)
	t.Setenv("PATH", bin+string(os.PathListSeparator)+os.Getenv("PATH"))
	res, synced, err := TrySyncExisting(context.Background(), Options{
		SitesRoot: root, SiteName: "demo", RemoteWWW: "/www/sites/demo/www", RemoteConf: "/etc/nginx/conf.d/demo.conf",
		Server: store.Server{ID: 1, Host: "dummy.invalid", PublicIP: "127.0.0.1", AuthType: "key"},
	}, nil)
	if err != nil || !synced || res.Primary != "old-primary" {
		t.Fatalf("sync=%v err=%v primary=%q", synced, err, res.Primary)
	}
}

func TestCertbotFailureRestoresRemoteConf(t *testing.T) {
	root := t.TempDir()
	site := filepath.Join(root, "demo")
	os.MkdirAll(filepath.Join(site, "www"), 0755)
	prev := "server {\n listen 80;\n" + confmark.ServerNameBegin + "\n server_name localhost;\n" + confmark.ServerNameEnd + "\n" + confmark.SSLBegin + "\n" + confmark.SSLEnd + "\n location /custom { return 204; }\n}\n"
	os.WriteFile(filepath.Join(site, "nginx.conf"), []byte(prev), 0644)
	bin := t.TempDir()
	restored := filepath.Join(t.TempDir(), "restored")
	calls := filepath.Join(t.TempDir(), "calls")
	t.Setenv("SSP_RESTORED_CONF", restored)
	t.Setenv("SSP_CALLS", calls)
	script := `#!/bin/sh
printf 'SSH %s\n' "$*" >> "$SSP_CALLS"
case "$*" in
 *'openssl x509'*) exit 1;;
 *'test -s'*) exit 1;;
 *'certbot certonly'*) echo certbot-fail >&2; exit 1;;
esac
exit 0
`
	os.WriteFile(filepath.Join(bin, "ssh"), []byte(script), 0755)
	os.WriteFile(filepath.Join(bin, "rsync"), []byte("#!/bin/sh\nprintf 'RSYNC\n' >> \"$SSP_CALLS\"\nfor f do if [ -f \"$f\" ]; then printf 'FILE %s\n' \"$f\" >> \"$SSP_CALLS\"; cp \"$f\" \"$SSP_RESTORED_CONF\"; fi; done\nexit 0\n"), 0755)
	t.Setenv("PATH", bin+string(os.PathListSeparator)+os.Getenv("PATH"))
	_, err := Issue(context.Background(), Options{
		SitesRoot: root, SiteName: "demo", RemoteWWW: "/www/sites/demo/www", RemoteConf: "/etc/nginx/conf.d/demo.conf",
		Server: store.Server{ID: 1, Host: "fixture.invalid", PublicIP: "127.0.0.1", AuthType: "key"}, Force: true,
	}, nil)
	if err == nil {
		t.Fatal("expected certbot failure")
	}
	master, _ := os.ReadFile(filepath.Join(site, "nginx.conf"))
	if string(master) != prev {
		t.Fatal("master conf changed after failed issue")
	}
	got, _ := os.ReadFile(restored)
	if !strings.Contains(string(got), "location /custom") || !strings.Contains(string(got), "server_name localhost") {
		callLog, _ := os.ReadFile(calls)
		t.Fatalf("restore push missing original vhost: %q\nerr=%v\ncalls=\n%s", got, err, callLog)
	}
}

func TestIssueWithoutCertKeepsCustomLocationsOnACMEPush(t *testing.T) {
	root := t.TempDir()
	site := filepath.Join(root, "demo")
	os.MkdirAll(filepath.Join(site, "www"), 0755)
	conf := "server {\n listen 80;\n" + confmark.ServerNameBegin + "\n server_name localhost;\n" + confmark.ServerNameEnd + "\n" + confmark.SSLBegin + "\n" + confmark.SSLEnd + "\n location /custom { return 204; }\n location /proxy { proxy_pass http://127.0.0.1:9; }\n}\n"
	os.WriteFile(filepath.Join(site, "nginx.conf"), []byte(conf), 0644)
	bin := t.TempDir()
	first := filepath.Join(t.TempDir(), "first-conf")
	t.Setenv("SSP_FIRST_CONF", first)
	date := time.Now().Add(90 * 24 * time.Hour).UTC().Format("Jan 2 15:04:05 2006 GMT")
	script := fmt.Sprintf("#!/bin/sh\ncase \"$*\" in *'openssl x509'*) printf 'notAfter=%s\\nDNS:localhost\\n';; *'test -s'*) exit 1;; esac\n", date)
	os.WriteFile(filepath.Join(bin, "ssh"), []byte(script), 0755)
	os.WriteFile(filepath.Join(bin, "rsync"), []byte("#!/bin/sh\nif [ ! -e \"$SSP_FIRST_CONF\" ]; then for f do if [ -f \"$f\" ]; then cp \"$f\" \"$SSP_FIRST_CONF\"; break; fi; done; fi\n"), 0755)
	t.Setenv("PATH", bin+string(os.PathListSeparator)+os.Getenv("PATH"))
	_, err := Issue(context.Background(), Options{
		SitesRoot: root, SiteName: "demo", RemoteWWW: "/www/sites/demo/www", RemoteConf: "/etc/nginx/conf.d/demo.conf",
		Server: store.Server{ID: 1, Host: "fixture.invalid", PublicIP: "127.0.0.1", AuthType: "key"}, Force: true,
	}, nil)
	if err != nil {
		t.Fatal(err)
	}
	body, _ := os.ReadFile(first)
	if !strings.Contains(string(body), "location /custom") || !strings.Contains(string(body), "location /proxy") {
		t.Fatalf("ACME push replaced live vhost: %s", body)
	}
}

func TestIssuedCertificateProbeFailureIsReported(t *testing.T) {
	root := t.TempDir()
	site := filepath.Join(root, "demo")
	os.MkdirAll(filepath.Join(site, "www"), 0755)
	conf := "server {\n listen 80;\n" + confmark.ServerNameBegin + "\n server_name localhost;\n" + confmark.ServerNameEnd + "\n" + confmark.SSLBegin + "\n" + confmark.SSLEnd + "\n}\n"
	os.WriteFile(filepath.Join(site, "nginx.conf"), []byte(conf), 0644)
	bin := t.TempDir()
	os.WriteFile(filepath.Join(bin, "ssh"), []byte("#!/bin/sh\ncase \"$*\" in *'openssl x509'*) exit 1;; *'test -s'*) exit 1;; esac\n"), 0755)
	os.WriteFile(filepath.Join(bin, "rsync"), []byte("#!/bin/sh\nexit 0\n"), 0755)
	t.Setenv("PATH", bin+string(os.PathListSeparator)+os.Getenv("PATH"))
	_, err := Issue(context.Background(), Options{SitesRoot: root, SiteName: "demo", RemoteWWW: "/www/sites/demo/www", RemoteConf: "/etc/nginx/conf.d/demo.conf", Server: store.Server{ID: 1, Host: "fixture.invalid", PublicIP: "127.0.0.1", AuthType: "key"}, Force: true}, nil)
	if err == nil {
		t.Fatal("issued certificate unreadable but operation reported success")
	}
	after, _ := os.ReadFile(filepath.Join(site, "nginx.conf"))
	if string(after) != conf {
		t.Fatal("unverified certificate changed master configuration")
	}
}
