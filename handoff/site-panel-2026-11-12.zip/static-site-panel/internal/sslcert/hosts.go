package sslcert

import (
	"net"
	"strings"
)

// CertHostnames drops IP literals (and empties). Let's Encrypt needs DNS names;
// IPs may stay in nginx server_name but must not go to certbot / DNS preflight.
func CertHostnames(domains []string) []string {
	out := make([]string, 0, len(domains))
	seen := map[string]struct{}{}
	for _, d := range domains {
		d = strings.TrimSpace(d)
		if d == "" || strings.HasPrefix(d, "#") || strings.Contains(d, "#") {
			continue
		}
		if net.ParseIP(d) != nil {
			continue
		}
		low := strings.ToLower(d)
		if _, ok := seen[low]; ok {
			continue
		}
		seen[low] = struct{}{}
		out = append(out, d)
	}
	return out
}

// IsIPLiteral reports whether host is a bare IPv4/IPv6 address.
func IsIPLiteral(host string) bool {
	return net.ParseIP(strings.TrimSpace(host)) != nil
}
