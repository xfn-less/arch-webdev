package sslcert

import (
	"context"
	"fmt"
	"regexp"
	"sort"
	"strings"
	"time"

	"github.com/xfn/static-site-panel/internal/confmark"
	"github.com/xfn/static-site-panel/internal/deploy"
	"github.com/xfn/static-site-panel/internal/dnscheck"
	"github.com/xfn/static-site-panel/internal/sitesfs"
	"github.com/xfn/static-site-panel/internal/store"
)

const MinRemainingDays = 7

type Options struct {
	SitesRoot  string
	SiteName   string
	RemoteWWW  string
	RemoteConf string
	Server     store.Server
	Site       store.Site
	Force      bool
	// SkipDNS reuses ReuseDNSItems when the SSL dialog just finished a passing
	// preflight (or deploy DNS). Apply then only does cert work on the server.
	SkipDNS       bool
	ReuseDNSItems []dnscheck.Item
}

type Result struct {
	Skipped   bool            `json:"skipped"`
	Issued    bool            `json:"issued"`
	Primary   string          `json:"primary"`
	NotAfter  time.Time       `json:"notAfter"`
	DaysLeft  int             `json:"daysLeft"`
	DNSItems  []dnscheck.Item `json:"dnsItems,omitempty"`
	Lines     []string        `json:"lines"`
	ConfWrote bool            `json:"confWrote"`
}

var (
	reNotAfter       = regexp.MustCompile(`(?i)notAfter=(.+)`)
	reConfiguredCert = regexp.MustCompile(`(?m)^\s*ssl_certificate(_key)?\s+([^;\r\n]+);`)
	reDNS            = regexp.MustCompile(`(?i)DNS:([^\s,]+)`)
)

func Issue(ctx context.Context, opt Options, log func(string)) (Result, error) {
	var res Result
	logLine := func(s string) {
		res.Lines = append(res.Lines, s)
		if log != nil {
			log(s)
		}
	}

	conf, err := sitesfs.ReadConf(opt.SitesRoot, opt.SiteName)
	if err != nil {
		return res, err
	}
	allDomains, err := confmark.Domains(conf)
	if err != nil {
		return res, err
	}
	if len(allDomains) == 0 {
		return res, fmt.Errorf("no domains in conf")
	}
	domains := CertHostnames(allDomains)
	for _, d := range allDomains {
		if IsIPLiteral(d) {
			logLine("skip IP in cert/DNS: " + d)
		}
	}
	if len(domains) == 0 {
		return res, fmt.Errorf("no DNS hostnames for Let’s Encrypt (only IP literals in server_name?)")
	}
	primary := domains[0]
	res.Primary = primary

	expect := opt.Server.PublicIP
	if expect == "" {
		expect = opt.Server.Host
	}
	items := opt.ReuseDNSItems
	reusedDNS := opt.SkipDNS && dnsItemsAllOK(domains, items)
	if !reusedDNS {
		logLine("dns-check → " + expect)
		items = dnscheck.CheckDomains(ctx, domains, expect)
	} else {
		logLine("前置已通过，跳过 DNS → " + expect)
	}
	res.DNSItems = items
	for _, it := range items {
		act := strings.Join(it.Actual, ",")
		if act == "" {
			act = "-"
		}
		if it.OK {
			logLine(fmt.Sprintf("OK  %s → %s", it.Domain, act))
		} else {
			logLine(fmt.Sprintf("FAIL %s → %s %s", it.Domain, act, it.Error))
		}
	}
	for _, it := range items {
		if !it.OK {
			return res, fmt.Errorf("dns check failed for %s", it.Domain)
		}
	}

	runner, err := deploy.NewRunner(opt.Server)
	if err != nil {
		return res, err
	}

	if err := ensureRenewal(ctx, runner, logLine); err != nil {
		return res, fmt.Errorf("certificate renewal setup: %w", err)
	}

	serverChanged := opt.Site.SSLServerID != 0 && opt.Site.SSLServerID != opt.Server.ID
	// Reissue only when current hostnames are not a subset of the last recorded
	// set (dropping a name, or IP-only noise, must not force renew).
	missingRecorded := MissingHostnames(strings.Split(opt.Site.SSLDomains, ","), domains)
	domainsChanged := opt.Site.SSLDomains != "" && len(missingRecorded) > 0
	force := opt.Force || serverChanged || domainsChanged
	if serverChanged {
		logLine("server changed — reissue")
	}
	if domainsChanged {
		logLine("domains changed — reissue: " + strings.Join(missingRecorded, ", "))
	}

	if !force {
		livePrimary, days, sans, nAfter, cerr := resolveRemoteCert(ctx, runner, conf, domains)
		if cerr == nil && days > MinRemainingDays && domainsCovered(sans, domains) {
			res.Skipped = true
			res.DaysLeft = days
			res.NotAfter = nAfter
			if livePrimary != "" {
				primary = livePrimary
				res.Primary = primary
			}
			logLine(fmt.Sprintf("cert ok (%d days left) — skip issue", days))
			wrote, err := ensureLocalSSLAndPush(ctx, opt, conf, primary, logLine)
			res.ConfWrote = wrote
			return res, err
		}
		if cerr != nil {
			logLine("no usable remote cert: " + cerr.Error())
		} else {
			logLine(fmt.Sprintf("cert remaining %d days / SAN mismatch — issue", days))
		}
	}

	wwwRoot := strings.TrimRight(opt.RemoteWWW, "/")
	prevConf := conf
	// Prefer keeping the live vhost. Only pause TLS when no readable cert files
	// exist — never replace the whole server with a stripped bootstrap.
	certReady := runner.Run(ctx, func(string) {}, "test -s "+deploy.ShellQuote("/etc/letsencrypt/live/"+primary+"/fullchain.pem")+" && test -s "+deploy.ShellQuote("/etc/letsencrypt/live/"+primary+"/privkey.pem")) == nil
	manualReady := HasManualCert(opt.SitesRoot, opt.SiteName) && strings.Contains(conf, deploy.ManualSSLDir(opt.SiteName)+"/")
	configuredReady := false
	if !certReady && !manualReady {
		var checks []string
		cert, key := false, false
		for _, match := range reConfiguredCert.FindAllStringSubmatch(conf, -1) {
			path := strings.Trim(strings.TrimSpace(match[2]), "\"'")
			checks = append(checks, "test -s "+deploy.ShellQuote(path))
			if match[1] == "_key" {
				key = true
			} else {
				cert = true
			}
		}
		configuredReady = cert && key && len(checks) > 0 && runner.Run(ctx, func(string) {}, strings.Join(checks, " && ")) == nil
	}
	needPauseTLS := !certReady && !manualReady && !configuredReady
	acmeConf, err := prepareACMEConf(prevConf, wwwRoot, needPauseTLS)
	if err != nil {
		return res, err
	}
	if needPauseTLS {
		logLine("pause TLS for ACME (keep custom locations)")
	}

	logLine("deploy http (acme webroot)")
	if _, err := deploy.SyncConf(ctx, deploy.Options{
		SitesRoot:  opt.SitesRoot,
		SiteName:   opt.SiteName,
		RemoteWWW:  opt.RemoteWWW,
		RemoteConf: opt.RemoteConf,
		Server:     opt.Server,
		ConfBody:   &acmeConf,
	}, logLine); err != nil {
		logLine("pre-ssl deploy failed; master nginx.conf unchanged — fix and retry")
		return res, fmt.Errorf("pre-ssl deploy: %w", err)
	}

	restoreRemote := func(reason string) {
		logLine(reason + " — restoring previous remote conf")
		if _, rerr := deploy.SyncConf(ctx, deploy.Options{
			SitesRoot:  opt.SitesRoot,
			SiteName:   opt.SiteName,
			RemoteWWW:  opt.RemoteWWW,
			RemoteConf: opt.RemoteConf,
			Server:     opt.Server,
			ConfBody:   &prevConf,
		}, logLine); rerr != nil {
			logLine("restore remote conf failed: " + rerr.Error())
		}
	}

	var dFlags []string
	for _, d := range domains {
		dFlags = append(dFlags, "-d", deploy.ShellQuote(d))
	}
	certCmd := "timeout 240 certbot certonly --webroot -w " + deploy.ShellQuote(wwwRoot) +
		" " + strings.Join(dFlags, " ") +
		" --cert-name " + deploy.ShellQuote(primary) + " --renew-with-new-domains --non-interactive --agree-tos --register-unsafely-without-email --keep-until-expiring --preferred-challenges http"
	logLine("certbot …")
	if err := runner.Run(ctx, logLine, certCmd); err != nil {
		restoreRemote("certbot failed")
		return res, fmt.Errorf("certbot: %w", err)
	}
	res.Issued = true

	days, sans, nAfter, cerr := remoteCertInfo(ctx, runner, primary)
	if cerr != nil {
		restoreRemote("issued cert unreadable")
		return res, fmt.Errorf("certificate issued, but verification failed; retry SSL: %w", cerr)
	}
	if !domainsCovered(sans, domains) {
		restoreRemote("issued cert SAN incomplete")
		return res, fmt.Errorf("issued certificate does not cover all requested domains")
	}
	res.DaysLeft = days
	res.NotAfter = nAfter

	wrote, err := ensureLocalSSLAndPush(ctx, opt, prevConf, primary, logLine)
	res.ConfWrote = wrote
	return res, err
}

// TrySyncExisting reuses a remote Let’s Encrypt cert that already covers all
// hostnames with enough remaining life. It only writes conf + pushes — never
// runs certbot. synced=false means the caller should offer a normal issue.
func TrySyncExisting(ctx context.Context, opt Options, log func(string)) (res Result, synced bool, err error) {
	logLine := func(s string) {
		res.Lines = append(res.Lines, s)
		if log != nil {
			log(s)
		}
	}
	conf, err := sitesfs.ReadConf(opt.SitesRoot, opt.SiteName)
	if err != nil {
		return res, false, err
	}
	allDomains, err := confmark.Domains(conf)
	if err != nil {
		return res, false, err
	}
	domains := CertHostnames(allDomains)
	if len(domains) == 0 {
		return res, false, fmt.Errorf("no DNS hostnames for Let’s Encrypt (only IP literals in server_name?)")
	}
	runner, err := deploy.NewRunner(opt.Server)
	if err != nil {
		return res, false, err
	}
	primary, days, sans, nAfter, cerr := resolveRemoteCert(ctx, runner, conf, domains)
	if cerr != nil {
		logLine("no usable remote cert: " + cerr.Error())
		return res, false, nil
	}
	res.Primary = primary
	if days <= MinRemainingDays || !domainsCovered(sans, domains) {
		miss := MissingHostnames(sans, domains)
		if len(miss) > 0 {
			logLine(fmt.Sprintf("remote cert SAN missing: %s", strings.Join(miss, ", ")))
		} else {
			logLine(fmt.Sprintf("remote cert remaining %d days — not enough to sync", days))
		}
		return res, false, nil
	}
	res.Skipped = true
	res.DaysLeft = days
	res.NotAfter = nAfter
	logLine(fmt.Sprintf("remote cert covers all (%d days left, live=%s) — sync conf", days, primary))
	wrote, err := ensureLocalSSLAndPush(ctx, opt, conf, primary, logLine)
	res.ConfWrote = wrote
	if err != nil {
		return res, false, err
	}
	return res, true, nil
}

func ensureLocalSSLAndPush(ctx context.Context, opt Options, conf, primary string, logLine func(string)) (bool, error) {
	next, err := confmark.ApplyIssuedSSL(conf, primary)
	if err != nil {
		return false, err
	}
	next = confmark.EnsureACMEChallenge(next, strings.TrimRight(opt.RemoteWWW, "/"))
	prev, _ := sitesfs.ReadConf(opt.SitesRoot, opt.SiteName)
	changed := prev != next
	if changed {
		if err := sitesfs.WriteConf(opt.SitesRoot, opt.SiteName, next); err != nil {
			return false, err
		}
		logLine("wrote SSL block + listen 443")
	} else {
		logLine("local ssl conf already set")
	}
	// Keep master-side manual PEMs (.manual + pem) as a backup so the dialog can
	// still show / reinstall them. Live nginx now points at Let’s Encrypt paths;
	// deploy only re-pushes manual files when conf still references ManualSSLDir.
	if HasManualCert(opt.SitesRoot, opt.SiteName) {
		logLine("保留主控手动证书备份（未删除 ssl/）")
	}
	logLine("push conf + reload")
	if _, err := deploy.SyncConf(ctx, deploy.Options{
		SitesRoot:  opt.SitesRoot,
		SiteName:   opt.SiteName,
		RemoteWWW:  opt.RemoteWWW,
		RemoteConf: opt.RemoteConf,
		Server:     opt.Server,
	}, logLine); err != nil {
		logLine("push failed; master HTTPS config saved — retry deploy")
		return changed, err
	}
	return changed, nil
}

func remoteCertInfo(ctx context.Context, runner *deploy.Runner, primary string) (days int, sans []string, notAfter time.Time, err error) {
	path := "/etc/letsencrypt/live/" + primary + "/fullchain.pem"
	out, err := runner.Output(ctx, "openssl x509 -in "+deploy.ShellQuote(path)+" -noout -enddate -text 2>/dev/null")
	if err != nil {
		return 0, nil, time.Time{}, err
	}
	m := reNotAfter.FindStringSubmatch(out)
	if m == nil {
		return 0, nil, time.Time{}, fmt.Errorf("no notAfter in openssl output")
	}
	// openssl format: Jan  2 15:04:05 2027 GMT
	notAfter, err = time.Parse("Jan 2 15:04:05 2006 MST", strings.TrimSpace(m[1]))
	if err != nil {
		notAfter, err = time.Parse("Jan 02 15:04:05 2006 MST", strings.TrimSpace(m[1]))
		if err != nil {
			return 0, nil, time.Time{}, err
		}
	}
	days = int(time.Until(notAfter).Hours() / 24)
	for _, sm := range reDNS.FindAllStringSubmatch(out, -1) {
		sans = append(sans, strings.ToLower(sm[1]))
	}
	return days, sans, notAfter, nil
}

// resolveRemoteCert finds a usable Let’s Encrypt live cert. Prefers the name
// already referenced by ssl_certificate, then each hostname — not only domains[0].
func resolveRemoteCert(ctx context.Context, runner *deploy.Runner, conf string, domains []string) (primary string, days int, sans []string, notAfter time.Time, err error) {
	var candidates []string
	seen := map[string]struct{}{}
	add := func(name string) {
		name = strings.TrimSpace(strings.ToLower(name))
		if name == "" {
			return
		}
		if _, ok := seen[name]; ok {
			return
		}
		seen[name] = struct{}{}
		candidates = append(candidates, name)
	}
	for _, match := range reConfiguredCert.FindAllStringSubmatch(conf, -1) {
		if match[1] == "_key" {
			continue
		}
		path := strings.Trim(strings.TrimSpace(match[2]), "\"'")
		const prefix = "/etc/letsencrypt/live/"
		if !strings.HasPrefix(path, prefix) {
			continue
		}
		rest := strings.TrimPrefix(path, prefix)
		if i := strings.IndexByte(rest, '/'); i > 0 {
			add(rest[:i])
		}
	}
	for _, d := range domains {
		add(d)
	}
	if len(candidates) == 0 {
		return "", 0, nil, time.Time{}, fmt.Errorf("no certificate candidates")
	}
	var lastErr error
	for _, c := range candidates {
		d, s, n, cerr := remoteCertInfo(ctx, runner, c)
		if cerr == nil {
			return c, d, s, n, nil
		}
		lastErr = cerr
	}
	return "", 0, nil, time.Time{}, lastErr
}

func DomainsKey(domains []string) string {
	// IPs may stay in nginx server_name but never go on the LE cert — keep them
	// out of the stored/compared key so deploy won't false-prompt "SSL incomplete".
	cp := CertHostnames(domains)
	for i := range cp {
		cp[i] = strings.ToLower(strings.TrimSpace(cp[i]))
	}
	sort.Strings(cp)
	return strings.Join(cp, ",")
}

// MissingHostnames returns want DNS names (IPs ignored) not present in have.
func MissingHostnames(have, want []string) []string {
	set := map[string]struct{}{}
	for _, s := range CertHostnames(have) {
		set[strings.ToLower(s)] = struct{}{}
	}
	var missing []string
	seen := map[string]struct{}{}
	for _, w := range CertHostnames(want) {
		low := strings.ToLower(w)
		if _, ok := set[low]; ok {
			continue
		}
		if _, dup := seen[low]; dup {
			continue
		}
		seen[low] = struct{}{}
		missing = append(missing, low)
	}
	sort.Strings(missing)
	return missing
}

func domainsCovered(sans, want []string) bool {
	return len(MissingHostnames(sans, want)) == 0
}
