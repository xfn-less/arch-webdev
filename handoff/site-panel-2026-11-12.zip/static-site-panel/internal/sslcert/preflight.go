package sslcert

import (
	"context"
	"fmt"
	"net"
	"strings"
	"time"

	"github.com/xfn/static-site-panel/internal/confmark"
	"github.com/xfn/static-site-panel/internal/deploy"
	"github.com/xfn/static-site-panel/internal/dnscheck"
	"github.com/xfn/static-site-panel/internal/sitesfs"
)

type Check struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	OK       bool   `json:"ok"`
	Critical bool   `json:"critical"`
	Detail   string `json:"detail"`
}

type PreflightResult struct {
	OK       bool            `json:"ok"`
	Expected string          `json:"expected"`
	Domains  []string        `json:"domains"`
	Checks   []Check         `json:"checks"`
	DNSItems []dnscheck.Item `json:"dnsItems"`
	Lines    []string        `json:"lines"`
}

func Preflight(ctx context.Context, opt Options) PreflightResult {
	var res PreflightResult
	add := func(c Check) {
		res.Checks = append(res.Checks, c)
		mark := "OK"
		if !c.OK {
			mark = "FAIL"
		}
		res.Lines = append(res.Lines, fmt.Sprintf("%s  %s — %s", mark, c.Name, c.Detail))
	}

	expect := opt.Server.PublicIP
	if expect == "" {
		expect = opt.Server.Host
	}
	res.Expected = expect

	if opt.Server.ID == 0 || opt.Site.ServerID == 0 {
		add(Check{ID: "bind", Name: "站点已绑服务器", Critical: true, Detail: "还没选服务器"})
		res.OK = false
		return res
	}
	add(Check{ID: "bind", Name: "站点已绑服务器", OK: true, Critical: true, Detail: fmt.Sprintf("#%d %s", opt.Server.ID, opt.Server.Host)})

	conf, err := sitesfs.ReadConf(opt.SitesRoot, opt.SiteName)
	if err != nil {
		add(Check{ID: "conf", Name: "读到站点配置", Critical: true, Detail: err.Error()})
		res.OK = false
		return res
	}
	allDomains, err := confmark.Domains(conf)
	if err != nil || len(allDomains) == 0 {
		detail := "配置里没有域名"
		if err != nil {
			detail = err.Error()
		}
		add(Check{ID: "domains", Name: "配置里有域名", Critical: true, Detail: detail})
		res.OK = false
		return res
	}
	res.Domains = allDomains
	add(Check{ID: "domains", Name: "配置里有域名", OK: true, Critical: true, Detail: strings.Join(allDomains, ", ")})

	hosts := CertHostnames(allDomains)
	for _, d := range allDomains {
		if IsIPLiteral(d) {
			add(Check{ID: "dns:" + d, Name: "解析 " + d, OK: true, Critical: false, Detail: "这是 IP，不进证书、不查解析"})
		}
	}
	if len(hosts) == 0 {
		add(Check{ID: "certHosts", Name: "有可申请证书的域名", Critical: true, Detail: "只有 IP，Let’s Encrypt 签不了"})
	}

	if expect == "" || net.ParseIP(expect) == nil {
		add(Check{ID: "expectIP", Name: "服务器公网 IP", Critical: true, Detail: "请在服务器里填公网 IP"})
	} else {
		add(Check{ID: "expectIP", Name: "服务器公网 IP", OK: true, Critical: true, Detail: expect})
	}

	items := opt.ReuseDNSItems
	reusedDNS := opt.SkipDNS && dnsItemsCoverHosts(hosts, items)
	if !reusedDNS {
		items = dnscheck.CheckDomains(ctx, hosts, expect)
	} else {
		res.Lines = append(res.Lines, "部署时解析已通过，跳过重查")
	}
	res.DNSItems = items
	dnsOK := len(hosts) == 0 || len(items) > 0
	for _, it := range items {
		act := strings.Join(it.Actual, ",")
		if act == "" {
			act = "-"
		}
		detail := act
		if it.Error != "" {
			detail = it.Error + " / " + act
		}
		if reusedDNS {
			detail = detail + "（部署时已通过）"
		}
		c := Check{
			ID:       "dns:" + it.Domain,
			Name:     "解析到这台机 " + it.Domain,
			OK:       it.OK,
			Critical: true,
			Detail:   fmt.Sprintf("应是 %s，现在是 %s", expect, detail),
		}
		add(c)
		if !it.OK {
			dnsOK = false
		}
	}
	if len(hosts) > 0 && len(items) == 0 {
		dnsOK = false
	}

	runner, err := deploy.NewRunner(opt.Server)
	if err != nil {
		add(Check{ID: "ssh", Name: "能 SSH 上这台机", Critical: true, Detail: err.Error()})
		res.OK = allCriticalOK(res.Checks)
		return res
	}

	sshOut, sshErr := runner.Output(ctx, "echo ok && uname -s")
	if sshErr != nil {
		add(Check{ID: "ssh", Name: "能 SSH 上这台机", Critical: true, Detail: sshErr.Error()})
		res.OK = allCriticalOK(res.Checks)
		return res
	}
	add(Check{ID: "ssh", Name: "能 SSH 上这台机", OK: true, Critical: true, Detail: strings.TrimSpace(sshOut)})

	osInfo, osErr := deploy.ProbeOS(ctx, runner)
	if osErr != nil {
		add(Check{ID: "os", Name: "系统信息", Critical: true, Detail: osErr.Error()})
	} else {
		label := osInfo.Pretty
		if label == "" {
			label = osInfo.ID + " " + osInfo.Version
		}
		detail := fmt.Sprintf("%s（%s；可初始化=%v）", label, osInfo.Family(), osInfo.SupportsPanelInit())
		add(Check{ID: "os", Name: "系统信息", OK: true, Critical: false, Detail: detail})

		certOut, _ := runner.Output(ctx, "bash -lc "+deploy.ShellQuote(`command -v certbot >/dev/null && certbot --version 2>&1 | head -n1 || echo missing`))
		certOut = strings.TrimSpace(certOut)
		switch {
		case certOut != "" && certOut != "missing":
			add(Check{ID: "certbot", Name: "Certbot 可用", OK: true, Critical: true, Detail: certOut})
		case osInfo.CanPkgInstallCertbot():
			pkg := "apt"
			if osInfo.Family() == "rhel" {
				pkg = "yum/dnf"
			}
			add(Check{ID: "certbot", Name: "Certbot 可用", OK: true, Critical: true, Detail: "还没装，申请时用 " + pkg + " 自动装"})
		default:
			add(Check{ID: "certbot", Name: "Certbot 可用", Critical: true, Detail: "没装且装不了（Debian/Ubuntu 最稳；RHEL 要 yum 可用）"})
		}
	}

	ngx, ngxErr := runner.Output(ctx, "bash -lc "+deploy.ShellQuote(`
if ! command -v nginx >/dev/null 2>&1; then echo missing; exit 0; fi
active=no
systemctl is-active nginx >/dev/null 2>&1 && active=yes || true
systemctl is-active panel-nginx >/dev/null 2>&1 && active=yes || true
ver=$(nginx -v 2>&1 | head -n1)
echo "active=$active $ver"
`))
	ngx = strings.TrimSpace(ngx)
	if ngxErr != nil || ngx == "" || strings.HasPrefix(ngx, "missing") {
		detail := ngx
		if ngxErr != nil {
			detail = ngxErr.Error()
		}
		if detail == "" || detail == "missing" {
			detail = "没装 Nginx"
		}
		add(Check{ID: "nginx", Name: "Nginx 在运行", Critical: true, Detail: detail})
	} else if strings.Contains(ngx, "active=yes") {
		add(Check{ID: "nginx", Name: "Nginx 在运行", OK: true, Critical: true, Detail: ngx})
	} else {
		add(Check{ID: "nginx", Name: "Nginx 在运行", Critical: true, Detail: "没在跑: " + ngx})
	}

	listen, _ := runner.Output(ctx, "bash -lc "+deploy.ShellQuote(port80ProbeScript))
	listen = strings.TrimSpace(listen)
	if listen == "yes" {
		add(Check{ID: "port80", Name: "80 端口开着", OK: true, Critical: true, Detail: "申请证书要用"})
	} else {
		add(Check{ID: "port80", Name: "80 端口开着", Critical: true, Detail: "没在听 80，Let’s Encrypt 校验过不去"})
	}

	// From panel host: can we reach domain:80 at all? Soft check.
	httpOK := 0
	for _, d := range hosts {
		ok, detail := probeHTTP80(ctx, d)
		add(Check{
			ID:       "http:" + d,
			Name:     "面板侧能连 " + d + ":80",
			OK:       ok,
			Critical: false,
			Detail:   detail,
		})
		if ok {
			httpOK++
		}
	}
	if httpOK == 0 && len(hosts) > 0 {
		res.Lines = append(res.Lines, "提示: 面板连不上域名:80 也可能只是防火墙；解析和远端 80 过了仍可申请")
	}

	_ = dnsOK
	res.OK = allCriticalOK(res.Checks)
	return res
}

func allCriticalOK(checks []Check) bool {
	for _, c := range checks {
		if c.Critical && !c.OK {
			return false
		}
	}
	return len(checks) > 0
}

// dnsItemsCoverHosts is true when every cert hostname has a matching DNS item
// (used to decide whether deploy-time results can be reused).
func dnsItemsCoverHosts(hosts []string, items []dnscheck.Item) bool {
	if len(hosts) == 0 {
		return true
	}
	if len(items) == 0 {
		return false
	}
	have := make(map[string]struct{}, len(items))
	for _, it := range items {
		d := strings.TrimSpace(it.Domain)
		if d != "" {
			have[strings.ToLower(d)] = struct{}{}
		}
	}
	for _, h := range hosts {
		if _, ok := have[strings.ToLower(strings.TrimSpace(h))]; !ok {
			return false
		}
	}
	return true
}

// dnsItemsAllOK requires coverage and every listed cert hostname item marked OK.
func dnsItemsAllOK(hosts []string, items []dnscheck.Item) bool {
	if !dnsItemsCoverHosts(hosts, items) {
		return false
	}
	if len(hosts) == 0 {
		return true
	}
	by := make(map[string]bool, len(items))
	for _, it := range items {
		d := strings.ToLower(strings.TrimSpace(it.Domain))
		if d != "" {
			by[d] = it.OK
		}
	}
	for _, h := range hosts {
		if !by[strings.ToLower(strings.TrimSpace(h))] {
			return false
		}
	}
	return true
}

func probeHTTP80(ctx context.Context, domain string) (bool, string) {
	d := net.Dialer{Timeout: 4 * time.Second}
	cctx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	conn, err := d.DialContext(cctx, "tcp", net.JoinHostPort(domain, "80"))
	if err != nil {
		return false, "tcp :80 " + err.Error()
	}
	_ = conn.Close()
	return true, "tcp :80 可连"
}

// Explicit branches avoid emitting "yes" twice through mixed && / || chains.
const port80ProbeScript = `if ss -lnt 2>/dev/null | grep -q ":80 "; then echo yes; elif netstat -lnt 2>/dev/null | grep -q ":80 "; then echo yes; else echo no; fi`
