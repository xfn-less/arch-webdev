package sslcert

import (
	"github.com/xfn/static-site-panel/internal/confmark"
	"os/exec"
	"strings"
	"testing"
)

func TestPrepareACMEConfKeepsCustomLocations(t *testing.T) {
	base := "server {\n listen 443 ssl http2;\n" + confmark.ServerNameBegin + "\n server_name 3.xfnss.top 33.xfnss.top;\n" + confmark.ServerNameEnd + "\n" + confmark.SSLBegin + "\n    ssl_certificate /missing/fullchain.pem;\n    ssl_certificate_key /missing/privkey.pem;\n" + confmark.SSLEnd + "\n location /proxy { proxy_pass http://127.0.0.1:8080; }\n}\n"
	got, err := prepareACMEConf(base, "/www/sites/test/www", true)
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(got, "location /proxy") || !strings.Contains(got, "acme-challenge") {
		t.Fatal(got)
	}
	if strings.Contains(got, "return 301") {
		t.Fatal("HTTPS redirect should be paused", got)
	}
	for _, line := range strings.Split(got, "\n") {
		trim := strings.TrimSpace(line)
		if strings.HasPrefix(trim, "listen ") && strings.Contains(trim, "443") {
			t.Fatal("active listen 443 should be commented", got)
		}
	}
	next, err := confmark.ApplyIssuedSSL(got, "3.xfnss.top")
	if err != nil || !strings.Contains(next, "listen 443") || !strings.Contains(next, "location /proxy") {
		t.Fatal(next, err)
	}
}

func TestPort80ProbeSingleAnswer(t *testing.T) {
	for _, tc := range []struct{ ss, netstat, want string }{
		{"printf 'LISTEN 0 511 0.0.0.0:80 0.0.0.0:*\\n'", "return 1", "yes\n"},
		{"return 1", "printf 'tcp 0 0 0.0.0.0:80 0.0.0.0:*\\n'", "yes\n"},
		{"return 1", "return 1", "no\n"},
	} {
		out, err := exec.Command("bash", "-c", "ss() { "+tc.ss+"; }; netstat() { "+tc.netstat+"; }; "+port80ProbeScript).CombinedOutput()
		if err != nil || string(out) != tc.want {
			t.Fatalf("out=%q want=%q err=%v", out, tc.want, err)
		}
	}
}
