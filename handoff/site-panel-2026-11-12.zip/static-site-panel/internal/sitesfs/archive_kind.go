package sitesfs

import (
	"path/filepath"
	"strings"
)

// Archive kinds the panel can list/extract.
const (
	ArchiveZIP    = "zip"
	ArchiveTAR    = "tar"
	ArchiveTARGZ  = "tar.gz"
	ArchiveTARBZ2 = "tar.bz2"
	ArchiveTARXZ  = "tar.xz"
	Archive7Z     = "7z"
	ArchiveRAR    = "rar"
)

// DetectArchive returns the archive kind for a filename, or "" if unsupported.
func DetectArchive(name string) string {
	base := strings.ToLower(filepath.Base(strings.TrimSpace(name)))
	switch {
	case strings.HasSuffix(base, ".tar.gz"), strings.HasSuffix(base, ".tgz"):
		return ArchiveTARGZ
	case strings.HasSuffix(base, ".tar.bz2"), strings.HasSuffix(base, ".tbz2"), strings.HasSuffix(base, ".tbz"):
		return ArchiveTARBZ2
	case strings.HasSuffix(base, ".tar.xz"), strings.HasSuffix(base, ".txz"):
		return ArchiveTARXZ
	case strings.HasSuffix(base, ".tar"):
		return ArchiveTAR
	case strings.HasSuffix(base, ".zip"):
		return ArchiveZIP
	case strings.HasSuffix(base, ".7z"):
		return Archive7Z
	case strings.HasSuffix(base, ".rar"):
		return ArchiveRAR
	default:
		return ""
	}
}

// IsArchive reports whether name looks like a supported archive.
func IsArchive(name string) bool {
	return DetectArchive(name) != ""
}

// archiveBaseName strips known archive suffixes for folder naming.
func archiveBaseName(name string) string {
	base := filepath.Base(name)
	lower := strings.ToLower(base)
	for _, suf := range []string{".tar.gz", ".tar.bz2", ".tar.xz", ".tgz", ".tbz2", ".tbz", ".txz", ".zip", ".7z", ".rar", ".tar"} {
		if strings.HasSuffix(lower, suf) {
			return base[:len(base)-len(suf)]
		}
	}
	ext := filepath.Ext(base)
	if ext == "" {
		return base
	}
	return strings.TrimSuffix(base, ext)
}
