package sitesfs

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// TransferPaths copies or moves paths from fromSite into toSite's destDir (site-relative).
// mode: "copy" | "cut". conflict: "reject" | "overwrite" | "rename".
func TransferPaths(root, fromSite, toSite string, paths []string, destDir, mode, conflict string) error {
	mode = strings.ToLower(strings.TrimSpace(mode))
	if mode != "copy" && mode != "cut" {
		return fmt.Errorf("mode must be copy or cut")
	}
	conflict = strings.ToLower(strings.TrimSpace(conflict))
	if conflict == "" {
		conflict = "reject"
	}
	if conflict != "reject" && conflict != "overwrite" && conflict != "rename" {
		return fmt.Errorf("invalid paste conflict policy")
	}
	if len(paths) == 0 {
		return fmt.Errorf("paths required")
	}
	destDir = strings.Trim(strings.ReplaceAll(destDir, "\\", "/"), "/")
	if strings.Contains(destDir, "..") {
		return fmt.Errorf("invalid dest")
	}

	for _, p := range paths {
		p = strings.Trim(strings.ReplaceAll(p, "\\", "/"), "/")
		if p == "" {
			return fmt.Errorf("empty path")
		}
		srcAbs, srcRel, err := Resolve(root, fromSite, p)
		if err != nil {
			return err
		}
		st, err := os.Stat(srcAbs)
		if err != nil {
			return err
		}
		name := filepath.Base(srcAbs)
		destRel := name
		if destDir != "" {
			destRel = destDir + "/" + name
		}
		if fromSite == toSite {
			if srcRel == destRel {
				return fmt.Errorf("%s: source and dest are the same", p)
			}
			if st.IsDir() && (destRel == srcRel || strings.HasPrefix(destRel+"/", srcRel+"/")) {
				return fmt.Errorf("%s: cannot paste folder into itself", p)
			}
		}
		dstAbs, destClean, err := Resolve(root, toSite, destRel)
		if err != nil {
			return err
		}
		dstSt, dstErr := os.Lstat(dstAbs)
		exists := dstErr == nil
		if dstErr != nil && !os.IsNotExist(dstErr) {
			return dstErr
		}
		if exists {
			switch conflict {
			case "reject":
				return fmt.Errorf("%s already exists", destRel)
			case "overwrite":
				// Match upload: do not replace a directory with a file (or vice versa) via overwrite.
				if st.IsDir() != dstSt.IsDir() {
					return fmt.Errorf("%s: cannot overwrite %s with %s", destRel, typeLabel(dstSt.IsDir()), typeLabel(st.IsDir()))
				}
				if !st.IsDir() && !dstSt.Mode().IsRegular() {
					return fmt.Errorf("%s: paste target is not a regular file", destRel)
				}
				if err := os.RemoveAll(dstAbs); err != nil {
					return err
				}
			case "rename":
				freeRel, err := nextFreePasteRel(root, toSite, destClean)
				if err != nil {
					return err
				}
				destRel = freeRel
				dstAbs, destClean, err = Resolve(root, toSite, destRel)
				if err != nil {
					return err
				}
			}
		}
		if err := os.MkdirAll(filepath.Dir(dstAbs), 0o755); err != nil {
			return err
		}

		sameVolumeRename := false
		if mode == "cut" && fromSite == toSite {
			if err := os.Rename(srcAbs, dstAbs); err == nil {
				sameVolumeRename = true
			}
		}
		if !sameVolumeRename {
			if st.IsDir() {
				if err := copyDir(srcAbs, dstAbs); err != nil {
					_ = os.RemoveAll(dstAbs)
					return err
				}
			} else {
				if err := copyFile(srcAbs, dstAbs, st.Mode()); err != nil {
					_ = os.Remove(dstAbs)
					return err
				}
			}
			if mode == "cut" {
				if err := os.RemoveAll(srcAbs); err != nil {
					return fmt.Errorf("copied but failed to remove source %s: %w", p, err)
				}
			}
		}
	}
	return nil
}

func typeLabel(dir bool) string {
	if dir {
		return "folder"
	}
	return "file"
}

func nextFreePasteRel(root, site, rel string) (string, error) {
	for i := 2; ; i++ {
		candidateRel := renamedUploadPath(rel, i)
		abs, _, err := Resolve(root, site, candidateRel)
		if err != nil {
			return "", err
		}
		_, err = os.Lstat(abs)
		if os.IsNotExist(err) {
			return candidateRel, nil
		}
		if err != nil {
			return "", err
		}
	}
}
