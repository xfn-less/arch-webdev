package sitesfs

import (
	"archive/zip"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
)

// ZipPaths packs relative paths (files or dirs) into outRel zip under the site.
func ZipPaths(root, site string, paths []string, outRel string) error {
	if outRel == "" {
		return fmt.Errorf("out required")
	}
	if !strings.HasSuffix(strings.ToLower(outRel), ".zip") {
		outRel += ".zip"
	}
	outAbs, _, err := Resolve(root, site, outRel)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(outAbs), 0o755); err != nil {
		return err
	}
	f, err := os.CreateTemp(filepath.Dir(outAbs), ".panel-zip-*")
	if err != nil {
		return err
	}
	tmp := f.Name()
	defer os.Remove(tmp)
	zw := zip.NewWriter(f)

	base, err := siteRoot(root, site)
	if err != nil {
		zw.Close()
		f.Close()
		_ = os.Remove(tmp)
		return err
	}
	for _, p := range paths {
		abs, clean, err := Resolve(root, site, p)
		if err != nil {
			zw.Close()
			f.Close()
			_ = os.Remove(tmp)
			return err
		}
		st, err := os.Stat(abs)
		if err != nil {
			zw.Close()
			f.Close()
			_ = os.Remove(tmp)
			return err
		}
		if st.IsDir() {
			err = filepath.Walk(abs, func(path string, info os.FileInfo, err error) error {
				if err != nil {
					return err
				}
				if info.Mode()&os.ModeSymlink != 0 {
					return fmt.Errorf("cannot zip symlink: %s", path)
				}
				if path == tmp || path == outAbs {
					return nil
				}
				rel, err := filepath.Rel(base, path)
				if err != nil {
					return err
				}
				name := filepath.ToSlash(rel)
				if info.IsDir() {
					if !strings.HasSuffix(name, "/") {
						name += "/"
					}
					_, err := zw.Create(name)
					return err
				}
				return writeZipFile(zw, path, name)
			})
			if err != nil {
				zw.Close()
				f.Close()
				_ = os.Remove(tmp)
				return err
			}
			continue
		}
		name := filepath.ToSlash(clean)
		if err := writeZipFile(zw, abs, name); err != nil {
			zw.Close()
			f.Close()
			_ = os.Remove(tmp)
			return err
		}
	}
	if err := zw.Close(); err != nil {
		f.Close()
		_ = os.Remove(tmp)
		return err
	}
	if err := f.Close(); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	if err := os.Rename(tmp, outAbs); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	return nil
}

func writeZipFile(zw *zip.Writer, abs, name string) error {
	w, err := zw.Create(name)
	if err != nil {
		return err
	}
	r, err := os.Open(abs)
	if err != nil {
		return err
	}
	defer r.Close()
	_, err = io.Copy(w, r)
	return err
}

type ZipEntry struct {
	Name string `json:"name"`
	Dir  bool   `json:"dir"`
	Size int64  `json:"size"`
}

type UnzipInfo struct {
	Mode  string `json:"mode"` // flat | folder
	Dest  string `json:"dest"`
	Strip string `json:"strip,omitempty"`
}

func joinSiteRel(parent, name string) string {
	parent = strings.Trim(parent, "/")
	name = strings.Trim(name, "/")
	if parent == "" {
		return name
	}
	if name == "" {
		return parent
	}
	return parent + "/" + name
}
