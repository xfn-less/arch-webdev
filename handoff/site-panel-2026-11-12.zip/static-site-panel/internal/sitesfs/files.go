package sitesfs

import (
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
)

var ErrUploadConflict = errors.New("upload target already exists")

type UploadConflict struct {
	Name      string `json:"name"`
	Directory bool   `json:"directory"`
}

type Entry struct {
	Name  string `json:"name"`
	Dir   bool   `json:"dir"`
	Size  int64  `json:"size"`
	Mtime int64  `json:"mtime"` // unix seconds; 0 if unknown
	Path  string `json:"path"`  // relative to site root, slash-separated
}

func siteRoot(root, site string) (string, error) {
	if err := validName(site); err != nil {
		return "", err
	}
	return filepath.Join(root, site), nil
}

// Resolve joins site-relative path; rejects escape.
func Resolve(root, site, rel string) (abs string, cleanRel string, err error) {
	base, err := siteRoot(root, site)
	if err != nil {
		return "", "", err
	}
	rel = strings.ReplaceAll(rel, "\\", "/")
	rel = strings.TrimPrefix(rel, "/")
	if strings.Contains(rel, "..") {
		return "", "", fmt.Errorf("invalid path")
	}
	abs = filepath.Join(base, filepath.FromSlash(rel))
	abs, err = filepath.Abs(abs)
	if err != nil {
		return "", "", err
	}
	baseAbs, err := filepath.Abs(base)
	if err != nil {
		return "", "", err
	}
	if abs != baseAbs && !strings.HasPrefix(abs, baseAbs+string(os.PathSeparator)) {
		return "", "", fmt.Errorf("path escape")
	}
	cleanRel = strings.TrimPrefix(filepath.ToSlash(strings.TrimPrefix(abs, baseAbs)), "/")
	// Check every existing component, including ancestors of new files.
	for path := abs; ; path = filepath.Dir(path) {
		st, err := os.Lstat(path)
		if err != nil && !os.IsNotExist(err) {
			return "", "", err
		}
		if err == nil && st.Mode()&os.ModeSymlink != 0 {
			return "", "", fmt.Errorf("symlink path rejected")
		}
		if path == baseAbs {
			break
		}
	}
	return abs, cleanRel, nil
}

func ListDir(root, site, rel string) ([]Entry, error) {
	abs, cleanRel, err := Resolve(root, site, rel)
	if err != nil {
		return nil, err
	}
	st, err := os.Stat(abs)
	if err != nil {
		return nil, err
	}
	if !st.IsDir() {
		return nil, fmt.Errorf("not a directory")
	}
	ents, err := os.ReadDir(abs)
	if err != nil {
		return nil, err
	}
	out := make([]Entry, 0, len(ents))
	for _, e := range ents {
		name := e.Name()
		if strings.HasPrefix(name, ".") {
			continue
		}
		info, err := e.Info()
		if err != nil {
			continue
		}
		p := name
		if cleanRel != "" {
			p = cleanRel + "/" + name
		}
		out = append(out, Entry{
			Name:  name,
			Dir:   e.IsDir(),
			Size:  info.Size(),
			Mtime: info.ModTime().Unix(),
			Path:  p,
		})
	}
	return out, nil
}

func ReadFile(root, site, rel string, maxBytes int64) ([]byte, string, error) {
	abs, cleanRel, err := Resolve(root, site, rel)
	if err != nil {
		return nil, "", err
	}
	st, err := os.Stat(abs)
	if err != nil {
		return nil, "", err
	}
	if st.IsDir() {
		return nil, "", fmt.Errorf("is a directory")
	}
	if maxBytes <= 0 {
		maxBytes = 2 << 20
	}
	if st.Size() > maxBytes {
		return nil, "", fmt.Errorf("file too large")
	}
	b, err := os.ReadFile(abs)
	return b, cleanRel, err
}

func WriteFile(root, site, rel string, body []byte) error {
	abs, _, err := Resolve(root, site, rel)
	if err != nil {
		return err
	}
	st, err := os.Stat(abs)
	if err == nil && st.IsDir() {
		return fmt.Errorf("is a directory")
	}
	if err := os.MkdirAll(filepath.Dir(abs), 0o755); err != nil {
		return err
	}
	f, err := os.CreateTemp(filepath.Dir(abs), ".panel-write-*")
	if err != nil {
		return err
	}
	tmp := f.Name()
	defer os.Remove(tmp)
	if err := f.Chmod(0o644); err != nil {
		f.Close()
		return err
	}
	_, writeErr := f.Write(body)
	closeErr := f.Close()
	if writeErr != nil {
		return writeErr
	}
	if err := closeErr; err != nil {
		return err
	}
	if err := os.Rename(tmp, abs); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	return nil
}

// WriteFileStream writes from r to site path via temp+rename (atomic replace).
func WriteFileStream(root, site, rel string, r io.Reader, maxBytes int64) error {
	abs, _, err := Resolve(root, site, rel)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(abs), 0o755); err != nil {
		return err
	}
	out, err := os.CreateTemp(filepath.Dir(abs), ".panel-upload-*")
	if err != nil {
		return err
	}
	tmp := out.Name()
	defer os.Remove(tmp)
	if err := out.Chmod(0o644); err != nil {
		out.Close()
		return err
	}
	n, err := io.Copy(out, io.LimitReader(r, maxBytes+1))
	cerr := out.Close()
	if err != nil {
		_ = os.Remove(tmp)
		return err
	}
	if cerr != nil {
		_ = os.Remove(tmp)
		return cerr
	}
	if n > maxBytes {
		_ = os.Remove(tmp)
		return fmt.Errorf("file too large")
	}
	if err := os.Rename(tmp, abs); err != nil {
		_ = os.Remove(tmp)
		return err
	}
	return nil
}

// UploadConflicts reports existing names in the target directory, including hidden files.
func UploadConflicts(root, site, dir string, names []string) ([]UploadConflict, error) {
	var out []UploadConflict
	seen := map[string]bool{}
	for _, name := range names {
		name = uploadBaseName(name)
		if name == "" || name == "." || name == ".." || seen[name] {
			continue
		}
		seen[name] = true
		rel := name
		if dir != "" {
			rel = strings.TrimSuffix(dir, "/") + "/" + name
		}
		abs, _, err := Resolve(root, site, rel)
		if err != nil {
			return nil, err
		}
		st, err := os.Lstat(abs)
		if os.IsNotExist(err) {
			continue
		}
		if err != nil {
			return nil, err
		}
		out = append(out, UploadConflict{Name: name, Directory: st.IsDir()})
	}
	return out, nil
}

// WriteUploadStream atomically uploads with a selected same-name policy: reject, overwrite, or rename.
// Rename chooses the first free "name (N).ext" without replacing a concurrently-created file.
func WriteUploadStream(root, site, rel string, r io.Reader, maxBytes int64, policy string) (string, error) {
	abs, cleanRel, err := Resolve(root, site, rel)
	if err != nil {
		return "", err
	}
	if err := os.MkdirAll(filepath.Dir(abs), 0o755); err != nil {
		return "", err
	}
	out, err := os.CreateTemp(filepath.Dir(abs), ".panel-upload-*")
	if err != nil {
		return "", err
	}
	tmp := out.Name()
	defer os.Remove(tmp)
	if err := out.Chmod(0o644); err != nil {
		out.Close()
		return "", err
	}
	n, err := io.Copy(out, io.LimitReader(r, maxBytes+1))
	closeErr := out.Close()
	if err != nil {
		return "", err
	}
	if closeErr != nil {
		return "", closeErr
	}
	if n > maxBytes {
		return "", fmt.Errorf("file too large")
	}

	if policy == "overwrite" {
		st, statErr := os.Lstat(abs)
		if statErr == nil && (!st.Mode().IsRegular()) {
			return "", fmt.Errorf("upload target is not a regular file")
		}
		if statErr != nil && !os.IsNotExist(statErr) {
			return "", statErr
		}
		if err := os.Rename(tmp, abs); err != nil {
			return "", err
		}
		return cleanRel, nil
	}
	if policy != "reject" && policy != "rename" {
		return "", fmt.Errorf("invalid upload conflict policy")
	}

	for i := 1; ; i++ {
		candidate := abs
		candidateRel := cleanRel
		if i > 1 {
			candidateRel = renamedUploadPath(cleanRel, i)
			candidate, _, err = Resolve(root, site, candidateRel)
			if err != nil {
				return "", err
			}
		}
		err = os.Link(tmp, candidate)
		if err == nil {
			return candidateRel, nil
		}
		if !os.IsExist(err) {
			return "", err
		}
		if policy == "reject" {
			return "", fmt.Errorf("%w: %s", ErrUploadConflict, candidateRel)
		}
	}
}

func uploadBaseName(name string) string {
	name = strings.ReplaceAll(name, "\\", "/")
	return filepath.Base(name)
}

func renamedUploadPath(rel string, n int) string {
	dir, base := filepath.Split(rel)
	ext := filepath.Ext(base)
	stem := strings.TrimSuffix(base, ext)
	if stem == "" { // Keep dotfiles readable: .env -> .env (2)
		stem, ext = base, ""
	}
	return filepath.ToSlash(filepath.Join(dir, fmt.Sprintf("%s (%d)%s", stem, n, ext)))
}

func Mkdir(root, site, rel string) error {
	abs, _, err := Resolve(root, site, rel)
	if err != nil {
		return err
	}
	return os.MkdirAll(abs, 0o755)
}

func CreateEmpty(root, site, rel string) error {
	abs, _, err := Resolve(root, site, rel)
	if err != nil {
		return err
	}
	if _, err := os.Stat(abs); err == nil {
		return fmt.Errorf("already exists")
	}
	if err := os.MkdirAll(filepath.Dir(abs), 0o755); err != nil {
		return err
	}
	return os.WriteFile(abs, nil, 0o644)
}

func RemovePath(root, site, rel string) error {
	if rel == "" || rel == "." {
		return fmt.Errorf("cannot remove site root")
	}
	abs, _, err := Resolve(root, site, rel)
	if err != nil {
		return err
	}
	return os.RemoveAll(abs)
}

func RenamePath(root, site, from, to string) error {
	if from == "" || to == "" {
		return fmt.Errorf("from/to required")
	}
	src, _, err := Resolve(root, site, from)
	if err != nil {
		return err
	}
	dst, _, err := Resolve(root, site, to)
	if err != nil {
		return err
	}
	if _, err := os.Stat(dst); err == nil {
		return fmt.Errorf("target already exists")
	}
	if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
		return err
	}
	return os.Rename(src, dst)
}

func AbsPath(root, site, rel string) (string, error) {
	abs, _, err := Resolve(root, site, rel)
	return abs, err
}
