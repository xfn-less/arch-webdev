package sitesfs

import (
	"archive/tar"
	"compress/gzip"
	"os"
	"path/filepath"
	"testing"
)

func TestDetectArchive(t *testing.T) {
	cases := map[string]string{
		"a.zip":        ArchiveZIP,
		"a.ZIP":        ArchiveZIP,
		"a.tar":        ArchiveTAR,
		"a.tar.gz":     ArchiveTARGZ,
		"a.tgz":        ArchiveTARGZ,
		"a.tar.bz2":    ArchiveTARBZ2,
		"a.tar.xz":     ArchiveTARXZ,
		"a.7z":         Archive7Z,
		"a.rar":        ArchiveRAR,
		"a.txt":        "",
		"notatar.gz":   "",
		"pack.tar.gz":  ArchiveTARGZ,
	}
	for name, want := range cases {
		if got := DetectArchive(name); got != want {
			t.Fatalf("%s: got %q want %q", name, got, want)
		}
	}
	if archiveBaseName("pack.tar.gz") != "pack" {
		t.Fatal(archiveBaseName("pack.tar.gz"))
	}
}

func TestExtractTarGzFolder(t *testing.T) {
	root := t.TempDir()
	base := filepath.Join(root, "demo", "www")
	if err := os.MkdirAll(base, 0755); err != nil {
		t.Fatal(err)
	}
	arch := filepath.Join(base, "pack.tar.gz")
	f, err := os.Create(arch)
	if err != nil {
		t.Fatal(err)
	}
	gz := gzip.NewWriter(f)
	tw := tar.NewWriter(gz)
	writeTarFile(t, tw, "pack/a.txt", "hello")
	writeTarFile(t, tw, "pack/b.txt", "world")
	if err := tw.Close(); err != nil {
		t.Fatal(err)
	}
	if err := gz.Close(); err != nil {
		t.Fatal(err)
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}
	info, err := Extract(root, "demo", "www/pack.tar.gz", "", "folder")
	if err != nil {
		t.Fatal(err)
	}
	if info.Mode != "folder" || info.Dest != "www/pack" {
		t.Fatalf("%+v", info)
	}
	// folder mode keeps the archive's own wrap/ tree under dest
	b, err := os.ReadFile(filepath.Join(base, "pack", "pack", "a.txt"))
	if err != nil || string(b) != "hello" {
		t.Fatalf("a.txt=%q err=%v", b, err)
	}
}

func writeTarFile(t *testing.T, tw *tar.Writer, name, body string) {
	t.Helper()
	hdr := &tar.Header{Name: name, Mode: 0644, Size: int64(len(body))}
	if err := tw.WriteHeader(hdr); err != nil {
		t.Fatal(err)
	}
	if _, err := tw.Write([]byte(body)); err != nil {
		t.Fatal(err)
	}
}
