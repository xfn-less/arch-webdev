package sitesfs

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"time"
)

const (
	fileHistoryLimit = 10
	fileHistoryDir   = ".panel-history"
)

// FileHistoryMeta is one saved previous version (content stored beside meta).
type FileHistoryMeta struct {
	ID      string `json:"id"`
	SavedAt int64  `json:"savedAt"`
	Size    int    `json:"size"`
}

func historyBucket(root, site, rel string) (string, string, error) {
	base, err := siteRoot(root, site)
	if err != nil {
		return "", "", err
	}
	_, clean, err := Resolve(root, site, rel)
	if err != nil {
		return "", "", err
	}
	sum := sha256.Sum256([]byte(clean))
	key := hex.EncodeToString(sum[:16])
	dir := filepath.Join(base, fileHistoryDir, key)
	return dir, clean, nil
}

func readHistoryIndex(dir string) ([]FileHistoryMeta, error) {
	b, err := os.ReadFile(filepath.Join(dir, "index.json"))
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	var list []FileHistoryMeta
	if err := json.Unmarshal(b, &list); err != nil {
		return nil, err
	}
	return list, nil
}

func writeHistoryIndex(dir string, list []FileHistoryMeta) error {
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(list, "", "  ")
	if err != nil {
		return err
	}
	tmp := filepath.Join(dir, ".index.tmp")
	if err := os.WriteFile(tmp, append(raw, '\n'), 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, filepath.Join(dir, "index.json"))
}

// PushFileHistory stores previous file bytes before overwrite. No-op if empty or unchanged vs newest.
func PushFileHistory(root, site, rel string, previous []byte) error {
	if len(previous) == 0 {
		return nil
	}
	dir, _, err := historyBucket(root, site, rel)
	if err != nil {
		return err
	}
	list, err := readHistoryIndex(dir)
	if err != nil {
		return err
	}
	if len(list) > 0 {
		newest := list[0]
		old, err := os.ReadFile(filepath.Join(dir, newest.ID+".txt"))
		if err == nil && string(old) == string(previous) {
			return nil
		}
	}
	id := strconv.FormatInt(time.Now().UnixNano(), 10)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	bodyPath := filepath.Join(dir, id+".txt")
	if err := os.WriteFile(bodyPath, previous, 0o644); err != nil {
		return err
	}
	list = append([]FileHistoryMeta{{
		ID:      id,
		SavedAt: time.Now().Unix(),
		Size:    len(previous),
	}}, list...)
	for len(list) > fileHistoryLimit {
		drop := list[len(list)-1]
		_ = os.Remove(filepath.Join(dir, drop.ID+".txt"))
		list = list[:len(list)-1]
	}
	return writeHistoryIndex(dir, list)
}

// ListFileHistory returns newest-first metas (max 10).
func ListFileHistory(root, site, rel string) ([]FileHistoryMeta, error) {
	dir, _, err := historyBucket(root, site, rel)
	if err != nil {
		return nil, err
	}
	list, err := readHistoryIndex(dir)
	if err != nil {
		return nil, err
	}
	sort.SliceStable(list, func(i, j int) bool { return list[i].SavedAt > list[j].SavedAt })
	if len(list) > fileHistoryLimit {
		list = list[:fileHistoryLimit]
	}
	return list, nil
}

// ReadFileHistory returns one version body.
func ReadFileHistory(root, site, rel, id string, maxBytes int64) ([]byte, error) {
	if id == "" || filepath.Base(id) != id || id == "." || id == ".." {
		return nil, fmt.Errorf("invalid id")
	}
	dir, _, err := historyBucket(root, site, rel)
	if err != nil {
		return nil, err
	}
	list, err := readHistoryIndex(dir)
	if err != nil {
		return nil, err
	}
	found := false
	for _, m := range list {
		if m.ID == id {
			found = true
			break
		}
	}
	if !found {
		return nil, fmt.Errorf("history not found")
	}
	if maxBytes <= 0 {
		maxBytes = 2 << 20
	}
	p := filepath.Join(dir, id+".txt")
	st, err := os.Stat(p)
	if err != nil {
		return nil, err
	}
	if st.Size() > maxBytes {
		return nil, fmt.Errorf("file too large")
	}
	return os.ReadFile(p)
}
