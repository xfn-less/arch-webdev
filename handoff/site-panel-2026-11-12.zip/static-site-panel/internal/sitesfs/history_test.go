package sitesfs

import (
	"fmt"
	"os"
	"path/filepath"
	"testing"
)

func TestFileHistoryKeepsTen(t *testing.T) {
	root := t.TempDir()
	site := "demo"
	if err := os.MkdirAll(filepath.Join(root, site, "www"), 0o755); err != nil {
		t.Fatal(err)
	}
	rel := "www/a.txt"
	if err := WriteFile(root, site, rel, []byte("v0")); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 12; i++ {
		prev, _, err := ReadFile(root, site, rel, 1<<20)
		if err != nil {
			t.Fatal(err)
		}
		if err := PushFileHistory(root, site, rel, prev); err != nil {
			t.Fatal(err)
		}
		if err := WriteFile(root, site, rel, []byte(fmt.Sprintf("v%d", i+1))); err != nil {
			t.Fatal(err)
		}
	}
	list, err := ListFileHistory(root, site, rel)
	if err != nil {
		t.Fatal(err)
	}
	if len(list) != 10 {
		t.Fatalf("want 10 got %d", len(list))
	}
	body, err := ReadFileHistory(root, site, rel, list[0].ID, 1<<20)
	if err != nil {
		t.Fatal(err)
	}
	if string(body) != "v11" {
		t.Fatalf("newest hist %q want v11", body)
	}
}
