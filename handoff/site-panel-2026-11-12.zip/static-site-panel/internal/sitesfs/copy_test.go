package sitesfs

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/xfn/static-site-panel/internal/confmark"
)

func TestCopyResetsSSLAndDropsSSLDir(t *testing.T) {
	root := t.TempDir()
	src := filepath.Join(root, "s1")
	os.MkdirAll(filepath.Join(src, "www"), 0755)
	os.MkdirAll(filepath.Join(src, "ssl"), 0700)
	os.WriteFile(filepath.Join(src, "ssl", "fullchain.pem"), []byte("CERT"), 0600)
	os.WriteFile(filepath.Join(src, "www", "index.html"), []byte("hi"), 0644)
	conf := "server {\n listen 80;\n listen 443 ssl http2;\n" +
		confmark.ServerNameBegin + "\n server_name a.example;\n" + confmark.ServerNameEnd + "\n" +
		confmark.SSLBegin + "\n    ssl_certificate /etc/letsencrypt/live/a.example/fullchain.pem;\n    ssl_certificate_key /etc/letsencrypt/live/a.example/privkey.pem;\n" + confmark.SSLEnd + "\n" +
		" root /www/sites/s1/www;\n location /keep { return 204; }\n}\n"
	withSSL, err := confmark.ApplyIssuedSSL(conf, "a.example")
	if err != nil {
		t.Fatal(err)
	}
	os.WriteFile(filepath.Join(src, "nginx.conf"), []byte(withSSL), 0644)

	if err := Copy(root, "s1", "s2"); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(root, "s2", "ssl")); !os.IsNotExist(err) {
		t.Fatalf("ssl/ should not be copied: %v", err)
	}
	raw, err := os.ReadFile(filepath.Join(root, "s2", "nginx.conf"))
	if err != nil {
		t.Fatal(err)
	}
	got := string(raw)
	if confmark.SSLConfigured(got) {
		t.Fatal("copied conf still looks SSL-enabled", got)
	}
	if !strings.Contains(got, "/www/sites/s2/www") || strings.Contains(got, "/www/sites/s1/www") {
		t.Fatal("root path not rewritten", got)
	}
	if !strings.Contains(got, "location /keep") || !strings.Contains(got, "a.example") {
		t.Fatal("custom bits lost", got)
	}
	if strings.Contains(got, "letsencrypt") {
		t.Fatal("LE paths should be cleared", got)
	}
}
