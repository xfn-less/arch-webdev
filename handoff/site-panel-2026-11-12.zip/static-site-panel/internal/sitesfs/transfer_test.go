package sitesfs

import (
	"os"
	"path/filepath"
	"testing"
)

func TestTransferCopyAndCut(t *testing.T) {
	root := t.TempDir()
	must := func(err error) {
		t.Helper()
		if err != nil {
			t.Fatal(err)
		}
	}
	must(os.MkdirAll(filepath.Join(root, "a", "www"), 0o755))
	must(os.MkdirAll(filepath.Join(root, "b", "www"), 0o755))
	must(os.WriteFile(filepath.Join(root, "a", "www", "x.txt"), []byte("hi"), 0o644))

	must(TransferPaths(root, "a", "b", []string{"www/x.txt"}, "www", "copy", "reject"))
	b, err := os.ReadFile(filepath.Join(root, "b", "www", "x.txt"))
	must(err)
	if string(b) != "hi" {
		t.Fatalf("got %q", b)
	}
	if _, err := os.Stat(filepath.Join(root, "a", "www", "x.txt")); err != nil {
		t.Fatal("copy should keep source")
	}

	must(os.WriteFile(filepath.Join(root, "a", "www", "y.txt"), []byte("y"), 0o644))
	must(TransferPaths(root, "a", "b", []string{"www/y.txt"}, "www", "cut", "reject"))
	if _, err := os.Stat(filepath.Join(root, "a", "www", "y.txt")); !os.IsNotExist(err) {
		t.Fatalf("cut should remove source: %v", err)
	}
	yb, err := os.ReadFile(filepath.Join(root, "b", "www", "y.txt"))
	must(err)
	if string(yb) != "y" {
		t.Fatalf("got %q", yb)
	}

	if err := TransferPaths(root, "a", "b", []string{"www/x.txt"}, "www", "copy", "reject"); err == nil {
		t.Fatal("expected exists error")
	}

	must(os.WriteFile(filepath.Join(root, "a", "www", "x.txt"), []byte("new"), 0o644))
	must(TransferPaths(root, "a", "b", []string{"www/x.txt"}, "www", "copy", "overwrite"))
	ob, err := os.ReadFile(filepath.Join(root, "b", "www", "x.txt"))
	must(err)
	if string(ob) != "new" {
		t.Fatalf("overwrite got %q", ob)
	}

	must(os.WriteFile(filepath.Join(root, "a", "www", "x.txt"), []byte("copy2"), 0o644))
	must(TransferPaths(root, "a", "b", []string{"www/x.txt"}, "www", "copy", "rename"))
	rb, err := os.ReadFile(filepath.Join(root, "b", "www", "x (2).txt"))
	must(err)
	if string(rb) != "copy2" {
		t.Fatalf("rename got %q", rb)
	}
	kept, err := os.ReadFile(filepath.Join(root, "b", "www", "x.txt"))
	must(err)
	if string(kept) != "new" {
		t.Fatalf("rename should keep original, got %q", kept)
	}

	must(os.MkdirAll(filepath.Join(root, "a", "www", "pack"), 0o755))
	must(os.WriteFile(filepath.Join(root, "a", "www", "pack", "in.txt"), []byte("in"), 0o644))
	must(os.MkdirAll(filepath.Join(root, "b", "www", "pack"), 0o755))
	must(TransferPaths(root, "a", "b", []string{"www/pack"}, "www", "copy", "rename"))
	if _, err := os.Stat(filepath.Join(root, "b", "www", "pack (2)", "in.txt")); err != nil {
		t.Fatalf("renamed folder missing: %v", err)
	}
}

func TestTransferMultiOverwrite(t *testing.T) {
	root := t.TempDir()
	must := func(err error) {
		t.Helper()
		if err != nil {
			t.Fatal(err)
		}
	}
	must(os.MkdirAll(filepath.Join(root, "a", "www"), 0o755))
	must(os.MkdirAll(filepath.Join(root, "b", "www"), 0o755))
	must(os.WriteFile(filepath.Join(root, "a", "www", "a.txt"), []byte("A"), 0o644))
	must(os.WriteFile(filepath.Join(root, "a", "www", "b.txt"), []byte("B"), 0o644))
	must(os.WriteFile(filepath.Join(root, "b", "www", "a.txt"), []byte("oldA"), 0o644))
	must(os.WriteFile(filepath.Join(root, "b", "www", "b.txt"), []byte("oldB"), 0o644))
	must(TransferPaths(root, "a", "b", []string{"www/a.txt", "www/b.txt"}, "www", "copy", "overwrite"))
	a, err := os.ReadFile(filepath.Join(root, "b", "www", "a.txt"))
	must(err)
	bb, err := os.ReadFile(filepath.Join(root, "b", "www", "b.txt"))
	must(err)
	if string(a) != "A" || string(bb) != "B" {
		t.Fatalf("multi overwrite a=%q b=%q", a, bb)
	}
}
