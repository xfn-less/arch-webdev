package sitesfs

import (
	"archive/zip"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestListDirIncludesMtime(t *testing.T) {
	root := t.TempDir()
	base := filepath.Join(root, "demo", "www")
	if err := os.MkdirAll(base, 0755); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(base, "note.txt")
	if err := os.WriteFile(path, []byte("hi"), 0644); err != nil {
		t.Fatal(err)
	}
	ents, err := ListDir(root, "demo", "www")
	if err != nil {
		t.Fatal(err)
	}
	if len(ents) != 1 || ents[0].Name != "note.txt" || ents[0].Mtime <= 0 {
		t.Fatalf("unexpected entries: %+v", ents)
	}
	st, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	if ents[0].Mtime != st.ModTime().Unix() {
		t.Fatalf("mtime=%d want %d", ents[0].Mtime, st.ModTime().Unix())
	}
}

func TestRejectSymlinkAncestorsAndZip(t *testing.T) {
	root := t.TempDir()
	site := filepath.Join(root, "demo")
	outside := t.TempDir()
	if err := os.MkdirAll(filepath.Join(site, "www"), 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(outside, "secret"), []byte("secret"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(outside, filepath.Join(site, "www", "link")); err != nil {
		t.Fatal(err)
	}
	if err := WriteFile(root, "demo", "www/link/new.txt", []byte("bad")); err == nil {
		t.Fatal("symlink write accepted")
	}
	if err := ZipPaths(root, "demo", []string{"www"}, "out.zip"); err == nil {
		t.Fatal("symlink archive accepted")
	}
	if _, err := os.Stat(filepath.Join(outside, "new.txt")); !os.IsNotExist(err) {
		t.Fatal("outside file created")
	}
}

func TestUploadConflictPolicies(t *testing.T) {
	root := t.TempDir()
	base := filepath.Join(root, "demo", "www")
	if err := os.MkdirAll(filepath.Join(base, "folder"), 0755); err != nil {
		t.Fatal(err)
	}
	for name, body := range map[string]string{"index.html": "old", ".env": "secret"} {
		if err := os.WriteFile(filepath.Join(base, name), []byte(body), 0644); err != nil {
			t.Fatal(err)
		}
	}
	conflicts, err := UploadConflicts(root, "demo", "www", []string{"index.html", ".env", "folder", "new.txt"})
	if err != nil || len(conflicts) != 3 {
		t.Fatalf("conflicts=%+v err=%v", conflicts, err)
	}
	if conflicts[2].Name != "folder" || !conflicts[2].Directory {
		t.Fatalf("directory conflict not identified: %+v", conflicts[2])
	}

	if _, err := WriteUploadStream(root, "demo", "www/index.html", strings.NewReader("rejected"), 100, "reject"); !errors.Is(err, ErrUploadConflict) {
		t.Fatalf("expected safe rejection on collision, got %v", err)
	}
	data, _ := os.ReadFile(filepath.Join(base, "index.html"))
	if string(data) != "old" {
		t.Fatal("rejected upload changed existing file")
	}

	path, err := WriteUploadStream(root, "demo", "www/index.html", strings.NewReader("replacement"), 100, "overwrite")
	if err != nil || path != "www/index.html" {
		t.Fatalf("overwrite path=%q err=%v", path, err)
	}
	data, _ = os.ReadFile(filepath.Join(base, "index.html"))
	if string(data) != "replacement" {
		t.Fatalf("overwrite content=%q", data)
	}

	path, err = WriteUploadStream(root, "demo", "www/index.html", strings.NewReader("copy"), 100, "rename")
	if err != nil || path != "www/index (2).html" {
		t.Fatalf("rename path=%q err=%v", path, err)
	}
	data, _ = os.ReadFile(filepath.Join(base, "index (2).html"))
	if string(data) != "copy" {
		t.Fatalf("renamed content=%q", data)
	}
	path, err = WriteUploadStream(root, "demo", "www/folder", strings.NewReader("file"), 100, "rename")
	if err != nil || path != "www/folder (2)" {
		t.Fatalf("directory rename path=%q err=%v", path, err)
	}
}

func TestUnzipMergeAndPreflight(t *testing.T) {
	for _, conflict := range []bool{false, true} {
		t.Run(map[bool]string{false: "merge", true: "conflict"}[conflict], func(t *testing.T) {
			root := t.TempDir()
			base := filepath.Join(root, "demo")
			if err := os.MkdirAll(filepath.Join(base, "assets"), 0755); err != nil {
				t.Fatal(err)
			}
			os.WriteFile(filepath.Join(base, "assets", "keep.txt"), []byte("keep"), 0644)
			os.WriteFile(filepath.Join(base, "assets", "update.txt"), []byte("old"), 0644)
			if conflict {
				os.Mkdir(filepath.Join(base, "z-conflict"), 0755)
			}
			f, err := os.Create(filepath.Join(base, "patch.zip"))
			if err != nil {
				t.Fatal(err)
			}
			z := zip.NewWriter(f)
			for _, name := range []string{"assets/new.txt", "assets/update.txt", "z-conflict"} {
				w, e := z.Create("bundle/" + name)
				if e != nil {
					t.Fatal(e)
				}
				w.Write([]byte("new"))
			}
			if err := z.Close(); err != nil {
				t.Fatal(err)
			}
			f.Close()
			_, err = Unzip(root, "demo", "patch.zip", "", "")
			if conflict && err == nil {
				t.Fatal("conflict accepted")
			}
			if !conflict && err != nil {
				t.Fatal(err)
			}
			b, err := os.ReadFile(filepath.Join(base, "assets", "keep.txt"))
			if err != nil || string(b) != "keep" {
				t.Fatal("unrelated content lost", err)
			}
			b, err = os.ReadFile(filepath.Join(base, "assets", "update.txt"))
			want := "new"
			if conflict {
				want = "old"
			}
			if err != nil || string(b) != want {
				t.Fatalf("update=%q err=%v", b, err)
			}
			if conflict {
				if _, err := os.Stat(filepath.Join(base, "assets", "new.txt")); !os.IsNotExist(err) {
					t.Fatal("partial extraction")
				}
			}
		})
	}
}

func TestUnzipExplicitModes(t *testing.T) {
	mk := func(t *testing.T, entries map[string]string) (root string) {
		t.Helper()
		root = t.TempDir()
		base := filepath.Join(root, "demo", "www")
		if err := os.MkdirAll(base, 0755); err != nil {
			t.Fatal(err)
		}
		f, err := os.Create(filepath.Join(base, "pack.zip"))
		if err != nil {
			t.Fatal(err)
		}
		z := zip.NewWriter(f)
		for name, body := range entries {
			w, e := z.Create(name)
			if e != nil {
				t.Fatal(e)
			}
			w.Write([]byte(body))
		}
		if err := z.Close(); err != nil {
			t.Fatal(err)
		}
		f.Close()
		return root
	}

	t.Run("folder keeps wrapper", func(t *testing.T) {
		root := mk(t, map[string]string{"wrap/a.txt": "A", "wrap/b.txt": "B"})
		info, err := Unzip(root, "demo", "www/pack.zip", "", "folder")
		if err != nil {
			t.Fatal(err)
		}
		if info.Mode != "folder" || info.Dest != "www/pack" || info.Strip != "" {
			t.Fatalf("info=%+v", info)
		}
		b, err := os.ReadFile(filepath.Join(root, "demo", "www", "pack", "wrap", "a.txt"))
		if err != nil || string(b) != "A" {
			t.Fatalf("got %q err=%v", b, err)
		}
	})

	t.Run("flat keeps wrapper", func(t *testing.T) {
		root := mk(t, map[string]string{"wrap/a.txt": "A"})
		info, err := Unzip(root, "demo", "www/pack.zip", "", "flat")
		if err != nil {
			t.Fatal(err)
		}
		if info.Mode != "flat" || info.Dest != "www" || info.Strip != "" {
			t.Fatalf("info=%+v", info)
		}
		b, err := os.ReadFile(filepath.Join(root, "demo", "www", "wrap", "a.txt"))
		if err != nil || string(b) != "A" {
			t.Fatalf("got %q err=%v", b, err)
		}
	})

	t.Run("folder for flat zip", func(t *testing.T) {
		root := mk(t, map[string]string{"index.html": "hi"})
		info, err := Unzip(root, "demo", "www/pack.zip", "", "folder")
		if err != nil {
			t.Fatal(err)
		}
		if info.Dest != "www/pack" {
			t.Fatalf("dest=%q", info.Dest)
		}
		b, err := os.ReadFile(filepath.Join(root, "demo", "www", "pack", "index.html"))
		if err != nil || string(b) != "hi" {
			t.Fatalf("got %q err=%v", b, err)
		}
	})

	t.Run("flat for flat zip", func(t *testing.T) {
		root := mk(t, map[string]string{"index.html": "hi"})
		info, err := Unzip(root, "demo", "www/pack.zip", "", "flat")
		if err != nil {
			t.Fatal(err)
		}
		if info.Dest != "www" {
			t.Fatalf("dest=%q", info.Dest)
		}
		b, err := os.ReadFile(filepath.Join(root, "demo", "www", "index.html"))
		if err != nil || string(b) != "hi" {
			t.Fatalf("got %q err=%v", b, err)
		}
	})
}
