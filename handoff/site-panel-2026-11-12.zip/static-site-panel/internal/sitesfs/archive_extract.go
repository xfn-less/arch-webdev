package sitesfs

import (
	"archive/tar"
	"archive/zip"
	"compress/bzip2"
	"compress/gzip"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"

	"github.com/ulikunitz/xz"
)

const (
	maxArchiveEntries    = 20000
	maxArchiveTotalBytes = 512 << 20
)

// Unzip extracts an archive (zip and other supported kinds). Kept name for API compat.
func Unzip(root, site, archRel, destRel, mode string) (UnzipInfo, error) {
	return Extract(root, site, archRel, destRel, mode)
}

// Extract validates/extracts into a temp dir, then merges with atomic replacement.
// mode: "folder" | "flat" | "" (legacy auto).
func Extract(root, site, archRel, destRel, mode string) (UnzipInfo, error) {
	kind := DetectArchive(archRel)
	if kind == "" {
		return UnzipInfo{}, fmt.Errorf("unsupported archive type (use zip / tar.gz / tar.bz2 / tar.xz / tar / 7z / rar)")
	}
	abs, clean, err := Resolve(root, site, archRel)
	if err != nil {
		return UnzipInfo{}, err
	}
	parent := filepath.ToSlash(filepath.Dir(filepath.FromSlash(clean)))
	if parent == "." {
		parent = ""
	}
	baseName := archiveBaseName(clean)
	if baseName == "" {
		baseName = "unzipped"
	}

	tops, err := archiveTopLevels(kind, abs)
	if err != nil {
		return UnzipInfo{}, err
	}
	info, strip := planExtractDest(destRel, mode, parent, baseName, tops)

	destAbs, _, err := Resolve(root, site, info.Dest)
	if err != nil {
		return UnzipInfo{}, err
	}
	if err := os.MkdirAll(filepath.Dir(destAbs), 0o755); err != nil {
		return UnzipInfo{}, err
	}
	tmpAbs, err := os.MkdirTemp(filepath.Dir(destAbs), ".panel-extract-*")
	if err != nil {
		return UnzipInfo{}, err
	}
	defer os.RemoveAll(tmpAbs)

	switch kind {
	case ArchiveZIP:
		err = extractZipToTemp(abs, tmpAbs, strip)
	case ArchiveTAR, ArchiveTARGZ, ArchiveTARBZ2, ArchiveTARXZ:
		err = extractTarToTemp(kind, abs, tmpAbs, strip)
	case Archive7Z, ArchiveRAR:
		err = extractExternalToTemp(kind, abs, tmpAbs, strip)
	default:
		err = fmt.Errorf("unsupported archive type")
	}
	if err != nil {
		return UnzipInfo{}, err
	}
	if err := finalizeExtract(root, site, tmpAbs, info); err != nil {
		return UnzipInfo{}, err
	}
	return info, nil
}

func planExtractDest(destRel, mode, parent, baseName string, tops map[string]bool) (UnzipInfo, string) {
	mode = strings.ToLower(strings.TrimSpace(mode))
	info := UnzipInfo{}
	strip := ""
	switch mode {
	case "folder":
		info.Mode = "folder"
		if destRel != "" {
			info.Dest = strings.TrimPrefix(destRel, "/")
		} else {
			info.Dest = joinSiteRel(parent, baseName)
		}
	case "flat":
		info.Mode = "flat"
		if destRel != "" {
			info.Dest = strings.TrimPrefix(destRel, "/")
		} else {
			info.Dest = parent
		}
	default:
		if destRel != "" {
			info.Mode = "folder"
			info.Dest = strings.TrimPrefix(destRel, "/")
		} else if len(tops) == 1 {
			var only string
			var onlyDir bool
			for k, d := range tops {
				only, onlyDir = k, d
			}
			if onlyDir {
				info.Mode = "flat"
				info.Dest = parent
				strip = only + "/"
				info.Strip = only
			} else {
				info.Mode = "flat"
				info.Dest = parent
			}
		} else {
			info.Mode = "folder"
			info.Dest = joinSiteRel(parent, baseName)
		}
	}
	return info, strip
}

func finalizeExtract(root, site, tmpAbs string, info UnzipInfo) error {
	type move struct{ src, dst string }
	var moves []move
	var dirs []string
	err := filepath.Walk(tmpAbs, func(src string, st os.FileInfo, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		rel, err := filepath.Rel(tmpAbs, src)
		if err != nil {
			return err
		}
		if rel == "." {
			return nil
		}
		relSlash := filepath.ToSlash(rel)
		if strings.Contains(relSlash, "..") {
			return fmt.Errorf("invalid archive entry")
		}
		dst, _, err := Resolve(root, site, filepath.ToSlash(filepath.Join(info.Dest, rel)))
		if err != nil {
			return err
		}
		old, err := os.Lstat(dst)
		if err != nil && !os.IsNotExist(err) {
			return err
		}
		if err == nil && (old.IsDir() != st.IsDir() || !old.IsDir() && !old.Mode().IsRegular()) {
			return fmt.Errorf("incompatible extraction target: %s", dst)
		}
		if st.IsDir() {
			if os.IsNotExist(err) {
				dirs = append(dirs, dst)
			}
			return nil
		}
		moves = append(moves, move{src: src, dst: dst})
		return nil
	})
	if err != nil {
		return err
	}
	for _, dir := range dirs {
		if err := os.MkdirAll(dir, 0755); err != nil {
			return err
		}
	}
	for _, m := range moves {
		if err := os.Rename(m.src, m.dst); err != nil {
			// Cross-device fallback.
			if err := copyFile(m.src, m.dst, 0o644); err != nil {
				return err
			}
			_ = os.Remove(m.src)
		}
	}
	return nil
}

func safeRelName(name string) (string, error) {
	name = strings.TrimPrefix(filepath.ToSlash(name), "/")
	if name == "" || strings.Contains(name, "..") {
		return "", fmt.Errorf("invalid archive entry")
	}
	if strings.HasPrefix(name, "../") || name == ".." {
		return "", fmt.Errorf("invalid archive entry")
	}
	return name, nil
}

func applyStrip(name, strip string) (string, bool) {
	if strip == "" {
		return name, true
	}
	if name == strings.TrimSuffix(strip, "/") || name == strip {
		return "", false
	}
	if !strings.HasPrefix(name, strip) {
		return "", false
	}
	name = strings.TrimPrefix(name, strip)
	return name, name != ""
}

func extractZipToTemp(abs, tmpAbs, strip string) error {
	r, err := zip.OpenReader(abs)
	if err != nil {
		return err
	}
	defer r.Close()
	var written int64
	var nFiles int
	for _, f := range r.File {
		name, err := safeRelName(f.Name)
		if err != nil {
			return err
		}
		name, ok := applyStrip(name, strip)
		if !ok {
			continue
		}
		target := filepath.Join(tmpAbs, filepath.FromSlash(name))
		if err := guardUnder(tmpAbs, target); err != nil {
			return err
		}
		if f.FileInfo().IsDir() || strings.HasSuffix(f.Name, "/") {
			if err := os.MkdirAll(target, 0o755); err != nil {
				return err
			}
			continue
		}
		nFiles++
		if nFiles > maxArchiveEntries {
			return fmt.Errorf("archive too many files (>%d)", maxArchiveEntries)
		}
		if written+int64(f.UncompressedSize64) > maxArchiveTotalBytes {
			return fmt.Errorf("archive too large (>%d MiB uncompressed)", maxArchiveTotalBytes>>20)
		}
		if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
			return err
		}
		rc, err := f.Open()
		if err != nil {
			return err
		}
		out, err := os.OpenFile(target, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o644)
		if err != nil {
			rc.Close()
			return err
		}
		n, err := io.Copy(out, io.LimitReader(rc, maxArchiveTotalBytes-written+1))
		out.Close()
		rc.Close()
		if err != nil {
			return err
		}
		written += n
		if written > maxArchiveTotalBytes {
			return fmt.Errorf("archive too large (>%d MiB uncompressed)", maxArchiveTotalBytes>>20)
		}
	}
	return nil
}

func openTarStream(kind, abs string) (io.ReadCloser, error) {
	f, err := os.Open(abs)
	if err != nil {
		return nil, err
	}
	switch kind {
	case ArchiveTAR:
		return f, nil
	case ArchiveTARGZ:
		gz, err := gzip.NewReader(f)
		if err != nil {
			f.Close()
			return nil, err
		}
		return struct {
			io.Reader
			io.Closer
		}{Reader: gz, Closer: multiCloser{gz, f}}, nil
	case ArchiveTARBZ2:
		return struct {
			io.Reader
			io.Closer
		}{Reader: bzip2.NewReader(f), Closer: f}, nil
	case ArchiveTARXZ:
		xzr, err := xz.NewReader(f)
		if err != nil {
			f.Close()
			return nil, err
		}
		return struct {
			io.Reader
			io.Closer
		}{Reader: xzr, Closer: f}, nil
	default:
		f.Close()
		return nil, fmt.Errorf("not a tar archive")
	}
}

type multiCloser []io.Closer

func (m multiCloser) Close() error {
	var err error
	for _, c := range m {
		if e := c.Close(); e != nil && err == nil {
			err = e
		}
	}
	return err
}

func extractTarToTemp(kind, abs, tmpAbs, strip string) error {
	rc, err := openTarStream(kind, abs)
	if err != nil {
		return err
	}
	defer rc.Close()
	tr := tar.NewReader(rc)
	var written int64
	var nFiles int
	for {
		hdr, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}
		name, err := safeRelName(hdr.Name)
		if err != nil {
			return err
		}
		name, ok := applyStrip(name, strip)
		if !ok {
			continue
		}
		target := filepath.Join(tmpAbs, filepath.FromSlash(name))
		if err := guardUnder(tmpAbs, target); err != nil {
			return err
		}
		switch hdr.Typeflag {
		case tar.TypeDir:
			if err := os.MkdirAll(target, 0o755); err != nil {
				return err
			}
		case tar.TypeReg, tar.TypeRegA:
			nFiles++
			if nFiles > maxArchiveEntries {
				return fmt.Errorf("archive too many files (>%d)", maxArchiveEntries)
			}
			if hdr.Size > 0 && written+hdr.Size > maxArchiveTotalBytes {
				return fmt.Errorf("archive too large (>%d MiB uncompressed)", maxArchiveTotalBytes>>20)
			}
			if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
				return err
			}
			out, err := os.OpenFile(target, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o644)
			if err != nil {
				return err
			}
			n, err := io.Copy(out, io.LimitReader(tr, maxArchiveTotalBytes-written+1))
			out.Close()
			if err != nil {
				return err
			}
			written += n
			if written > maxArchiveTotalBytes {
				return fmt.Errorf("archive too large (>%d MiB uncompressed)", maxArchiveTotalBytes>>20)
			}
		default:
			// Skip symlinks/devices for safety.
			continue
		}
	}
	return nil
}

func extractExternalToTemp(kind, abs, tmpAbs, strip string) error {
	inner, err := os.MkdirTemp(tmpAbs, "raw-*")
	if err != nil {
		return err
	}
	switch kind {
	case Archive7Z:
		if err := run7zExtract(abs, inner); err != nil {
			return err
		}
	case ArchiveRAR:
		if err := run7zExtract(abs, inner); err != nil {
			if err2 := runUnrarExtract(abs, inner); err2 != nil {
				return fmt.Errorf("7z: %v; unrar: %w", err, err2)
			}
		}
	default:
		return fmt.Errorf("unsupported external archive")
	}
	// Re-home into tmpAbs with strip applied (and path checks).
	return filepath.Walk(inner, func(src string, st os.FileInfo, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		rel, err := filepath.Rel(inner, src)
		if err != nil {
			return err
		}
		if rel == "." {
			return nil
		}
		name, err := safeRelName(filepath.ToSlash(rel))
		if err != nil {
			return err
		}
		name, ok := applyStrip(name, strip)
		if !ok {
			return nil
		}
		dst := filepath.Join(tmpAbs, filepath.FromSlash(name))
		if err := guardUnder(tmpAbs, dst); err != nil {
			return err
		}
		if st.IsDir() {
			return os.MkdirAll(dst, 0o755)
		}
		if !st.Mode().IsRegular() {
			return nil
		}
		if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
			return err
		}
		return copyFile(src, dst, 0o644)
	})
}

func run7zExtract(abs, outDir string) error {
	bin, err := exec.LookPath("7z")
	if err != nil {
		bin, err = exec.LookPath("7za")
		if err != nil {
			return fmt.Errorf("7z not installed on panel host")
		}
	}
	cmd := exec.Command(bin, "x", "-y", "-o"+outDir, abs)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("7z extract failed: %w (%s)", err, strings.TrimSpace(string(out)))
	}
	return nil
}

func runUnrarExtract(abs, outDir string) error {
	bin, err := exec.LookPath("unrar")
	if err != nil {
		return fmt.Errorf("unrar not installed on panel host")
	}
	cmd := exec.Command(bin, "x", "-o+", abs, outDir+string(os.PathSeparator))
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("unrar extract failed: %w (%s)", err, strings.TrimSpace(string(out)))
	}
	return nil
}

func guardUnder(root, target string) error {
	rootAbs, err := filepath.Abs(root)
	if err != nil {
		return err
	}
	targetAbs, err := filepath.Abs(target)
	if err != nil {
		return err
	}
	if targetAbs != rootAbs && !strings.HasPrefix(targetAbs, rootAbs+string(os.PathSeparator)) {
		return fmt.Errorf("archive path escape")
	}
	return nil
}

func archiveTopLevels(kind, abs string) (map[string]bool, error) {
	ents, err := listArchiveEntries(kind, abs)
	if err != nil {
		return nil, err
	}
	tops := map[string]bool{}
	for _, e := range ents {
		name := strings.TrimPrefix(e.Name, "/")
		if name == "" {
			continue
		}
		parts := strings.Split(name, "/")
		top := parts[0]
		if top == "" {
			continue
		}
		isDir := e.Dir || len(parts) > 1
		if isDir {
			tops[top] = true
		} else if _, ok := tops[top]; !ok {
			tops[top] = false
		}
	}
	return tops, nil
}
