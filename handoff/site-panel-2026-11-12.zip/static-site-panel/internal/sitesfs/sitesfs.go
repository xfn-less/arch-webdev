package sitesfs

import (
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"github.com/xfn/static-site-panel/internal/confmark"
)

type Info struct {
	Name    string   `json:"name"`
	Domains []string `json:"domains"`
	Ports   []int    `json:"ports,omitempty"`
	SSL     bool     `json:"ssl"` // active cert / listen 443 — drives left-nav http(s) links
	HasWWW  bool     `json:"hasWww"`
	HasConf bool     `json:"hasConf"`
}

func List(root string) ([]Info, error) {
	entries, err := os.ReadDir(root)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	var out []Info
	for _, e := range entries {
		if !e.IsDir() || strings.HasPrefix(e.Name(), ".") {
			continue
		}
		info, err := Inspect(root, e.Name())
		if err != nil {
			continue
		}
		out = append(out, info)
	}
	return out, nil
}

func Inspect(root, name string) (Info, error) {
	info := Info{Name: name}
	www := filepath.Join(root, name, "www")
	confPath := filepath.Join(root, name, "nginx.conf")
	if st, err := os.Stat(www); err == nil && st.IsDir() {
		info.HasWWW = true
	}
	body, err := os.ReadFile(confPath)
	if err == nil {
		info.HasConf = true
		conf := string(body)
		domains, derr := confmark.Domains(conf)
		if derr == nil {
			info.Domains = domains
		}
		info.Ports = confmark.ListenPorts(conf)
		info.SSL = confmark.SSLConfigured(conf)
	}
	return info, nil
}

func ReadConf(root, name string) (string, error) {
	b, err := os.ReadFile(filepath.Join(root, name, "nginx.conf"))
	return string(b), err
}

func WriteConf(root, name, body string) error {
	return WriteFile(root, name, "nginx.conf", []byte(body))
}

func validName(name string) error {
	if name == "" || strings.Contains(name, "/") || strings.Contains(name, "..") || strings.Contains(name, "\\") {
		return fmt.Errorf("invalid site name")
	}
	return nil
}

func CreateSkeleton(root, name, template string) error {
	if err := validName(name); err != nil {
		return err
	}
	dir := filepath.Join(root, name)
	if _, err := os.Stat(dir); err == nil {
		return fmt.Errorf("site folder already exists")
	}
	www := filepath.Join(dir, "www")
	if err := os.MkdirAll(www, 0o755); err != nil {
		return err
	}
	index := filepath.Join(www, "index.html")
	if err := os.WriteFile(index, []byte("<!doctype html><meta charset=utf-8><title>"+name+"</title><h1>"+name+"</h1>\n"), 0o644); err != nil {
		return err
	}
	rootRemote := "/www/sites/" + name + "/www"
	body := strings.ReplaceAll(template, "__ROOT__", rootRemote)
	body = confmark.EnsureMarkers(body)
	return os.WriteFile(filepath.Join(dir, "nginx.conf"), []byte(body), 0o644)
}

// Copy duplicates a site directory to newName and rewrites remote root paths in nginx.conf.
// SSL is reset to a fresh-site shape so the copy can deploy without the source certs.
func Copy(root, srcName, dstName string) error {
	if err := validName(srcName); err != nil {
		return err
	}
	if err := validName(dstName); err != nil {
		return err
	}
	if srcName == dstName {
		return fmt.Errorf("new name must differ")
	}
	src := filepath.Join(root, srcName)
	dst := filepath.Join(root, dstName)
	if _, err := os.Stat(src); err != nil {
		return fmt.Errorf("source site: %w", err)
	}
	if _, err := os.Stat(dst); err == nil {
		return fmt.Errorf("site folder already exists")
	}
	if err := copyDir(src, dst); err != nil {
		_ = os.RemoveAll(dst)
		return err
	}
	// New sites have no ssl/ PEMs; drop any copied manual/LE backup so deploy
	// does not push stale certs for a site that no longer references them.
	_ = os.RemoveAll(filepath.Join(dst, "ssl"))
	confPath := filepath.Join(dst, "nginx.conf")
	body, err := os.ReadFile(confPath)
	if err != nil {
		return err
	}
	oldRoot := "/www/sites/" + srcName + "/www"
	newRoot := "/www/sites/" + dstName + "/www"
	next := strings.ReplaceAll(string(body), oldRoot, newRoot)
	next = confmark.ResetSSLToNewSite(next)
	return os.WriteFile(confPath, []byte(next), 0o644)
}

// Remove deletes the site directory on disk.
func Remove(root, name string) error {
	if err := validName(name); err != nil {
		return err
	}
	return os.RemoveAll(filepath.Join(root, name))
}

func copyDir(src, dst string) error {
	return filepath.Walk(src, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		rel, err := filepath.Rel(src, path)
		if err != nil {
			return err
		}
		target := filepath.Join(dst, rel)
		if info.IsDir() {
			return os.MkdirAll(target, info.Mode())
		}
		if info.Mode()&os.ModeSymlink != 0 {
			link, err := os.Readlink(path)
			if err != nil {
				return err
			}
			return os.Symlink(link, target)
		}
		return copyFile(path, target, info.Mode())
	})
}

func copyFile(src, dst string, mode os.FileMode) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
		return err
	}
	out, err := os.OpenFile(dst, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, mode)
	if err != nil {
		return err
	}
	_, copyErr := io.Copy(out, in)
	closeErr := out.Close()
	if copyErr != nil {
		return copyErr
	}
	return closeErr
}
