package sitesfs

import (
	"archive/tar"
	"archive/zip"
	"fmt"
	"io"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
)

// ListZip returns archive table of contents. Name kept for API compat.
func ListZip(root, site, archRel string) ([]ZipEntry, error) {
	return ListArchive(root, site, archRel)
}

// ListArchive returns sorted archive entries (dirs first).
func ListArchive(root, site, archRel string) ([]ZipEntry, error) {
	kind := DetectArchive(archRel)
	if kind == "" {
		return nil, fmt.Errorf("unsupported archive type")
	}
	abs, _, err := Resolve(root, site, archRel)
	if err != nil {
		return nil, err
	}
	return listArchiveEntries(kind, abs)
}

func listArchiveEntries(kind, abs string) ([]ZipEntry, error) {
	switch kind {
	case ArchiveZIP:
		return listZipEntries(abs)
	case ArchiveTAR, ArchiveTARGZ, ArchiveTARBZ2, ArchiveTARXZ:
		return listTarEntries(kind, abs)
	case Archive7Z, ArchiveRAR:
		return list7zEntries(abs)
	default:
		return nil, fmt.Errorf("unsupported archive type")
	}
}

func listZipEntries(abs string) ([]ZipEntry, error) {
	r, err := zip.OpenReader(abs)
	if err != nil {
		return nil, err
	}
	defer r.Close()
	seen := map[string]ZipEntry{}
	for _, f := range r.File {
		name := strings.TrimPrefix(filepath.ToSlash(f.Name), "/")
		if name == "" || strings.Contains(name, "..") {
			continue
		}
		isDir := f.FileInfo().IsDir() || strings.HasSuffix(name, "/")
		name = strings.TrimSuffix(name, "/")
		if name == "" {
			continue
		}
		for i, c := range name {
			if c == '/' {
				p := name[:i]
				if _, ok := seen[p]; !ok {
					seen[p] = ZipEntry{Name: p, Dir: true}
				}
			}
		}
		if isDir {
			seen[name] = ZipEntry{Name: name, Dir: true}
		} else {
			seen[name] = ZipEntry{Name: name, Dir: false, Size: int64(f.UncompressedSize64)}
		}
	}
	return sortZipEntries(seen), nil
}

func listTarEntries(kind, abs string) ([]ZipEntry, error) {
	rc, err := openTarStream(kind, abs)
	if err != nil {
		return nil, err
	}
	defer rc.Close()
	tr := tar.NewReader(rc)
	seen := map[string]ZipEntry{}
	for {
		hdr, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		name := strings.TrimPrefix(filepath.ToSlash(hdr.Name), "/")
		if name == "" || strings.Contains(name, "..") {
			continue
		}
		isDir := hdr.Typeflag == tar.TypeDir || strings.HasSuffix(name, "/")
		name = strings.TrimSuffix(name, "/")
		if name == "" {
			continue
		}
		for i, c := range name {
			if c == '/' {
				p := name[:i]
				if _, ok := seen[p]; !ok {
					seen[p] = ZipEntry{Name: p, Dir: true}
				}
			}
		}
		if isDir {
			seen[name] = ZipEntry{Name: name, Dir: true}
		} else if hdr.Typeflag == tar.TypeReg || hdr.Typeflag == tar.TypeRegA {
			seen[name] = ZipEntry{Name: name, Dir: false, Size: hdr.Size}
		}
	}
	return sortZipEntries(seen), nil
}

func list7zEntries(abs string) ([]ZipEntry, error) {
	bin, err := exec.LookPath("7z")
	if err != nil {
		bin, err = exec.LookPath("7za")
		if err != nil {
			return nil, fmt.Errorf("7z not installed on panel host (needed to list 7z/rar)")
		}
	}
	cmd := exec.Command(bin, "l", "-ba", "-slt", abs)
	out, err := cmd.Output()
	if err != nil {
		return nil, fmt.Errorf("7z list failed: %w", err)
	}
	seen := map[string]ZipEntry{}
	var curPath string
	var curDir bool
	var curSize int64
	flush := func() {
		if curPath == "" {
			return
		}
		name := strings.TrimPrefix(filepath.ToSlash(curPath), "/")
		if name == "" || strings.Contains(name, "..") {
			curPath, curDir, curSize = "", false, 0
			return
		}
		name = strings.TrimSuffix(name, "/")
		for i, c := range name {
			if c == '/' {
				p := name[:i]
				if _, ok := seen[p]; !ok {
					seen[p] = ZipEntry{Name: p, Dir: true}
				}
			}
		}
		if curDir {
			seen[name] = ZipEntry{Name: name, Dir: true}
		} else {
			seen[name] = ZipEntry{Name: name, Dir: false, Size: curSize}
		}
		curPath, curDir, curSize = "", false, 0
	}
	for _, line := range strings.Split(string(out), "\n") {
		line = strings.TrimRight(line, "\r")
		if line == "" {
			flush()
			continue
		}
		if strings.HasPrefix(line, "Path = ") {
			flush()
			curPath = strings.TrimPrefix(line, "Path = ")
			continue
		}
		if strings.HasPrefix(line, "Folder = ") {
			curDir = strings.EqualFold(strings.TrimPrefix(line, "Folder = "), "+")
			continue
		}
		if strings.HasPrefix(line, "Size = ") {
			fmt.Sscanf(strings.TrimPrefix(line, "Size = "), "%d", &curSize)
		}
	}
	flush()
	// 7z -slt lists the archive file itself as first Path sometimes — drop matching basename.
	base := filepath.Base(abs)
	delete(seen, base)
	return sortZipEntries(seen), nil
}

func sortZipEntries(seen map[string]ZipEntry) []ZipEntry {
	out := make([]ZipEntry, 0, len(seen))
	for _, e := range seen {
		out = append(out, e)
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Dir != out[j].Dir {
			return out[i].Dir
		}
		return out[i].Name < out[j].Name
	})
	return out
}
