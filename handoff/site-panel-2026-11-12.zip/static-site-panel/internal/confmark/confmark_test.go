package confmark

import (
	"strings"
	"testing"
)

func TestSSLConfigured(t *testing.T) {
	empty := `server {
    listen 80;
` + SSLBegin + `
    # ssl_certificate     /path/to/fullchain.pem;
    # ssl_certificate_key /path/to/privkey.pem;
` + SSLEnd + `
}`
	if SSLConfigured(empty) {
		t.Fatal("commented cert should not count")
	}
	active := `server {
    listen 80;
    listen 443 ssl http2;
` + SSLBegin + `
    ssl_certificate     /etc/letsencrypt/live/a.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/a.com/privkey.pem;
` + SSLEnd + `
}`
	if !SSLConfigured(active) {
		t.Fatal("active cert should count")
	}
}

func TestListenPorts(t *testing.T) {
	conf := `server {
    listen 80;
    # listen 8080;
    listen 443 ssl http2;
    listen 8099;
    listen *:9000;
}`
	ports := ListenPorts(conf)
	want := map[int]bool{80: true, 443: true, 8099: true, 9000: true}
	if len(ports) != 4 {
		t.Fatalf("ports=%v", ports)
	}
	for _, p := range ports {
		if !want[p] {
			t.Fatalf("unexpected %d in %v", p, ports)
		}
	}
}

func TestLegacyMarkersNormalized(t *testing.T) {
	legacy := `
server {
` + "# >>> 域名改这里" + `
    server_name a.com;
` + "# <<< 域名改这里" + `
` + "# >>> SSL改这里" + `
    ssl_certificate /c.pem;
    ssl_certificate_key /k.pem;
` + "# <<< SSL改这里" + `
}
`
	next := EnsureMarkers(legacy)
	if !strings.Contains(next, ServerNameBegin) || strings.Contains(next, "域名改这里") {
		t.Fatalf("domain markers not normalized: %s", next)
	}
	if !strings.Contains(next, SSLBegin) || strings.Contains(next, "SSL改这里") {
		t.Fatalf("ssl markers not normalized: %s", next)
	}
	domains, err := Domains(next)
	if err != nil || len(domains) != 1 || domains[0] != "a.com" {
		t.Fatalf("domains=%v err=%v", domains, err)
	}
	if !SSLConfigured(next) {
		t.Fatal("ssl should still count after normalize")
	}
}

func TestHTTPSRedirectOnlyWhenSSL(t *testing.T) {
	base := `server {
    listen 80;
` + ServerNameBegin + `
    server_name a.com;
` + ServerNameEnd + `
` + SSLBegin + `
    # ssl_certificate     /path/to/fullchain.pem;
    # ssl_certificate_key /path/to/privkey.pem;
` + SSLEnd + `
    location ^~ /.well-known/acme-challenge/ {
        root /www;
        default_type text/plain;
    }
    location / { try_files $uri =404; }
}
`
	if strings.Contains(EnsureHTTPSRedirect(base), HTTPSRedirectBegin) {
		t.Fatal("no redirect without active cert")
	}
	withSSL, err := ApplyIssuedSSL(base, "a.com")
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(withSSL, HTTPSRedirectBegin) || !strings.Contains(withSSL, "return 301 https://") {
		t.Fatalf("expected redirect after SSL: %s", withSSL)
	}
	if !strings.Contains(withSSL, `$server_port != 80`) {
		t.Fatal("redirect must skip non-80 ports")
	}
	if !strings.Contains(withSSL, "acme-challenge") {
		t.Fatal("ACME exclusion missing")
	}
	// idempotent refresh
	again := EnsureHTTPSRedirect(withSSL)
	if strings.Count(again, HTTPSRedirectBegin) != 1 {
		t.Fatalf("duplicate redirect blocks: %d", strings.Count(again, HTTPSRedirectBegin))
	}
	stripped := StripHTTPSRedirect(withSSL)
	if strings.Contains(stripped, HTTPSRedirectBegin) || strings.Contains(stripped, "panel_https_redirect") {
		t.Fatal("strip failed")
	}
}

func TestResetSSLToNewSite(t *testing.T) {
	base := `
server {
    listen 80;
    listen 443 ssl http2;
` + ServerNameBegin + `
    server_name a.com;
` + ServerNameEnd + `
` + SSLBegin + `
    ssl_certificate /etc/letsencrypt/live/a.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/a.com/privkey.pem;
` + SSLEnd + `
    location /proxy { proxy_pass http://127.0.0.1:8080; }
}
`
	got := ResetSSLToNewSite(EnsureHTTPSRedirect(base))
	if SSLConfigured(got) {
		t.Fatal("SSL should look unconfigured", got)
	}
	if strings.Contains(got, HTTPSRedirectBegin) {
		t.Fatal("redirect should be removed")
	}
	if !strings.Contains(got, "location /proxy") || !strings.Contains(got, "server_name a.com") {
		t.Fatal(got)
	}
	body, ok := SSLBody(got)
	if !ok || !strings.Contains(body, "/path/to/fullchain.pem") {
		t.Fatalf("want new-site placeholder SSL block: %q", body)
	}
	for _, line := range strings.Split(got, "\n") {
		trim := strings.TrimSpace(line)
		if strings.HasPrefix(trim, "listen ") && strings.Contains(trim, "443") {
			t.Fatal("listen 443 should be commented", got)
		}
	}
}

func TestPauseTLSServingKeepsCustomLocations(t *testing.T) {
	base := `
server {
    listen 80;
    listen 443 ssl http2;
` + ServerNameBegin + `
    server_name a.com;
` + ServerNameEnd + `
` + SSLBegin + `
    ssl_certificate /etc/letsencrypt/live/a.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/a.com/privkey.pem;
` + SSLEnd + `
    location /proxy { proxy_pass http://127.0.0.1:8080; }
}
`
	withRedirect := EnsureHTTPSRedirect(base)
	got := PauseTLSServing(withRedirect)
	if strings.Contains(got, HTTPSRedirectBegin) {
		t.Fatal("redirect should be removed")
	}
	if !strings.Contains(got, "location /proxy") {
		t.Fatal(got)
	}
	if body, ok := SSLBody(got); !ok || strings.Contains(body, "ssl_certificate") {
		t.Fatalf("ssl body should be cleared: %q", body)
	}
	for _, line := range strings.Split(got, "\n") {
		trim := strings.TrimSpace(line)
		if strings.HasPrefix(trim, "listen ") && strings.Contains(trim, "443") {
			t.Fatal("listen 443 should be commented", got)
		}
	}
}

func TestEnsureListen80ForDomains(t *testing.T) {
	no80 := `
server {
` + ServerNameBegin + `
    server_name
        a.example
        ;
` + ServerNameEnd + `
    listen 10000;
}
`
	got := EnsureListen80ForDomains(no80)
	if !HasListen80(got) {
		t.Fatalf("expected listen 80, got:\n%s", got)
	}
	if !strings.Contains(got, "listen 10000") {
		t.Fatal("custom port lost")
	}
	commented := `
server {
    # listen 80;
    listen 10000;
` + ServerNameBegin + `
    server_name a.example;
` + ServerNameEnd + `
}
`
	got = EnsureListen80ForDomains(commented)
	ports := ListenPorts(got)
	if len(ports) < 2 || !HasListen80(got) {
		t.Fatalf("ports=%v conf=\n%s", ports, got)
	}
	empty := `
server {
    listen 10000;
` + ServerNameBegin + `
    # server_name example.com;
` + ServerNameEnd + `
}
`
	if EnsureListen80ForDomains(empty) != empty {
		t.Fatal("no domains should not add listen 80")
	}
	next, err := SetDomains(empty, []string{"b.example"})
	if err != nil {
		t.Fatal(err)
	}
	if !HasListen80(next) {
		t.Fatalf("SetDomains should add listen 80:\n%s", next)
	}
}

func TestDomainsStripsInlineComments(t *testing.T) {
	conf := `
server {
    listen 80;
` + ServerNameBegin + `
    server_name
        ddie.aypzqgm.cn
        dzjf.aypzqgm.cn #还没发
        dzgh.aypzqgm.cn;
` + ServerNameEnd + `
}
`
	domains, err := Domains(conf)
	if err != nil {
		t.Fatal(err)
	}
	want := []string{"ddie.aypzqgm.cn", "dzjf.aypzqgm.cn", "dzgh.aypzqgm.cn"}
	if len(domains) != len(want) {
		t.Fatalf("got %#v", domains)
	}
	for i, h := range want {
		if domains[i] != h {
			t.Fatalf("got %#v", domains)
		}
	}
	oneLine := `
server {
` + ServerNameBegin + `
    server_name ddie.aypzqgm.cn dzjf.aypzqgm.cn; #还没发
` + ServerNameEnd + `
}
`
	domains, err = Domains(oneLine)
	if err != nil || len(domains) != 2 || domains[0] != "ddie.aypzqgm.cn" || domains[1] != "dzjf.aypzqgm.cn" {
		t.Fatalf("trailing comment domains=%#v err=%v", domains, err)
	}
}

func TestDomainsRoundTrip(t *testing.T) {
	conf := `
server {
    listen 80;
` + ServerNameBegin + `
    server_name a.com www.a.com;
` + ServerNameEnd + `
` + SSLBegin + `
` + SSLEnd + `
    root /var/www;
}
`
	domains, err := Domains(conf)
	if err != nil {
		t.Fatal(err)
	}
	if len(domains) != 2 || domains[0] != "a.com" || domains[1] != "www.a.com" {
		t.Fatalf("got %#v", domains)
	}
	next, err := SetDomains(conf, []string{"b.com"})
	if err != nil {
		t.Fatal(err)
	}
	domains, err = Domains(next)
	if err != nil {
		t.Fatal(err)
	}
	if len(domains) != 1 || domains[0] != "b.com" {
		t.Fatalf("got %#v", domains)
	}
	if !hasBlock(next, SSLBegin, SSLEnd) {
		t.Fatal("ssl markers lost")
	}
	if !strings.Contains(next, "    server_name\n        b.com\n        ;\n") {
		t.Fatalf("single domain should remain readable: %s", next)
	}

	multiline := strings.Replace(conf, "server_name a.com www.a.com;", "server_name a.com\n        www.a.com;", 1)
	domains, err = Domains(multiline)
	if err != nil || len(domains) != 2 || domains[0] != "a.com" || domains[1] != "www.a.com" {
		t.Fatalf("multiline domains=%#v err=%v", domains, err)
	}

	next, err = SetDomains(multiline, []string{"a.com", "www.a.com", "cdn.a.com"})
	if err != nil {
		t.Fatal(err)
	}
	want := "    server_name\n        a.com\n        www.a.com\n        cdn.a.com\n        ;\n"
	if !strings.Contains(next, want) {
		t.Fatalf("SetDomains did not put each hostname and final semicolon on its own line:\n%s", next)
	}
	wrapped, err := SetDomains(multiline, []string{"a.com", "www.a.com", "cdn.a.com", "static.a.com"})
	if err != nil {
		t.Fatal(err)
	}
	want = "    server_name\n        a.com\n        www.a.com\n        cdn.a.com\n        static.a.com\n        ;\n"
	if !strings.Contains(wrapped, want) {
		t.Fatalf("SetDomains did not wrap after three hostnames:\n%s", wrapped)
	}
}
