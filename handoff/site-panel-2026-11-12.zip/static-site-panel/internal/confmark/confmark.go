package confmark

import (
	"fmt"
	"regexp"
	"strings"
)

const (
	ServerNameBegin = "# >>> 域名"
	ServerNameEnd   = "# <<< 域名"
	SSLBegin        = "# >>> SSL（面板自动生成，勿手改）"
	SSLEnd          = "# <<< SSL"
	// HTTPSRedirect* wraps rewrite rules that send :80 HTTP → HTTPS once a cert exists.
	// ACME on :80 and non-80 listen ports are left alone.
	HTTPSRedirectBegin = "# >>> HTTP→HTTPS（有证书时由面板生成，勿手改）"
	HTTPSRedirectEnd   = "# <<< HTTP→HTTPS"
)

// httpsRedirectSnippet only redirects plain HTTP on port 80 (keeps ACME + custom ports).
const httpsRedirectSnippet = `    ` + HTTPSRedirectBegin + `
    set $panel_https_redirect 0;
    if ($scheme = http) { set $panel_https_redirect 1; }
    if ($server_port != 80) { set $panel_https_redirect 0; }
    if ($request_uri ~* "^/.well-known/acme-challenge/") { set $panel_https_redirect 0; }
    if ($panel_https_redirect = 1) { return 301 https://$host$request_uri; }
    ` + HTTPSRedirectEnd + `
`

// Older marker wording still accepted so existing site conf keeps working.
var (
	domainMarkerAliases = [][2]string{
		{ServerNameBegin, ServerNameEnd},
		{"# >>> 域名改这里", "# <<< 域名改这里"},
	}
	sslMarkerAliases = [][2]string{
		{SSLBegin, SSLEnd},
		{"# >>> SSL改这里", "# <<< SSL改这里"},
	}
	serverNameLine = regexp.MustCompile(`(?is)^\s*server_name\s+(.+?)\s*;\s*$`)
	listenLine     = regexp.MustCompile(`(?i)^\s*listen\s+([^;]+);`)
	portInListen   = regexp.MustCompile(`(?:^|:)(\d+)\b`)
)

// stripInlineComment drops nginx-style `# …` tails (full-line comments become empty).
func stripInlineComment(line string) string {
	if i := strings.IndexByte(line, '#'); i >= 0 {
		return strings.TrimSpace(line[:i])
	}
	return line
}

func domainBounds(conf string) (begin, end string, ok bool) {
	for _, p := range domainMarkerAliases {
		if hasBlock(conf, p[0], p[1]) {
			return p[0], p[1], true
		}
	}
	return "", "", false
}

func sslBounds(conf string) (begin, end string, ok bool) {
	for _, p := range sslMarkerAliases {
		if hasBlock(conf, p[0], p[1]) {
			return p[0], p[1], true
		}
	}
	return "", "", false
}

// normalizeMarkers rewrites legacy marker labels to the current wording.
func normalizeMarkers(conf string) string {
	out := conf
	for _, p := range domainMarkerAliases[1:] {
		out = strings.ReplaceAll(out, p[0], ServerNameBegin)
		out = strings.ReplaceAll(out, p[1], ServerNameEnd)
	}
	for _, p := range sslMarkerAliases[1:] {
		out = strings.ReplaceAll(out, p[0], SSLBegin)
		out = strings.ReplaceAll(out, p[1], SSLEnd)
	}
	return out
}

// Domains reads hostnames from the panel domain block (duplicates dropped).
func Domains(conf string) ([]string, error) {
	hosts, _, err := parseDomainHosts(conf)
	return hosts, err
}

// DuplicateDomains returns hostnames that appear more than once in the panel
// domain block (case-insensitive). Empty if none or markers missing.
func DuplicateDomains(conf string) ([]string, error) {
	_, dups, err := parseDomainHosts(conf)
	return dups, err
}

func parseDomainHosts(conf string) (unique, dups []string, err error) {
	begin, end, ok := domainBounds(conf)
	if !ok {
		return nil, nil, fmt.Errorf("missing panel domain markers")
	}
	body, _ := blockBody(conf, begin, end)
	seen := map[string]string{} // lower → first spelling
	dupSeen := map[string]struct{}{}
	var directive strings.Builder
	readingServerName := false
	for _, line := range strings.Split(body, "\n") {
		line = stripInlineComment(strings.TrimSpace(line))
		if line == "" {
			continue
		}
		if !readingServerName {
			fields := strings.Fields(line)
			if len(fields) == 0 || !strings.EqualFold(fields[0], "server_name") {
				continue
			}
			directive.Reset()
			readingServerName = true
		}
		directive.WriteByte(' ')
		directive.WriteString(line)
		if !strings.Contains(line, ";") {
			continue
		}
		readingServerName = false
		m := serverNameLine.FindStringSubmatch(directive.String())
		if m == nil {
			continue
		}
		for _, part := range strings.Fields(m[1]) {
			host := strings.TrimSpace(part)
			if host == "" || host == "_" || strings.HasPrefix(host, "#") {
				continue
			}
			key := strings.ToLower(host)
			if first, exists := seen[key]; exists {
				if _, listed := dupSeen[key]; !listed {
					dupSeen[key] = struct{}{}
					dups = append(dups, first)
				}
				continue
			}
			seen[key] = host
			unique = append(unique, host)
		}
	}
	return unique, dups, nil
}

// ListenPorts returns unique ports from uncommented listen directives.
func ListenPorts(conf string) []int {
	seen := map[int]struct{}{}
	var out []int
	for _, line := range strings.Split(conf, "\n") {
		trim := strings.TrimSpace(line)
		if trim == "" || strings.HasPrefix(trim, "#") {
			continue
		}
		m := listenLine.FindStringSubmatch(line)
		if m == nil {
			continue
		}
		pm := portInListen.FindStringSubmatch(m[1])
		if pm == nil {
			continue
		}
		var p int
		if _, err := fmt.Sscanf(pm[1], "%d", &p); err != nil || p <= 0 || p > 65535 {
			continue
		}
		if _, ok := seen[p]; ok {
			continue
		}
		seen[p] = struct{}{}
		out = append(out, p)
	}
	return out
}

// SetDomains rewrites the panel domain block. Other content is preserved.
func SetDomains(conf string, domains []string) (string, error) {
	conf = EnsureMarkers(conf)
	begin, end, ok := domainBounds(conf)
	if !ok {
		return "", fmt.Errorf("missing panel domain markers")
	}
	clean := make([]string, 0, len(domains))
	seen := map[string]struct{}{}
	for _, d := range domains {
		d = strings.TrimSpace(d)
		if d == "" {
			continue
		}
		if _, dup := seen[d]; dup {
			continue
		}
		seen[d] = struct{}{}
		clean = append(clean, d)
	}
	var body string
	body = "    # server_name 可换行写域名，最后单独一行写分号：\n"
	if len(clean) == 0 {
		body += "    # server_name\n    #     example.com\n    #     www.example.com\n    #     ;\n"
	} else {
		body += "    server_name\n"
		for _, d := range clean {
			body += "        " + d + "\n"
		}
		body += "        ;\n"
	}
	return EnsureListen80ForDomains(replaceBlock(conf, begin, end, body)), nil
}

// HasListen80 reports an active (uncommented) listen …80….
func HasListen80(conf string) bool {
	for _, p := range ListenPorts(conf) {
		if p == 80 {
			return true
		}
	}
	return false
}

// EnsureListen80ForDomains adds listen 80 when the domain block has hostnames
// but conf does not yet listen on 80 (uncomment existing # listen 80 if present).
func EnsureListen80ForDomains(conf string) string {
	domains, err := Domains(conf)
	if err != nil || len(domains) == 0 {
		return conf
	}
	if HasListen80(conf) {
		return conf
	}
	return enableListen80(conf)
}

func enableListen80(conf string) string {
	lines := strings.Split(conf, "\n")
	for i, line := range lines {
		trim := strings.TrimSpace(line)
		if !strings.HasPrefix(trim, "#") {
			continue
		}
		un := strings.TrimSpace(strings.TrimPrefix(trim, "#"))
		m := listenLine.FindStringSubmatch(un)
		if m == nil {
			continue
		}
		pm := portInListen.FindStringSubmatch(m[1])
		if pm == nil || pm[1] != "80" {
			continue
		}
		indent := line[:len(line)-len(strings.TrimLeft(line, " \t"))]
		lines[i] = indent + un
		return strings.Join(lines, "\n")
	}
	out := make([]string, 0, len(lines)+1)
	inserted := false
	for _, line := range lines {
		out = append(out, line)
		if inserted {
			continue
		}
		trim := strings.TrimSpace(line)
		if strings.HasPrefix(trim, "server {") || trim == "server{" {
			out = append(out, "    listen 80;")
			inserted = true
		}
	}
	if !inserted {
		return conf + "\n    listen 80;\n"
	}
	return strings.Join(out, "\n")
}

// SetSSLBody replaces panel SSL block inner body (including indentation/newlines as given).
func SetSSLBody(conf, sslBody string) (string, error) {
	conf = EnsureMarkers(conf)
	begin, end, ok := sslBounds(conf)
	if !ok {
		return "", fmt.Errorf("missing panel SSL markers")
	}
	if !strings.HasSuffix(sslBody, "\n") && sslBody != "" {
		sslBody += "\n"
	}
	return replaceBlock(conf, begin, end, sslBody), nil
}

// SSLBody returns the inner panel SSL block.
func SSLBody(conf string) (string, bool) {
	begin, end, ok := sslBounds(conf)
	if !ok {
		return "", false
	}
	return blockBody(conf, begin, end)
}

// SSLConfigured reports whether conf already has an active certificate
// (uncommented ssl_certificate) or listen 443.
func SSLConfigured(conf string) bool {
	if body, ok := SSLBody(conf); ok {
		for _, line := range strings.Split(body, "\n") {
			trim := strings.TrimSpace(line)
			if trim == "" || strings.HasPrefix(trim, "#") {
				continue
			}
			low := strings.ToLower(trim)
			if strings.HasPrefix(low, "ssl_certificate") && !strings.HasPrefix(low, "ssl_certificate_key") {
				return true
			}
		}
	}
	for _, p := range ListenPorts(conf) {
		if p == 443 {
			return true
		}
	}
	return false
}

// ApplyIssuedSSL writes Let's Encrypt certificate paths into the SSL block and enables listen 443.
func ApplyIssuedSSL(conf, primaryDomain string) (string, error) {
	return ApplyIssuedSSLPaths(conf,
		"/etc/letsencrypt/live/"+primaryDomain+"/fullchain.pem",
		"/etc/letsencrypt/live/"+primaryDomain+"/privkey.pem",
	)
}

// ApplyIssuedSSLPaths writes explicit certificate paths into the SSL block and enables listen 443.
func ApplyIssuedSSLPaths(conf, certPath, keyPath string) (string, error) {
	conf = EnsureMarkers(conf)
	body := fmt.Sprintf(
		"    ssl_certificate     %s;\n"+
			"    ssl_certificate_key %s;\n"+
			"    ssl_session_timeout 1d;\n"+
			"    ssl_session_cache shared:MozSSL:10m;\n"+
			"    ssl_protocols TLSv1.2 TLSv1.3;\n",
		certPath, keyPath,
	)
	next, err := SetSSLBody(conf, body)
	if err != nil {
		return "", err
	}
	next = EnsureListen80ForDomains(next)
	return EnsureHTTPSRedirect(EnableListen443(next)), nil
}

// EnsureHTTPSRedirect inserts (or refreshes) the panel HTTP→HTTPS block.
// No-op when SSL is not configured — sites without a cert keep working on HTTP.
func EnsureHTTPSRedirect(conf string) string {
	conf = StripHTTPSRedirect(conf)
	if !SSLConfigured(conf) {
		return conf
	}
	if i := strings.Index(conf, "location ^~ /.well-known/acme-challenge/"); i >= 0 {
		// Insert after the ACME location block's closing brace.
		rest := conf[i:]
		depth := 0
		endRel := -1
		for j := 0; j < len(rest); j++ {
			switch rest[j] {
			case '{':
				depth++
			case '}':
				depth--
				if depth == 0 {
					endRel = j
				}
			}
			if endRel >= 0 {
				break
			}
		}
		if endRel >= 0 {
			at := i + endRel + 1
			return conf[:at] + "\n" + httpsRedirectSnippet + conf[at:]
		}
	}
	idx := strings.LastIndex(conf, "}")
	if idx < 0 {
		return conf + "\n" + httpsRedirectSnippet
	}
	return conf[:idx] + httpsRedirectSnippet + conf[idx:]
}

// StripHTTPSRedirect removes the panel HTTP→HTTPS marker block if present.
func StripHTTPSRedirect(conf string) string {
	begin := HTTPSRedirectBegin
	end := HTTPSRedirectEnd
	bi := strings.Index(conf, begin)
	if bi < 0 {
		return conf
	}
	ei := strings.Index(conf[bi:], end)
	if ei < 0 {
		return conf
	}
	ei = bi + ei + len(end)
	// drop surrounding newlines cleanly
	for bi > 0 && (conf[bi-1] == '\n' || conf[bi-1] == '\r') {
		bi--
	}
	for ei < len(conf) && (conf[ei] == '\n' || conf[ei] == '\r') {
		ei++
	}
	return conf[:bi] + "\n" + conf[ei:]
}

// ResetSSLToNewSite restores SSL-related bits to the same shape as a fresh
// site template: no active 443, placeholder SSL block, no HTTP→HTTPS redirect.
// Domains, locations, and other custom config are left alone.
func ResetSSLToNewSite(conf string) string {
	conf = PauseTLSServing(EnsureMarkers(conf))
	placeholder := "    # ssl_certificate     /path/to/fullchain.pem;\n" +
		"    # ssl_certificate_key /path/to/privkey.pem;\n"
	if next, err := SetSSLBody(conf, placeholder); err == nil {
		conf = next
	}
	return conf
}

// PauseTLSServing comments out listen 443 and clears the panel SSL block so
// nginx can load while ACME runs on HTTP. Custom locations / proxy stay intact.
// Callers must restore a full HTTPS conf after issuance (or on failure).
func PauseTLSServing(conf string) string {
	conf = StripHTTPSRedirect(conf)
	if next, err := SetSSLBody(EnsureMarkers(conf), ""); err == nil {
		conf = next
	}
	lines := strings.Split(conf, "\n")
	for i, line := range lines {
		trim := strings.TrimSpace(line)
		if strings.HasPrefix(trim, "#") {
			continue
		}
		if strings.HasPrefix(trim, "listen ") && strings.Contains(trim, "443") {
			indent := line[:len(line)-len(strings.TrimLeft(line, " \t"))]
			lines[i] = indent + "# " + trim
		}
	}
	return strings.Join(lines, "\n")
}

// EnableListen443 uncomment/adds listen 443 ssl http2.
func EnableListen443(conf string) string {
	lines := strings.Split(conf, "\n")
	has443 := false
	for i, line := range lines {
		trim := strings.TrimSpace(line)
		if strings.HasPrefix(trim, "listen ") && strings.Contains(trim, "443") {
			has443 = true
			break
		}
		if strings.HasPrefix(trim, "#") && strings.Contains(trim, "listen") && strings.Contains(trim, "443") {
			// uncomment
			un := strings.TrimSpace(strings.TrimPrefix(trim, "#"))
			indent := line[:len(line)-len(strings.TrimLeft(line, " \t"))]
			lines[i] = indent + un
			has443 = true
			break
		}
	}
	if has443 {
		return strings.Join(lines, "\n")
	}
	out := make([]string, 0, len(lines)+1)
	inserted := false
	for _, line := range lines {
		out = append(out, line)
		trim := strings.TrimSpace(line)
		if !inserted && strings.HasPrefix(trim, "listen ") && strings.Contains(trim, "80") {
			indent := line[:len(line)-len(strings.TrimLeft(line, " \t"))]
			out = append(out, indent+"listen 443 ssl http2;")
			inserted = true
		}
	}
	if !inserted {
		return conf + "\n    listen 443 ssl http2;\n"
	}
	return strings.Join(out, "\n")
}

// EnsureACMEChallenge inserts a webroot ACME location if missing.
func EnsureACMEChallenge(conf, wwwRoot string) string {
	if strings.Contains(conf, ".well-known/acme-challenge") {
		return conf
	}
	snippet := fmt.Sprintf(`
    location ^~ /.well-known/acme-challenge/ {
        root %s;
        default_type text/plain;
    }
`, wwwRoot)
	// insert before last closing brace of file (end of server block)
	idx := strings.LastIndex(conf, "}")
	if idx < 0 {
		return conf + snippet
	}
	return conf[:idx] + snippet + conf[idx:]
}

func EnsureMarkers(conf string) string {
	out := normalizeMarkers(conf)
	if _, _, ok := domainBounds(out); !ok {
		out += "\n" + ServerNameBegin + "\n    # server_name 可换行写域名，最后单独一行写分号：\n    # server_name\n    #     example.com\n    #     www.example.com\n    #     ;\n" + ServerNameEnd + "\n"
	}
	if _, _, ok := sslBounds(out); !ok {
		out += "\n" + SSLBegin + "\n" + SSLEnd + "\n"
	}
	return out
}

func hasBlock(conf, begin, end string) bool {
	_, ok := blockBody(conf, begin, end)
	return ok
}

func blockBody(conf, begin, end string) (string, bool) {
	i := strings.Index(conf, begin)
	if i < 0 {
		return "", false
	}
	start := i + len(begin)
	// skip newline after begin
	if start < len(conf) && conf[start] == '\r' {
		start++
	}
	if start < len(conf) && conf[start] == '\n' {
		start++
	}
	j := strings.Index(conf[start:], end)
	if j < 0 {
		return "", false
	}
	return conf[start : start+j], true
}

func replaceBlock(conf, begin, end, body string) string {
	i := strings.Index(conf, begin)
	if i < 0 {
		return conf
	}
	startContent := i + len(begin)
	if startContent < len(conf) && conf[startContent] == '\r' {
		startContent++
	}
	if startContent < len(conf) && conf[startContent] == '\n' {
		startContent++
	}
	jRel := strings.Index(conf[startContent:], end)
	if jRel < 0 {
		return conf
	}
	endIdx := startContent + jRel
	lineStart := endIdx
	for lineStart > 0 && conf[lineStart-1] != '\n' {
		lineStart--
	}
	return conf[:i] + begin + "\n" + body + conf[lineStart:endIdx] + end + conf[endIdx+len(end):]
}
