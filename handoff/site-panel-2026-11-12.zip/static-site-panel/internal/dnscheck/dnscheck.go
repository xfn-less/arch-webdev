package dnscheck

import (
	"context"
	"net"
	"strings"
	"time"
)

type Item struct {
	Domain   string   `json:"domain"`
	Expected string   `json:"expected"`
	Actual   []string `json:"actual"`
	OK       bool     `json:"ok"`
	Error    string   `json:"error,omitempty"`
}

func CheckDomains(ctx context.Context, domains []string, expectIP string) []Item {
	expectIP = strings.TrimSpace(expectIP)
	out := make([]Item, 0, len(domains))
	for _, d := range domains {
		d = strings.TrimSpace(d)
		if d == "" {
			continue
		}
		out = append(out, CheckOne(ctx, d, expectIP))
	}
	return out
}

func CheckOne(ctx context.Context, domain, expectIP string) Item {
	item := Item{Domain: domain, Expected: expectIP}
	// server_name may include the machine IP; that is not a DNS name to resolve.
	if ip := net.ParseIP(domain); ip != nil {
		item.Actual = []string{ip.String()}
		item.OK = expectIP != "" && ip.String() == expectIP
		if !item.OK && expectIP != "" {
			item.Error = "IP 字面量不是域名"
		}
		return item
	}
	if expectIP == "" {
		item.Error = "目标机未填公网 IP"
		return item
	}
	r := &net.Resolver{}
	cctx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()
	ips, err := r.LookupIPAddr(cctx, domain)
	if err != nil {
		item.Error = err.Error()
		return item
	}
	seen := map[string]struct{}{}
	for _, ip := range ips {
		s := ip.IP.String()
		if _, ok := seen[s]; ok {
			continue
		}
		seen[s] = struct{}{}
		item.Actual = append(item.Actual, s)
		if s == expectIP {
			item.OK = true
		}
	}
	if len(item.Actual) == 0 {
		item.Error = "无 A/AAAA 记录"
	}
	return item
}
