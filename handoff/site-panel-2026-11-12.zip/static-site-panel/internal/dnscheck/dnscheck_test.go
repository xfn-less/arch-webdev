package dnscheck

import (
	"context"
	"testing"
)

func TestCheckOneIPLiteral(t *testing.T) {
	item := CheckOne(context.Background(), "103.236.63.214", "103.236.63.214")
	if !item.OK || len(item.Actual) != 1 || item.Actual[0] != "103.236.63.214" {
		t.Fatalf("same IP should be ok: %+v", item)
	}
	bad := CheckOne(context.Background(), "103.236.63.214", "1.2.3.4")
	if bad.OK {
		t.Fatalf("mismatched IP must fail: %+v", bad)
	}
}
