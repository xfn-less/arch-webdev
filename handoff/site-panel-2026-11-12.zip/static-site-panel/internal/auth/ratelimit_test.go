package auth

import (
	"testing"
	"time"
)

func TestRateLimitNeedsConfirmAfterFiveFails(t *testing.T) {
	r := NewRateLimiter(5, 10*time.Minute)
	key := "1.2.3.4"
	for i := 0; i < 5; i++ {
		if !r.Allow(key) {
			t.Fatalf("blocked too early at %d", i)
		}
		r.Fail(key)
	}
	if r.Allow(key) {
		t.Fatal("expected block after 5 fails")
	}
	r.Confirm(key)
	if !r.Allow(key) {
		t.Fatal("confirm should unlock one try")
	}
	// busy-style: no Fail → credit still usable for kick
	if !r.Allow(key) {
		t.Fatal("credit should remain until Fail or Clear")
	}
	r.Fail(key)
	if r.Allow(key) {
		t.Fatal("failed confirm try should re-block")
	}
}

func TestCaptchaCheckReusableUntilConsume(t *testing.T) {
	store := NewCaptchaStore()
	issue, err := store.Issue()
	if err != nil {
		t.Fatal(err)
	}
	// difficulty 0 via direct entry for speed
	store.byID[issue.ID].difficulty = 0
	if err := store.Check(issue.ID, 0); err != nil {
		t.Fatal(err)
	}
	if err := store.Check(issue.ID, 0); err != nil {
		t.Fatal(err)
	}
	if err := store.Consume(issue.ID, 0); err != nil {
		t.Fatal(err)
	}
	if err := store.Check(issue.ID, 0); err == nil {
		t.Fatal("expected consumed proof rejected")
	}
}
