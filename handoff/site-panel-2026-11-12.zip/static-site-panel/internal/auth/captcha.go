package auth

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"strconv"
	"sync"
	"time"
)

const (
	captchaDifficulty = 3 // lightweight browser proof (~4096 tries avg), including iOS
	captchaTTL        = 2 * time.Minute
)

var ErrBadCaptcha = errors.New("bad captcha")

type CaptchaIssue struct {
	ID         string `json:"id"`
	Challenge  string `json:"challenge"`
	Difficulty int    `json:"difficulty"`
}

type captchaEntry struct {
	challenge  string
	difficulty int
	expires    time.Time
	used       bool
}

type CaptchaStore struct {
	mu   sync.Mutex
	byID map[string]*captchaEntry
}

func NewCaptchaStore() *CaptchaStore {
	return &CaptchaStore{byID: map[string]*captchaEntry{}}
}

func (s *CaptchaStore) Issue() (CaptchaIssue, error) {
	s.sweepLocked()
	raw := make([]byte, 16)
	if _, err := rand.Read(raw); err != nil {
		return CaptchaIssue{}, err
	}
	idRaw := make([]byte, 12)
	if _, err := rand.Read(idRaw); err != nil {
		return CaptchaIssue{}, err
	}
	id := hex.EncodeToString(idRaw)
	ch := hex.EncodeToString(raw)
	s.mu.Lock()
	s.byID[id] = &captchaEntry{
		challenge:  ch,
		difficulty: captchaDifficulty,
		expires:    time.Now().Add(captchaTTL),
	}
	s.mu.Unlock()
	return CaptchaIssue{ID: id, Challenge: ch, Difficulty: captchaDifficulty}, nil
}

// Check validates the proof without consuming it (so a busy→kick retry can reuse it).
func (s *CaptchaStore) Check(id string, nonce int64) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.checkLocked(id, nonce)
}

func (s *CaptchaStore) Consume(id string, nonce int64) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := s.checkLocked(id, nonce); err != nil {
		return err
	}
	e := s.byID[id]
	e.used = true
	delete(s.byID, id)
	return nil
}

func (s *CaptchaStore) checkLocked(id string, nonce int64) error {
	e := s.byID[id]
	if e == nil || e.used || time.Now().After(e.expires) {
		return ErrBadCaptcha
	}
	sum := sha256.Sum256([]byte(e.challenge + strconv.FormatInt(nonce, 10)))
	if !hasLeadingZeroNibbles(sum[:], e.difficulty) {
		return ErrBadCaptcha
	}
	return nil
}

func hasLeadingZeroNibbles(hash []byte, n int) bool {
	for i := 0; i < n; i++ {
		b := hash[i/2]
		var nib byte
		if i%2 == 0 {
			nib = b >> 4
		} else {
			nib = b & 0x0f
		}
		if nib != 0 {
			return false
		}
	}
	return true
}

func (s *CaptchaStore) sweepLocked() {
	s.mu.Lock()
	defer s.mu.Unlock()
	now := time.Now()
	for id, e := range s.byID {
		if e.used || now.After(e.expires) {
			delete(s.byID, id)
		}
	}
}
