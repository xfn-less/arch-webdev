package auth

import (
	"crypto/sha256"
	"errors"
	"strconv"
	"testing"
	"time"
)

func TestCaptchaProofAndSingleUse(t *testing.T) {
	store := NewCaptchaStore()
	issue, err := store.Issue()
	if err != nil {
		t.Fatal(err)
	}
	if issue.Difficulty != 3 {
		t.Fatalf("unexpected mobile proof cost: %d", issue.Difficulty)
	}
	var valid, invalid int64
	foundInvalid := false
	for nonce := int64(0); ; nonce++ {
		sum := sha256.Sum256([]byte(issue.Challenge + strconv.FormatInt(nonce, 10)))
		if hasLeadingZeroNibbles(sum[:], issue.Difficulty) {
			valid = nonce
			break
		}
		invalid = nonce
		foundInvalid = true
	}
	if foundInvalid {
		if err := store.Consume(issue.ID, invalid); !errors.Is(err, ErrBadCaptcha) {
			t.Fatalf("invalid proof accepted: %v", err)
		}
	}
	if err := store.Consume(issue.ID, valid); err != nil {
		t.Fatal(err)
	}
	if err := store.Consume(issue.ID, valid); !errors.Is(err, ErrBadCaptcha) {
		t.Fatalf("reused proof accepted: %v", err)
	}
}

func TestExpiredCaptchaRejected(t *testing.T) {
	store := NewCaptchaStore()
	store.byID["expired"] = &captchaEntry{challenge: "challenge", difficulty: 0, expires: time.Now().Add(-time.Second)}
	if err := store.Consume("expired", 0); !errors.Is(err, ErrBadCaptcha) {
		t.Fatalf("expired proof accepted: %v", err)
	}
}
