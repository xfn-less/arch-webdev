package auth

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"net/http"
	"strings"
	"time"

	"github.com/xfn/static-site-panel/internal/store"
	"golang.org/x/crypto/bcrypt"
)

const cookieName = "ssp_session"

// Common single-admin panel session policy: short idle + hard daily cap.
const (
	sessionIdleTTL = 2 * time.Hour
	sessionMaxTTL  = 24 * time.Hour
)

var (
	ErrUnauthorized = errors.New("unauthorized")
	ErrBusy         = errors.New("session busy")
	ErrBadPassword  = errors.New("bad password")
	ErrRateLimited  = errors.New("rate limited")
)

type Manager struct {
	store        *store.Store
	secureCookie bool
	loginLimit   *RateLimiter
	captcha      *CaptchaStore
}

func New(st *store.Store, secureCookie bool) *Manager {
	return &Manager{
		store:        st,
		secureCookie: secureCookie,
		loginLimit:   NewRateLimiter(5, 10*time.Minute), // 5 fails → need human confirm
		captcha:      NewCaptchaStore(),
	}
}

func (m *Manager) IssueCaptcha() (CaptchaIssue, error) {
	return m.captcha.Issue()
}

func (m *Manager) CheckCaptcha(id string, nonce int64) error {
	return m.captcha.Check(id, nonce)
}

func (m *Manager) ConsumeCaptcha(id string, nonce int64) error {
	return m.captcha.Consume(id, nonce)
}

// VerifyCaptcha consumes the proof (setup / one-shot paths).
func (m *Manager) VerifyCaptcha(id string, nonce int64) error {
	return m.captcha.Consume(id, nonce)
}

func (m *Manager) HasPassword(ctx context.Context) (bool, error) {
	_, err := m.store.Meta(ctx, "password_hash")
	if errors.Is(err, store.ErrNotFound) {
		return false, nil
	}
	return err == nil, err
}

func (m *Manager) SetPassword(ctx context.Context, password string) error {
	if len(password) < 8 {
		return errors.New("password too short (min 8)")
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	return m.store.SetMeta(ctx, "password_hash", string(hash))
}

func (m *Manager) ChangePassword(ctx context.Context, oldPassword, newPassword string) error {
	if err := m.checkPassword(ctx, oldPassword); err != nil {
		return err
	}
	return m.SetPassword(ctx, newPassword)
}

func (m *Manager) checkPassword(ctx context.Context, password string) error {
	hashStr, err := m.store.Meta(ctx, "password_hash")
	if errors.Is(err, store.ErrNotFound) {
		return errors.New("password not set")
	}
	if err != nil {
		return err
	}
	if bcrypt.CompareHashAndPassword([]byte(hashStr), []byte(password)) != nil {
		return ErrBadPassword
	}
	return nil
}

type LoginResult struct {
	Token string
	CSRF  string
}

func (m *Manager) Login(ctx context.Context, r *http.Request, password string, kick, confirm bool) (LoginResult, error) {
	ip := ClientIP(r)
	if confirm {
		m.loginLimit.Confirm(ip)
	}
	if !m.loginLimit.Allow(ip) {
		return LoginResult{}, ErrRateLimited
	}
	if err := m.checkPassword(ctx, password); err != nil {
		if errors.Is(err, ErrBadPassword) {
			m.loginLimit.Fail(ip)
		}
		return LoginResult{}, err
	}
	existing, err := m.store.GetSession(ctx)
	if err == nil && existing.ExpiresAt.After(time.Now()) {
		if !kick {
			return LoginResult{}, ErrBusy
		}
	} else if err != nil && !errors.Is(err, store.ErrNotFound) {
		return LoginResult{}, err
	}
	token, tokenHash, err := newToken()
	if err != nil {
		return LoginResult{}, err
	}
	csrf, err := randomString(16)
	if err != nil {
		return LoginResult{}, err
	}
	now := time.Now()
	if err := m.store.PutSession(ctx, tokenHash, csrf, now.Add(sessionIdleTTL), now.Add(sessionMaxTTL)); err != nil {
		return LoginResult{}, err
	}
	m.loginLimit.Clear(ip)
	return LoginResult{Token: token, CSRF: csrf}, nil
}

func (m *Manager) Logout(ctx context.Context) error {
	return m.store.ClearSession(ctx)
}

func (m *Manager) cookieSecure(r *http.Request) bool {
	if m.secureCookie {
		return true
	}
	if r == nil {
		return false
	}
	if strings.EqualFold(r.Header.Get("X-Forwarded-Proto"), "https") {
		return true
	}
	return r.TLS != nil
}

func (m *Manager) WriteCookie(w http.ResponseWriter, r *http.Request, token string) {
	http.SetCookie(w, &http.Cookie{
		Name:     cookieName,
		Value:    token,
		Path:     "/",
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
		Secure:   m.cookieSecure(r),
		MaxAge:   int(sessionMaxTTL.Seconds()),
	})
}

func (m *Manager) ClearCookie(w http.ResponseWriter, r *http.Request) {
	http.SetCookie(w, &http.Cookie{
		Name:     cookieName,
		Value:    "",
		Path:     "/",
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
		Secure:   m.cookieSecure(r),
		MaxAge:   -1,
	})
}

func (m *Manager) Authenticate(r *http.Request) (csrf string, err error) {
	c, err := r.Cookie(cookieName)
	if err != nil || c.Value == "" {
		return "", ErrUnauthorized
	}
	sum := sha256.Sum256([]byte(c.Value))
	row, err := m.store.GetSession(r.Context())
	if errors.Is(err, store.ErrNotFound) {
		return "", ErrUnauthorized
	}
	if err != nil {
		return "", err
	}
	now := time.Now()
	if now.After(row.MaxExpiresAt) || now.After(row.ExpiresAt) {
		_ = m.store.ClearSession(r.Context())
		return "", ErrUnauthorized
	}
	if subtle.ConstantTimeCompare(sum[:], row.TokenHash) != 1 {
		return "", ErrUnauthorized
	}
	// Slide idle window; never past the absolute login cap.
	nextIdle := now.Add(sessionIdleTTL)
	if nextIdle.After(row.MaxExpiresAt) {
		nextIdle = row.MaxExpiresAt
	}
	if nextIdle.After(row.ExpiresAt) {
		_ = m.store.TouchSession(r.Context(), nextIdle)
	}
	return row.CSRF, nil
}

func newToken() (token string, hash []byte, err error) {
	raw := make([]byte, 32)
	if _, err = rand.Read(raw); err != nil {
		return "", nil, err
	}
	token = base64.RawURLEncoding.EncodeToString(raw)
	sum := sha256.Sum256([]byte(token))
	return token, sum[:], nil
}

func randomString(n int) (string, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}
