package auth

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"testing"
	"time"

	"github.com/xfn/static-site-panel/internal/store"
)

func TestSingleSessionKickAndLogout(t *testing.T) {
	st, err := store.Open(filepath.Join(t.TempDir(), "panel.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer st.Close()
	manager := New(st, false)
	ctx := context.Background()
	if err := manager.SetPassword(ctx, "fixture-password"); err != nil {
		t.Fatal(err)
	}
	req := httptest.NewRequest("POST", "/api/login", nil)
	if _, err := manager.Login(ctx, req, "wrong-password", false, false); !errors.Is(err, ErrBadPassword) {
		t.Fatal("wrong password accepted", err)
	}
	first, err := manager.Login(ctx, req, "fixture-password", false, false)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := manager.Login(ctx, req, "fixture-password", false, false); !errors.Is(err, ErrBusy) {
		t.Fatal("second session did not require kick", err)
	}
	second, err := manager.Login(ctx, req, "fixture-password", true, false)
	if err != nil {
		t.Fatal(err)
	}
	authenticate := func(token string) error {
		r := httptest.NewRequest("GET", "/api/tree", nil)
		r.AddCookie(&http.Cookie{Name: cookieName, Value: token})
		_, err := manager.Authenticate(r)
		return err
	}
	if err := authenticate(first.Token); !errors.Is(err, ErrUnauthorized) {
		t.Fatal("kicked session remains valid", err)
	}
	if err := authenticate(second.Token); err != nil {
		t.Fatal(err)
	}
	if err := manager.Logout(ctx); err != nil {
		t.Fatal(err)
	}
	if err := authenticate(second.Token); !errors.Is(err, ErrUnauthorized) {
		t.Fatal("logged-out session remains valid", err)
	}
}

func TestSessionIdleAndAbsoluteExpiry(t *testing.T) {
	st, err := store.Open(filepath.Join(t.TempDir(), "panel.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer st.Close()
	manager := New(st, false)
	ctx := context.Background()
	if err := manager.SetPassword(ctx, "fixture-password"); err != nil {
		t.Fatal(err)
	}
	req := httptest.NewRequest("POST", "/api/login", nil)
	login, err := manager.Login(ctx, req, "fixture-password", false, false)
	if err != nil {
		t.Fatal(err)
	}
	row, err := st.GetSession(ctx)
	if err != nil {
		t.Fatal(err)
	}
	idleLeft := time.Until(row.ExpiresAt)
	maxLeft := time.Until(row.MaxExpiresAt)
	if idleLeft < sessionIdleTTL-time.Minute || idleLeft > sessionIdleTTL+time.Minute {
		t.Fatalf("idle ttl = %v, want ~%v", idleLeft, sessionIdleTTL)
	}
	if maxLeft < sessionMaxTTL-time.Minute || maxLeft > sessionMaxTTL+time.Minute {
		t.Fatalf("max ttl = %v, want ~%v", maxLeft, sessionMaxTTL)
	}

	// Force idle expiry.
	if err := st.TouchSession(ctx, time.Now().Add(-time.Second)); err != nil {
		t.Fatal(err)
	}
	r := httptest.NewRequest("GET", "/api/tree", nil)
	r.AddCookie(&http.Cookie{Name: cookieName, Value: login.Token})
	if _, err := manager.Authenticate(r); !errors.Is(err, ErrUnauthorized) {
		t.Fatal("idle-expired session still valid", err)
	}
}
