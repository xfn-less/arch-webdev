package auth

import (
	"net"
	"net/http"
	"strings"
	"sync"
	"time"
)

type attemptWindow struct {
	fails   []time.Time
	credits int
}

type RateLimiter struct {
	mu     sync.Mutex
	byKey  map[string]*attemptWindow
	limit  int
	window time.Duration
}

func NewRateLimiter(limit int, window time.Duration) *RateLimiter {
	return &RateLimiter{
		byKey:  map[string]*attemptWindow{},
		limit:  limit,
		window: window,
	}
}

func (r *RateLimiter) windowFor(key string) *attemptWindow {
	w := r.byKey[key]
	if w == nil {
		w = &attemptWindow{}
		r.byKey[key] = w
	}
	now := time.Now()
	cut := now.Add(-r.window)
	kept := w.fails[:0]
	for _, t := range w.fails {
		if t.After(cut) {
			kept = append(kept, t)
		}
	}
	w.fails = kept
	return w
}

// Allow is true under the fail threshold, or when a confirm credit remains.
// Credits are not spent here so a busy→kick retry can reuse the same unlock.
func (r *RateLimiter) Allow(key string) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	w := r.windowFor(key)
	if len(w.fails) < r.limit {
		return true
	}
	return w.credits > 0
}

// Confirm grants one extra try after 5 failures (server-side; UI click alone is not enough).
func (r *RateLimiter) Confirm(key string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	w := r.windowFor(key)
	w.credits = 1
}

func (r *RateLimiter) Fail(key string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	w := r.windowFor(key)
	wasLimited := len(w.fails) >= r.limit
	w.fails = append(w.fails, time.Now())
	if wasLimited && w.credits > 0 {
		w.credits--
	}
}

func (r *RateLimiter) Clear(key string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	delete(r.byKey, key)
}

func (r *RateLimiter) FailCount(key string) int {
	r.mu.Lock()
	defer r.mu.Unlock()
	return len(r.windowFor(key).fails)
}

func ClientIP(r *http.Request) string {
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
		parts := strings.Split(xff, ",")
		return strings.TrimSpace(parts[0])
	}
	if xrip := r.Header.Get("X-Real-IP"); xrip != "" {
		return strings.TrimSpace(xrip)
	}
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}
