package confcheck

import (
	"fmt"
	"regexp"
	"strings"

	"github.com/xfn/static-site-panel/internal/confmark"
)

// Result is a lightweight nginx.conf sanity check (not a full nginx -t).
type Result struct {
	OK       bool     `json:"ok"`
	Errors   []string `json:"errors,omitempty"`
	Warnings []string `json:"warnings,omitempty"`
}

var (
	reLocationRoot    = regexp.MustCompile(`(?i)^\s*location\s+/(\s|\{)`)
	reEmptyServerName = regexp.MustCompile(`(?i)^\s*server_name\s*;`)
	reDirectiveEnd    = regexp.MustCompile(`;\s*$`)
)

// Check looks for brace/quote problems and common location / conflicts.
func Check(conf string) Result {
	var errs, warns []string
	for _, line := range strings.Split(conf, "\n") {
		if reEmptyServerName.MatchString(stripLineComment(line)) {
			errs = append(errs, "server_name 缺少参数；请填写域名或注释掉整行")
			break
		}
	}
	if n := braceBalance(conf); n != 0 {
		if n > 0 {
			errs = append(errs, fmt.Sprintf("花括号可能多出 %d 个 '{'", n))
		} else {
			errs = append(errs, fmt.Sprintf("花括号可能缺少 %d 个 '}'", -n))
		}
	}
	if oddQuotes(conf) {
		errs = append(errs, "引号可能未成对")
	}
	roots := activeLocationRootCount(conf)
	if roots > 1 {
		warns = append(warns, fmt.Sprintf("有 %d 个未注释的 location /，通常会冲突（片段2 需先去掉默认 location /）", roots))
	}
	if danglingProxy(conf) {
		warns = append(warns, "存在 proxy_pass 但未见 location，请确认片段是否贴完整")
	}
	if dups, derr := confmark.DuplicateDomains(conf); derr == nil && len(dups) > 0 {
		errs = append(errs, "域名重复，禁止保存："+strings.Join(dups, ", "))
	}
	return Result{OK: len(errs) == 0, Errors: errs, Warnings: warns}
}

func braceBalance(conf string) int {
	depth := 0
	for _, line := range strings.Split(conf, "\n") {
		code := stripLineComment(line)
		inSQ, inDQ := false, false
		for i := 0; i < len(code); i++ {
			c := code[i]
			if c == '\\' && i+1 < len(code) {
				i++
				continue
			}
			if !inDQ && c == '\'' {
				inSQ = !inSQ
				continue
			}
			if !inSQ && c == '"' {
				inDQ = !inDQ
				continue
			}
			if inSQ || inDQ {
				continue
			}
			switch c {
			case '{':
				depth++
			case '}':
				depth--
				if depth < 0 {
					return depth
				}
			}
		}
	}
	return depth
}

func oddQuotes(conf string) bool {
	inSQ, inDQ := false, false
	for _, line := range strings.Split(conf, "\n") {
		for i := 0; i < len(line); i++ {
			c := line[i]
			if c == '\\' && i+1 < len(line) {
				i++
				continue
			}
			if !inSQ && !inDQ && c == '#' {
				break
			}
			if !inDQ && c == '\'' {
				inSQ = !inSQ
			}
			if !inSQ && c == '"' {
				inDQ = !inDQ
			}
		}
	}
	return inSQ || inDQ
}

func activeLocationRootCount(conf string) int {
	n := 0
	for _, line := range strings.Split(conf, "\n") {
		code := strings.TrimSpace(stripLineComment(line))
		if code == "" {
			continue
		}
		if reLocationRoot.MatchString(code) {
			n++
		}
	}
	return n
}

func danglingProxy(conf string) bool {
	hasProxy, hasLoc := false, false
	for _, line := range strings.Split(conf, "\n") {
		code := strings.ToLower(strings.TrimSpace(stripLineComment(line)))
		if strings.HasPrefix(code, "proxy_pass") && reDirectiveEnd.MatchString(code) {
			hasProxy = true
		}
		if strings.HasPrefix(code, "location") {
			hasLoc = true
		}
	}
	return hasProxy && !hasLoc
}

func stripLineComment(line string) string {
	inSQ, inDQ := false, false
	for i := 0; i < len(line); i++ {
		c := line[i]
		if c == '\\' && i+1 < len(line) {
			i++
			continue
		}
		if !inDQ && c == '\'' {
			inSQ = !inSQ
			continue
		}
		if !inSQ && c == '"' {
			inDQ = !inDQ
			continue
		}
		if !inSQ && !inDQ && c == '#' {
			return line[:i]
		}
	}
	return line
}
