package confcheck

import (
	"strings"
	"testing"

	"github.com/xfn/static-site-panel/internal/confmark"
)

func TestCheckOK(t *testing.T) {
	conf := `
server {
    listen 80;
    location / {
        try_files $uri /index.html;
    }
}
`
	r := Check(conf)
	if !r.OK || len(r.Errors) != 0 || len(r.Warnings) != 0 {
		t.Fatalf("%+v", r)
	}
}

func TestCheckBraceAndDupLocation(t *testing.T) {
	bad := `server { location / { } `
	r := Check(bad)
	if r.OK || len(r.Errors) == 0 {
		t.Fatalf("expected brace error: %+v", r)
	}
	dup := `
server {
  location / { try_files $uri /index.html; }
  location / { proxy_pass http://127.0.0.1:8080; }
}
`
	r = Check(dup)
	if !r.OK || len(r.Warnings) == 0 {
		t.Fatalf("expected dup warning: %+v", r)
	}
	commented := `
server {
  location / { try_files $uri /index.html; }
  # location / { proxy_pass http://127.0.0.1:8080; }
}
`
	r = Check(commented)
	if !r.OK || len(r.Warnings) != 0 {
		t.Fatalf("commented dup should be fine: %+v", r)
	}
}

func TestQuotedOppositeQuotesAreValid(t *testing.T) {
	for _, conf := range []string{`server { add_header X-Text "it's fine # }"; }`, `server { add_header X-Text 'a "quote"'; }`} {
		if result := Check(conf); !result.OK {
			t.Fatalf("valid quoted value rejected: %+v", result)
		}
	}
}

func TestEmptyServerNameRejected(t *testing.T) {
	if result := Check("server {\nserver_name ;\n}\n"); result.OK {
		t.Fatal("empty server_name accepted")
	}
	if result := Check("server {\nserver_name \"\";\n}\n"); !result.OK {
		t.Fatal("explicit empty hostname is valid Nginx", result)
	}
	validMultiline := "server {\nserver_name\n    example.test\n    ;\n}\n"
	if result := Check(validMultiline); !result.OK {
		t.Fatal("multiline server_name with a standalone semicolon was rejected", result)
	}
}

func TestDuplicateDomainsRejected(t *testing.T) {
	conf := `
server {
` + confmark.ServerNameBegin + `
    server_name
        a.example.test
        b.example.test
        A.example.test
        ;
` + confmark.ServerNameEnd + `
` + confmark.SSLBegin + `
` + confmark.SSLEnd + `
}
`
	r := Check(conf)
	if r.OK {
		t.Fatal("duplicate domains accepted")
	}
	joined := strings.Join(r.Errors, "\n")
	if !strings.Contains(joined, "域名重复") || !strings.Contains(joined, "a.example.test") {
		t.Fatalf("expected duplicate error, got %+v", r)
	}
}
