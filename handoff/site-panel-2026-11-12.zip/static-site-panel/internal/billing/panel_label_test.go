package billing

import (
	"context"
	"path/filepath"
	"testing"

	"github.com/xfn/static-site-panel/internal/store"
)

func TestPanelLabelFallsBackToFirstSiteWhenRemarkIsEmpty(t *testing.T) {
	ctx := context.Background()
	root := t.TempDir()
	st, err := store.Open(filepath.Join(root, "panel.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer st.Close()

	srv, err := st.UpsertServer(ctx, store.Server{Host: "192.0.2.10", PublicIP: "192.0.2.10"})
	if err != nil {
		t.Fatal(err)
	}
	for _, site := range []store.Site{
		{Name: "s20", Title: "第二个站点", ServerID: srv.ID},
		{Name: "s10", Title: "第一个站点", ServerID: srv.ID},
	} {
		if _, err := st.UpsertSite(ctx, site); err != nil {
			t.Fatal(err)
		}
	}
	if err := st.ReplaceBillingAssets(ctx, []store.BillingAsset{{IP: "192.0.2.10", IPNorm: "192.0.2.10"}}); err != nil {
		t.Fatal(err)
	}

	svc := &Service{Store: st, AccountsPath: filepath.Join(root, "missing-accounts.json")}
	rows, _, _, err := svc.List(ctx, 0)
	if err != nil || len(rows) != 1 {
		t.Fatal(rows, err)
	}
	if rows[0].PanelName != "第一个站点" {
		t.Fatalf("fallback panel label = %q", rows[0].PanelName)
	}

	srv.Note = "香港主机"
	if _, err := st.UpsertServer(ctx, srv); err != nil {
		t.Fatal(err)
	}
	rows, _, _, err = svc.List(ctx, 0)
	if err != nil || len(rows) != 1 {
		t.Fatal(rows, err)
	}
	if rows[0].PanelName != "香港主机" {
		t.Fatalf("remark did not take precedence: %q", rows[0].PanelName)
	}
}
