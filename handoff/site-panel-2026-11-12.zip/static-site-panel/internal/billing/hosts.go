package billing

import (
	"context"
	"net"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/xfn/static-site-panel/internal/sshutil"
	"github.com/xfn/static-site-panel/internal/store"
)

type hostProbe struct {
	Name string
	Addr string
	OK   bool
	Err  string
}

func probePanelHosts(ctx context.Context, servers []store.Server) []hostProbe {
	out := make([]hostProbe, len(servers))
	if len(servers) == 0 {
		return out
	}
	sem := make(chan struct{}, 8)
	var wg sync.WaitGroup
	for i, srv := range servers {
		wg.Add(1)
		go func(i int, srv store.Server) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			port := srv.Port
			if port <= 0 {
				port = 22
			}
			host := strings.TrimSpace(srv.Host)
			addr := net.JoinHostPort(host, strconv.Itoa(port))
			name := strings.TrimSpace(srv.Name)
			if name == "" {
				name = host
			}
			p := hostProbe{Name: name, Addr: addr}
			if skipHostProbe(host) {
				p.OK = true
				out[i] = p
				return
			}
			if host == "" {
				p.Err = "无 Host"
				out[i] = p
				return
			}
			var (
				conn net.Conn
				err  error
			)
			if srv.ViaJump {
				conn, err = sshutil.TCPViaJump(host, port)
			} else {
				d := net.Dialer{Timeout: 5 * time.Second}
				cctx, cancel := context.WithTimeout(ctx, 6*time.Second)
				conn, err = d.DialContext(cctx, "tcp", addr)
				cancel()
			}
			if err != nil {
				p.Err = shortProbeErr(err)
				out[i] = p
				return
			}
			_ = conn.Close()
			p.OK = true
			out[i] = p
		}(i, srv)
	}
	wg.Wait()
	return out
}

// skipHostProbe lists machines whose public SSH port flaps and should not page.
func skipHostProbe(host string) bool {
	switch strings.TrimSpace(host) {
	case "180.97.215.102":
		return true
	default:
		return false
	}
}

func shortProbeErr(err error) string {
	s := err.Error()
	if len(s) > 120 {
		s = s[:117] + "..."
	}
	return s
}
