package billing

import (
	"context"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/xfn/static-site-panel/internal/store"
)

func TestBuildQuietDigestLines(t *testing.T) {
	ctx := context.Background()
	root := t.TempDir()
	backup := filepath.Join(root, "backup")
	manifests := filepath.Join(backup, "manifests")
	if err := os.MkdirAll(manifests, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(manifests, "manifest-test.json"), []byte(`{}`), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(backup, "blob.bin"), make([]byte, 2*1024*1024), 0o644); err != nil {
		t.Fatal(err)
	}
	t.Setenv("SITE_PANEL_BACKUP_DIR", backup)
	t.Setenv("SITE_PANEL_ROOT", root)
	healthPath := filepath.Join(root, "health-last")
	t.Setenv("SITE_PANEL_HEALTH_LAST", healthPath)
	stamp := strconv.FormatInt(time.Now().Unix(), 10) + "\tok\t\n"
	if err := os.WriteFile(healthPath, []byte(stamp), 0o644); err != nil {
		t.Fatal(err)
	}

	st, err := store.Open(filepath.Join(root, "panel.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer st.Close()
	now := time.Now().Unix()
	if err := st.ReplaceBillingAssets(ctx, []store.BillingAsset{
		{IP: "192.0.2.1", IPNorm: "192.0.2.1", ExpireUnix: now + 10*24*3600, Status: "正常"},
	}); err != nil {
		t.Fatal(err)
	}
	s := &Service{Store: st}
	body := s.buildQuietDigest(ctx, nil)
	want := []string{
		"抓取成功,48h内无需续费ip",
		"数据已备份(2M)",
		"面板和所有ip可达",
	}
	got := strings.Split(body, "\n")
	if len(got) != 3 {
		t.Fatalf("body=%q", body)
	}
	for i, w := range want {
		if got[i] != w {
			t.Fatalf("line %d: got %q want %q\nfull=%q", i, got[i], w, body)
		}
	}

	failBody := s.buildQuietDigest(ctx, context.Canceled)
	if !strings.HasPrefix(failBody, "抓取失败\n") {
		t.Fatalf("syncErr digest=%q", failBody)
	}
	if !digestAllOK(body) {
		t.Fatalf("normal digest should be silent-ok: %q", body)
	}
	if digestAllOK(failBody) {
		t.Fatalf("failed digest must not be silent-ok: %q", failBody)
	}
	if digestAllOK("抓取成功,48h内待续费2台\n数据已备份(2M)\n面板和所有ip可达") {
		t.Fatal("due renewals should alert with sound")
	}
}
