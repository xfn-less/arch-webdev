package billing

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"

	"github.com/xfn/static-site-panel/internal/lizhi"
	"github.com/xfn/static-site-panel/internal/store"
)

func TestFetchVersionsNeverMixOldRows(t *testing.T) {
	for _, allFail := range []bool{false, true} {
		t.Run(fmt.Sprint(allFail), func(t *testing.T) {
			provider := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				switch r.URL.Path {
				case "/login":
					if r.Method == "POST" {
						w.Header().Set("Location", "/clientarea")
						w.WriteHeader(302)
					} else {
						fmt.Fprint(w, `<input name="token" value="fixture">`)
					}
				case "/clientarea":
					fmt.Fprint(w, `<div class="balance-info"><h1>100</h1></div>`)
				case "/service":
					if allFail || r.URL.Query().Get("groupid") == "306" {
						http.Error(w, "temporary provider failure", 503)
						return
					}
					fmt.Fprint(w, `var serviceList = [{"dedicatedip":"192.0.2.3"}]; productManagement`)
				default:
					http.NotFound(w, r)
				}
			}))
			defer provider.Close()
			ctx := context.Background()
			root := t.TempDir()
			st, err := store.Open(filepath.Join(root, "panel.db"))
			if err != nil {
				t.Fatal(err)
			}
			defer st.Close()
			service := &Service{Store: st, AccountsPath: filepath.Join(root, "accounts.json")}
			cfg := lizhi.ConfigFile{Accounts: []lizhi.Account{{Name: "broken", Email: "broken@example.test", BaseURL: provider.URL, GroupIDs: []int{305, 306}}, {Name: "healthy", Email: "healthy@example.test", BaseURL: provider.URL, GroupIDs: []int{305}}}}
			if err := service.SaveConfig(cfg); err != nil {
				t.Fatal(err)
			}
			previous := []store.BillingAsset{{AccountName: "broken", LoginID: "broken@example.test", IP: "192.0.2.1", IPNorm: "192.0.2.1"}, {AccountName: "healthy", LoginID: "healthy@example.test", IP: "192.0.2.2", IPNorm: "192.0.2.2"}}
			if err := st.ReplaceBillingAssets(ctx, previous); err != nil {
				t.Fatal(err)
			}
			if err := service.sync(ctx, nil, true, nil); err == nil {
				t.Fatal("failed account reported as a fully successful fetch")
			}
			current, err := st.ListBillingAssets(ctx)
			if err != nil || len(current) != 2 {
				t.Fatal(current, err)
			}
			failed := 0
			for _, row := range current {
				if row.IP == "192.0.2.1" || row.IP == "192.0.2.2" {
					t.Fatal("current version contains old assets", row)
				}
				if row.Status == fetchFailedStatus {
					failed++
					if row.IP != "" || row.ExpireUnix != 0 || !strings.Contains(row.Note, "切换旧版") {
						t.Fatal("unclear failure row", row)
					}
				}
			}
			expected := 1
			if allFail {
				expected = 2
			}
			if failed != expected {
				t.Fatalf("failure rows=%d want=%d", failed, expected)
			}
			snapshots, err := st.ListBillingSnapshots(ctx)
			if err != nil || len(snapshots) != 1 {
				t.Fatal("prior version unavailable", snapshots, err)
			}
			old, _, err := st.GetBillingSnapshotAssets(ctx, snapshots[0].ID)
			if err != nil || len(old) != 2 {
				t.Fatal(old, err)
			}
			ips := map[string]bool{}
			for _, row := range old {
				ips[row.IP] = true
			}
			if !ips["192.0.2.1"] || !ips["192.0.2.2"] {
				t.Fatal("snapshot did not preserve previous data", old)
			}
			digest := service.buildQuietDigest(ctx, context.Canceled)
			if !strings.HasPrefix(digest, "抓取失败") || strings.Contains(digest, "无需续费") {
				t.Fatal("failed fetch falsely described as healthy", digest)
			}
		})
	}
}
