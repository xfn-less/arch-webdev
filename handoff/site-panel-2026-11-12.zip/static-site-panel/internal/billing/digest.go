package billing

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const (
	healthLastMetaKey = "health_last_status"
	backupMaxAge      = 36 * time.Hour
	healthMaxAge      = 3 * time.Hour
)

// buildQuietDigest builds the short morning / manual TG body.
// Example:
//
//	抓取成功,48h内无需续费ip
//	数据已备份(40M)
//	面板和所有ip可达
func (s *Service) buildQuietDigest(ctx context.Context, syncErr error) string {
	return strings.Join([]string{
		s.fetchDigestLine(ctx, syncErr),
		s.backupDigestLine(),
		s.reachDigestLine(ctx),
	}, "\n")
}

// digestAllOK is true only for the fully-normal morning body (silent TG).
// 待续费 / 失败 / 异常 → false（有声）。
func digestAllOK(body string) bool {
	lines := strings.Split(strings.TrimSpace(body), "\n")
	if len(lines) != 3 {
		return false
	}
	if lines[0] != "抓取成功,48h内无需续费ip" {
		return false
	}
	if !strings.HasPrefix(lines[1], "数据已备份") {
		return false
	}
	return lines[2] == "面板和所有ip可达"
}

func (s *Service) fetchDigestLine(ctx context.Context, syncErr error) string {
	if syncErr != nil {
		return "抓取失败"
	}
	assets, err := s.Store.ListBillingAssets(ctx)
	if err != nil {
		return "抓取失败"
	}
	if len(assets) == 0 {
		return "抓取成功,暂无机器数据"
	}
	now := time.Now().Unix()
	due := 0
	failed := 0
	for _, a := range assets {
		if a.Status == fetchFailedStatus {
			failed++
			continue
		}
		if a.IPNorm == "" || a.ExpireUnix <= 0 {
			continue
		}
		left := a.ExpireUnix - now
		if left >= 0 && left <= 48*3600 {
			due++
		}
	}
	if failed > 0 && failed == len(assets) {
		return "抓取失败"
	}
	if due == 0 {
		return "抓取成功,48h内无需续费ip"
	}
	return fmt.Sprintf("抓取成功,48h内待续费%d台", due)
}

func (s *Service) backupDigestLine() string {
	dir := strings.TrimSpace(os.Getenv("SITE_PANEL_BACKUP_DIR"))
	if dir == "" {
		dir = "/root/backups/site-panel"
	}
	manifests := filepath.Join(dir, "manifests")
	entries, err := os.ReadDir(manifests)
	if err != nil {
		return "备份失败"
	}
	var latest time.Time
	for _, e := range entries {
		if e.IsDir() || !strings.HasPrefix(e.Name(), "manifest-") || !strings.HasSuffix(e.Name(), ".json") {
			continue
		}
		info, err := e.Info()
		if err != nil {
			continue
		}
		if info.ModTime().After(latest) {
			latest = info.ModTime()
		}
	}
	if latest.IsZero() || time.Since(latest) > backupMaxAge {
		return "备份失败"
	}
	size := backupDirSizeLabel(dir)
	if size == "" {
		return "数据已备份"
	}
	return "数据已备份(" + size + ")"
}

func backupDirSizeLabel(dir string) string {
	var total int64
	_ = filepath.Walk(dir, func(_ string, info os.FileInfo, err error) error {
		if err != nil || info == nil || info.IsDir() {
			return nil
		}
		total += info.Size()
		return nil
	})
	if total <= 0 {
		return ""
	}
	const mb = 1024 * 1024
	if total < mb {
		kb := total / 1024
		if kb < 1 {
			kb = 1
		}
		return fmt.Sprintf("%dK", kb)
	}
	return fmt.Sprintf("%dM", (total+mb/2)/mb)
}

func (s *Service) reachDigestLine(ctx context.Context) string {
	if line := s.readHealthStamp(ctx); line != "" {
		return line
	}
	return s.liveReachDigest(ctx)
}

func (s *Service) readHealthStamp(ctx context.Context) string {
	raw := ""
	if p := healthLastPath(); p != "" {
		if b, err := os.ReadFile(p); err == nil {
			raw = strings.TrimSpace(string(b))
		}
	}
	if raw == "" {
		if v, err := s.Store.Meta(ctx, healthLastMetaKey); err == nil {
			raw = strings.TrimSpace(v)
		}
	}
	if raw == "" {
		return ""
	}
	// format: <unix>\tok   or  <unix>\tfail\t面板异常,1.2.3.4不可达
	parts := strings.SplitN(raw, "\t", 3)
	if len(parts) < 2 {
		return ""
	}
	sec, err := parseUnixDigits(parts[0])
	if err != nil {
		return ""
	}
	if time.Since(time.Unix(sec, 0)) > healthMaxAge {
		return ""
	}
	if parts[1] == "ok" {
		return "面板和所有ip可达"
	}
	if len(parts) >= 3 && strings.TrimSpace(parts[2]) != "" {
		return strings.TrimSpace(parts[2])
	}
	return "面板异常"
}

func (s *Service) liveReachDigest(ctx context.Context) string {
	if !panelHTTPOK() {
		return "面板异常"
	}
	servers, err := s.Store.ListServers(ctx)
	if err != nil {
		return "面板异常"
	}
	if len(servers) == 0 {
		return "面板和所有ip可达"
	}
	probes := probePanelHosts(ctx, servers)
	var bad []string
	for _, p := range probes {
		if p.OK {
			continue
		}
		ip := p.Addr
		if host, _, ok := strings.Cut(p.Addr, ":"); ok && host != "" {
			ip = host
		}
		if ip == "" {
			ip = p.Name
		}
		bad = append(bad, ip)
	}
	if len(bad) == 0 {
		return "面板和所有ip可达"
	}
	if len(bad) > 3 {
		bad = bad[:3]
	}
	return "面板异常," + strings.Join(bad, ",") + "不可达"
}

func panelHTTPOK() bool {
	client := &http.Client{Timeout: 5 * time.Second}
	res, err := client.Get("http://127.0.0.1:8790/api/status")
	if err != nil {
		return false
	}
	defer res.Body.Close()
	return res.StatusCode >= 200 && res.StatusCode < 300
}

func panelRoot() string {
	root := strings.TrimSpace(os.Getenv("SITE_PANEL_ROOT"))
	if root == "" {
		root = "/www/site-panel"
	}
	return root
}

func healthLastPath() string {
	if p := strings.TrimSpace(os.Getenv("SITE_PANEL_HEALTH_LAST")); p != "" {
		return p
	}
	return filepath.Join(panelRoot(), ".data", "health-last")
}

func parseUnixDigits(s string) (int64, error) {
	if s == "" {
		return 0, fmt.Errorf("empty")
	}
	var n int64
	for _, c := range s {
		if c < '0' || c > '9' {
			return 0, fmt.Errorf("bad int")
		}
		n = n*10 + int64(c-'0')
	}
	return n, nil
}
