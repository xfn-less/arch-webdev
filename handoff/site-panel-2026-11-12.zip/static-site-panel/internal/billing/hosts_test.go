package billing

import (
	"context"
	"net"
	"strconv"
	"testing"
	"time"

	"github.com/xfn/static-site-panel/internal/store"
)

func TestProbePanelHosts(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	port := ln.Addr().(*net.TCPAddr).Port
	go func() {
		c, err := ln.Accept()
		if err == nil {
			_ = c.Close()
		}
	}()

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	probes := probePanelHosts(ctx, []store.Server{
		{Name: "up", Host: "127.0.0.1", Port: port},
		{Name: "down", Host: "127.0.0.1", Port: 1},
		{Name: "empty", Host: "", Port: 22},
		{Name: "skip", Host: "180.97.215.102", Port: 22},
	})
	if len(probes) != 4 {
		t.Fatalf("len=%d", len(probes))
	}
	if !probes[0].OK || probes[0].Addr != net.JoinHostPort("127.0.0.1", strconv.Itoa(port)) {
		t.Fatalf("up: %+v", probes[0])
	}
	if probes[1].OK || probes[1].Err == "" {
		t.Fatalf("down: %+v", probes[1])
	}
	if probes[2].OK || probes[2].Err != "无 Host" {
		t.Fatalf("empty: %+v", probes[2])
	}
	if !probes[3].OK {
		t.Fatalf("skipped host should not be reported down: %+v", probes[3])
	}
}
