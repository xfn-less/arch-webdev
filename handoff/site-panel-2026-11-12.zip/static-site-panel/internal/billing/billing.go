package billing

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/xfn/static-site-panel/internal/lizhi"
	"github.com/xfn/static-site-panel/internal/store"
	"github.com/xfn/static-site-panel/internal/tgbot"
)

type Service struct {
	Store        *store.Store
	AccountsPath string
	mu           sync.Mutex
	syncing      bool
}

const fetchFailedStatus = "抓取失败"

type Row struct {
	store.BillingAsset
	BalanceOK     bool    `json:"balanceOk"`
	PanelServerID int64   `json:"panelServerId"`
	PanelName     string  `json:"panelName"`
	InPanel       bool    `json:"inPanel"`
	HoursLeft     float64 `json:"hoursLeft"`
}

func (s *Service) LoadConfig() (lizhi.ConfigFile, error) {
	return lizhi.LoadConfig(s.AccountsPath)
}

// SaveConfig writes accounts JSON. Empty password keeps previous password for that name/login.
func (s *Service) SaveConfig(cfg lizhi.ConfigFile) error {
	prev, _ := s.LoadConfig()
	if strings.TrimSpace(cfg.Proxy) == "" {
		cfg.Proxy = prev.Proxy
	}
	if strings.TrimSpace(cfg.Telegram.PanelURL) == "" {
		cfg.Telegram.PanelURL = prev.Telegram.PanelURL
	}
	prevByKey := map[string]string{}
	for _, a := range prev.Accounts {
		key := strings.TrimSpace(a.Name) + "\n" + a.LoginID()
		prevByKey[key] = a.Password
		prevByKey[a.LoginID()] = a.Password
	}
	for i := range cfg.Accounts {
		a := &cfg.Accounts[i]
		if strings.TrimSpace(a.Password) != "" {
			continue
		}
		key := strings.TrimSpace(a.Name) + "\n" + a.LoginID()
		if p := prevByKey[key]; p != "" {
			a.Password = p
		} else if p := prevByKey[a.LoginID()]; p != "" {
			a.Password = p
		}
	}
	if err := os.MkdirAll(filepath.Dir(s.AccountsPath), 0o755); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(cfg, "", "  ")
	if err != nil {
		return err
	}
	tmp := s.AccountsPath + ".tmp"
	if err := os.WriteFile(tmp, append(raw, '\n'), 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, s.AccountsPath)
}

func (s *Service) ConfigForEdit() (lizhi.ConfigFile, error) {
	cfg, err := s.LoadConfig()
	if err != nil {
		if os.IsNotExist(err) {
			return lizhi.ConfigFile{Accounts: []lizhi.Account{}}, nil
		}
		return lizhi.ConfigFile{}, err
	}
	return cfg, nil
}

func (s *Service) Sync(ctx context.Context, log func(string)) error {
	return s.sync(ctx, log, true, nil)
}

// SyncFailed re-fetches only accounts whose current rows are status 抓取失败.
func (s *Service) SyncFailed(ctx context.Context, log func(string)) error {
	assets, err := s.Store.ListBillingAssets(ctx)
	if err != nil {
		return err
	}
	filter := map[string]bool{}
	for _, a := range assets {
		if a.Status == fetchFailedStatus {
			name := strings.TrimSpace(a.AccountName)
			if name != "" {
				filter[name] = true
			}
		}
	}
	if len(filter) == 0 {
		return fmt.Errorf("没有失败账号")
	}
	if log != nil {
		names := make([]string, 0, len(filter))
		for n := range filter {
			names = append(names, n)
		}
		sort.Strings(names)
		log(fmt.Sprintf("仅重试失败账号: %s", strings.Join(names, ", ")))
	}
	return s.sync(ctx, log, true, filter)
}

// filter nil = all accounts; non-nil = only those AccountName keys.
func (s *Service) sync(ctx context.Context, log func(string), notify bool, filter map[string]bool) error {
	s.mu.Lock()
	if s.syncing {
		s.mu.Unlock()
		return fmt.Errorf("sync already running")
	}
	s.syncing = true
	s.mu.Unlock()
	defer func() {
		s.mu.Lock()
		s.syncing = false
		s.mu.Unlock()
	}()

	cfg, err := s.LoadConfig()
	if err != nil {
		msg := fmt.Sprintf("accounts: %v", err)
		if notify {
			_ = s.notifyTG(ctx, "抓取失败", false)
		}
		return fmt.Errorf("%s", msg)
	}
	if len(cfg.Accounts) == 0 {
		msg := "无账号配置"
		if notify {
			_ = s.notifyTG(ctx, "抓取失败", false)
		}
		return fmt.Errorf("%s", msg)
	}

	var existing []store.BillingAsset
	if filter != nil {
		existing, err = s.Store.ListBillingAssets(ctx)
		if err != nil {
			return err
		}
	}

	var all []store.BillingAsset
	var fails []string
	now := time.Now().Unix()
	matched := 0
	for _, acc := range cfg.Accounts {
		if filter != nil && !filter[strings.TrimSpace(acc.Name)] {
			continue
		}
		matched++
		if strings.TrimSpace(acc.Email) == "" && strings.TrimSpace(acc.Phone) == "" {
			fails = append(fails, fmt.Sprintf("%s: 无 email/phone", acc.Name))
			all = append(all, failedAccountRow(acc, "无 email/phone", now))
			if log != nil {
				log(fmt.Sprintf("[跳过] %s: 无 email/phone", acc.Name))
			}
			continue
		}
		tries := 1
		if !notify {
			tries = 3 // 早6点自动抓：每账号最多 3 次
		} else if filter != nil {
			tries = 2 // 重试失败：整轮最多 2 次
		}
		var assets []lizhi.Asset
		var syncErr error
		for attempt := 1; attempt <= tries; attempt++ {
			assets, syncErr = lizhi.SyncAccount(acc, 100, log, cfg.Proxy)
			if syncErr == nil {
				break
			}
			if log != nil {
				log(fmt.Sprintf("[重试 %d/%d] %s: %v", attempt, tries, acc.Name, syncErr))
			}
			if attempt == tries {
				break
			}
			select {
			case <-ctx.Done():
				syncErr = ctx.Err()
				attempt = tries
			case <-time.After(8 * time.Second):
			}
		}
		if syncErr != nil {
			fails = append(fails, fmt.Sprintf("%s (%s): %v", acc.Name, acc.LoginID(), syncErr))
			all = append(all, failedAccountRow(acc, syncErr.Error(), now))
			if log != nil {
				log(fmt.Sprintf("[登录失败] %s: %v", acc.Name, syncErr))
			}
			continue
		}
		for _, a := range assets {
			all = append(all, store.BillingAsset{
				AccountName: a.AccountName,
				LoginID:     a.LoginID,
				Balance:     a.Balance,
				Product:     a.Product,
				Note:        a.Note,
				Status:      a.Status,
				IP:          a.IP,
				IPNorm:      lizhi.NormIP(a.IP),
				ExpireAt:    a.ExpireAt,
				ExpireUnix:  a.ExpireUnix,
				DaysLeft:    a.DaysLeft,
				Fee:         a.Fee,
				Cycle:       a.Cycle,
				OS:          a.OS,
				Bandwidth:   a.Bandwidth,
				Region:      a.Region,
				SyncedAt:    now,
			})
		}
	}
	if filter != nil && matched == 0 {
		return fmt.Errorf("失败账号不在配置中")
	}
	if filter != nil {
		kept := make([]store.BillingAsset, 0, len(existing))
		for _, row := range existing {
			if filter[strings.TrimSpace(row.AccountName)] {
				continue
			}
			kept = append(kept, row)
		}
		all = append(kept, all...)
	}
	if len(fails) > 0 && notify {
		_ = s.notifyTG(ctx, "抓取失败", false)
	}

	snap, err := s.Store.ArchiveBillingAssets(ctx, "")
	if err != nil {
		return fmt.Errorf("归档旧续费数据失败，未覆盖当前数据: %w", err)
	}
	if snap.ID != 0 && log != nil {
		log(fmt.Sprintf("已归档旧版 #%d（%d 条）", snap.ID, snap.RowCount))
	}

	if err := s.Store.ReplaceBillingAssets(ctx, all); err != nil {
		if notify {
			_ = s.notifyTG(ctx, "抓取失败", false)
		}
		return err
	}
	if log != nil {
		log(fmt.Sprintf("已写入 %d 条", len(all)))
	}
	if len(fails) > 0 {
		return fmt.Errorf("%s", strings.Join(fails, "; "))
	}
	return nil
}

func (s *Service) List(ctx context.Context, snapshotID int64) ([]Row, int64, []store.BillingSnapshotMeta, error) {
	var assets []store.BillingAsset
	var synced int64
	var err error
	if snapshotID > 0 {
		assets, _, err = s.Store.GetBillingSnapshotAssets(ctx, snapshotID)
		if err != nil {
			return nil, 0, nil, err
		}
		if len(assets) > 0 {
			synced = assets[0].SyncedAt
		}
	} else {
		assets, err = s.Store.ListBillingAssets(ctx)
		if err != nil {
			return nil, 0, nil, err
		}
		synced, _ = s.Store.BillingSyncedAt(ctx)
	}
	snaps, _ := s.Store.ListBillingSnapshots(ctx)
	servers, err := s.Store.ListServers(ctx)
	if err != nil {
		return nil, 0, nil, err
	}
	sites, err := s.Store.ListSites(ctx)
	if err != nil {
		return nil, 0, nil, err
	}
	firstSiteByServer := map[int64]string{}
	for _, site := range sites { // ListSites sorts by the stable directory name.
		if site.ServerID == 0 || firstSiteByServer[site.ServerID] != "" {
			continue
		}
		label := strings.TrimSpace(site.Title)
		if label == "" {
			label = site.Name
		}
		firstSiteByServer[site.ServerID] = label
	}
	byIP := map[string]store.Server{}
	for _, srv := range servers {
		ip := lizhi.NormIP(srv.PublicIP)
		if ip == "" {
			ip = lizhi.NormIP(srv.Host)
		}
		if ip == "" {
			continue
		}
		byIP[ip] = srv
	}
	now := time.Now().Unix()
	out := make([]Row, 0, len(assets))
	for _, a := range assets {
		r := Row{BillingAsset: a}
		bal := lizhi.ParseMoney(a.Balance)
		fee := lizhi.ParseMoney(a.Fee)
		r.BalanceOK = fee <= 0 || bal+1e-9 >= fee
		if a.ExpireUnix > 0 {
			r.HoursLeft = float64(a.ExpireUnix-now) / 3600
		}
		if srv, ok := byIP[a.IPNorm]; ok {
			r.InPanel = true
			r.PanelServerID = srv.ID
			r.PanelName = strings.TrimSpace(srv.Note)
			if r.PanelName == "" {
				r.PanelName = strings.TrimSpace(srv.Name) // legacy server name, displayed as a remark
			}
			if r.PanelName == "" {
				r.PanelName = firstSiteByServer[srv.ID]
			}
		}
		out = append(out, r)
	}
	// 按账号配置顺序，同账号内按 IP
	order := map[string]int{}
	if cfg, err := s.LoadConfig(); err == nil {
		for i, a := range cfg.Accounts {
			order[strings.TrimSpace(a.Name)] = i
			order[a.LoginID()] = i
		}
	}
	sort.SliceStable(out, func(i, j int) bool {
		oi, oki := order[out[i].AccountName]
		if !oki {
			oi, oki = order[out[i].LoginID]
		}
		if !oki {
			oi = 1 << 20
		}
		oj, okj := order[out[j].AccountName]
		if !okj {
			oj, okj = order[out[j].LoginID]
		}
		if !okj {
			oj = 1 << 20
		}
		if oi != oj {
			return oi < oj
		}
		return out[i].IP < out[j].IP
	})
	return out, synced, snaps, nil
}

func (s *Service) RestoreSnapshot(ctx context.Context, id int64, log func(string)) error {
	if id <= 0 {
		return fmt.Errorf("bad snapshot id")
	}
	if err := s.Store.RestoreBillingSnapshot(ctx, id); err != nil {
		return err
	}
	if log != nil {
		log(fmt.Sprintf("已恢复旧版 #%d", id))
	}
	return nil
}

const (
	tgLastMsgMetaKey = "billing_tg_last_msg_id"
)

// RemindManual always sends the quiet digest (same as morning report).
func (s *Service) RemindManual(ctx context.Context, log func(string)) error {
	return s.sendQuietReport(ctx, nil, log)
}

func (s *Service) SendDailyReport(ctx context.Context, syncErr error, log func(string)) error {
	return s.sendQuietReport(ctx, syncErr, log)
}

func (s *Service) sendQuietReport(ctx context.Context, syncErr error, log func(string)) error {
	cfg, err := s.LoadConfig()
	if err != nil {
		return err
	}
	if strings.TrimSpace(cfg.Telegram.BotToken) == "" || strings.TrimSpace(cfg.Telegram.ChatID) == "" {
		return fmt.Errorf("未配置 Telegram bot_token / chat_id")
	}
	body := s.buildQuietDigest(ctx, syncErr)
	silent := digestAllOK(body)
	if err := s.notifyTGHTML(ctx, tgbot.EscapeHTML(body), silent); err != nil {
		return err
	}
	if log != nil {
		if silent {
			log("tg: 已静默发送早报")
		} else {
			log("tg: 已发送早报（有声）")
		}
	}
	return nil
}

func (s *Service) notifyTG(ctx context.Context, text string, _ bool) error {
	// Failures always alert with sound.
	return s.notifyTGHTML(ctx, tgbot.EscapeHTML(strings.TrimSpace(text)), false)
}

func (s *Service) notifyTGHTML(ctx context.Context, html string, silent bool) error {
	cfg, err := s.LoadConfig()
	if err != nil {
		return err
	}
	tok := strings.TrimSpace(cfg.Telegram.BotToken)
	chat := strings.TrimSpace(cfg.Telegram.ChatID)
	if tok == "" || chat == "" {
		return nil
	}
	var prevID int64
	if raw, err := s.Store.Meta(ctx, tgLastMsgMetaKey); err == nil && raw != "" {
		prevID, _ = strconv.ParseInt(strings.TrimSpace(raw), 10, 64)
	}
	res, err := tgbot.SendOpts(ctx, tok, chat, html, true, silent)
	if err != nil {
		return err
	}
	if res.MessageID > 0 {
		_ = s.Store.SetMeta(ctx, tgLastMsgMetaKey, strconv.FormatInt(res.MessageID, 10))
	}
	if prevID > 0 && prevID != res.MessageID {
		_ = tgbot.Delete(ctx, tok, chat, prevID)
	}
	return nil
}

const autoFetchDayMetaKey = "billing_last_auto_fetch_day"

func billingLocation() *time.Location {
	loc, err := time.LoadLocation("Asia/Shanghai")
	if err != nil {
		return time.Local
	}
	return loc
}

// StartBackground: 每分钟看是否到上海时区 06:00 抓取+短早报（无 30 分钟到期扫）。
func (s *Service) StartBackground(ctx context.Context) {
	go func() {
		tick := time.NewTicker(1 * time.Minute)
		defer tick.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case now := <-tick.C:
				cctx, cancel := context.WithTimeout(ctx, 25*time.Minute)
				if err := s.maybeMorningFetch(cctx, now); err != nil {
					slog.Error("morning billing report", "err", err)
				}
				cancel()
			}
		}
	}()
}

func (s *Service) maybeMorningFetch(ctx context.Context, wall time.Time) error {
	now := wall.In(billingLocation())
	// 06:00–06:04 窗口内跑一次，避免整点错过
	if now.Hour() != 6 || now.Minute() > 4 {
		return nil
	}
	day := now.Format("2006-01-02")
	if raw, err := s.Store.Meta(ctx, autoFetchDayMetaKey); err == nil && raw == day {
		return nil
	}
	_ = s.Store.SetMeta(ctx, autoFetchDayMetaKey, day)
	// 抓取成功/失败都发短早报；可达性优先用上一次健康检查结果
	err := s.sync(ctx, func(string) {}, false, nil)
	reportErr := s.SendDailyReport(ctx, err, nil)
	return errors.Join(err, reportErr)
}

// Each attempt is one version: failed accounts get a status row, never old assets.
func failedAccountRow(account lizhi.Account, reason string, syncedAt int64) store.BillingAsset {
	return store.BillingAsset{AccountName: account.Name, LoginID: account.LoginID(),
		Status: fetchFailedStatus, Note: "请切换旧版查看。原因：" + reason, SyncedAt: syncedAt}
}
