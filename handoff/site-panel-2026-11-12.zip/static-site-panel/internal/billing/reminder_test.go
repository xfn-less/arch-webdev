package billing

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/xfn/static-site-panel/internal/lizhi"
	"github.com/xfn/static-site-panel/internal/store"
)

type testRoundTrip func(*http.Request) (*http.Response, error)

func (f testRoundTrip) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

func TestRegressionFailedTGRetried(t *testing.T) {
	ctx := context.Background()
	root := t.TempDir()
	st, err := store.Open(filepath.Join(root, "panel.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer st.Close()
	s := &Service{Store: st, AccountsPath: filepath.Join(root, "accounts.json")}
	if err := s.SaveConfig(lizhi.ConfigFile{Telegram: lizhi.Telegram{BotToken: "fake-token", ChatID: "fake-chat"}}); err != nil {
		t.Fatal(err)
	}
	if err := st.ReplaceBillingAssets(ctx, []store.BillingAsset{{IP: "192.0.2.1", IPNorm: "192.0.2.1", ExpireUnix: time.Now().Add(time.Hour).Unix()}}); err != nil {
		t.Fatal(err)
	}
	// Avoid live panel HTTP during digest (would share DefaultTransport with TG mock).
	t.Setenv("SITE_PANEL_ROOT", root)
	t.Setenv("SITE_PANEL_HEALTH_LAST", filepath.Join(root, "health-last"))
	t.Setenv("SITE_PANEL_BACKUP_DIR", filepath.Join(root, "nobackup"))
	if err := os.WriteFile(filepath.Join(root, "health-last"), []byte(strconv.FormatInt(time.Now().Unix(), 10)+"\tok\t\n"), 0o644); err != nil {
		t.Fatal(err)
	}

	old := http.DefaultTransport
	defer func() { http.DefaultTransport = old }()
	calls := 0
	http.DefaultTransport = testRoundTrip(func(r *http.Request) (*http.Response, error) {
		if !strings.Contains(r.URL.Host, "api.telegram.org") {
			return nil, fmt.Errorf("unexpected host %s", r.URL.Host)
		}
		calls++
		if calls == 1 {
			return nil, fmt.Errorf("simulated TG outage")
		}
		return &http.Response{StatusCode: 200, Body: io.NopCloser(strings.NewReader(`{"ok":true,"result":{"message_id":1}}`)), Header: make(http.Header)}, nil
	})
	if err := s.RemindManual(ctx, nil); err == nil {
		t.Fatal("expected first send failure")
	}
	if err := s.RemindManual(ctx, nil); err != nil {
		t.Fatal(err)
	}
	if calls != 2 {
		t.Fatalf("first send failed, retry did not send again: HTTP calls=%d", calls)
	}
}
