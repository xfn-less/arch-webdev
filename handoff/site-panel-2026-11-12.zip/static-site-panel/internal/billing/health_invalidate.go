package billing

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"sync"
	"time"

	"github.com/xfn/static-site-panel/internal/store"
)

var (
	healthRecheckMu   sync.Mutex
	healthRecheckFire bool
)

// InvalidateHealthStamp drops the last probe result so a stale fail (e.g. deleted
// dead host) cannot keep reporting until the next cron. Call when the managed
// server IP set changes; ScheduleHealthRecheck refreshes soon after.
func InvalidateHealthStamp(ctx context.Context, st *store.Store) {
	if p := healthLastPath(); p != "" {
		_ = os.Remove(p)
	}
	if st != nil {
		_ = st.DeleteMeta(ctx, healthLastMetaKey)
	}
}

// ScheduleHealthRecheck runs health-lizhi.sh once after a short debounce so
// rapid server edits only probe once. Missing script is a no-op (dev/tests).
func ScheduleHealthRecheck() {
	healthRecheckMu.Lock()
	already := healthRecheckFire
	healthRecheckFire = true
	healthRecheckMu.Unlock()
	if already {
		return
	}
	go func() {
		time.Sleep(2 * time.Second)
		healthRecheckMu.Lock()
		healthRecheckFire = false
		healthRecheckMu.Unlock()

		root := panelRoot()
		script := filepath.Join(root, "scripts", "health-lizhi.sh")
		if st, err := os.Stat(script); err != nil || st.IsDir() {
			return
		}
		cmd := exec.Command(script)
		cmd.Dir = root
		cmd.Env = append(os.Environ(), "SITE_PANEL_ROOT="+root)
		_ = cmd.Run()
	}()
}
