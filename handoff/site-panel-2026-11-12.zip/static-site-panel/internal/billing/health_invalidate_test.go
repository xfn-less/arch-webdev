package billing

import (
	"context"
	"os"
	"path/filepath"
	"testing"

	"github.com/xfn/static-site-panel/internal/store"
)

func TestInvalidateHealthStampRemovesFileAndMeta(t *testing.T) {
	root := t.TempDir()
	t.Setenv("SITE_PANEL_ROOT", root)
	health := filepath.Join(root, ".data", "health-last")
	if err := os.MkdirAll(filepath.Dir(health), 0o755); err != nil {
		t.Fatal(err)
	}
	t.Setenv("SITE_PANEL_HEALTH_LAST", health)
	if err := os.WriteFile(health, []byte("1\tfail\t面板异常,1.2.3.4不可达\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	st, err := store.Open(filepath.Join(root, "panel.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer st.Close()
	ctx := context.Background()
	if err := st.SetMeta(ctx, healthLastMetaKey, "1\tfail\told"); err != nil {
		t.Fatal(err)
	}

	InvalidateHealthStamp(ctx, st)

	if _, err := os.Stat(health); !os.IsNotExist(err) {
		t.Fatalf("health-last still present: %v", err)
	}
	if v, err := st.Meta(ctx, healthLastMetaKey); err == nil && v != "" {
		t.Fatalf("meta still set: %q", v)
	}
}
