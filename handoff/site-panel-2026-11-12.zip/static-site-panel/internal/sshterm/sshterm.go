package sshterm

import (
	"fmt"
	"io"
	"net"
	"os"
	"strconv"
	"time"

	"golang.org/x/crypto/ssh"

	"github.com/xfn/static-site-panel/internal/sshutil"
	"github.com/xfn/static-site-panel/internal/store"
)

// Dial opens an SSH client for the panel server record (password or key).
func Dial(s store.Server) (*ssh.Client, error) {
	client, err := dialOnce(s)
	if err == nil {
		return client, nil
	}
	if sshutil.IsAuthFailure(err) && s.AuthType == "key" && s.Password != "" {
		keyPath := s.AuthValue
		if keyPath == "" {
			keyPath = sshutil.DefaultKeyPath
		}
		if _, ensureErr := sshutil.EnsurePanelKey(keyPath); ensureErr == nil {
			if repairErr := sshutil.InstallPublicKey(s, keyPath); repairErr == nil {
				return dialOnce(s)
			} else {
				return nil, fmt.Errorf("SSH 密钥登录失败，已自动尝试重装；保存的密码可能已变更: %w", repairErr)
			}
		} else {
			return nil, fmt.Errorf("SSH 密钥登录失败，自动修复密钥失败: %w", ensureErr)
		}
	}
	if sshutil.IsAuthFailure(err) {
		return nil, fmt.Errorf("SSH 认证失败，保存的密码可能已变更；请更新服务器密码后重装密钥: %w", err)
	}
	return nil, err
}

func dialOnce(s store.Server) (*ssh.Client, error) {
	user := s.User
	if user == "" {
		user = "root"
	}
	port := s.Port
	if port == 0 {
		port = 22
	}
	var auth []ssh.AuthMethod
	usePassword := s.AuthType == "password" || (s.AuthType != "key" && s.Password != "")
	if usePassword {
		if s.Password == "" {
			return nil, fmt.Errorf("ssh password empty")
		}
		auth = append(auth, ssh.Password(s.Password))
	} else {
		keyPath := s.AuthValue
		if keyPath == "" {
			keyPath = "/www/site-panel/.ssh/id_ed25519"
		}
		key, err := os.ReadFile(keyPath)
		if err != nil {
			if s.Password != "" {
				auth = append(auth, ssh.Password(s.Password))
			} else {
				return nil, fmt.Errorf("read key: %w", err)
			}
		} else {
			signer, err := ssh.ParsePrivateKey(key)
			if err != nil {
				return nil, fmt.Errorf("parse key: %w", err)
			}
			auth = append(auth, ssh.PublicKeys(signer))
		}
	}
	hostKey, err := sshutil.HostKeyCallback()
	if err != nil {
		return nil, err
	}
	cfg := &ssh.ClientConfig{
		User:            user,
		Auth:            auth,
		HostKeyCallback: hostKey,
		Timeout:         15 * time.Second,
	}
	if s.ViaJump {
		return sshutil.DialViaJump(s, cfg)
	}
	addr := net.JoinHostPort(s.Host, strconv.Itoa(port))
	return ssh.Dial("tcp", addr, cfg)
}

// StartShell starts an interactive PTY shell on client.
func StartShell(client *ssh.Client, cols, rows int) (*ssh.Session, io.WriteCloser, io.Reader, error) {
	if cols < 20 {
		cols = 80
	}
	if rows < 10 {
		rows = 24
	}
	sess, err := client.NewSession()
	if err != nil {
		return nil, nil, nil, err
	}
	modes := ssh.TerminalModes{
		ssh.ECHO:          1,
		ssh.TTY_OP_ISPEED: 14400,
		ssh.TTY_OP_OSPEED: 14400,
	}
	if err := sess.RequestPty("xterm-256color", rows, cols, modes); err != nil {
		_ = sess.Close()
		return nil, nil, nil, err
	}
	stdin, err := sess.StdinPipe()
	if err != nil {
		_ = sess.Close()
		return nil, nil, nil, err
	}
	stdout, err := sess.StdoutPipe()
	if err != nil {
		_ = sess.Close()
		return nil, nil, nil, err
	}
	if err := sess.Shell(); err != nil {
		_ = sess.Close()
		return nil, nil, nil, err
	}
	return sess, stdin, stdout, nil
}
