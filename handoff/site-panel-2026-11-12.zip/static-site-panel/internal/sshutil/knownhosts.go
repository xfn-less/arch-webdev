package sshutil

import (
	"errors"
	"fmt"
	"net"
	"os"
	"os/exec"
	"os/user"
	"path/filepath"
	"strings"

	"golang.org/x/crypto/ssh"
	"golang.org/x/crypto/ssh/knownhosts"
)

// HostKeyCallback shares the SSH CLI's known_hosts. New hosts are recorded once;
// changed keys are refreshed automatically for the panel's single-user fleet.
func HostKeyCallback() (ssh.HostKeyCallback, error) {
	return hostKeyCallback()
}

// AutoRefreshHostKeyCallback is reserved for the password-assisted key reinstall
// flow. It replaces only the presented host:port entry when its key changed.
func AutoRefreshHostKeyCallback() (ssh.HostKeyCallback, error) {
	return HostKeyCallback()
}

func hostKeyCallback() (ssh.HostKeyCallback, error) {
	home, err := sshHomeDir()
	if err != nil {
		return nil, err
	}
	dir := filepath.Join(home, ".ssh")
	if err := os.MkdirAll(dir, 0700); err != nil {
		return nil, err
	}
	path := filepath.Join(dir, "known_hosts")
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return nil, err
	}
	if err := f.Close(); err != nil {
		return nil, err
	}
	check, err := knownhosts.New(path)
	if err != nil {
		return nil, err
	}
	return func(host string, remote net.Addr, key ssh.PublicKey) error {
		err := check(host, remote, key)
		if err == nil {
			return nil
		}
		var keyErr *knownhosts.KeyError
		if !errors.As(err, &keyErr) {
			return err
		}
		// Known host but fingerprint changed (reinstall / IP reuse) — not fail2ban.
		if len(keyErr.Want) > 0 {
			if err := replaceKnownHostKey(path, host, key); err != nil {
				return fmt.Errorf("ssh host key changed; automatic known_hosts refresh failed: %w", err)
			}
			return nil
		}
		f, err := os.OpenFile(path, os.O_APPEND|os.O_WRONLY, 0600)
		if err != nil {
			return err
		}
		_, writeErr := f.WriteString(knownhosts.Line([]string{knownhosts.Normalize(host)}, key) + "\n")
		closeErr := f.Close()
		if writeErr != nil {
			return writeErr
		}
		return closeErr
	}, nil
}

func replaceKnownHostKey(path, host string, key ssh.PublicKey) error {
	normalized := knownhosts.Normalize(host)
	// ssh-keygen understands plain and hashed known_hosts entries and preserves
	// every other host. Never rewrite the shared file by matching text ourselves.
	out, err := exec.Command("ssh-keygen", "-R", normalized, "-f", path).CombinedOutput()
	if err != nil {
		return fmt.Errorf("ssh-keygen -R: %w (%s)", err, strings.TrimSpace(string(out)))
	}
	f, err := os.OpenFile(path, os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	_, writeErr := f.WriteString(knownhosts.Line([]string{normalized}, key) + "\n")
	closeErr := f.Close()
	if writeErr != nil {
		return writeErr
	}
	return closeErr
}

// systemd services may have no HOME; the account database remains authoritative.
func sshHomeDir() (string, error) {
	if home, err := os.UserHomeDir(); err == nil && home != "" {
		return home, nil
	}
	account, err := user.Current()
	if err != nil {
		return "", err
	}
	return account.HomeDir, nil
}
