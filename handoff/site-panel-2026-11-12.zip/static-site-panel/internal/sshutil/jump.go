package sshutil

import (
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/xfn/static-site-panel/internal/store"
	"golang.org/x/crypto/ssh"
)

// Jump defaults match the panel's CN egress used by lizhi-socks.
const (
	DefaultJumpHost = "183.56.236.235"
	DefaultJumpUser = "root"
	DefaultJumpKey  = "/www/site-panel/.ssh/lizhi-socks_ed25519"
)

type JumpConfig struct {
	Host string
	User string
	Key  string
}

func JumpFromEnv() JumpConfig {
	host := strings.TrimSpace(os.Getenv("SSP_JUMP_HOST"))
	if host == "" {
		host = DefaultJumpHost
	}
	user := strings.TrimSpace(os.Getenv("SSP_JUMP_USER"))
	if user == "" {
		user = DefaultJumpUser
	}
	key := strings.TrimSpace(os.Getenv("SSP_JUMP_IDENTITY"))
	if key == "" {
		key = DefaultJumpKey
	}
	return JumpConfig{Host: host, User: user, Key: key}
}

// CLIProxyCommand is an OpenSSH ProxyCommand that dials %h:%p via the jump host.
// Safe to embed in `ssh -o ProxyCommand=...` when jump is configured.
func (j JumpConfig) CLIProxyCommand() string {
	// OpenSSH runs ProxyCommand via the shell. Do not embed shell quotes here:
	// rsync -e already shell-quotes the whole -o ProxyCommand=… argv, and nested
	// quotes turned the identity path into …ed25519' (file not found).
	key := strings.TrimSpace(j.Key)
	user := strings.TrimSpace(j.User)
	host := strings.TrimSpace(j.Host)
	return fmt.Sprintf(
		"ssh -i %s -W %%h:%%p -o BatchMode=yes -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new -o ConnectTimeout=15 %s@%s",
		key, user, host,
	)
}

func (j JumpConfig) configured() bool {
	return j.Host != "" && j.User != "" && j.Key != ""
}

// TCPViaJump opens a raw TCP connection to host:port through the CN jump.
func TCPViaJump(host string, port int) (net.Conn, error) {
	j := JumpFromEnv()
	if !j.configured() {
		return nil, fmt.Errorf("jump not configured")
	}
	if port <= 0 {
		port = 22
	}
	jumpAuth, err := privateKeyAuth(j.Key)
	if err != nil {
		return nil, fmt.Errorf("jump key: %w", err)
	}
	jumpHostKey, err := AutoRefreshHostKeyCallback()
	if err != nil {
		return nil, err
	}
	jumpCfg := &ssh.ClientConfig{
		User:            j.User,
		Auth:            []ssh.AuthMethod{jumpAuth},
		HostKeyCallback: jumpHostKey,
		Timeout:         15 * time.Second,
	}
	jumpClient, err := ssh.Dial("tcp", net.JoinHostPort(j.Host, "22"), jumpCfg)
	if err != nil {
		return nil, fmt.Errorf("ssh dial jump: %w", err)
	}
	conn, err := jumpClient.Dial("tcp", net.JoinHostPort(host, strconv.Itoa(port)))
	if err != nil {
		_ = jumpClient.Close()
		return nil, err
	}
	return &jumpConn{Conn: conn, jump: jumpClient}, nil
}

type jumpConn struct {
	net.Conn
	jump *ssh.Client
}

func (c *jumpConn) Close() error {
	err := c.Conn.Close()
	_ = c.jump.Close()
	return err
}

// DialViaJump opens an SSH client to s by first dialing the panel CN jump host.
func DialViaJump(s store.Server, targetCfg *ssh.ClientConfig) (*ssh.Client, error) {
	j := JumpFromEnv()
	if !j.configured() {
		return nil, fmt.Errorf("jump not configured")
	}
	jumpAuth, err := privateKeyAuth(j.Key)
	if err != nil {
		return nil, fmt.Errorf("jump key: %w", err)
	}
	jumpHostKey, err := AutoRefreshHostKeyCallback()
	if err != nil {
		return nil, err
	}
	jumpCfg := &ssh.ClientConfig{
		User:            j.User,
		Auth:            []ssh.AuthMethod{jumpAuth},
		HostKeyCallback: jumpHostKey,
		Timeout:         15 * time.Second,
	}
	jumpClient, err := ssh.Dial("tcp", net.JoinHostPort(j.Host, "22"), jumpCfg)
	if err != nil {
		return nil, fmt.Errorf("ssh dial jump: %w", err)
	}

	port := s.Port
	if port == 0 {
		port = 22
	}
	addr := net.JoinHostPort(s.Host, strconv.Itoa(port))
	conn, err := jumpClient.Dial("tcp", addr)
	if err != nil {
		_ = jumpClient.Close()
		return nil, fmt.Errorf("ssh dial target via jump: %w", err)
	}
	clientConn, chans, reqs, err := ssh.NewClientConn(conn, addr, targetCfg)
	if err != nil {
		_ = conn.Close()
		_ = jumpClient.Close()
		return nil, fmt.Errorf("ssh handshake via jump: %w", err)
	}
	client := ssh.NewClient(clientConn, chans, reqs)
	// Keep jumpClient open for the lifetime of the target client.
	go func() {
		_ = client.Wait()
		_ = jumpClient.Close()
	}()
	return client, nil
}
