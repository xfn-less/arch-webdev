package sshutil

import (
	"crypto/ed25519"
	"crypto/rand"
	"net"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"golang.org/x/crypto/ssh"
)

func TestMissingPublicKeyDoesNotRotatePrivateKey(t *testing.T) {
	path := filepath.Join(t.TempDir(), "id_ed25519")
	if _, err := EnsurePanelKey(path); err != nil {
		t.Fatal(err)
	}
	before, _ := os.ReadFile(path)
	os.Remove(path + ".pub")
	if _, err := EnsurePanelKey(path); err != nil {
		t.Fatal(err)
	}
	after, _ := os.ReadFile(path)
	if string(before) != string(after) {
		t.Fatal("private identity rotated")
	}
}

func TestHostKeyChangesAutomaticallyRefreshed(t *testing.T) {
	t.Setenv("HOME", t.TempDir())
	makeKey := func() ssh.PublicKey {
		pub, _, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			t.Fatal(err)
		}
		key, err := ssh.NewPublicKey(pub)
		if err != nil {
			t.Fatal(err)
		}
		return key
	}
	key := makeKey()
	addr := &net.TCPAddr{IP: net.ParseIP("192.0.2.1"), Port: 22}
	check, err := HostKeyCallback()
	if err != nil {
		t.Fatal(err)
	}
	if err := check("test.example:22", addr, key); err != nil {
		t.Fatal(err)
	}
	check, err = HostKeyCallback()
	if err != nil {
		t.Fatal(err)
	}
	if err := check("test.example:22", addr, key); err != nil {
		t.Fatal(err)
	}
	rotated := makeKey()
	if err := check("test.example:22", addr, rotated); err != nil {
		t.Fatalf("changed host key was not refreshed: %v", err)
	}
	check, err = HostKeyCallback()
	if err != nil {
		t.Fatal(err)
	}
	if err := check("test.example:22", addr, rotated); err != nil {
		t.Fatalf("refreshed host key was not persisted: %v", err)
	}
}

func TestSystemdHomeFallback(t *testing.T) {
	t.Setenv("HOME", "")
	home, err := sshHomeDir()
	if err != nil || !filepath.IsAbs(home) {
		t.Fatalf("cannot resolve account home without HOME: %q %v", home, err)
	}
}

func TestInstallKeyScriptEnablesPubkey(t *testing.T) {
	script := installKeyAndEnablePubkeyScript("ssh-ed25519 AAAA test")
	for _, need := range []string{
		"PubkeyAuthentication yes",
		"00-site-panel-pubkey.conf",
		"sshd -t",
		"authorized_keys",
		"PreferredAuthentications", // must NOT force pubkey-only during password install
	} {
		if need == "PreferredAuthentications" {
			if strings.Contains(script, need) {
				t.Fatalf("password install script must not set %s", need)
			}
			continue
		}
		if !strings.Contains(script, need) {
			t.Fatalf("script missing %q", need)
		}
	}
}
