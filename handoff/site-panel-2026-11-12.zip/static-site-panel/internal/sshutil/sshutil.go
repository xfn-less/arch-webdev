package sshutil

import (
	"crypto/ed25519"
	"crypto/rand"
	"encoding/pem"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/xfn/static-site-panel/internal/store"
	"golang.org/x/crypto/ssh"
)

const DefaultKeyPath = "/www/site-panel/.ssh/id_ed25519"

// EnsurePanelKey creates an ed25519 keypair if missing; returns private key path.
func EnsurePanelKey(keyPath string) (string, error) {
	if keyPath == "" {
		keyPath = DefaultKeyPath
	}
	if err := os.MkdirAll(filepath.Dir(keyPath), 0o700); err != nil {
		return "", err
	}
	if raw, err := os.ReadFile(keyPath); err == nil {
		signer, err := ssh.ParsePrivateKey(raw)
		if err != nil {
			return "", fmt.Errorf("existing deployment key is invalid: %w", err)
		}
		// Recover the public half from the original identity; never silently rotate it.
		if _, err := os.Stat(keyPath + ".pub"); os.IsNotExist(err) {
			if err := os.WriteFile(keyPath+".pub", ssh.MarshalAuthorizedKey(signer.PublicKey()), 0644); err != nil {
				return "", err
			}
		} else if err != nil {
			return "", err
		}
		return keyPath, nil
	} else if !os.IsNotExist(err) {
		return "", err
	}

	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return "", err
	}
	block, err := ssh.MarshalPrivateKey(priv, "panel")
	if err != nil {
		return "", err
	}
	if err := os.WriteFile(keyPath, pem.EncodeToMemory(block), 0o600); err != nil {
		return "", err
	}
	pub, err := ssh.NewPublicKey(priv.Public().(ed25519.PublicKey))
	if err != nil {
		return "", err
	}
	pubLine := strings.TrimSpace(string(ssh.MarshalAuthorizedKey(pub))) + " panel@site-panel\n"
	if err := os.WriteFile(keyPath+".pub", []byte(pubLine), 0o644); err != nil {
		return "", err
	}
	return keyPath, nil
}

func ReadPublicKey(keyPath string) (string, error) {
	b, err := os.ReadFile(keyPath + ".pub")
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(string(b)), nil
}

func dialSSH(s store.Server, auth ...ssh.AuthMethod) (*ssh.Client, error) {
	return dialSSHWithHostKey(s, HostKeyCallback, auth...)
}

func dialSSHWithHostKey(s store.Server, callbackFactory func() (ssh.HostKeyCallback, error), auth ...ssh.AuthMethod) (*ssh.Client, error) {
	port := s.Port
	if port == 0 {
		port = 22
	}
	user := s.User
	if user == "" {
		user = "root"
	}
	hostKey, err := callbackFactory()
	if err != nil {
		return nil, err
	}
	cfg := &ssh.ClientConfig{
		User:            user,
		Auth:            auth,
		HostKeyCallback: hostKey,
		Timeout:         15 * time.Second,
	}
	if s.ViaJump {
		return DialViaJump(s, cfg)
	}
	return ssh.Dial("tcp", fmt.Sprintf("%s:%d", s.Host, port), cfg)
}

func privateKeyAuth(privateKeyPath string) (ssh.AuthMethod, error) {
	raw, err := os.ReadFile(privateKeyPath)
	if err != nil {
		return nil, err
	}
	signer, err := ssh.ParsePrivateKey(raw)
	if err != nil {
		return nil, err
	}
	return ssh.PublicKeys(signer), nil
}

// AuthFailureError marks an SSH authentication rejection (or a failed
// password-assisted key repair). APIs can surface errorCode=ssh_auth without
// scraping localized error text in the browser.
type AuthFailureError struct {
	Msg string
	Err error
}

func (e *AuthFailureError) Error() string {
	if e == nil {
		return ""
	}
	if e.Msg != "" && e.Err != nil {
		return e.Msg + ": " + e.Err.Error()
	}
	if e.Msg != "" {
		return e.Msg
	}
	if e.Err != nil {
		return e.Err.Error()
	}
	return "SSH 认证失败"
}

func (e *AuthFailureError) Unwrap() error {
	if e == nil {
		return nil
	}
	return e.Err
}

// IsAuthFailure identifies SSH authentication rejection so callers can offer
// the password-assisted key repair path without retrying network failures.
func IsAuthFailure(err error) bool {
	if err == nil {
		return false
	}
	var auth *AuthFailureError
	if errors.As(err, &auth) {
		return true
	}
	msg := strings.ToLower(err.Error())
	return strings.Contains(msg, "unable to authenticate") || strings.Contains(msg, "permission denied (")
}

// installKeyAndEnablePubkeyScript appends the panel pubkey, then turns on sshd pubkey auth.
func installKeyAndEnablePubkeyScript(pub string) string {
	return strings.TrimSpace(`
set -euo pipefail
mkdir -p ~/.ssh && chmod 700 ~/.ssh
touch ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys
PUB=`+shellQuote(pub)+`
grep -qxF "$PUB" ~/.ssh/authorized_keys || echo "$PUB" >> ~/.ssh/authorized_keys

# sshd takes the first PubkeyAuthentication value. Flip any active "no", then
# drop an early Include snippet so fresh images that omit the directive still allow keys.
CONF_D=/etc/ssh/sshd_config.d
if [ -d "$CONF_D" ]; then
  printf '%s\n' 'PubkeyAuthentication yes' 'AuthorizedKeysFile .ssh/authorized_keys' >"$CONF_D/00-site-panel-pubkey.conf"
fi
for f in /etc/ssh/sshd_config "$CONF_D"/*.conf; do
  [ -f "$f" ] || continue
  if grep -qiE '^[[:space:]]*PubkeyAuthentication[[:space:]]+no([[:space:]]|$)' "$f"; then
    sed -i -E 's/^([[:space:]]*)PubkeyAuthentication[[:space:]]+[Nn][Oo]/\1PubkeyAuthentication yes/' "$f"
  fi
done

if command -v sshd >/dev/null 2>&1; then
  sshd -t
fi
if systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null \
  || service ssh reload 2>/dev/null || service sshd reload 2>/dev/null; then
  :
elif command -v sshd >/dev/null 2>&1; then
  pkill -HUP -x sshd 2>/dev/null || pkill -HUP sshd 2>/dev/null || true
fi
echo "pubkey ready"
`) + "\n"
}

// InstallPublicKey SSHs with password only, appends the panel pubkey, enables
// sshd PubkeyAuthentication when needed, then verifies key login works.
func InstallPublicKey(s store.Server, privateKeyPath string) error {
	if strings.TrimSpace(s.Password) == "" {
		return fmt.Errorf("ssh password required")
	}
	pub, err := ReadPublicKey(privateKeyPath)
	if err != nil {
		return err
	}
	// The key-reinstall path also refreshes this server's host key if it changed.
	client, err := dialSSHWithHostKey(s, AutoRefreshHostKeyCallback, ssh.Password(s.Password))
	if err != nil {
		if IsAuthFailure(err) {
			return fmt.Errorf("SSH 密码认证失败，保存的密码可能已变更；更新服务器密码后再重装密钥: %w", err)
		}
		return fmt.Errorf("ssh dial (password): %w", err)
	}
	defer client.Close()

	session, err := client.NewSession()
	if err != nil {
		return err
	}
	out, err := session.CombinedOutput(installKeyAndEnablePubkeyScript(pub))
	_ = session.Close()
	if err != nil {
		return fmt.Errorf("remote: %w (%s)", err, strings.TrimSpace(string(out)))
	}

	keyAuth, err := privateKeyAuth(privateKeyPath)
	if err != nil {
		return fmt.Errorf("local key: %w", err)
	}
	// Brief pause so reload finishes accepting new connections.
	time.Sleep(500 * time.Millisecond)
	verify, err := dialSSH(s, keyAuth)
	if err != nil {
		return fmt.Errorf("密钥已写入且已尝试打开 PubkeyAuthentication，但密钥登录仍失败: %w", err)
	}
	defer verify.Close()
	vs, err := verify.NewSession()
	if err != nil {
		return fmt.Errorf("密钥登录会话失败: %w", err)
	}
	defer vs.Close()
	if out, err := vs.CombinedOutput("echo ok"); err != nil || !strings.Contains(string(out), "ok") {
		return fmt.Errorf("密钥登录校验失败: %w (%s)", err, strings.TrimSpace(string(out)))
	}
	return nil
}

func shellQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'"
}
