package sshutil

import (
	"strings"
	"testing"
)

func TestCLIProxyCommandNoNestedQuotes(t *testing.T) {
	j := JumpConfig{Host: "183.56.236.235", User: "root", Key: "/www/site-panel/.ssh/lizhi-socks_ed25519"}
	cmd := j.CLIProxyCommand()
	if !strings.Contains(cmd, "-W %h:%p") {
		t.Fatal(cmd)
	}
	if strings.Contains(cmd, "'") {
		t.Fatalf("nested quotes break rsync -e: %s", cmd)
	}
	if !strings.Contains(cmd, "-i /www/site-panel/.ssh/lizhi-socks_ed25519 ") {
		t.Fatal(cmd)
	}
	if !strings.Contains(cmd, " root@183.56.236.235") {
		t.Fatal(cmd)
	}
}
