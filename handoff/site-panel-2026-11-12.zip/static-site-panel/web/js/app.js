import van from "../vendor/van-1.6.1.js"
import { api, setCsrf, setUnauthorizedHandler } from "./api.js"

const { div, button, input, textarea, label, span, h1, p, select, option, a, pre } = van.tags

/** Lucide icon names used in UI */
const LUCIDE = {
  sun: "sun",
  moon: "moon",
  monitor: "monitor",
  plus: "plus",
  server: "server",
  globe: "globe",
  copy: "copy",
  cut: "scissors",
  paste: "clipboard-paste",
  trash: "trash-2",
  save: "save",
  rocket: "rocket",
  lock: "lock",
  unlock: "lock-open",
  refresh: "refresh-cw",
  key: "key",
  shield: "shield",
  package: "package",
  clock: "clock",
  home: "home",
  play: "play",
  pause: "pause",
  terminal: "terminal",
  logout: "log-out",
  menu: "menu",
  close: "x",
  pen: "pencil",
  file: "file",
  filePlus: "file-plus",
  folder: "folder",
  folderPlus: "folder-plus",
  upload: "upload",
  download: "download",
  zip: "file-archive",
  unzip: "folder-open",
  pin: "pin",
  bell: "bell",
  comment: "message-square-code",
  list: "list",
  back: "arrow-left",
  more: "ellipsis",
  expand: "chevron-up",
  collapse: "chevron-down",
  dropdown: "chevrons-up-down",
}

/** One rAF batch for Lucide — per-icon createIcons was ~O(sites×actions) and froze overview. */
const lucidePending = []
let lucideFlushOn = false
function flushLucideIcons() {
  lucideFlushOn = false
  if (!window.lucide || !lucidePending.length) return
  const nodes = lucidePending.splice(0, lucidePending.length).filter((n) => n.isConnected)
  if (!nodes.length) return
  window.lucide.createIcons({ nodes, attrs: { "stroke-width": 1.75 } })
}
function scheduleLucideFlush() {
  if (lucideFlushOn) return
  lucideFlushOn = true
  requestAnimationFrame(flushLucideIcons)
}
function ico(name) {
  if (name === "android") return androidIco()
  const wrap = span({ class: "ico" })
  const i = document.createElement("i")
  i.setAttribute("data-lucide", LUCIDE[name] || name)
  wrap.appendChild(i)
  lucidePending.push(i)
  scheduleLucideFlush()
  return wrap
}

/** Lucide has no Android mark — inline robot for 过apk. */
function androidIco() {
  const wrap = span({ class: "ico ico-android", "aria-hidden": "true" })
  wrap.innerHTML =
    '<svg viewBox="0 0 24 24" width="1em" height="1em" fill="currentColor" focusable="false">' +
    '<path d="M17.6 9.48l1.84-3.18a.5.5 0 0 0-.87-.5l-1.9 3.29A8.1 8.1 0 0 0 12 8c-1.6 0-3.07.46-4.32 1.25L5.78 5.96a.5.5 0 1 0-.87.5L6.75 9.64C4.5 11.1 3 13.65 3 16.5h18c0-2.85-1.5-5.4-3.4-6.86zM9 14.25a1 1 0 1 1 0-2 1 1 0 0 1 0 2zm6 0a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"/>' +
    "</svg>"
  return wrap
}

function apkOn() {
  return !!(state.siteMeta.val && state.siteMeta.val.meta && state.siteMeta.val.meta.apkObfuscate)
}

function apkToggleBtn(siteName, opts = {}) {
  const { className = "editor-head-btn editor-head-apk", showLabel = true } = opts
  return button(
    {
      type: "button",
      class: () => className + (apkOn() ? " on accent" : ""),
      title: "过apk：部署后立刻混淆并装 30 分钟定时；关则卸定时",
      "aria-label": "过apk",
      "aria-pressed": () => (apkOn() ? "true" : "false"),
      disabled: () => state.busy.val,
      onclick: () => setApkObfuscate(siteName, !apkOn()),
    },
    ico("android"),
    ...(showLabel ? ["过apk"] : []),
  )
}
/** Load Lucide after first paint so overview HTML is not blocked on ~350KB icons. */
function ensureLucide() {
  if (window.lucide) {
    scheduleLucideFlush()
    return Promise.resolve()
  }
  if (ensureLucide._p) return ensureLucide._p
  ensureLucide._p = new Promise((resolve, reject) => {
    const s = document.createElement("script")
    s.src = "/vendor/lucide/lucide.min.js"
    s.async = true
    s.onload = () => {
      scheduleLucideFlush()
      resolve()
    }
    s.onerror = () => reject(new Error("lucide load failed"))
    document.head.appendChild(s)
  })
  return ensureLucide._p
}


function loadScriptOnce(src) {
  return new Promise((resolve, reject) => {
    if ([...document.scripts].some((s) => s.src && s.src.endsWith(src))) return resolve()
    const el = document.createElement("script")
    el.src = src
    el.async = false
    el.onload = () => resolve()
    el.onerror = () => reject(new Error("script " + src))
    document.head.appendChild(el)
  })
}
function loadStyleOnce(href) {
  if ([...document.querySelectorAll("link[rel=stylesheet]")].some((l) => l.href && l.href.endsWith(href))) return
  const el = document.createElement("link")
  el.rel = "stylesheet"
  el.href = href
  document.head.appendChild(el)
}
function setHighlightTheme(theme) {
  const dark = theme !== "light"
  document.querySelectorAll("link[data-hljs-theme]").forEach((l) => l.remove())
  const el = document.createElement("link")
  el.rel = "stylesheet"
  el.href = dark ? "/vendor/highlightjs/github-dark.min.css" : "/vendor/highlightjs/github.min.css"
  el.dataset.hljsTheme = dark ? "dark" : "light"
  document.head.appendChild(el)
}
/** CodeJar + highlight.js only when opening a text editor. */
function ensureLiteEditor() {
  if (ensureLiteEditor._p) return ensureLiteEditor._p
  ensureLiteEditor._p = (async () => {
    setHighlightTheme(state.theme.rawVal === "light" ? "light" : "dark")
    await loadScriptOnce("/vendor/highlightjs/highlight.min.js")
    await loadScriptOnce("/vendor/highlightjs/nginx.min.js")
    const mod = await import("/vendor/codejar/codejar.js")
    ensureLiteEditor.CodeJar = mod.CodeJar
  })()
  return ensureLiteEditor._p
}

/** Plain-text secret field (always visible). props: value, oninput, placeholder, class, style, autocomplete */
function PasswordField(props = {}) {
  const {
    value,
    oninput,
    placeholder,
    class: className,
    style,
    autocomplete = "off",
  } = props
  return input({
    class: className || undefined,
    style,
    type: "text",
    autocomplete,
    spellcheck: "false",
    placeholder,
    value,
    oninput,
  })
}

function resolveTheme(mode) {
  if (mode === "light" || mode === "dark") return mode
  return window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark"
}

const savedMode = ["auto", "light", "dark"].includes(localStorage.getItem("ssp-theme"))
  ? localStorage.getItem("ssp-theme")
  : "auto"

const state = {
  boot: van.state(true),
  authed: van.state(false),
  hasPassword: van.state(false),
  securityOpen: van.state(false),
  chromeMenuOpen: van.state(false),
  tree: van.state(null),
  sel: van.state(null),
  serverForm: van.state(null), // draft while server dialog open
  serverDlgOpen: van.state(false),
  siteMeta: van.state(null),
  /** Own flag (like fsDirty): saved master changes not yet deployed → 部署 red dot. */
  deployPending: van.state(false),
  logs: van.state([]),
  themeMode: van.state(savedMode),
  theme: van.state(resolveTheme(savedMode)),
  busy: van.state(false),
  error: van.state(""),
  sitesRoot: van.state(""),
  fsDir: van.state(""),
  fsEntries: van.state([]),
  fsFile: van.state(""),
  fsText: van.state(""),
  fsDirty: van.state(false),
  fsRev: van.state(0),
  fsSelected: van.state([]), // multi-select paths in current dir
  fsSelectMode: van.state(false), // mobile / explicit multi-select
  fsKind: van.state("empty"), // empty | text | image | zip | binary
  fsZipEntries: van.state([]),
  copyPick: van.state(null), // site name when picking target IP
  ctxMenu: van.state(null), // { x, y, site, entry|null, targets? }
  dialog: van.state(null), // custom modal { kind, title, message, value?, resolve }
  // SSL dialog shell (stable while check runs): { name, preferForce }
  sslDlg: van.state(null),
  // SSL check pane only: { phase: "loading"|"ready", pre, error }
  sslCheck: van.state(null),
  sslDlgBusy: van.state(false),
  // cross-site clipboard: { mode:"copy"|"cut", site, paths:string[], labels:string[] }
  clip: van.state(null),
  // log panel height steps: 0=3 lines, 1=default expanded, 2+=taller
  logStep: van.state(1),
  billing: van.state(null), // { rows, syncedAt, accountsPath, snapshots, snapshotId }
  billingSnapId: van.state(0), // 0 = current
  billingDaysSort: van.state(""), // default account order | asc | desc
  billingAcctOpen: van.state(false),
  billingAcct: van.state(null), // editable config
}

/** In-place PEM draft so SSL dialog textareas do not remount on state updates. */
let sslManualDraft = { fullchain: "", key: "" }
let sslAbort = null

function applyTheme() {
  const resolved = resolveTheme(state.themeMode.val)
  state.theme.val = resolved
  document.documentElement.setAttribute("data-theme", resolved)
  localStorage.setItem("ssp-theme", state.themeMode.val)
  if (window.hljs) setHighlightTheme(resolved)
}

function cycleTheme() {
  const order = ["auto", "light", "dark"]
  const i = order.indexOf(state.themeMode.val)
  state.themeMode.val = order[(i + 1) % order.length]
  applyTheme()
}

applyTheme()
window.matchMedia("(prefers-color-scheme: light)").addEventListener("change", () => {
  if (state.themeMode.val === "auto") applyTheme()
})

/*
  Hash routes (bookmark / share / back-forward):
    #/                      → sites overview (home)
    #/sites                 → sites overview (alias)
    #/billing               → renewal table
    #/sites/{siteName}      → focus site (alias of #/site/…)
    #/s/{serverId}          → overview + server dialog (legacy deep link)
    #/site/{siteName}
    #/site/{siteName}/path/to/file-or-dir
*/
let routeLock = false
let routeReady = false
/** Hash/popstate arrived while applyRoute held the lock — re-run after unlock. */
let routeNavQueued = false

function encodePathSegments(path) {
  if (!path) return ""
  return String(path)
    .split("/")
    .filter((p) => p !== "")
    .map(encodeURIComponent)
    .join("/")
}

function encodeRoute() {
  const sel = state.sel.val
  if (!sel || sel.type === "sites") return "#/"
  if (sel.type === "billing") return "#/billing"
  // Server editing is a dialog now; no #/s/ page route while browsing.
  if (sel.type === "site") {
    const base = `#/site/${encodeURIComponent(sel.name)}`
    const path = state.fsFile.val || state.fsDir.val || ""
    if (!path) return base
    return `${base}/${encodePathSegments(path)}`
  }
  return "#/"
}

function parseRoute(hash) {
  let raw = hash || ""
  if (raw.startsWith("#")) raw = raw.slice(1)
  if (!raw || raw === "/") return { type: "sites" }
  const parts = raw.split("/").filter((p) => p !== "")
  const dec = parts.map((p) => {
    try {
      return decodeURIComponent(p)
    } catch {
      return p
    }
  })
  if (dec[0] === "billing") return { type: "billing" }
  if (dec[0] === "sites") {
    if (dec[1]) return { type: "site", name: dec[1], path: dec.slice(2).join("/") }
    return { type: "sites" }
  }
  if (dec[0] === "s" && dec[1]) {
    const id = Number(dec[1])
    if (!Number.isFinite(id) || id <= 0) return { type: "sites" }
    return { type: "server", id }
  }
  if (dec[0] === "site" && dec[1]) {
    return { type: "site", name: dec[1], path: dec.slice(2).join("/") }
  }
  return { type: "sites" }
}

function syncRoute({ replace = false } = {}) {
  if (!routeReady || routeLock) return
  const next = encodeRoute()
  const cur = location.hash || "#/"
  if (cur === next) return
  if (replace) history.replaceState(null, "", next)
  else history.pushState(null, "", next)
}

/** Open server editor as a dialog (no dedicated IP page). */
async function openServerDlg(s) {
  if (!s) return false
  state.serverForm.val = { ...s, note: s.note || s.name || "" }
  state.serverDlgOpen.val = true
  return true
}

async function selectServer(s, { replaceRoute = false } = {}) {
  void replaceRoute
  return openServerDlg(s)
}

function closeServerDlg() {
  state.serverDlgOpen.val = false
  state.serverForm.val = null
}

async function applyRoute({ replace = true } = {}) {
  if (!state.authed.val || !state.tree.val) return
  const r = parseRoute(location.hash)
  routeLock = true
  routeNavQueued = false
  try {
    if (r.type === "billing") {
      const cur = state.sel.val
      if (cur && cur.type === "billing") {
        await loadBilling()
        return
      }
      if (!(await confirmDiscard())) {
        history.replaceState(null, "", encodeRoute())
        return
      }
      state.sel.val = { type: "billing" }
      closeServerDlg()
      state.siteMeta.val = null
      state.deployPending.val = false
      await loadBilling()
      return
    }
    if (r.type === "sites" || r.type === "home") {
      const cur = state.sel.val
      if (cur && cur.type === "sites") {
        return
      }
      if (!(await confirmDiscard())) {
        history.replaceState(null, "", encodeRoute())
        return
      }
      if (cur && cur.type === "site" && cur.name) overviewFocusSite = cur.name
      state.sel.val = { type: "sites" }
      closeServerDlg()
      state.siteMeta.val = null
      state.deployPending.val = false
      state.fsFile.val = ""
      state.fsDir.val = ""
      return
    }
    if (r.type === "server") {
      // Legacy #/s/{id}: stay on overview and open the server dialog.
      const t = state.tree.val
      const s = (t.servers || []).find((x) => x.id === r.id)
      if (!s) {
        pushLog(`路由：服务器 #${r.id} 不存在`, "err")
        history.replaceState(null, "", "#/")
        return
      }
      if (!(await confirmDiscard())) {
        history.replaceState(null, "", encodeRoute())
        return
      }
      state.sel.val = { type: "sites" }
      state.siteMeta.val = null
      state.deployPending.val = false
      state.fsFile.val = ""
      state.fsDir.val = ""
      await openServerDlg(s)
      history.replaceState(null, "", "#/")
      return
    }
    if (r.type === "site") {
      const cur = state.sel.val
      const sameSite = cur && cur.type === "site" && cur.name === r.name
      const want = r.path || ""
      const have = state.fsFile.val || state.fsDir.val || ""
      if (sameSite && have === want) {
        return
      }
      if (!(await confirmDiscard())) {
        history.replaceState(null, "", encodeRoute())
        return
      }
      await openSite(r.name, {
        skipDefaultFile: !!want,
        focusPath: want || "",
        sync: false,
        fromRoute: true,
      })
    }
  } finally {
    routeLock = false
    if (replace) {
      const normalized = encodeRoute()
      if ((location.hash || "#/") !== normalized) history.replaceState(null, "", normalized)
    }
    if (routeNavQueued) {
      routeNavQueued = false
      applyRoute({ replace: false })
    }
  }
}

function logClock(d = new Date()) {
  const p = (n) => String(n).padStart(2, "0")
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
}

let logFlashTimer = 0
function flashLogs(kind) {
  const el = document.querySelector(".logs")
  if (!el) return
  el.classList.remove("flash", "flash-ok", "flash-err")
  // Retrigger CSS animation when lines arrive in a burst.
  void el.offsetWidth
  const cls = kind === "err" ? "flash-err" : kind === "ok" ? "flash-ok" : "flash"
  el.classList.add(cls)
  clearTimeout(logFlashTimer)
  logFlashTimer = setTimeout(() => {
    el.classList.remove("flash", "flash-ok", "flash-err")
  }, 900)
}

function pushLog(line, kind = "") {
  const text = line == null ? "" : typeof line === "string" ? line : String(line)
  state.logs.val = [...state.logs.val.slice(-499), { t: logClock(), line: text, kind: kind || "" }]
  flashLogs(kind || "")
}

function closeDialog(result) {
  const d = state.dialog.val
  if (!d) return
  state.dialog.val = null
  d.resolve(result)
}

function dlgAlert(message, title = "提示") {
  return new Promise((resolve) => {
    state.dialog.val = { kind: "alert", title, message, resolve }
  })
}

function dlgConfirm(message, title = "确认", {
  confirmLabel = "确定",
  cancelLabel = "取消",
  disableEnter = false,
  confirmFirst = false,
  danger = false,
} = {}) {
  return new Promise((resolve) => {
    state.dialog.val = { kind: "confirm", title, message, confirmLabel, cancelLabel, disableEnter, confirmFirst, danger, resolve }
  })
}

/** @returns {Promise<string|null>} null = cancel */
function dlgPrompt(message, def = "", title = "输入", { multiline = false, password = false } = {}) {
  return new Promise((resolve) => {
    state.dialog.val = {
      kind: "prompt",
      title,
      message,
      value: def == null ? "" : String(def),
      multiline: !!multiline,
      password: !!password,
      resolve,
    }
  })
}

/**
 * Multi-option dialog. options: [{ value, label, accent? }]
 * @returns {Promise<any|null>} selected value, or null if cancelled
 */
function dlgChoice(message, title = "选择", options = []) {
  return new Promise((resolve) => {
    state.dialog.val = {
      kind: "choice",
      title,
      message,
      options: Array.isArray(options) ? options : [],
      resolve,
    }
  })
}

/** @returns {Promise<boolean>} true if user copied */
function dlgSnippet(title, tip, body) {
  return new Promise((resolve) => {
    state.dialog.val = { kind: "snippet", title, tip: tip || "", body: body || "", resolve }
  })
}

async function copyText(text) {
  const s = String(text || "")
  if (navigator.clipboard && navigator.clipboard.writeText) {
    await navigator.clipboard.writeText(s)
    return
  }
  const ta = document.createElement("textarea")
  ta.value = s
  ta.setAttribute("readonly", "")
  ta.style.position = "fixed"
  ta.style.left = "-9999px"
  document.body.appendChild(ta)
  ta.select()
  document.execCommand("copy")
  ta.remove()
}

const NGINX_SNIPPET_1 = `    # 片段1：接口反代 + 静态（粘贴前先注释掉默认 location /，按需改路径/端口）
    # 宽松默认：大图/客服上传不轻易被网关掐断；Connection 写死 upgrade，不依赖主 conf 的 map
    location ~ ^/(api|uploads|chat-api|account|account-api|live)(/|$) {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_connect_timeout 120s;
        proxy_send_timeout 3600s;
        proxy_read_timeout 3600s;
        proxy_buffering off;
        proxy_request_buffering off;
        proxy_cache off;
        client_max_body_size 100m;
    }

    location ~* \\.(html?|js|mjs|css|gif|jpe?g|png|bmp|webp|avif|svg|ico|woff2?|ttf)$ {
        try_files $uri =404;
        expires off;
        add_header Cache-Control "no-cache";
    }

    location / {
        try_files $uri $uri/ /index.html;
        expires off;
        add_header Cache-Control "no-cache";
    }`

const NGINX_SNIPPET_2 = `    # 片段2：全站反代 — 粘贴前删掉或注释掉原来的 location /，并改端口
    # 宽松默认：大上传/长连接；Connection 写死 upgrade，不依赖主 conf 的 map
    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_connect_timeout 120s;
        proxy_send_timeout 3600s;
        proxy_read_timeout 3600s;
        proxy_buffering off;
        proxy_request_buffering off;
        proxy_cache off;
        client_max_body_size 100m;
    }`

async function showNginxSnippet(which) {
  const one = which === 1
  const ok = await dlgSnippet(
    one ? "片段1 · 接口反代" : "片段2 · 全站反代",
    one
      ? "复制后：先注释掉默认 location /，再粘贴本段（改 API 路径和端口）。纯静态站不用贴。"
      : "复制后：先注释/删除原来的 location /，再粘贴本段（改 upstream 端口）。",
    one ? NGINX_SNIPPET_1 : NGINX_SNIPPET_2,
  )
  if (ok) pushLog(one ? "已复制片段1" : "已复制片段2", "ok")
}

function DialogHost() {
  return () => {
    const d = state.dialog.val
    if (!d) return div({ class: "dlg-layer off" })
    const draft = van.state(d.value || "")
    const finish = (v) => closeDialog(v)
    const cancelVal = () =>
      d.kind === "confirm"
        ? false
        : d.kind === "prompt" || d.kind === "snippet" || d.kind === "choice" || d.kind === "history"
          ? null
          : undefined
    const enterOk =
      d.kind === "alert" ||
      d.kind === "prompt" ||
      (d.kind === "confirm" && !d.disableEnter)
    const onKey = (e) => {
      if (e.key === "Escape") {
        e.preventDefault()
        finish(cancelVal())
      }
      if (e.key === "Enter" && enterOk) {
        if (e.target && e.target.tagName === "TEXTAREA") return
        e.preventDefault()
        if (d.kind === "confirm") finish(true)
        else if (d.kind === "prompt") finish(draft.val)
        else if (d.kind === "alert") finish()
      }
    }
    const copyAndClose = async () => {
      try {
        await copyText(d.body || "")
        finish(true)
      } catch (err) {
        pushLog(err.message || "复制失败", "err")
      }
    }
    const multiChoice = (d.options || []).length > 1
    const choiceBtns = (d.options || []).map((opt) =>
      button(
        {
          class: opt.danger ? "danger" : opt.accent ? "accent" : multiChoice ? "accent-soft" : "accent",
          type: "button",
          onclick: () => finish(opt.value),
        },
        opt.label || String(opt.value),
      ),
    )
    const confirmButton = button(
      {
        class: d.danger ? "danger" : "accent",
        type: "button",
        onclick: () => finish(d.kind === "confirm" ? true : draft.val),
      },
      ...withKbd(d.confirmLabel || "确定", enterOk ? "Enter" : ""),
    )
    const actionItems = d.kind === "alert"
      ? [button({ class: "accent", type: "button", onclick: () => finish() }, ...withKbd("好的", "Enter"))]
      : d.kind === "snippet"
        ? [button({ class: "accent", type: "button", onclick: () => copyAndClose() }, "复制并关闭")]
        : d.kind === "history"
          ? [button({
              class: "accent",
              type: "button",
              disabled: () => d.loading.val || !d.body.val,
              onclick: async () => {
                try {
                  await copyText(d.body.val)
                  pushLog("已复制历史全文", "ok")
                } catch (err) {
                  pushLog(err.message || "复制失败", "err")
                }
              },
            }, "复制全文")]
          : d.kind === "choice"
            ? choiceBtns
            : [confirmButton]
    const histBody =
      d.kind === "history"
        ? div(
            { class: "hist-dlg" },
            div(
              { class: "hist-list" },
              ...(d.items || []).map((it) =>
                button(
                  {
                    type: "button",
                    class: () => "hist-item" + (d.selected.val === it.id ? " on" : ""),
                    onclick: () => {
                      d.selected.val = it.id
                      d.load(it.id)
                    },
                  },
                  span({}, new Date(it.savedAt * 1000).toLocaleString()),
                  span({ class: "muted" }, formatSize(it.size)),
                ),
              ),
            ),
            pre({ class: "hist-body" }, () => (d.loading.val ? "加载中…" : d.body.val)),
          )
        : null
    const box = div(
      {
        class: "dlg" + (d.kind === "snippet" || d.kind === "history" ? " dlg-wide" : ""),
        tabindex: "0",
        onkeydown: onKey,
      },
      div(
        { class: "dlg-head" },
        span({ class: "dlg-title" }, d.title),
        button(
          { class: "dlg-close", type: "button", title: "关闭 Esc", onclick: () => finish(cancelVal()) },
          ico("close"),
        ),
      ),
      d.kind === "history"
        ? null
        : d.kind === "snippet"
          ? div({ class: "dlg-tip" }, d.tip || "")
          : div({ class: "dlg-msg" }, d.message),
      d.kind === "snippet" ? pre({ class: "dlg-snippet-body" }, d.body || "") : null,
      histBody,
      d.kind === "prompt"
        ? d.multiline
          ? textarea({
              class: "dlg-input dlg-textarea",
              rows: 8,
              value: draft,
              oninput: (e) => (draft.val = e.target.value),
              onkeydown: onKey,
            })
          : input({
              class: "dlg-input",
              type: d.password ? "password" : "text",
              value: draft,
              oninput: (e) => (draft.val = e.target.value),
              onkeydown: onKey,
            })
        : null,
      div(
        { class: "dlg-actions" + (d.kind === "choice" ? " dlg-actions-wrap" : "") },
        ...actionItems,
      ),
    )
    queueMicrotask(() => {
      const el =
        d.kind === "snippet" || d.kind === "choice" || d.kind === "history"
          ? box.querySelector("button.accent") || box.querySelector(".dlg-actions button:last-child")
          : box.querySelector(".dlg-input") || box.querySelector("button.accent")
      if (el) el.focus()
      if (el && el.select) el.select()
    })
    return div(
      {
        class: "dlg-layer",
        onclick: (e) => {
          if (e.target.classList.contains("dlg-layer")) finish(cancelVal())
        },
      },
      box,
    )
  }
}

async function solveCaptcha(onProgress) {
  const started = performance.now()
  const minimumMs = 3000
  const issue = await api.captcha()
  const challenge = issue.challenge
  const difficulty = issue.difficulty || 3
  const likelihood = Math.pow(16, -difficulty)
  let nonce = 0
  let lastUI = 0
  const enc = new TextEncoder()
  while (true) {
    const buf = await crypto.subtle.digest("SHA-256", enc.encode(challenge + String(nonce)))
    const bytes = new Uint8Array(buf)
    let ok = true
    for (let i = 0; i < difficulty; i++) {
      const b = bytes[(i / 2) | 0]
      const nib = i % 2 === 0 ? b >> 4 : b & 0x0f
      if (nib !== 0) {
        ok = false
        break
      }
    }
    if (ok) {
      // Keep a predictable verification rhythm without raising the random PoW cost.
      while (performance.now() - started < minimumMs) {
        onProgress?.(Math.min(99, ((performance.now() - started) / minimumMs) * 100), "mining")
        await new Promise((r) => setTimeout(r, 80))
      }
      onProgress?.(100, "ok")
      return { id: issue.id, nonce }
    }
    nonce++
    if (nonce % 256 === 0) {
      const now = Date.now()
      if (now - lastUI > 80) {
        lastUI = now
        const probability = Math.pow(1 - likelihood, nonce)
        const pct = Math.min(99, (1 - Math.pow(probability, 2)) * 100)
        onProgress?.(Math.min(pct, ((performance.now() - started) / minimumMs) * 99), "mining")
      }
      await new Promise((r) => setTimeout(r, 0))
    }
  }
}

function Gate() {
  const password = van.state("")
  const msg = van.state("")
  const phase = van.state("idle") // idle | mining | ok | err
  const progress = van.state(0)
  const busy = van.state(false)
  return div(
    { class: "gate" },
    div(
      { class: "blk" },
      h1(() => (state.hasPassword.val ? "登录" : "设置密码")),
      input({
        type: "text",
        autocomplete: "off",
        spellcheck: "false",
        placeholder: () => (state.hasPassword.val ? "密码" : "密码（至少 8 位）"),
        value: password,
        disabled: () => busy.val,
        oninput: (e) => (password.val = e.target.value),
        onkeydown: async (e) => {
          if (e.key === "Enter") await submit()
        },
      }),
      div(
        { class: "pow" },
        div(
          {
            class: () =>
              "pow-mascot" +
              (phase.val === "ok" ? " happy" : "") +
              (phase.val === "err" ? " sad" : "") +
              (phase.val === "mining" ? " work" : ""),
          },
          () => (phase.val === "ok" ? "✓" : phase.val === "err" ? "!" : "🦊"),
        ),
        div(
          { class: "pow-bar", role: "progressbar", "aria-valuenow": () => progress.val },
          div({ class: "pow-fill", style: () => `width:${progress.val}%` }),
        ),
        p(
          { class: "pow-status muted" },
          () =>
            phase.val === "mining"
              ? "正在验证（防机器人）…"
              : phase.val === "ok"
                ? "验证通过"
                : phase.val === "err"
                  ? "验证失败，请重试"
                  : "点登录后会先跑一段小验证",
        ),
      ),
      () => (msg.val ? p({ class: "err" }, msg.val) : null),
      button(
        {
          class: "accent",
          style: "justify-content:center",
          disabled: () => busy.val,
          onclick: () => submit(false),
        },
        () => (busy.val ? "验证中…" : state.hasPassword.val ? "登录" : "创建并进入"),
        span({ class: "dlg-kbd", "aria-hidden": "true" }, "Enter"),
      ),
    ),
  )

  async function finishLogin(res) {
    setCsrf(res.csrf)
    state.authed.val = true
    await refreshTree()
    routeReady = true
    await applyRoute({ replace: true })
  }

  async function submit(kick = false, confirm = false, reusedCap = null) {
    if (busy.val) return
    msg.val = ""
    busy.val = true
    phase.val = "mining"
    progress.val = 0
    try {
      let cap = reusedCap
      if (!cap) {
        cap = await solveCaptcha((pct) => {
          progress.val = pct
          phase.val = "mining"
        })
      }
      phase.val = "ok"
      progress.val = 100
      if (!state.hasPassword.val) {
        const res = await api.setup(password.val, cap.id, cap.nonce)
        await finishLogin(res)
        return
      }
      try {
        const res = await api.login(password.val, !!kick, cap.id, cap.nonce, !!confirm)
        await finishLogin(res)
      } catch (e) {
        if (e.status === 409 && e.data && e.data.busy) {
          busy.val = false
          phase.val = "ok"
          if (await dlgConfirm("已有会话在线，挤掉？")) {
            return submit(true, confirm, cap)
          }
          phase.val = "idle"
          progress.val = 0
          return
        }
        if (e.status === 429 && e.data && e.data.needConfirm) {
          busy.val = false
          phase.val = "ok"
          if (await dlgConfirm("尝试次数过多，确认是你本人再试一次？")) {
            return submit(kick, true, cap)
          }
          phase.val = "idle"
          progress.val = 0
          return
        }
        throw e
      }
    } catch (e) {
      phase.val = "err"
      msg.val = e.message
    } finally {
      busy.val = false
    }
  }
}

function isSitesOverviewSel() {
  return !state.sel.val || state.sel.val.type === "sites"
}

function panelHashURL(hash) {
  const h = hash.startsWith("#") ? hash : `#${hash}`
  return `${location.pathname}${location.search}${h}`
}

async function goBilling({ replaceRoute = false } = {}) {
  snapshotOverviewScroll()
  state.chromeMenuOpen.val = false
  state.copyPick.val = null
  await openBilling({ replaceRoute })
}

async function goSites({ replaceRoute = false, keepServerDlg = false } = {}) {
  if (!(await confirmDiscard())) return
  state.chromeMenuOpen.val = false
  state.sel.val = { type: "sites" }
  if (!keepServerDlg) closeServerDlg()
  state.siteMeta.val = null
  state.deployPending.val = false
  state.fsFile.val = ""
  state.fsDir.val = ""
  syncRoute({ replace: replaceRoute })
}

/** Restart CSS flash: short pulse then long pulse (see site-flash / host-flash). */
const OVERVIEW_FLASH_MS = 1900

function playOverviewFlash(el, cls) {
  if (!el) return
  el.classList.remove(cls)
  el.getBoundingClientRect()
  el.classList.add(cls)
  setTimeout(() => el.classList.remove(cls), OVERVIEW_FLASH_MS)
}

/** Jump to overview and briefly flash the host cell for this server. */
async function focusOverviewServer(serverId) {
  const id = Number(serverId) || 0
  if (!id) return
  await goSites({ replaceRoute: true })
  const tryFlash = () => {
    const el = document.querySelector(`.sites-td-host[data-server-id="${id}"]`)
    if (!el) return false
    el.scrollIntoView({ block: "center", inline: "nearest" })
    playOverviewFlash(el, "flash-host")
    return true
  }
  // Overview table mounts asynchronously after sel change — retry briefly.
  requestAnimationFrame(() => {
    if (tryFlash()) return
    requestAnimationFrame(() => {
      if (tryFlash()) return
      setTimeout(tryFlash, 50)
      setTimeout(tryFlash, 150)
      setTimeout(tryFlash, 350)
    })
  })
}


async function doLogout() {
  if (!(await dlgConfirm("确定退出登录？"))) return
  await api.logout()
  state.authed.val = false
}

/** +IP leftmost, then theme / 安全 / 退出 — always top-right. */
function ChromeTrailButtons(lead = null) {
  return [
    ...(lead ? [lead] : []),
    button({ class: "accent", title: "加服务器", onclick: onAddServer }, ico("plus"), "IP"),
    button(
      {
        title: () => {
          const m = state.themeMode.val
          return m === "auto" ? "主题: 自动" : m === "light" ? "主题: 亮" : "主题: 暗"
        },
        onclick: cycleTheme,
      },
      () => {
        const m = state.themeMode.val
        return ico(m === "light" ? "sun" : m === "dark" ? "moon" : "monitor")
      },
    ),
    button(
      {
        title: "安全",
        onclick: () => (state.securityOpen.val = true),
      },
      ico("shield"),
    ),
    button(
      {
        title: "退出",
        onclick: () => doLogout(),
      },
      ico("logout"),
    ),
  ]
}

function GoBillingSwitch() {
  return button(
    {
      class: "accent home-top",
      title: "续费表格（未保存会先确认）",
      onclick: () => goBilling(),
    },
    ico("home"),
    "去表格",
  )
}

function GoSitesSwitch() {
  return button(
    {
      class: "accent home-top",
      title: "站点概览（未保存会先确认）",
      onclick: () => goSites(),
    },
    ico("server"),
    "去站点",
  )
}

function BackToOverviewBtn() {
  return button(
    {
      class: "sites-back",
      title: "回站点概览",
      onclick: () => goSites(),
    },
    ico("back"),
    span({ class: "sites-back-label" }, "概览"),
  )
}

/**
 * Desktop: body min-width = uncompressed header strip (switch+mid+chrome).
 * Mobile (≤800px): page-min is 0 — mid moves to a second header row instead of sideways scroll.
 */
let pageMinWidthTick = 0
function isMobileLayout() {
  return window.matchMedia("(max-width: 800px)").matches
}
function syncPageMinWidth() {
  if (isMobileLayout()) {
    document.documentElement.style.setProperty("--page-min-width", "0px")
    return
  }
  const h = document.querySelector(".page-header")
  if (!h) {
    document.documentElement.style.setProperty("--page-min-width", "0px")
    return
  }
  if (!h.querySelector(".page-header-switch") || !h.querySelector(".page-header-mid") || !h.querySelector(".page-header-chrome")) {
    return
  }
  const prevW = h.style.width
  const prevMin = h.style.minWidth
  h.style.width = "max-content"
  h.style.minWidth = "max-content"
  const need = Math.ceil(h.getBoundingClientRect().width)
  h.style.width = prevW
  h.style.minWidth = prevMin
  document.documentElement.style.setProperty("--page-min-width", Math.max(need, 1) + "px")
}
function schedulePageMinWidth() {
  const n = ++pageMinWidthTick
  requestAnimationFrame(() => {
    if (n !== pageMinWidthTick) return
    requestAnimationFrame(() => {
      if (n !== pageMinWidthTick) return
      syncPageMinWidth()
    })
  })
}

/** Row 1: pink/back left · page mid · theme/安全/退出/+IP always top-right. */
function PageShellHeader(switchEl, chromeLead, ...midChildren) {
  schedulePageMinWidth()
  return div(
    { class: "page-header" },
    div({ class: "page-header-switch" }, switchEl),
    div({ class: "page-header-mid" }, ...midChildren),
    div({ class: "page-header-chrome" }, ...ChromeTrailButtons(chromeLead)),
  )
}

function billingReport(title, lines, { ok = true } = {}) {
  pushLog(title || "续费", ok ? "cmd" : "err")
  for (const l of lines || []) {
    if (l == null || String(l) === "") continue
    pushLog(String(l), ok ? "" : "err")
  }
}

async function openBilling({ replaceRoute = false } = {}) {
  if (!(await confirmDiscard())) return
  state.sel.val = { type: "billing" }
  closeServerDlg()
  syncRoute({ replace: replaceRoute })
  await loadBilling()
}

async function loadBilling() {
  try {
    const snap = state.billingSnapId.val || 0
    state.billing.val = await api.billingList(snap || undefined)
  } catch (e) {
    state.billing.val = { rows: [], syncedAt: 0, snapshots: [], error: e.message }
    await dlgAlert(e.message || String(e), "续费加载失败")
  }
}

/** Editable billing accounts draft; kept outside van state so typing does not remount the modal. */
let billingAcctDraft = null

async function openBillingAccounts() {
  try {
    const cfg = await api.billingGetAccounts()
    billingAcctDraft = {
      proxy: cfg.proxy || "",
      telegram: {
        bot_token: (cfg.telegram && cfg.telegram.bot_token) || "",
        chat_id: (cfg.telegram && cfg.telegram.chat_id) || "",
        panel_url: (cfg.telegram && cfg.telegram.panel_url) || "",
      },
      accounts: (cfg.accounts || []).map((a) => ({
        name: a.name || "",
        email: a.email || "",
        phone: a.phone || "",
        password: a.password || "",
        base_url: a.base_url || "https://www.lizhidc.cn",
        group_ids: (a.group_ids && a.group_ids.length ? a.group_ids : [305]).join(","),
      })),
    }
    state.billingAcct.val = billingAcctDraft
    state.billingAcctOpen.val = true
  } catch (e) {
    await dlgAlert(e.message || String(e))
  }
}

async function saveBillingAccounts() {
  const draft = billingAcctDraft || state.billingAcct.val
  if (!draft) return
  const body = {
    proxy: draft.proxy || "",
    telegram: {
      bot_token: draft.telegram.bot_token || "",
      chat_id: draft.telegram.chat_id || "",
      panel_url: draft.telegram.panel_url || "",
    },
    accounts: (draft.accounts || []).map((a) => ({
      name: a.name.trim(),
      email: a.email.trim(),
      phone: (a.phone || "").trim(),
      password: a.password || "",
      base_url: (a.base_url || "").trim() || "https://www.lizhidc.cn",
      group_ids: String(a.group_ids || "305")
        .split(/[,，\s]+/)
        .map((x) => parseInt(x, 10))
        .filter((n) => Number.isFinite(n) && n > 0),
    })),
  }
  for (const a of body.accounts) {
    if (!a.name) throw new Error("账号名称不能空")
    if (!a.email && !a.phone) throw new Error(`${a.name}: 需要 email 或 phone`)
  }
  await api.billingPutAccounts(body)
  billingAcctDraft = null
  state.billingAcctOpen.val = false
  await dlgAlert("账号已保存", "续费")
}

async function confirmDiscard() {
  if (!state.fsDirty.val) return true
  if (!(await dlgConfirm("有未保存修改，丢弃？"))) return false
  state.fsDirty.val = false
  return true
}

/** Active TLS in conf (listen 443 / ssl_certificate) — drives overview lock + https links. */
function siteHasSSL(site) {
  if (!site) return false
  if (site.ssl) return true
  return (site.ports || []).includes(443)
}

/** Master disk ahead of last successful deploy — red dot on 部署. */
function setSitePendingDeploy(on) {
  const next = !!on
  state.deployPending.val = next
  // Keep siteMeta.meta in sync for anything that reads the API-shaped object.
  if (!state.siteMeta.val) return
  const cur = !!(state.siteMeta.val.meta && state.siteMeta.val.meta.pendingDeploy)
  if (cur === next) return
  state.siteMeta.val = {
    ...state.siteMeta.val,
    meta: { ...(state.siteMeta.val.meta || {}), pendingDeploy: next },
  }
}

/**
 * Overview clickable URLs from conf listen + domains.
 * Bare http(s)://host (default 80/443) only when that port is actually listened —
 * e.g. server_name IP with only listen 10000 must not show http://IP.
 * Extra ports → http://公网IP:port.
 */
function siteAccessLinks(site, publicIP) {
  const ports = site.ports || []
  const has80 = ports.includes(80)
  const ssl = siteHasSSL(site)
  const links = []
  const seen = new Set()
  const push = (href) => {
    if (seen.has(href)) return
    seen.add(href)
    links.push({ label: href, href })
  }
  for (const d of site.domains || []) {
    if (ssl) push(`https://${d}`)
    else if (has80) push(`http://${d}`)
  }
  if (publicIP) {
    for (const p of ports) {
      if (p === 80 || p === 443) continue
      push(`http://${publicIP}:${p}`)
    }
  }
  return links
}

function siteNavIcon(siteName) {
  const wrap = span({ class: "site-ico" })
  wrap.appendChild(ico("globe"))
  if (!siteName) return wrap
  const img = document.createElement("img")
  img.className = "site-logo"
  img.alt = ""
  img.decoding = "async"
  // onload MUST be set before src — cached logos finish sync and would skip the handler.
  img.onload = () => {
    wrap.replaceChildren(img)
  }
  img.onerror = () => {
    /* keep globe */
  }
  img.src = api.downloadURL(siteName, "www/logo.png")
  if (img.complete && img.naturalWidth > 0) wrap.replaceChildren(img)
  return wrap
}

const WWW_ROOT = "www"
const CONF_PATH = "nginx.conf"

function isUnderWWW(path) {
  const p = String(path || "")
  return p === WWW_ROOT || p.startsWith(WWW_ROOT + "/")
}

function clampWWWDir(path) {
  const p = String(path || "").replace(/^\/+|\/+$/g, "")
  if (!p || !isUnderWWW(p)) return WWW_ROOT
  return p
}

function displayFsPath(path) {
  const p = String(path || "")
  if (!p) return ""
  if (p === CONF_PATH) return CONF_PATH
  if (p === WWW_ROOT) return ""
  if (p.startsWith(WWW_ROOT + "/")) return p.slice(WWW_ROOT.length + 1)
  return p
}

let siteRequest = 0

async function openSite(name, opts = {}) {
  const sync = opts.sync !== false
  if (!opts.fromRoute && !(await confirmDiscard())) return
  snapshotOverviewScroll()
  overviewFocusSite = name || ""
  state.copyPick.val = null
  const request = ++siteRequest
  const current = () => request === siteRequest && isCurrentSite(name)
  state.sel.val = { type: "site", name }
  state.siteMeta.val = null
  state.deployPending.val = false
  state.fsDir.val = WWW_ROOT
  state.fsFile.val = ""
  state.fsText.val = ""
  state.fsDirty.val = false
  state.fsKind.val = "empty"
  state.fsZipEntries.val = []
  state.fsSelected.val = []
  try {
    const site = await api.getSite(name)
    if (!current()) return
    state.siteMeta.val = site
    state.deployPending.val = !!(site.meta && site.meta.pendingDeploy)
    await loadDir(name, WWW_ROOT, { sync: false })
    if (!current()) return
    if (opts.focusPath) {
      await focusSitePath(name, opts.focusPath)
    } else if (!opts.skipDefaultFile) {
      await openFile(name, CONF_PATH, true, { sync: false })
    }
  } catch (e) {
    pushLog(e.message, "err")
  }
  if (!current()) return
  if (sync) syncRoute({ replace: !!opts.replaceRoute })
}

/** Open a file or enter a directory under the current site. */
async function focusSitePath(site, path) {
  if (!path) return
  if (path === CONF_PATH) {
    await loadDir(site, WWW_ROOT, { sync: false })
    await openFile(site, CONF_PATH, true, { sync: false })
    return
  }
  const target = isUnderWWW(path) ? path : joinPath(WWW_ROOT, path)
  if (target === WWW_ROOT || target.endsWith("/")) {
    await loadDir(site, clampWWWDir(target.replace(/\/$/, "")), { sync: false, clearFile: true })
    return
  }
  const parent = parentPath(target)
  await loadDir(site, clampWWWDir(parent || WWW_ROOT), { sync: false })
  const ent = (state.fsEntries.val || []).find((e) => e.path === target)
  if (ent && ent.dir) {
    await loadDir(site, target, { sync: false, clearFile: true })
    return
  }
  try {
    await openFile(site, target, true, { sync: false })
  } catch (e) {
    try {
      await loadDir(site, target, { sync: false, clearFile: true })
    } catch (e2) {
      pushLog(e2.message || e.message || `无法打开 ${path}`, "err")
    }
  }
}

async function setApkObfuscate(name, enabled) {
  try {
    state.busy.val = true
    const res = await api.setApkObfuscate(name, enabled)
    for (const line of res.lines || []) pushLog(line)
    if (!res.ok) throw new Error(res.error || "设置失败")
    if (state.siteMeta.val && state.sel.val && state.sel.val.name === name) {
      state.siteMeta.val = {
        ...state.siteMeta.val,
        meta: { ...(state.siteMeta.val.meta || {}), ...(res.meta || { apkObfuscate: enabled }) },
      }
    }
    if (isCurrentSite(name)) setSitePendingDeploy(true)
    pushLog(
      enabled
        ? ".apk文件自动混淆：已开（下次部署：立刻跑一遍 + 装远端 30 分钟定时）"
        : ".apk文件自动混淆：已关（下次部署卸远端定时；本次不改远端）",
      "ok",
    )
  } catch (e) {
    pushLog(e.message || String(e), "err")
    await dlgAlert(e.message || String(e))
    // reload meta so checkbox snaps back
    try {
      state.siteMeta.val = await api.getSite(name)
    } catch (_) {}
  } finally {
    state.busy.val = false
  }
}

function sortEntries(ents) {
  ents.sort((a, b) => {
    if (a.dir !== b.dir) return a.dir ? -1 : 1
    return a.name.localeCompare(b.name)
  })
  return ents
}

let directoryRequest = 0

async function loadDir(site, path, opts = {}) {
  const request = ++directoryRequest
  const dir = clampWWWDir(path)
  const res = await api.listFiles(site, dir)
  if (request !== directoryRequest || !isCurrentSite(site)) return
  state.fsDir.val = dir
  state.fsEntries.val = sortEntries(res.entries || [])
  state.fsSelected.val = []
  state.fsSelectMode.val = false
  // only when navigating into a folder (not refresh after upload/mkdir)
  if (opts.clearFile) {
    state.fsFile.val = ""
    state.fsKind.val = "empty"
    state.fsText.val = ""
    state.fsDirty.val = false
    state.fsZipEntries.val = []
    state.fsRev.val++
  }
  if (opts.sync !== false) syncRoute()
}

function clearSelectMode() {
  state.fsSelectMode.val = false
  state.fsSelected.val = []
}

function enterSelectMode(path) {
  state.fsSelectMode.val = true
  if (path) state.fsSelected.val = [path]
}

function dirEntryPaths() {
  return (state.fsEntries.val || []).map((e) => e.path)
}

function allDirSelected() {
  const paths = dirEntryPaths()
  if (!paths.length) return false
  const sel = new Set(state.fsSelected.val)
  return paths.every((p) => sel.has(p))
}

function toggleSelectAll() {
  const paths = dirEntryPaths()
  if (!paths.length) return
  if (allDirSelected()) {
    clearSelectMode()
    return
  }
  state.fsSelected.val = paths
  state.fsSelectMode.val = true
}

async function goParentDir(site) {
  const dir = state.fsDir.val || WWW_ROOT
  if (dir === WWW_ROOT) return
  const parent = parentPath(dir)
  await loadDir(site, clampWWWDir(parent || WWW_ROOT), { clearFile: true })
}

/** Long-press → same as right-click. Returns cleanup. */
function bindLongPress(el, onLong) {
  let timer = null
  let sx = 0
  let sy = 0
  let armed = false
  const clear = () => {
    if (timer) clearTimeout(timer)
    timer = null
  }
  const onStart = (e) => {
    const t = e.touches && e.touches[0]
    if (!t) return
    sx = t.clientX
    sy = t.clientY
    armed = false
    clear()
    timer = setTimeout(() => {
      timer = null
      armed = true
      onLong({ clientX: sx, clientY: sy, preventDefault() {}, stopPropagation() {} })
    }, 480)
  }
  const onMove = (e) => {
    if (!timer || !e.touches || !e.touches[0]) return
    const dx = e.touches[0].clientX - sx
    const dy = e.touches[0].clientY - sy
    if (dx * dx + dy * dy > 64) clear()
  }
  const onEnd = (e) => {
    if (armed) {
      e.preventDefault()
      e.stopPropagation()
    }
    clear()
    // swallow click after long-press
    if (armed) {
      const block = (ev) => {
        ev.preventDefault()
        ev.stopPropagation()
        el.removeEventListener("click", block, true)
      }
      el.addEventListener("click", block, true)
      setTimeout(() => el.removeEventListener("click", block, true), 0)
    }
    armed = false
  }
  el.addEventListener("touchstart", onStart, { passive: true })
  el.addEventListener("touchmove", onMove, { passive: true })
  el.addEventListener("touchend", onEnd, { passive: false })
  el.addEventListener("touchcancel", clear, { passive: true })
}

function selectedEntries() {
  const set = new Set(state.fsSelected.val)
  return (state.fsEntries.val || []).filter((e) => set.has(e.path))
}

function clipTargets(entry) {
  if (entry) {
    const sel = state.fsSelected.val
    if ((state.fsSelectMode.val || sel.length > 1) && sel.includes(entry.path) && sel.length) {
      return selectedEntries()
    }
    return [entry]
  }
  // Keyboard / bulk ops: only checkbox selection. Never the open editor file
  // (nginx.conf is pinned config — opening it must not imply "copy this file").
  return selectedEntries()
}

function setClipboard(mode, site, entries) {
  const list = (entries || []).filter((e) => e && e.path)
  if (!list.length) return false
  state.clip.val = {
    mode,
    site,
    paths: list.map((e) => e.path),
    labels: list.map((e) => e.name || e.path.split("/").pop()),
  }
  return true
}

function clearClipboard() {
  state.clip.val = null
}

function inEditableFocus(t) {
  if (!t || !t.closest) return false
  if (t.closest(".cm-host") || t.closest("[contenteditable=true]")) return true
  const tag = (t.tagName || "").toLowerCase()
  if (tag === "textarea" || tag === "select") return true
  if (tag === "input") {
    const ty = (t.type || "text").toLowerCase()
    return ty !== "checkbox" && ty !== "radio" && ty !== "button" && ty !== "file"
  }
  return !!t.isContentEditable
}

/** True when Ctrl/Cmd+C/X/V must stay with the text editor (or any field), not file clipboard. */
function shouldKeepNativeClipboard(t) {
  if (document.activeElement && document.activeElement.closest?.(".cm-host")) return true
  if (inEditableFocus(t) || inEditableFocus(document.activeElement)) return true
  return false
}

async function fsClipboardSet(site, mode, entry) {
  const targets = clipTargets(entry)
  if (!targets.length) {
    await dlgAlert("请先勾选要复制/剪切的文件或文件夹")
    return
  }
  setClipboard(mode, site, targets)
  // Drop multi-select so the paste float is not covered by select ops.
  clearSelectMode()
  pushLog(`${mode === "cut" ? "剪切" : "复制"} ${targets.length} 项 @ ${site}`, "ok")
}

/**
 * Shared name-conflict prompt for upload/paste.
 * Returns "reject" | "overwrite" | "rename", or null if the user cancels.
 */
async function resolveNameConflicts(kind, conflictsIn, names) {
  const conflicts = [...(conflictsIn || [])]
  const counts = new Map()
  for (const name of names || []) counts.set(name, (counts.get(name) || 0) + 1)
  for (const [name, count] of counts) {
    if (count < 2) continue
    const item = conflicts.find((entry) => entry.name === name)
    if (item) item.selectedDuplicate = true
    else conflicts.push({ name, directory: false, selectedDuplicate: true })
  }
  if (!conflicts.length) return "reject"
  const verb = kind === "paste" ? "粘贴" : "上传"
  const hasDirectory = conflicts.some((item) => item.directory)
  const hasSelectedDuplicate = conflicts.some((item) => item.selectedDuplicate)
  const shown = conflicts
    .slice(0, 10)
    .map((item) => `${item.name}${item.directory ? "/（文件夹）" : ""}${item.selectedDuplicate ? "（本批有重名）" : ""}`)
  if (conflicts.length > shown.length) shown.push(`……以及另外 ${conflicts.length - shown.length} 项`)
  const explanation = hasDirectory
    ? kind === "paste"
      ? "本批包含同名文件夹，不能用覆盖替换文件夹；选择自动重命名可保留两边内容。"
      : "本批包含同名文件夹，文件不能覆盖文件夹；选择自动重命名可保留两边内容。"
    : hasSelectedDuplicate
      ? kind === "paste"
        ? "剪贴板里有重复文件名；为避免互相覆盖，本批只能自动重命名或取消。"
        : "所选文件里有重复文件名；为避免这些文件互相覆盖，本批只能自动重命名或取消。"
      : `覆盖会替换同名文件；自动重命名会保留原文件并${verb}副本，例如 index (2).html。`
  const options = hasDirectory || hasSelectedDuplicate
    ? [{ value: "rename", label: `自动重命名${verb}`, accent: true }]
    : [
        { value: "rename", label: `自动重命名${verb}` },
        { value: "overwrite", label: "覆盖同名文件", accent: true },
      ]
  return await dlgChoice(
    `目标目录已存在这些同名项目：\n${shown.join("\n")}\n\n${explanation}`,
    `${verb}遇到同名项目`,
    options,
  )
}

async function fsPaste(site) {
  const clip = state.clip.val
  if (!clip || !clip.paths || !clip.paths.length) {
    await dlgAlert("剪贴板为空")
    return
  }
  const dest = state.fsDir.val || WWW_ROOT
  const basenames = clip.paths.map((p) => String(p).split("/").pop()).filter(Boolean)
  try {
    state.busy.val = true
    pushLog(`paste → ${site}/${dest}（${clip.paths.length} 项）`, "cmd")
    pushLog("检查目标目录同名项目…", "cmd")
    const check = await api.uploadConflicts(site, dest, basenames)
    const conflict = await resolveNameConflicts("paste", check.conflicts || [], basenames)
    if (!conflict) {
      pushLog("已取消粘贴", "cmd")
      return
    }
    await api.pastePaths(site, {
      fromSite: clip.site,
      paths: clip.paths,
      dest,
      mode: clip.mode,
      conflict,
    })
    pushLog("paste ok", "ok")
    if (isCurrentSite(site)) setSitePendingDeploy(true)
    if (clip.mode === "cut") clearClipboard()
    await loadDir(site, dest, { clearFile: false })
  } catch (e) {
    pushLog(e.message || String(e), "err")
    await dlgAlert(e.message || String(e))
  } finally {
    state.busy.val = false
  }
}

/** Clipboard actions: same edge/style as multi-select float (paste + clear). */
function ClipFloat(site) {
  return () => {
    void state.clip.val
    void state.fsSelected.val
    void state.busy.val
    const clip = state.clip.val
    // Multi-select float owns this edge while choosing files.
    if (!clip || state.fsSelected.val.length) {
      return div({ class: "files-select-float clip-float off", "aria-hidden": "true" })
    }
    const n = clip.paths.length
    const tip =
      n === 1
        ? `${clip.mode === "cut" ? "剪切" : "复制"} · ${clip.site}/${clip.labels[0]}`
        : `${clip.mode === "cut" ? "剪切" : "复制"} · ${clip.site} · ${n} 项`
    return div(
      {
        class: "files-select-float clip-float" + (clip.mode === "cut" ? " cut" : ""),
        role: "toolbar",
        "aria-label": "剪贴板",
        title: tip,
      },
      filesOpBtn("paste", "粘贴到当前目录 (Ctrl/⌘V)", () => fsPaste(site), { accent: true }),
      filesOpBtn("close", "清空剪贴板", () => clearClipboard()),
    )
  }
}

function toggleSelect(path, additive) {
  const cur = state.fsSelected.val
  if (!additive) {
    state.fsSelected.val = cur.length === 1 && cur[0] === path ? [] : [path]
    return
  }
  if (cur.includes(path)) state.fsSelected.val = cur.filter((p) => p !== path)
  else state.fsSelected.val = [...cur, path]
}

function rangeSelect(toPath) {
  const ents = state.fsEntries.val || []
  const paths = ents.map((e) => e.path)
  const to = paths.indexOf(toPath)
  if (to < 0) return
  const fromPath = state.fsSelected.val[state.fsSelected.val.length - 1]
  let from = paths.indexOf(fromPath)
  if (from < 0) from = to
  const [a, b] = from < to ? [from, to] : [to, from]
  state.fsSelected.val = paths.slice(a, b + 1)
}

/** zip / tar(.gz|.bz2|.xz) / tgz|tbz2|txz / 7z / rar — matches sitesfs.DetectArchive */
function isArchiveName(name) {
  return /\.(zip|7z|rar|tgz|tbz2?|txz|tar(\.(gz|bz2|xz))?)$/i.test(name || "")
}

function archiveBaseName(name) {
  const n = String(name || "")
  const m = n.match(/\.(tar\.(gz|bz2|xz)|tgz|tbz2?|txz|zip|7z|rar|tar)$/i)
  if (!m) return n || "unzipped"
  return n.slice(0, -m[0].length) || "unzipped"
}

function fileKind(path) {
  if (!path) return "empty"
  if (/\.(png|jpe?g|gif|webp|svg|ico|bmp|avif)$/i.test(path)) return "image"
  if (isArchiveName(path)) return "zip"
  if (/\.(woff2?|ttf|otf|eot|mp[34]|webm|wav|pdf|gz|wasm|bin|exe|dmg|apk)$/i.test(path))
    return "binary"
  return "text"
}

function formatSize(n) {
  if (n == null || n < 0) return ""
  if (n < 1024) return n + " B"
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + " KB"
  return (n / (1024 * 1024)).toFixed(1) + " MB"
}

/** Short mtime for file list: MM-DD HH:mm this year, else YYYY-MM-DD. */
function formatMtime(sec) {
  const n = Number(sec)
  if (!n || n < 0) return ""
  const d = new Date(n * 1000)
  if (Number.isNaN(d.getTime())) return ""
  const pad = (x) => String(x).padStart(2, "0")
  const y = d.getFullYear()
  const md = `${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
  if (y !== new Date().getFullYear()) return `${y}-${md}`
  return `${md} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

function withKbd(label, kbd) {
  if (!kbd) return [label]
  return [label, span({ class: "dlg-kbd", "aria-hidden": "true" }, kbd)]
}

let fileRequest = 0
function isCurrentSite(name) {
  return state.sel.val && state.sel.val.type === "site" && state.sel.val.name === name
}

async function openFile(site, path, skipConfirm, opts = {}) {
  if (!skipConfirm && !(await confirmDiscard())) return
  if (!isCurrentSite(site)) return
  const request = ++fileRequest
  const current = () => request === fileRequest && isCurrentSite(site) && state.fsFile.val === path
  const kind = fileKind(path)
  state.fsFile.val = path
  state.fsKind.val = kind
  state.fsDirty.val = false
  state.fsText.val = ""
  state.fsZipEntries.val = []
  try {
    if (kind === "text") {
      const res = await api.readFile(site, path)
      if (!current() || state.fsDirty.val) return
      state.fsFile.val = res.path || path
      state.fsText.val = res.content || ""
    } else if (kind === "zip") {
      const res = await api.zipList(site, path)
      if (!current()) return
      state.fsZipEntries.val = res.entries || []
    }
  } catch (e) {
    if (!current()) return
    pushLog(e.message, "err")
    state.fsKind.val = "binary"
  }
  if (request !== fileRequest || !isCurrentSite(site)) return
  state.fsRev.val++
  if (opts.sync !== false) syncRoute({ replace: !!opts.replaceRoute })
}

function parentPath(p) {
  if (!p) return ""
  const i = p.lastIndexOf("/")
  return i < 0 ? "" : p.slice(0, i)
}

function hlLangFor(path) {
  if (!path) return "nginx"
  const base = path.split("/").pop() || path
  if (/\.cron$/i.test(base)) return "bash"
  if (/\.conf$/i.test(path) || /nginx/i.test(path)) return "nginx"
  if (/\.html?$/i.test(path) || /\.vue$/i.test(path)) return "xml"
  if (/\.css$/i.test(path) || /\.s[ac]ss$/i.test(path) || /\.less$/i.test(path)) return "css"
  if (/\.jsx?$/i.test(path) || /\.mjs$/i.test(path) || /\.cjs$/i.test(path) || /\.tsx?$/i.test(path)) return "javascript"
  if (/\.json$/i.test(path)) return "json"
  if (/\.md$/i.test(path) || /\.markdown$/i.test(path)) return "markdown"
  if (/\.ya?ml$/i.test(path)) return "yaml"
  if (/\.xml$/i.test(path) || /\.svg$/i.test(path)) return "xml"
  if (/\.sh$/i.test(path) || /\.bash$/i.test(path)) return "bash"
  return "plaintext"
}

function lineCommentPrefix(path) {
  const lang = hlLangFor(path)
  if (lang === "javascript" || lang === "css" || lang === "json") return "//"
  if (lang === "xml") return "<!--"
  return "#"
}

function toggleCommentLines(lines, path) {
  const prefix = lineCommentPrefix(path)
  if (prefix === "<!--") {
    const allCommented = lines.every((l) => !l.trim() || /^\s*<!--/.test(l))
    return lines.map((l) => {
      if (!l.trim()) return l
      if (allCommented) return l.replace(/^(\s*)<!--\s?/, "$1").replace(/\s?-->\s*$/, "")
      return l.replace(/^(\s*)/, `$1<!-- `) + " -->"
    })
  }
  const re = new RegExp(`^(\\s*)${prefix.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s?`)
  const codeLines = lines.filter((l) => l.trim())
  const allCommented = codeLines.length > 0 && codeLines.every((l) => re.test(l))
  return lines.map((l) => {
    if (!l.trim()) return l
    if (allCommented) return l.replace(re, "$1")
    return l.replace(/^(\s*)/, `$1${prefix} `)
  })
}

/** Comment/uncomment selected lines (or the current line). Returns new text + selection. */
function toggleLineComments(text, path, selStart, selEnd) {
  const s = String(text || "")
  let a = selStart == null ? 0 : Math.max(0, Math.min(selStart, s.length))
  let b = selEnd == null ? s.length : Math.max(0, Math.min(selEnd, s.length))
  if (a > b) [a, b] = [b, a]
  const lines = s.split("\n")
  const offsetToLine = (off) => {
    let line = 0
    let at = 0
    while (line < lines.length) {
      const end = at + lines[line].length
      if (off <= end) return line
      at = end + 1
      line++
    }
    return Math.max(0, lines.length - 1)
  }
  let from = offsetToLine(a)
  let to = offsetToLine(b)
  // Range ending at column 0 excludes that next line (common editor behavior).
  if (b > a) {
    let at = 0
    for (let i = 0; i < to; i++) at += lines[i].length + 1
    if (b === at) to = Math.max(from, to - 1)
  }
  const nextSlice = toggleCommentLines(lines.slice(from, to + 1), path)
  const nextLines = lines.slice(0, from).concat(nextSlice, lines.slice(to + 1))
  const next = nextLines.join("\n")
  let start = 0
  for (let i = 0; i < from; i++) start += nextLines[i].length + 1
  let end = start
  for (let i = from; i <= to; i++) {
    end += nextLines[i].length
    if (i < to) end += 1
  }
  return { text: next, start, end }
}

function applyEditorComment() {
  if (!liveTextEditor || !liveTextEditor.commentToggle) return
  liveTextEditor.commentToggle()
}

async function onAddServer() {
  await openServerDlg({
    name: "", host: "", publicIP: "", port: 22, user: "root",
    authType: "password", authValue: "", password: "", viaJump: false,
  })
}

async function onAddSiteUnder(serverId) {
  const title = await dlgPrompt("请输入站点名称备注")
  if (!title) return
  try {
    const site = await api.createSite(title, serverId)
    await refreshTree()
    await openSite(site.name)
    pushLog(`站点 ${site.title || title}（${site.name}）`, "ok")
  } catch (e) {
    await dlgAlert(e.message)
  }
}

async function openCopyPick(name) {
  const servers = (state.tree.val && state.tree.val.servers) || []
  if (!servers.length) {
    await dlgAlert("没有可用服务器")
    return
  }
  closeSiteActions()
  state.copyPick.val = name
}

function cancelCopyPick() {
  state.copyPick.val = null
}

async function copySiteToServer(srcName, server) {
  if (!server || !server.id) return
  const title = await dlgPrompt("新显示名", siteDisplayName(srcName) + "-副本")
  if (!title) return
  try {
    const site = await api.copySite(srcName, title, server.id)
    state.copyPick.val = null
    await refreshTree()
    await openSite(site.name)
    const label = server.publicIP || server.host
    pushLog(`copied → ${site.title || title}（${site.name}）@ ${label}`, "ok")
  } catch (e) {
    await dlgAlert(e.message)
  }
}

function CopyPickLayer() {
  const src = state.copyPick.val
  if (!src) return div({ class: "copy-pick-layer off" })
  const cols = collectIpColumns().filter((c) => c.serverId)
  const curId = state.siteMeta.val && state.siteMeta.val.serverId
  return div(
    {
      class: "copy-pick-layer",
      tabindex: "0",
      onclick: (e) => {
        if (e.target === e.currentTarget) cancelCopyPick()
      },
      onkeydown: (e) => {
        if (e.key === "Escape") {
          e.preventDefault()
          cancelCopyPick()
        }
      },
    },
    div(
      { class: "copy-pick-panel", onclick: (e) => e.stopPropagation() },
      div(
        { class: "copy-pick-head" },
        span({ class: "grow" }, `复制「${siteDisplayName(src)}」到…（SSL 不会带走）`),
        button({ title: "关闭 Esc", onclick: () => cancelCopyPick() }, ico("close")),
      ),
      div(
        { class: "copy-pick-list" },
        ...cols.map((col) => {
          const t = state.tree.val
          const server = (t.servers || []).find((x) => x.id === col.serverId)
          const sites = col.sites || []
          return div(
            {
              class: "copy-pick-row" + (col.serverId === curId ? " on" : ""),
              onclick: () => server && copySiteToServer(src, server),
            },
            div(
              { class: "copy-pick-ip" },
              ico("server"),
              span({ class: "grow" }, col.ip + (col.serverNote ? ` · ${col.serverNote}` : "")),
            ),
            div(
              { class: "copy-pick-sites" },
              sites.length
                ? sites.map((s) => (s && (s.title || s.name)) || "").filter(Boolean).join("、") || "无站点"
                : "无站点",
            ),
          )
        }),
      ),
    ),
  )
}

async function onRenameSite(site) {
  const name = typeof site === "string" ? site : site.name
  const cur = (typeof site === "string" ? site : site.title || site.name) || name
  const title = await dlgPrompt("显示名（不影响目录/远端）", cur)
  if (!title || title === cur) return
  try {
    const res = await api.renameSite(name, title)
    await refreshTree()
    if (state.siteMeta.val && state.siteMeta.val.meta && state.sel.val && state.sel.val.name === name) {
      state.siteMeta.val = {
        ...state.siteMeta.val,
        meta: { ...state.siteMeta.val.meta, ...(res.site || { title }) },
      }
    }
    pushLog(`显示名 → ${title}`, "ok")
  } catch (e) {
    await dlgAlert(e.message)
  }
}

async function onDeleteSite(name) {
  const col = collectIpColumns().find((c) => (c.sites || []).some((s) => s && s.name === name))
  const site = (col?.sites || []).find((s) => s && s.name === name)
  const label = site?.title || name
  const location = col ? `${col.ip}${col.serverName ? ` · ${col.serverName}` : ""}` : "服务器未知"
  const detail = `站点：${label}（${name}）\n服务器：${location}\n建议不要删除；暂时不用时建议停用。删除会移除主控目录及远端 conf/www，无法恢复。`
  if (!(await dlgConfirm(detail, "删除站点", { confirmLabel: "继续删除", cancelLabel: "取消", disableEnter: true, danger: true }))) return
  if (!(await dlgConfirm(detail, "再次确认删除站点", { confirmLabel: "确认删除", cancelLabel: "保留站点", disableEnter: true, confirmFirst: true, danger: true }))) return
  try {
    const res = await api.deleteSite(name)
    for (const line of res.lines || []) pushLog(line, "cmd")
    if (state.sel.val && state.sel.val.type === "site" && state.sel.val.name === name) {
      await goSites({ replaceRoute: true })
    }
    await refreshTree()
    pushLog(`deleted ${name}`, "ok")
  } catch (e) {
    if (e.data && e.data.lines) for (const line of e.data.lines) pushLog(line, "err")
    await dlgAlert(e.message)
  }
}

async function onToggleSiteDisabled(site) {
  const name = typeof site === "string" ? site : site.name
  const cur =
    typeof site === "object" && site && "disabled" in site
      ? !!site.disabled
      : !!(state.siteMeta.val && state.siteMeta.val.meta && state.siteMeta.val.meta.disabled)
  const next = !cur
  const label = siteDisplayName(name)
  if (next) {
    if (
      !(await dlgConfirm(
        `停用「${label}」？\n远端 Nginx 会摘掉该站 conf（不再对外），本机与远端 www 保留。`,
      ))
    )
      return
  } else if (!(await dlgConfirm(`启用「${label}」？\n会重新推送远端 conf/www 并 reload Nginx。`))) {
    return
  }
  try {
    state.busy.val = true
    const res = await api.setSiteDisabled(name, next)
    for (const line of res.lines || []) pushLog(line, "cmd")
    if (!res.ok) throw new Error(res.error || (next ? "停用失败" : "启用失败"))
    if (state.siteMeta.val && state.sel.val && state.sel.val.name === name) {
      state.siteMeta.val = {
        ...state.siteMeta.val,
        meta: { ...(state.siteMeta.val.meta || {}), ...(res.meta || { disabled: next }) },
      }
    }
    await refreshTree()
    pushLog(next ? `已停用 ${label}` : `已启用 ${label}`, "ok")
  } catch (e) {
    if (e.data && e.data.lines) for (const line of e.data.lines) pushLog(line, "err")
    pushLog(e.message || String(e), "err")
    await dlgAlert(e.message || String(e))
    try {
      if (state.sel.val && state.sel.val.name === name) {
        state.siteMeta.val = await api.getSite(name)
      }
      await refreshTree()
    } catch (_) {}
  } finally {
    state.busy.val = false
  }
}

/** Servers with their sites for the overview table (IP+名称 rowspan). */
function collectIpColumns() {
  const t = state.tree.val
  if (!t) return []
  const cols = []
  let siteCount = 0
  const un = t.unassigned || []
  if (un.length) {
    siteCount += un.length
    cols.push({ key: "unassigned", ip: "未分配", serverName: "", serverId: 0, sites: un })
  }
  for (const s of t.servers || []) {
    const ip = s.publicIP || s.host || ""
    const sites = (t.byServer && (t.byServer[s.id] || t.byServer[String(s.id)])) || []
    siteCount += sites.length
    cols.push({
      key: "s" + s.id,
      ip: ip || "—",
      serverName: s.note || s.name || "",
      serverNote: s.note || s.name || "",
      serverId: s.id,
      sites,
    })
  }
  cols.siteCount = siteCount
  return cols
}

function overviewIconBtn(title, iconName, onClick) {
  const btn = document.createElement("button")
  btn.type = "button"
  btn.title = title
  btn.appendChild(ico(iconName))
  btn.onclick = (e) => {
    e.stopPropagation()
    onClick(e)
  }
  return btn
}

// One floating action menu, shared by every viewport and site row.
let siteActionsMenu = null

function closeSiteActions() {
  if (!siteActionsMenu) return
  siteActionsMenu.button.setAttribute("aria-expanded", "false")
  const { menu, row } = siteActionsMenu
  menu.classList.remove("is-floating")
  menu.style.cssText = ""
  if (row.isConnected) row.appendChild(menu)
  else menu.remove()
  siteActionsMenu = null
}

function toggleSiteActions(button, menu, row) {
  const wasOpen = siteActionsMenu && siteActionsMenu.button === button
  closeSiteActions()
  if (wasOpen) return
  menu.classList.add("is-floating")
  document.body.appendChild(menu)
  // Detached menu icons were skipped by the overview's first render batch.
  lucidePending.push(...menu.querySelectorAll("[data-lucide]"))
  scheduleLucideFlush()
  button.setAttribute("aria-expanded", "true")
  siteActionsMenu = { button, menu, row }
  const anchor = row.getBoundingClientRect()
  const trigger = button.getBoundingClientRect()
  const rect = menu.getBoundingClientRect()
  const scroller = row.closest(".sites-table-wrap").getBoundingClientRect()
  const bottom = Math.min(window.innerHeight, scroller.bottom) - 8
  const left = Math.max(8, Math.min(trigger.left, window.innerWidth - rect.width - 8))
  let top = anchor.bottom + 4
  if (top + rect.height > bottom) top = anchor.top - rect.height - 4
  menu.style.left = left + "px"
  menu.style.top = Math.max(8, Math.min(top, bottom - rect.height)) + "px"
}

document.addEventListener("click", (e) => {
  if (siteActionsMenu && !siteActionsMenu.button.contains(e.target) && !siteActionsMenu.menu.contains(e.target)) closeSiteActions()
}, true)
document.addEventListener("scroll", closeSiteActions, true)
window.addEventListener("resize", closeSiteActions)
window.addEventListener("hashchange", closeSiteActions)
window.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && siteActionsMenu) {
    const button = siteActionsMenu.button
    closeSiteActions()
    button.focus()
    return
  }
  if (e.key === "Escape" && state.copyPick.val) {
    e.preventDefault()
    cancelCopyPick()
  }
})

/**
 * Click always navigates. Only a drag gesture (text select) suppresses the
 * following click — no sticky window after a plain selection/copy.
 */
function guardDragSelectClick(element, thresholdPx = 4) {
  let pointerStart = null
  let dragged = false
  let blockNextClick = false
  element.addEventListener("pointerdown", (event) => {
    if (!event.isPrimary || event.button !== 0) return
    pointerStart = { x: event.clientX, y: event.clientY }
    dragged = false
  })
  element.addEventListener("pointermove", (event) => {
    if (!pointerStart) return
    if (Math.hypot(event.clientX - pointerStart.x, event.clientY - pointerStart.y) > thresholdPx) {
      dragged = true
    }
  })
  const endPointer = () => {
    if (dragged) blockNextClick = true
    pointerStart = null
    dragged = false
  }
  element.addEventListener("pointerup", endPointer)
  element.addEventListener("pointercancel", () => {
    pointerStart = null
    dragged = false
  })
  return () => {
    if (!blockNextClick) return false
    blockNextClick = false
    return true
  }
}

function SitesOverviewTable(cols) {
  closeSiteActions()
  const table = document.createElement("table")
  table.className = "sites-table"
  const thead = document.createElement("thead")
  const hr = document.createElement("tr")
  const headers = ["IP", "站点", "SSL", "访问"]
  for (const [i, h] of headers.entries()) {
    const th = document.createElement("th")
    th.className = ["sites-th-host", "sites-th-site", "sites-th-ssl", "sites-th-links"][i]
    th.appendChild(document.createTextNode(h))
    if (i === 0 || i === 1) {
      const count = document.createElement("span")
      count.className = "sites-th-count"
      count.textContent = i === 0 ? `${cols.length}台` : `${cols.siteCount || 0}站`
      th.appendChild(count)
    }
    if (h === "SSL") {
      th.title = "是否启用 SSL"
      th.setAttribute("aria-label", "SSL")
    }
    hr.appendChild(th)
  }
  thead.appendChild(hr)
  table.appendChild(thead)
  const tb = document.createElement("tbody")
  for (const col of cols) {
    const sites = col.sites.length ? col.sites : [null]
    const spanN = sites.length
    const publicIP = col.ip === "未分配" || col.ip === "—" ? "" : col.ip
    sites.forEach((site, idx) => {
      const tr = document.createElement("tr")
      if (site && site.disabled) tr.className = "disabled"
      if (idx === 0) {
        // 上：终端 + 名称；下：加站点 + IP。
        const tdHost = document.createElement("td")
        tdHost.className = "sites-td-host"
        tdHost.rowSpan = spanN
        if (col.serverId) tdHost.dataset.serverId = String(col.serverId)
        const suppressHostOpenAfterDrag = guardDragSelectClick(tdHost)
        const hostCell = document.createElement("div")
        hostCell.className = "sites-host-cell" + (col.serverNote ? "" : " sites-host-cell-no-note")

        const hostActBtn = (title, iconName, label, onClick) => {
          const btn = document.createElement("button")
          btn.type = "button"
          btn.className = "sites-host-act"
          btn.title = title
          if (onClick) {
            btn.onclick = (e) => {
              e.stopPropagation()
              onClick(e)
            }
          } else {
            btn.disabled = true
          }
          btn.appendChild(ico(iconName))
          const lab = document.createElement("span")
          lab.className = "sites-host-label"
          lab.textContent = label
          btn.appendChild(lab)
          return btn
        }

        const termLine = document.createElement("div")
        termLine.className = "sites-host-line sites-host-term"
        termLine.appendChild(
          hostActBtn(
            "加站点",
            "plus",
            "站点",
            col.serverId ? () => onAddSiteUnder(col.serverId) : null,
          ),
        )
        const ipBtn = document.createElement("button")
        ipBtn.type = "button"
        ipBtn.className = "sites-ip-btn"
        ipBtn.textContent = col.ip
        ipBtn.title = col.serverId ? "编辑服务器" : ""
        if (col.serverId) {
          const suppressIPOpenAfterDrag = guardDragSelectClick(ipBtn)
          ipBtn.onclick = (e) => {
            e.stopPropagation()
            if (suppressIPOpenAfterDrag() || suppressHostOpenAfterDrag()) return
            const t = state.tree.val
            const s = (t.servers || []).find((x) => x.id === col.serverId)
            if (s) openServerDlg(s)
          }
        } else {
          ipBtn.disabled = true
        }
        termLine.appendChild(ipBtn)

        const siteLine = document.createElement("div")
        siteLine.className = "sites-host-line sites-host-site"
        siteLine.appendChild(
          hostActBtn(
            "远程终端",
            "terminal",
            "终端",
            col.serverId
              ? () => {
                  window.open(`/term.html?server=${encodeURIComponent(col.serverId)}`, "_blank", "noopener")
                }
              : null,
          ),
        )
        const noteText = document.createElement("button")
        noteText.type = "button"
        noteText.className = "sites-name-text"
        noteText.textContent = col.serverNote || ""
        if (col.serverId) {
          noteText.className += " sites-clickable"
          noteText.title = "编辑服务器"
          const suppressNoteOpenAfterDrag = guardDragSelectClick(noteText)
          noteText.onclick = (e) => {
            e.stopPropagation()
            if (suppressNoteOpenAfterDrag() || suppressHostOpenAfterDrag()) return
            const t = state.tree.val
            const s = (t.servers || []).find((x) => x.id === col.serverId)
            if (s) openServerDlg(s)
          }
        } else {
          noteText.disabled = true
        }
        siteLine.appendChild(noteText)
        hostCell.append(siteLine, termLine)

        tdHost.appendChild(hostCell)
        if (col.serverId) {
          tdHost.onclick = (e) => {
            if (e.target.closest(".sites-host-act, .sites-ip-btn, .sites-name-text")) return
            if (suppressHostOpenAfterDrag()) return
            const t = state.tree.val
            const s = (t.servers || []).find((x) => x.id === col.serverId)
            if (s) openServerDlg(s)
          }
        }
        tr.appendChild(tdHost)
      }
      if (idx === spanN - 1) tr.classList.add("sites-host-end")

      const tdSite = document.createElement("td")
      tdSite.className = "sites-td-site"
      if (!site) {
        tdSite.className += " muted"
        tdSite.textContent = "无站点"
      } else {
        tdSite.dataset.site = site.name
        const wrap = document.createElement("div")
        wrap.className = "sites-site-cell"
        wrap.appendChild(siteNavIcon(site.name))
        const name = document.createElement("span")
        name.className = "sites-site-name sites-clickable"
        name.textContent = site.title || site.name
        name.title = "打开站点"
        const suppressNameOpenAfterDrag = guardDragSelectClick(name)
        name.onclick = (e) => {
          e.stopPropagation()
          if (suppressNameOpenAfterDrag()) return
          openSite(site.name)
        }
        wrap.appendChild(name)
        if (site.disabled) {
          const badge = document.createElement("span")
          badge.className = "site-badge"
          badge.textContent = "停用"
          wrap.appendChild(badge)
        }
        const acts = document.createElement("div")
        acts.className = "sites-site-acts"
        acts.setAttribute("role", "group")
        acts.setAttribute("aria-label", "站点操作")
        const action = (title, icon, fn) => overviewIconBtn(title, icon, () => {
          closeSiteActions()
          fn()
        })
        acts.appendChild(
          action(
            site.disabled ? "启用（推回远端 conf）" : "停用（摘掉远端 conf，文件保留）",
            site.disabled ? "play" : "pause",
            () => onToggleSiteDisabled(site),
          ),
        )
        acts.appendChild(
          action("改显示名", "pen", () => onRenameSite(site)),
        )
        acts.appendChild(
          action("复制到", "copy", () => openCopyPick(site.name)),
        )
        acts.appendChild(
          action("删除", "trash", () => onDeleteSite(site.name)),
        )
        acts.id = `site-acts-${site.name}`
        const more = overviewIconBtn("站点操作", "more", () => {
          toggleSiteActions(more, acts, wrap)
        })
        more.className = "sites-site-more"
        more.setAttribute("aria-label", "站点操作")
        more.setAttribute("aria-expanded", "false")
        more.setAttribute("aria-controls", acts.id)
        wrap.append(more, acts)
        tdSite.appendChild(wrap)
        const suppressSiteOpenAfterDrag = guardDragSelectClick(tdSite)
        tdSite.onclick = (e) => {
          if (e.target.closest(".sites-site-acts, .sites-site-more, .sites-site-name")) return
          if (suppressSiteOpenAfterDrag()) return
          openSite(site.name)
        }
      }
      tr.appendChild(tdSite)

      const tdSsl = document.createElement("td")
      tdSsl.className = "sites-td-ssl"
      if (site) {
        const on = siteHasSSL(site)
        const wrap = document.createElement("span")
        wrap.className = "sites-ssl-ico" + (on ? " on" : "")
        wrap.title = on ? "已启用 SSL" : "未启用 SSL"
        wrap.appendChild(ico(on ? "lock" : "unlock"))
        tdSsl.appendChild(wrap)
      } else {
        tdSsl.className += " muted"
        tdSsl.textContent = "—"
      }
      tr.appendChild(tdSsl)

      const tdLinks = document.createElement("td")
      tdLinks.className = "sites-td-links"
      if (site) {
        const links = siteAccessLinks(site, publicIP)
        if (!links.length) {
          tdLinks.className += " muted"
          tdLinks.textContent = "—"
        } else {
          for (const l of links) {
            const link = document.createElement("a")
            link.className = "dom"
            link.href = l.href
            link.target = "_blank"
            link.rel = "noopener"
            link.title = l.href
            // Keep scheme in the label so SSL vs plain HTTP is obvious and matches click target.
            link.textContent = l.label
            link.onclick = (e) => e.stopPropagation()
            tdLinks.appendChild(link)
          }
        }
      } else {
        tdLinks.className += " muted"
        tdLinks.textContent = "—"
      }
      tr.appendChild(tdLinks)
      tb.appendChild(tr)
    })
  }
  table.appendChild(tb)
  return table
}

// Survive leaving overview for site/billing; full page reload clears these.
let overviewScrollTop = 0
let overviewScrollLeft = 0
/** Site name to flash when returning to overview. */
let overviewFocusSite = ""

function snapshotOverviewScroll() {
  const wrap = document.querySelector(".sites-table-wrap:not(.empty)")
  if (!wrap) return
  overviewScrollTop = wrap.scrollTop
  overviewScrollLeft = wrap.scrollLeft
}

function flashOverviewSite(name) {
  if (!name) return
  const sel = `.sites-td-site[data-site="${CSS.escape(name)}"]`
  const tryFlash = () => {
    const el = document.querySelector(sel)
    if (!el) return false
    const wrap = el.closest(".sites-table-wrap")
    if (wrap) {
      const er = el.getBoundingClientRect()
      const wr = wrap.getBoundingClientRect()
      if (er.top < wr.top || er.bottom > wr.bottom) {
        el.scrollIntoView({ block: "nearest", inline: "nearest" })
      }
    }
    playOverviewFlash(el, "flash-site")
    return true
  }
  requestAnimationFrame(() => {
    if (tryFlash()) return
    requestAnimationFrame(() => {
      if (tryFlash()) return
      setTimeout(tryFlash, 50)
      setTimeout(tryFlash, 150)
      setTimeout(tryFlash, 350)
    })
  })
}
let overviewCachedKey = ""
let overviewCachedTable = null

function SitesOverview() {
  return div(
    { class: "sites-overview" },
    PageShellHeader(
      GoBillingSwitch(),
      null,
      span({ class: "title" }, "站点概览"),
      null,
    ),
    () => {
      const cols = collectIpColumns()
      if (!cols.length) {
        overviewCachedKey = ""
        overviewCachedTable = null
        return div({ class: "sites-table-wrap empty muted" }, "暂无服务器")
      }
      const key = cols
        .map((c) => {
          const sites = (c.sites || [])
            .map((s) => {
              if (!s) return "-"
              const ports = (s.ports || []).join(",")
              const doms = (s.domains || []).join(",")
              return `${s.name}:${s.title || ""}:${s.disabled ? 1 : 0}:${s.ssl ? 1 : 0}:${ports}:${doms}`
            })
            .join("|")
          return `${c.serverId}:${c.ip}:${c.serverName}:${c.serverNote}:${sites}`
        })
        .join(";")
      if (key !== overviewCachedKey || !overviewCachedTable) {
        overviewCachedKey = key
        overviewCachedTable = SitesOverviewTable(cols)
        scheduleLucideFlush()
      }
      const wrap = div({
        class: "sites-table-wrap",
        onscroll: (e) => {
          overviewScrollTop = e.currentTarget.scrollTop
          overviewScrollLeft = e.currentTarget.scrollLeft
        },
      })
      wrap.appendChild(overviewCachedTable)
      queueMicrotask(() => {
        wrap.scrollTop = overviewScrollTop
        wrap.scrollLeft = overviewScrollLeft
        const focus = overviewFocusSite
        if (focus) {
          overviewFocusSite = ""
          flashOverviewSite(focus)
        }
      })
      return wrap
    },
  )
}

function Detail() {
  return div({ class: "detail" }, () => {
    const sel = state.sel.val
    if (!sel || sel.type === "sites" || sel.type === "server") return SitesOverview()
    if (sel.type === "billing") return BillingView()
    if (sel.type === "site") return SiteView()
    return null
  })
}

function billingExpireClass(row) {
  if (!row || !row.expireUnix) return ""
  const h = row.hoursLeft
  if (h <= 0) return "exp-dead"
  if (h <= 48) return "exp-hot"
  if (row.daysLeft <= 7) return "exp-warn"
  if (row.daysLeft <= 14) return "exp-soon"
  return ""
}

function formatSyncedAt(ts) {
  if (!ts) return "从未抓取"
  const d = new Date(ts * 1000)
  return d.toLocaleString()
}

function sortBillingRows(rows, direction) {
  if (!direction) return rows
  return [...rows].sort((a, b) => {
    const aKnown = a.expireUnix > 0 && Number.isFinite(Number(a.daysLeft))
    const bKnown = b.expireUnix > 0 && Number.isFinite(Number(b.daysLeft))
    if (aKnown !== bKnown) return aKnown ? -1 : 1
    if (!aKnown) return 0
    return (Number(a.daysLeft) - Number(b.daysLeft)) * (direction === "asc" ? 1 : -1)
  })
}

function BillingView() {
  return div(
    { class: "billing-view" },
    PageShellHeader(
      GoSitesSwitch(),
      null,
      button({ onclick: () => openBillingAccounts(), title: "账号" }, ico("pen"), span({ class: "btn-label" }, "账号")),
      button(
        {
          disabled: () => state.busy.val,
          title: "手动发送 TG：续费巡检 + 面板主机是否可达",
          onclick: async () => {
            try {
              state.busy.val = true
              const res = await api.billingRemind()
              const lines = [...(res.lines || [])]
              if (!res.ok) {
                lines.push(res.error || "tg remind failed")
                billingReport("TG 通知失败", lines, { ok: false })
                return
              }
              lines.push("ok")
              billingReport("TG 通知", lines)
            } catch (e) {
              pushLog(e.message || String(e), "err")
            } finally {
              state.busy.val = false
            }
          },
        },
        ico("bell"),
        span({ class: "btn-label" }, "TG"),
      ),
      button(
        {
          class: "accent",
          disabled: () => state.busy.val,
          title: "抓取荔枝（成功会归档上一版）",
          onclick: async () => {
            try {
              state.busy.val = true
              pushLog("抓取中…", "cmd")
              const res = await api.billingSync()
              // Failed-account rows also belong to the newly published version.
              state.billingSnapId.val = 0
              await loadBilling()
              const lines = [...(res.lines || [])]
              if (!res.ok) {
                lines.push(res.error || "fetch failed")
                billingReport("抓取失败", lines, { ok: false })
                return
              }
              lines.push("ok")
              billingReport("抓取", lines)
            } catch (e) {
              pushLog(e.message || String(e), "err")
            } finally {
              state.busy.val = false
            }
          },
        },
        ico("refresh"),
        span({ class: "btn-label" }, "抓取"),
      ),
      button(
        {
          disabled: () => {
            if (state.busy.val) return true
            const b = state.billing.val
            const rows = (b && b.rows) || []
            return !rows.some((r) => r.status === "抓取失败")
          },
          title: "只重试表里「抓取失败」的账号，不动已成功的",
          onclick: async () => {
            try {
              state.busy.val = true
              pushLog("重试失败账号中…", "cmd")
              const res = await api.billingSyncFailed()
              state.billingSnapId.val = 0
              await loadBilling()
              const lines = [...(res.lines || [])]
              if (!res.ok) {
                lines.push(res.error || "retry failed")
                billingReport("重试失败", lines, { ok: false })
                return
              }
              lines.push("ok")
              billingReport("重试失败账号", lines)
            } catch (e) {
              pushLog(e.message || String(e), "err")
            } finally {
              state.busy.val = false
            }
          },
        },
        ico("refresh"),
        span({ class: "btn-label btn-label-long" }, "重试失败"),
        span({ class: "btn-label btn-label-short" }, "重试"),
      ),
      button(
        {
          onclick: () => {
            const a = document.createElement("a")
            a.href = api.billingExportURL(state.billingSnapId.val || undefined)
            a.download = "billing.csv"
            a.click()
          },
          title: "导出",
        },
        ico("download"),
        span({ class: "btn-label" }, "导出"),
      ),
      // Trailing edge of mid (desktop + phone): face「版本」, menu「最新」+ history (no star).
      () => {
        const b = state.billing.val
        const snaps = (b && b.snapshots) || []
        const wrap = document.createElement("label")
        wrap.className = "billing-snap-wrap"
        wrap.title = "版本 / 历史"
        const face = document.createElement("span")
        face.className = "billing-snap-face"
        face.append(ico("dropdown"), document.createTextNode("版本"))
        const sel = document.createElement("select")
        sel.className = "billing-snap-sel"
        sel.setAttribute("aria-label", "版本")
        const n = ((b && b.rows) || []).length
        const opt0 = document.createElement("option")
        opt0.value = "0"
        opt0.textContent = b
          ? `最新 · ${formatSyncedAt(b.syncedAt)} · ${n} 台`
          : "最新 · …"
        sel.appendChild(opt0)
        for (const s of snaps) {
          const o = document.createElement("option")
          o.value = String(s.id)
          o.textContent = `#${s.id} ${s.label || ""} (${s.rowCount})`
          sel.appendChild(o)
        }
        sel.value = String(state.billingSnapId.val || 0)
        sel.onchange = async () => {
          state.billingSnapId.val = Number(sel.value) || 0
          await loadBilling()
        }
        wrap.append(face, sel)
        return wrap
      },
    ),
    () => {
      const b = state.billing.val
      if (!b) return div({ class: "muted pad" }, "加载中…")
      const direction = state.billingDaysSort.val
      const rows = sortBillingRows(b.rows || [], direction)
      if (!rows.length) {
        return div(
          { class: "muted pad" },
          "暂无数据。点「账号」配置后抓取。",
        )
      }
      const table = document.createElement("table")
      table.className = "billing-table"
      const head = document.createElement("thead")
      const headerRow = document.createElement("tr")
      for (const title of ["面板备注", "序号", "账号", "余额", "ip", "费用", "到期", "天", "cycle", "备注", "status", "带宽", "地区", "product", "os"]) {
        const th = document.createElement("th")
        th.scope = "col"
        if (title === "天") {
          th.setAttribute("aria-sort", direction === "asc" ? "ascending" : direction === "desc" ? "descending" : "none")
          const sort = document.createElement("button")
          sort.className = "billing-sort"
          sort.textContent = `天 ${direction === "asc" ? "↑" : direction === "desc" ? "↓" : "↕"}`
          sort.title = "点击切换：天数升序 → 降序 → 默认账号顺序"
          sort.onclick = () => {
            state.billingDaysSort.val = direction === "" ? "asc" : direction === "asc" ? "desc" : ""
          }
          th.appendChild(sort)
        } else th.textContent = title
        headerRow.appendChild(th)
      }
      head.appendChild(headerRow)
      table.appendChild(head)
      const tb = document.createElement("tbody")
      for (const row of rows) {
        const tr = document.createElement("tr")
        tr.className = billingExpireClass(row)
        const days = row.expireUnix ? String(row.daysLeft) : "—"
        const bal = row.balance || "—"
        const fee = row.fee || "—"
        const panelNote = row.inPanel && row.panelName ? row.panelName : ""
        tr.innerHTML = `
          <td class="panel-note"><span class="billing-panel"><span class="panel-name">${escapeHtml(panelNote)}</span><span class="panel-cell"></span></span></td>
          <td>${escapeHtml(row.accountName || "")}</td>
          <td>${escapeHtml(row.loginId || "")}</td>
          <td class="num">${escapeHtml(bal)}</td>
          <td class="mono">${escapeHtml(row.status === "抓取失败" ? "失败，请看旧版" : row.ip || "—")}</td>
          <td class="num">${escapeHtml(fee)}</td>
          <td class="mono">${escapeHtml(row.expireAt || "—")}</td>
          <td class="num">${escapeHtml(days)}</td>
          <td>${escapeHtml(row.cycle || "")}</td>
          <td class="note"><span class="note-text">${escapeHtml(row.note || "")}</span></td>
          <td>${escapeHtml(row.status || "")}</td>
          <td>${escapeHtml(row.bandwidth || "")}</td>
          <td>${escapeHtml(row.region || "")}</td>
          <td>${escapeHtml(row.product || "")}</td>
          <td>${escapeHtml(row.os || "")}</td>`
        const cell = tr.querySelector(".panel-cell")
        if (row.inPanel && row.panelServerId) {
          const btn = document.createElement("button")
          btn.className = "accent"
          btn.textContent = "打开"
          btn.title = (row.panelName || "") + "（回概览高亮该 IP）"
          btn.onclick = () => focusOverviewServer(row.panelServerId)
          cell.appendChild(btn)
        }
        tb.appendChild(tr)
      }
      table.appendChild(tb)
      const wrap = div({ class: "billing-scroll" })
      wrap.appendChild(table)
      schedulePageMinWidth()
      return wrap
    },
    () => BillingAccountsLayer(),
  )
}

function BillingAccountsLayer() {
  // Only depend on open flag — draft lives in billingAcctDraft so edits never remount.
  if (!state.billingAcctOpen.val) return div({ class: "billing-acct-layer off" })
  const draft = billingAcctDraft
  if (!draft) return div({ class: "billing-acct-layer off" })
  const close = () => {
    billingAcctDraft = null
    state.billingAcctOpen.val = false
  }
  const setTg = (key) => (e) => {
    draft.telegram[key] = e.target.value
  }
  const setAcc = (i, key) => (e) => {
    draft.accounts[i][key] = e.target.value
  }
  const list = div({ class: "billing-acct-list" })
  const renderRows = () => {
    list.replaceChildren()
    for (let i = 0; i < draft.accounts.length; i++) {
      const a = draft.accounts[i]
      const idx = i
      van.add(
        list,
        div(
          { class: "billing-acct-row" },
          input({ placeholder: "名称", value: a.name, oninput: setAcc(idx, "name") }),
          input({ placeholder: "email", value: a.email, oninput: setAcc(idx, "email") }),
          PasswordField({
            placeholder: "密码",
            value: a.password,
            oninput: setAcc(idx, "password"),
          }),
          input({
            placeholder: "group_ids",
            value: a.group_ids,
            oninput: setAcc(idx, "group_ids"),
          }),
          button(
            {
              title: "删除",
              onclick: async () => {
                if (!(await dlgConfirm(`移除续费账号「${a.name || a.email || `账号 ${idx + 1}`}」？修改会在保存后生效。`, "移除账号", {
                  confirmLabel: "移除",
                  disableEnter: true,
                  danger: true,
                }))) return
                draft.accounts.splice(idx, 1)
                renderRows()
              },
            },
            ico("trash"),
          ),
        ),
      )
    }
  }
  renderRows()
  return div(
    {
      class: "billing-acct-layer",
      onclick: (e) => {
        if (e.target.classList.contains("billing-acct-layer")) close()
      },
      onkeydown: (e) => {
        if (e.key === "Escape") {
          e.preventDefault()
          close()
        }
      },
    },
    div(
      { class: "billing-acct" },
      div(
        { class: "billing-acct-head" },
        span({ class: "title" }, "荔枝账号 / TG"),
        button({ title: "关闭 Esc", onclick: close }, ico("close")),
      ),
      div(
        { class: "billing-acct-tg" },
        label(
          {},
          "Bot Token",
          PasswordField({ value: draft.telegram.bot_token, oninput: setTg("bot_token") }),
        ),
        label({}, "Chat ID", input({ value: draft.telegram.chat_id, oninput: setTg("chat_id") })),
      ),
      list,
      div(
        { class: "billing-acct-acts" },
        button(
          {
            onclick: () => {
              draft.accounts.push({
                name: "",
                email: "",
                phone: "",
                password: "",
                base_url: "https://www.lizhidc.cn",
                group_ids: "305",
              })
              renderRows()
            },
          },
          ico("plus"),
          "加账号",
        ),
        button(
          {
            class: "accent",
            onclick: async () => {
              try {
                await saveBillingAccounts()
              } catch (e) {
                await dlgAlert(e.message || String(e))
              }
            },
          },
          ico("save"),
          "保存",
        ),
      ),
    ),
  )
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
}


/** Server editor dialog (replaces the old full-page IP view). */
function ServerDlgLayer() {
  if (!state.serverDlgOpen.val) return div({ class: "server-dlg-layer off" })
  // Mutate the draft in place — replacing serverForm remounts and steals focus.
  const f = state.serverForm.val
  if (!f) return div({ class: "server-dlg-layer off" })
  const title = van.state(f.name || f.host || f.publicIP || "服务器")
  const bind = (key) => (e) => {
    f[key] = e.target.value
    if (key === "name") title.val = e.target.value || f.host || f.publicIP || "服务器"
  }
  const saving = van.state(false)
  let saveRequest = null
  const save = () => {
    if (saveRequest) return saveRequest
    saving.val = true
    saveRequest = (async () => {
      const cur = f
      const ip = (cur.host || cur.publicIP || "").trim()
      if (!ip) throw new Error("请填写 IP")
      const body = {
        id: cur.id || 0,
        name: "",
        host: ip,
        publicIP: ip,
        port: cur.port || 22,
        user: cur.user || "root",
        authType: cur.authType === "key" && cur.authValue ? "key" : "password",
        authValue: cur.authValue || "",
        password: cur.password || "",
        note: (cur.note || "").trim(),
        viaJump: !!cur.viaJump,
      }
      const saved = await api.saveServer(body)
      Object.assign(cur, saved)
      title.val = cur.name || cur.host || cur.publicIP || "服务器"
      await refreshTree()
      return saved
    })().finally(() => {
      saveRequest = null
      saving.val = false
    })
    return saveRequest
  }
  return div(
    {
      class: "server-dlg-layer",
      onclick: (e) => {
        if (e.target.classList.contains("server-dlg-layer")) closeServerDlg()
      },
    },
    div(
      {
        class: "server-dlg",
        tabindex: "0",
        onkeydown: (e) => {
          if (e.key === "Escape") {
            e.preventDefault()
            closeServerDlg()
          }
        },
      },
      div(
        { class: "server-dlg-head" },
        span({ class: "title" }, () => title.val),
        button({ class: "server-dlg-close", title: "关闭 Esc", onclick: () => closeServerDlg() }, ico("close")),
      ),
      div(
        { class: "server-body" },
        div(
          { class: "fields server-form" },
          label("IP"),
          input({
            value: f.host || f.publicIP || "",
            oninput: (e) => {
              const v = e.target.value
              f.host = v
              f.publicIP = v
            },
          }),
          label("端口"),
          input({
            value: String(f.port || 22),
            oninput: (e) => {
              f.port = Number(e.target.value) || 22
            },
          }),
          label("用户"),
          input({ value: f.user || "", oninput: bind("user") }),
          label("SSH 密码"),
          div(
            { class: "row" },
            PasswordField({
              style: "flex:1",
              placeholder: "SSH 密码（库内加密）",
              value: f.password || "",
              oninput: bind("password"),
            }),
            button(
              {
                title: "如服务器重装导致 SSH 主机密钥变化，会自动更新该主机记录并重装面板密钥",
                onclick: async () => {
                  if (!f.id) {
                    await dlgAlert("请先保存")
                    return
                  }
                  pushLog(`install-key #${f.id}`, "cmd")
                  try {
                    await save()
                    const res = await api.installKey(f.id, f.password)
                    Object.assign(f, res.server || {})
                    title.val = f.name || f.host || f.publicIP || "服务器"
                    await refreshTree()
                    pushLog(`key → ${res.keyPath}`, "ok")
                  } catch (e) {
                    pushLog(e.message, "err")
                  }
                },
              },
              ico("key"),
              "重装密钥",
            ),
          ),
          label("备注（可选）"),
          input({
            placeholder: "备注（可选）",
            value: f.note || "",
            oninput: bind("note"),
          }),
          label(
            {
              class: "check block",
              title: "HK 直连不稳时走国内跳板（与荔枝 SOCKS 同机）",
            },
            input({
              type: "checkbox",
              checked: !!f.viaJump,
              onchange: (e) => {
                f.viaJump = !!e.target.checked
              },
            }),
            "经国内跳板（部署/终端/装钥）",
          ),
        ),
      ),
      div(
        { class: "server-dlg-foot" },
        button(
          {
            class: "danger",
            disabled: () => saving.val || state.busy.val || !f.id,
            onclick: async () => {
              const cols = collectIpColumns()
              const col = cols.find((c) => c.serverId === f.id)
              const siteNames = (col?.sites || []).map((s) => s.title || s.name)
              const label = f.note || f.name || f.host || f.publicIP || `服务器 #${f.id}`
              const detail = `服务器：${label}\nIP：${f.publicIP || f.host || "未知"}\n绑定站点：${siteNames.length ? siteNames.join("、") : "无"}\n删除只移除面板记录并解绑站点，远端文件不会删除。`
              if (!(await dlgConfirm(detail, "删除服务器", { confirmLabel: "继续删除", disableEnter: true, danger: true }))) return
              if (!(await dlgConfirm(detail, "再次确认删除服务器", { confirmLabel: "确认删除", cancelLabel: "保留服务器", disableEnter: true, confirmFirst: true, danger: true }))) return
              if (f.id) await api.deleteServer(f.id)
              closeServerDlg()
              await refreshTree()
            },
          },
          ico("trash"),
          "删除",
        ),
        button(
          {
            disabled: () => state.busy.val || saving.val,
            onclick: async () => {
              try {
                await save()
                pushLog(`server saved #${f.id}`, "ok")
              } catch (e) {
                await dlgAlert(e.message)
              }
            },
          },
          ico("save"),
          "保存",
        ),
        button(
          {
            class: "accent",
            title: "装密钥并安装 Nginx/rsync",
            disabled: () => state.busy.val || saving.val,
            onclick: async () => {
              if (!f.id && !(f.host || f.publicIP)) {
                await dlgAlert("请先填写 IP 并保存")
                return
              }
              if (
                !(await dlgConfirm(
                  "装密钥 + 安装 Nginx/rsync，并加 fail2ban / sshd 基本限制？\n\n仅 Debian/Ubuntu。CentOS 等会直接拒绝初始化。",
                ))
              )
                return
              try {
                await save()
              } catch (e) {
                await dlgAlert(e.message)
                return
              }
              state.busy.val = true
              const id = f.id
              const pw = f.password
              try {
                pushLog(`install-key #${id}`, "cmd")
                const keyRes = await api.installKey(id, pw)
                Object.assign(f, keyRes.server || {})
                title.val = f.name || f.host || f.publicIP || "服务器"
                pushLog(`key → ${keyRes.keyPath}`, "ok")
                pushLog(`install-nginx #${id}`, "cmd")
                const res = await api.installNginx(id, pw)
                for (const line of res.lines || []) pushLog(line, res.ok ? "cmd" : "err")
                if (!res.ok) throw new Error(res.error || "install failed")
                pushLog("服务器已就绪", "ok")
                await refreshTree()
              } catch (e) {
                pushLog(e.message, "err")
                await dlgAlert(e.message)
              } finally {
                state.busy.val = false
              }
            },
          },
          ico("package"),
          "装 Nginx",
        ),
      ),
    ),
  )
}

function SecurityLayer() {
  if (!state.securityOpen.val) return div({ class: "pick-layer off" })
  const oldPw = van.state("")
  const newPw = van.state("")
  const newPw2 = van.state("")
  const msg = van.state("")
  return div(
    {
      class: "pick-layer",
      tabindex: "0",
      onkeydown: (e) => {
        if (e.key === "Escape") {
          e.preventDefault()
          state.securityOpen.val = false
        }
      },
    },
    div({ class: "pick-backdrop", onclick: () => (state.securityOpen.val = false) }),
    div(
      { class: "pick-panel security-panel" },
      div(
        { class: "pick-head" },
        span({ class: "grow" }, "改密码"),
        button({ title: "关闭 Esc", onclick: () => (state.securityOpen.val = false) }, ico("close")),
      ),
      div(
        { class: "fields" },
        PasswordField({
          placeholder: "当前密码",
          value: oldPw,
          oninput: (e) => (oldPw.val = e.target.value),
        }),
        PasswordField({
          placeholder: "新密码",
          value: newPw,
          oninput: (e) => (newPw.val = e.target.value),
        }),
        PasswordField({
          placeholder: "再输入一次新密码",
          value: newPw2,
          oninput: (e) => (newPw2.val = e.target.value),
        }),
        button(
          {
            class: "accent",
            onclick: async () => {
              msg.val = ""
              if (newPw.val !== newPw2.val) {
                msg.val = "两次新密码不一致"
                return
              }
              try {
                await api.changePassword(oldPw.val, newPw.val)
                oldPw.val = ""
                newPw.val = ""
                newPw2.val = ""
                msg.val = "已更新"
              } catch (e) {
                msg.val = e.message
              }
            },
          },
          "更新",
        ),
        () => (msg.val ? p({ class: msg.val === "已更新" ? "ok-msg" : "err" }, msg.val) : null),
      ),
    ),
  )
}

function siteDisplayName(name) {
  const sm = state.siteMeta.val
  if (sm && sm.meta && sm.meta.title) return sm.meta.title
  const t = state.tree.val
  if (t && t.byServer) {
    for (const list of Object.values(t.byServer)) {
      const hit = (list || []).find((s) => s.name === name)
      if (hit) return hit.title || hit.name
    }
  }
  const u = (t && t.unassigned) || []
  const hit = u.find((s) => s.name === name)
  return (hit && (hit.title || hit.name)) || name
}

/** Bound server IP for site chrome (publicIP, else host). Empty when unbound. */
function siteBoundIP(name) {
  const t = state.tree.val
  const sm = state.siteMeta.val
  const sid = (sm && sm.meta && sm.meta.serverId) || (sm && sm.serverId) || 0
  if (t && t.servers && sid) {
    const s = (t.servers || []).find((x) => x.id === sid)
    if (s) return s.publicIP || s.host || ""
  }
  if (t && t.byServer) {
    for (const [id, list] of Object.entries(t.byServer)) {
      if (!(list || []).some((s) => s.name === name)) continue
      const s = (t.servers || []).find((x) => String(x.id) === String(id))
      if (s) return s.publicIP || s.host || ""
    }
  }
  return ""
}

function siteTopTitleText(name) {
  const label = siteDisplayName(name)
  const ip = siteBoundIP(name)
  const off = !!(state.siteMeta.val && state.siteMeta.val.meta && state.siteMeta.val.meta.disabled)
  let text = ip ? `${ip} · ${label}` : label
  if (off) text += " [停用]"
  return text
}

/** Live CodeJar handle for toolbar actions. */
let liveTextEditor = null

/** Desktop editor pane header: all tools expanded (no ⋯ fold). */
function EditorPaneHead(siteName) {
  return () => {
    void state.fsFile.val
    void state.fsKind.val
    void state.fsDirty.val
    void state.busy.val
    void state.siteMeta.val
    const path = state.fsFile.val
    const textOn = path && state.fsKind.val === "text"
    if (!textOn) {
      return div({ class: "pane-head editor-pane-head is-empty", "aria-hidden": "true" })
    }
    const isNginx = String(path).split("/").pop() === "nginx.conf"
    const kids = [
      span({ class: "files-head-grow" }),
      button(
        {
          type: "button",
          class: () => "editor-head-btn editor-head-save" + (state.fsDirty.val ? " accent" : ""),
          title: "保存 (Ctrl/⌘S)",
          disabled: () => state.busy.val || !state.fsDirty.val,
          onclick: () => saveCurrentFile(siteName),
        },
        ico("save"),
        "保存",
      ),
      button(
        {
          type: "button",
          class: "editor-head-btn",
          title: "历史",
          disabled: () => state.busy.val,
          onclick: () => openFileHistory(siteName, path),
        },
        ico("clock"),
        "历史",
      ),
      button(
        {
          type: "button",
          class: "editor-head-btn",
          title: "注释选中行 (Ctrl/⌘/)",
          disabled: () => state.busy.val,
          onmousedown: (event) => event.preventDefault(),
          onclick: () => applyEditorComment(),
        },
        ico("comment"),
        "注释",
      ),
    ]
    if (isNginx) {
      kids.push(
        button(
          {
            type: "button",
            class: "editor-head-btn",
            title: "片段1",
            onclick: () => showNginxSnippet(1),
          },
          "片段1",
        ),
        button(
          {
            type: "button",
            class: "editor-head-btn",
            title: "片段2",
            onclick: () => showNginxSnippet(2),
          },
          "片段2",
        ),
      )
    }
    kids.push(apkToggleBtn(siteName, { className: "editor-head-btn editor-head-apk", showLabel: true }))
    return div({ class: "pane-head editor-pane-head" }, ...kids)
  }
}

/** Phone: vertical save/tools rail on the editor right edge. */
const editorRailOpen = van.state(false)
function EditorRailFloat(siteName) {
  return () => {
    void state.fsFile.val
    void state.fsKind.val
    void state.fsDirty.val
    void state.busy.val
    void state.siteMeta.val
    void editorRailOpen.val
    const path = state.fsFile.val
    const textOn = path && state.fsKind.val === "text"
    if (!textOn) {
      if (editorRailOpen.val) editorRailOpen.val = false
      return div({ class: "editor-rail-float off", "aria-hidden": "true" })
    }
    const isNginx = String(path).split("/").pop() === "nginx.conf"
    const open = editorRailOpen.val
    const railBtn = (title, iconName, fn, cls = "", preserveSelection = false) =>
      button(
        {
          type: "button",
          class: "files-op" + (cls ? " " + cls : ""),
          title,
          "aria-label": title,
          disabled: () => state.busy.val,
          onmousedown: preserveSelection ? (event) => event.preventDefault() : undefined,
          onclick: () => fn(),
        },
        ico(iconName),
      )
    const saveBtn = button(
      {
        type: "button",
        class: () => "files-op editor-rail-save" + (state.fsDirty.val ? " accent" : ""),
        title: "保存 (Ctrl/⌘S)",
        "aria-label": "保存",
        disabled: () => state.busy.val || !state.fsDirty.val,
        onclick: () => saveCurrentFile(siteName),
      },
      ico("save"),
    )
    // Top edge: save + expand/collapse → 「7」; extra tools hang down the right.
    const top = [
      saveBtn,
      open
        ? railBtn("收起", "close", () => {
            editorRailOpen.val = false
          })
        : railBtn("更多编辑操作", "more", () => {
            editorRailOpen.val = true
          }),
    ]
    const down = []
    if (open) {
      down.push(
        railBtn("历史", "clock", () => {
          editorRailOpen.val = false
          openFileHistory(siteName, path)
        }),
        railBtn("注释", "comment", () => {
          applyEditorComment()
        }, "", true),
      )
      if (isNginx) {
        down.push(
          railBtn("片段1", "filePlus", () => {
            editorRailOpen.val = false
            showNginxSnippet(1)
          }),
          railBtn("片段2", "filePlus", () => {
            editorRailOpen.val = false
            showNginxSnippet(2)
          }),
        )
      }
      down.push(apkToggleBtn(siteName, { className: "files-op editor-rail-apk", showLabel: false }))
    }
    const railKids = [div({ class: "editor-rail-top" }, ...top)]
    if (down.length) railKids.push(div({ class: "editor-rail-down" }, ...down))
    return div(
      { class: "editor-rail-float" + (open ? " open" : ""), role: "toolbar", "aria-label": "编辑操作" },
      ...railKids,
    )
  }
}

function SiteView() {
  const name = state.sel.val.name
  return div({ class: "site-view" }, SiteTopBar(name), SiteFiles(name))
}

function formatConfCheck(check) {
  if (!check) return ""
  const parts = []
  for (const e of check.errors || []) parts.push("错误: " + e)
  for (const w of check.warnings || []) parts.push("注意: " + w)
  return parts.join("\n")
}

/** Coalesce overlapping Ctrl/Cmd-S (CodeMirror + window) into one save/log. */
let saveFileInflight = null

async function saveCurrentFile(name) {
  // Keyboard shortcuts must obey the same guard as the disabled Save button.
  if (state.busy.val) return
  const path = state.fsFile.val
  if (!path || state.fsKind.val !== "text" || !state.fsDirty.val) return
  if (saveFileInflight) {
    await saveFileInflight
    if (isCurrentSite(name) && state.fsFile.val === path && state.fsDirty.val) return saveCurrentFile(name)
    return
  }
  saveFileInflight = (async () => {
    try {
      const content = state.fsText.val
      const res = await api.writeFile(name, path, content)
      const isNginxConf = path === CONF_PATH || path.endsWith("/" + CONF_PATH)
      if (isCurrentSite(name) && state.fsFile.val === path) {
        if (isNginxConf && typeof res.content === "string" && res.content !== content) {
          // CodeJar does not follow state.fsText — push into the live editor too.
          if (liveTextEditor && liveTextEditor.path === path) liveTextEditor.set(res.content)
          else state.fsText.val = res.content
          if (/^\s*listen\s+80\b/m.test(res.content) && !/^\s*listen\s+80\b/m.test(content)) {
            pushLog("已自动加上 listen 80（配置里有域名）", "ok")
          }
        }
        state.fsDirty.val = false
      }
      if (isCurrentSite(name)) setSitePendingDeploy(true)
      pushLog(isNginxConf ? "nginx.conf 基础检查通过并已保存" : "saved " + path, "ok")
      for (const w of (res.confCheck && res.confCheck.warnings) || []) pushLog("注意: " + w, "err")
      // Left-nav domains/ports come from master conf — refresh as soon as nginx.conf is saved.
      if (path === CONF_PATH || path.endsWith("/" + CONF_PATH) || Object.prototype.hasOwnProperty.call(res, "domains")) {
        await refreshTree()
      }
    } catch (e) {
      const check = e && e.data && e.data.confCheck
      const note = formatConfCheck(check)
      if (note) {
        pushLog(note, "err")
        await dlgAlert(note, "nginx.conf 未保存")
      } else {
        pushLog(e.message, "err")
      }
    } finally {
      saveFileInflight = null
    }
  })()
  return saveFileInflight
}

function joinPath(dir, name) {
  return dir ? dir.replace(/\/$/, "") + "/" + name : name
}

async function fsNewFile(site) {
  const n = await dlgPrompt("新文件名")
  if (!n) return
  const path = joinPath(state.fsDir.val, n)
  try {
    await api.touch(site, path)
    if (isCurrentSite(site)) setSitePendingDeploy(true)
    await loadDir(site, state.fsDir.val)
    await openFile(site, path, true)
  } catch (e) {
    await dlgAlert(e.message)
  }
}

async function fsNewDir(site) {
  const n = await dlgPrompt("新文件夹名")
  if (!n) return
  const path = joinPath(state.fsDir.val, n)
  try {
    await api.mkdir(site, path)
    if (isCurrentSite(site)) setSitePendingDeploy(true)
    await loadDir(site, state.fsDir.val)
  } catch (e) {
    await dlgAlert(e.message)
  }
}

async function fsRename(site, entry) {
  const oldName = entry.name || String(entry.path).split("/").pop()
  const raw = await dlgPrompt("新名称", oldName)
  if (raw == null) return
  const name = raw.trim().replace(/[\\/]/g, "")
  if (!name || name === oldName) return
  if (name.includes("..")) {
    await dlgAlert("名称无效")
    return
  }
  const parent = parentPath(entry.path)
  const to = parent ? `${parent}/${name}` : name
  try {
    await api.renamePath(site, entry.path, to)
    if (isCurrentSite(site)) setSitePendingDeploy(true)
    if (state.fsFile.val === entry.path) {
      state.fsFile.val = to
      state.fsDirty.val = false
    } else if ((state.fsFile.val || "").startsWith(entry.path + "/")) {
      state.fsFile.val = to + state.fsFile.val.slice(entry.path.length)
    }
    await loadDir(site, state.fsDir.val)
    pushLog(`rename ${entry.path} → ${to}`, "ok")
  } catch (e) {
    await dlgAlert(e.message)
  }
}

async function fsDelete(site, entries) {
  const list = Array.isArray(entries) ? entries : entries ? [entries] : []
  if (!list.length) return
  const shown = list.slice(0, 8).map((entry) => entry.path)
  const more = list.length > shown.length ? `\n……以及另外 ${list.length - shown.length} 项` : ""
  const paths = shown.length === 1 ? shown[0] : `\n${shown.map((path) => `• ${path}`).join("\n")}${more}`
  if (!(await dlgConfirm(`将从站点 ${site} 删除：${paths}\n删除后无法恢复。`, "删除文件", { confirmLabel: "删除", disableEnter: true, danger: true }))) return
  try {
    for (const entry of list) {
      await api.deletePath(site, entry.path)
      if (state.fsFile.val === entry.path || (state.fsFile.val || "").startsWith(entry.path + "/")) {
        state.fsFile.val = ""
        state.fsText.val = ""
        state.fsDirty.val = false
        state.fsRev.val++
      }
    }
    if (isCurrentSite(site)) setSitePendingDeploy(true)
    await loadDir(site, state.fsDir.val)
  } catch (e) {
    await dlgAlert(e.message)
  }
}

async function fsUpload(site, files) {
  if (!files || !files.length) return
  const selected = Array.from(files)
  const dir = state.fsDir.val || WWW_ROOT
  const archFiles = selected.filter((f) => isArchiveName(f.name || ""))
  let zipMode = "keep"
  if (archFiles.length) {
    zipMode = await dlgChoice(
      `选中了 ${archFiles.length} 个压缩包（zip / tar / 7z / rar 等）。\n\n原样上传：留下压缩包\n解压到文件夹：解到「包名/」，然后删掉压缩包\n铺开解压：解到当前目录，然后删掉压缩包`,
      "压缩包怎么处理",
      [
        { value: "keep", label: "原样上传" },
        { value: "folder", label: "解压到文件夹" },
        { value: "flat", label: "铺开解压", accent: true },
      ],
    )
    if (!zipMode) return
  }
  let uploaded = 0
  state.busy.val = true
  pushLog(`准备上传 ${selected.length} 个文件 → ${site}/${dir}`, "cmd")
  try {
    pushLog("检查目标目录同名项目…", "cmd")
    const check = await api.uploadConflicts(site, dir, selected.map((f) => f.name))
    const policy = await resolveNameConflicts("upload", check.conflicts || [], selected.map((f) => f.name))
    if (!policy) {
      pushLog("已取消上传", "cmd")
      return
    }
    for (const [index, f] of selected.entries()) {
      const isArch = isArchiveName(f.name || "")
      const extract = isArch && zipMode !== "keep"
      pushLog(`上传中 (${index + 1}/${selected.length}) ${f.name}`, "cmd")
      const res = await api.upload(site, dir, f, policy)
      uploaded++
      if (isCurrentSite(site)) setSitePendingDeploy(true)
      const uploadedPath = res.path || joinPath(dir, f.name)
      pushLog("uploaded " + uploadedPath, "ok")
      if (extract) {
        pushLog(`解压 ${uploadedPath}（${zipMode === "flat" ? "铺开" : "到文件夹"}）…`, "cmd")
        const uz = await api.unzip(site, uploadedPath, "", zipMode)
        await api.deletePath(site, uploadedPath)
        if (zipMode === "flat") {
          pushLog(`unzip → 铺开` + (uz.dest ? ` @ ${uz.dest}` : "") + "，已删压缩包", "ok")
        } else {
          pushLog(`unzip → ${uz.dest || ""}，已删压缩包`, "ok")
        }
      }
    }
    await loadDir(site, state.fsDir.val)
    pushLog(`上传完成：${uploaded} 个文件`, "ok")
  } catch (e) {
    if (uploaded > 0) {
      if (isCurrentSite(site)) setSitePendingDeploy(true)
      try {
        await loadDir(site, dir)
      } catch (_) {}
    }
    pushLog(`上传失败：${e.message || String(e)}`, "err")
    await dlgAlert(e.message)
  } finally {
    state.busy.val = false
  }
}

function fsDownload(site, entry) {
  if (entry.dir) return
  const a = document.createElement("a")
  a.href = api.downloadURL(site, entry.path)
  a.download = entry.name
  a.click()
}

async function fsZip(site, entries) {
  const list = Array.isArray(entries) ? entries : entries ? [entries] : selectedEntries()
  if (!list.length) {
    await dlgAlert("请选择文件或文件夹")
    return
  }
  const def = list.length === 1 ? list[0].name : "archive"
  const out = await dlgPrompt("压缩包名", def.replace(/\.zip$/i, "") + ".zip")
  if (!out) return
  const outPath = joinPath(state.fsDir.val, out.replace(/\.zip$/i, "") + ".zip")
  try {
    await api.zip(
      site,
      list.map((e) => e.path),
      outPath,
    )
    if (isCurrentSite(site)) setSitePendingDeploy(true)
    await loadDir(site, state.fsDir.val)
    pushLog("zip → " + outPath, "ok")
  } catch (e) {
    await dlgAlert(e.message)
  }
}

async function fsUnzip(site, entry) {
  if (!isArchiveName(entry.name)) return
  const base = archiveBaseName(entry.name)
  const mode = await dlgChoice(
    `「${entry.name}」\n\n解压到文件夹：新建或合并 ${base}/，包内结构原样放入\n铺开：直接解到当前目录，包内结构原样展开\n\n目标位置已有同名文件时会直接覆盖；其他文件保留。`,
    "解压方式",
    [
      { value: "folder", label: "解压到文件夹" },
      { value: "flat", label: "铺开", accent: true },
    ],
  )
  if (!mode) return
  try {
    const res = await api.unzip(site, entry.path, "", mode)
    if (isCurrentSite(site)) setSitePendingDeploy(true)
    await loadDir(site, state.fsDir.val)
    if (res.mode === "flat") {
      pushLog(`unzip ${entry.path} → 铺开` + (res.dest ? ` @ ${res.dest || "/"}` : ""), "ok")
    } else {
      pushLog(`unzip ${entry.path} → 文件夹 ${res.dest || ""}`, "ok")
    }
  } catch (e) {
    await dlgAlert(e.message)
  }
}

function closeCtx() {
  state.ctxMenu.val = null
}

function openCtx(e, site, entry) {
  if (e && e.preventDefault) e.preventDefault()
  if (e && e.stopPropagation) e.stopPropagation()
  let targets = null
  if (entry) {
    const sel = state.fsSelected.val
    if ((state.fsSelectMode.val || sel.length > 1) && sel.includes(entry.path) && sel.length) {
      targets = selectedEntries()
    } else targets = [entry]
  } else if (state.fsSelected.val.length) {
    targets = selectedEntries()
  }
  const x = e && e.clientX != null ? e.clientX : 16
  const y = e && e.clientY != null ? e.clientY : 16
  state.ctxMenu.val = { x, y, site, entry, targets }
}

function CtxMenu() {
  return () => {
    const m = state.ctxMenu.val
    if (!m) return div({ class: "ctx off" })
    const { site, entry, targets } = m
    const multi = targets && targets.length > 1
    const selectedN = (targets && targets.length) || 0
    const items = []
    const add = (label, fn, icon) => {
      items.push(
        button({
          onclick: async () => {
            closeCtx()
            await fn()
          },
        }, icon ? ico(icon) : null, label),
      )
    }
    const sep = (label) => {
      items.push(div({ class: "ctx-sep" }, label || ""))
    }
    const addDirOps = () => {
      add("新建文件", () => fsNewFile(site), "file")
      add("新建文件夹", () => fsNewDir(site), "folder")
      add("上传", () => {
        const inp = document.createElement("input")
        inp.type = "file"
        inp.multiple = true
        inp.onchange = () => fsUpload(site, inp.files)
        inp.click()
      }, "upload")
    }
    if (!entry) {
      if (selectedN) {
        sep(`已选 ${selectedN}`)
        add("复制", () => fsClipboardSet(site, "copy", null), "copy")
        add("剪切", () => fsClipboardSet(site, "cut", null), "cut")
        add("压缩", () => fsZip(site, targets), "zip")
        add("删除", () => fsDelete(site, targets), "trash")
        add("取消多选", () => clearSelectMode())
        sep("当前目录")
      }
      if (state.clip.val) add("粘贴到此", () => fsPaste(site), "paste")
      addDirOps()
    } else if (multi || (state.fsSelectMode.val && selectedN > 1)) {
      sep(`已选 ${selectedN}`)
      add("复制", () => fsClipboardSet(site, "copy", null), "copy")
      add("剪切", () => fsClipboardSet(site, "cut", null), "cut")
      add("压缩", () => fsZip(site, targets), "zip")
      add("删除", () => fsDelete(site, targets), "trash")
      add("取消多选", () => clearSelectMode())
      sep("当前目录")
      if (state.clip.val) add("粘贴到此", () => fsPaste(site), "paste")
      addDirOps()
    } else {
      const one = (targets && targets[0]) || entry
      sep("此项")
      add("复制", () => fsClipboardSet(site, "copy", one), "copy")
      add("剪切", () => fsClipboardSet(site, "cut", one), "cut")
      if (!one.dir) add("下载", () => fsDownload(site, one), "download")
      add("重命名", () => fsRename(site, one), "pen")
      add("压缩 zip", () => fsZip(site, one), "zip")
      if (!one.dir && isArchiveName(one.name)) add("解压", () => fsUnzip(site, one), "unzip")
      add("删除", () => fsDelete(site, one), "trash")
      sep("当前目录")
      if (state.clip.val) add("粘贴到此", () => fsPaste(site), "paste")
      addDirOps()
    }
    const menu = div(
      {
        class: "ctx",
        style: `left:${m.x}px;top:${m.y}px`,
        onclick: (e) => e.stopPropagation(),
      },
      ...items,
    )
    queueMicrotask(() => {
      if (!menu.isConnected) return
      const r = menu.getBoundingClientRect()
      const pad = 8
      let left = m.x
      let top = m.y
      if (r.right > window.innerWidth - pad) left = Math.max(pad, window.innerWidth - r.width - pad)
      if (r.bottom > window.innerHeight - pad) top = Math.max(pad, window.innerHeight - r.height - pad)
      if (left < pad) left = pad
      if (top < pad) top = pad
      menu.style.left = left + "px"
      menu.style.top = top + "px"
    })
    return div(
      { class: "ctx-layer", onclick: closeCtx, oncontextmenu: (e) => e.preventDefault() },
      menu,
    )
  }
}

function pickUpload(site) {
  const inp = document.createElement("input")
  inp.type = "file"
  inp.multiple = true
  inp.onchange = () => fsUpload(site, inp.files)
  inp.click()
}

function filesOpBtn(iconName, title, fn, opts = {}) {
  return button(
    {
      type: "button",
      class: "files-op" + (opts.accent ? " accent" : ""),
      title,
      "aria-label": title,
      disabled: () => state.busy.val || !!opts.disabled,
      onclick: () => fn(),
    },
    ico(iconName),
  )
}

/** nginx.conf control — sits after 新建文件夹 in the files head. */
function SiteConfBtn(site) {
  return () => {
    void state.fsFile.val
    const on = state.fsFile.val === CONF_PATH
    return button(
      {
        class: "files-conf-btn" + (on ? " on" : ""),
        type: "button",
        title: "站点 nginx 配置（与 www 内容分开）",
        onclick: async () => {
          closeCtx()
          await openFile(site, CONF_PATH)
        },
      },
      CONF_PATH,
    )
  }
}

/** Site chrome: ←概览 | centered name | 部署 SSL. Save/⋯ live on the editor. */
function SiteTopBar(name) {
  return div(
    { class: "site-top-bar" },
    div({ class: "site-top-left" }, BackToOverviewBtn()),
    span(
      { class: "site-top-title", title: () => siteTopTitleText(name) },
      // VanJS stringifies arrays — keep one reactive root with real child nodes.
      () => {
        void state.siteMeta.val
        void state.tree.val
        const label = siteDisplayName(name)
        const ip = siteBoundIP(name)
        const off = !!(state.siteMeta.val && state.siteMeta.val.meta && state.siteMeta.val.meta.disabled)
        const nameText = off ? `${label} [停用]` : label
        return span(
          { class: "site-top-title-stack" },
          ip ? span({ class: "site-top-title-ip" }, ip) : null,
          span({ class: "site-top-title-name" }, nameText),
        )
      },
    ),
    div(
      { class: "site-top-right toolbar-acts" },
      button(
        {
          class: () => "accent" + (state.deployPending.val ? " has-pending" : ""),
          title: () =>
            state.deployPending.val
              ? "有已保存未部署的修改 — 先同步站点与配置"
              : "先同步站点与配置",
          disabled: () =>
            state.busy.val ||
            state.fsDirty.val ||
            !!(state.siteMeta.val && state.siteMeta.val.meta && state.siteMeta.val.meta.disabled),
          onclick: () => doDeploy(name),
        },
        ico("rocket"),
        span({ class: "act-label-full" }, "先部署"),
        span({ class: "act-label-short", "aria-hidden": "true" }, "先部署"),
        span({
          class: () => "act-pending-dot" + (state.deployPending.val ? " on" : ""),
          "aria-hidden": "true",
        }),
      ),
      button(
        {
          class: "site-ssl-btn",
          title: "部署完成后再申请 / 同步证书",
          disabled: () =>
            state.busy.val ||
            state.fsDirty.val ||
            !!(state.siteMeta.val && state.siteMeta.val.meta && state.siteMeta.val.meta.disabled),
          onclick: () => doSSL(name, false),
        },
        ico("lock"),
        span({ class: "act-label-full" }, "再SSL"),
        span({ class: "act-label-short", "aria-hidden": "true" }, "再SSL"),
      ),
    ),
  )
}

/** File-pane head: select · conf · dir · upload/new. */
function FilesPaneHead(site) {
  return () => {
    void state.busy.val
    void state.fsDir.val
    void state.fsSelected.val
    void state.fsEntries.val
    void state.fsFile.val
    const dir = state.fsDir.val || WWW_ROOT
    const atRoot = dir === WWW_ROOT
    const dirLabel = atRoot ? "www" : dir.replace(/^www\/?/, "") || "www"
    const n = state.fsSelected.val.length
    const total = dirEntryPaths().length
    const all = total > 0 && allDirSelected()
    const kids = [
      label(
        {
          class: "files-select-all" + (all ? " on" : ""),
          title: all ? "取消全选" : "全选当前目录",
        },
        input({
          type: "checkbox",
          class: "file-check",
          checked: all,
          disabled: () => state.busy.val || total === 0,
          onchange: () => toggleSelectAll(),
        }),
        span(
          { class: "files-sel-n muted", title: n ? `已选 ${n} / ${total}` : "未选择" },
          String(n),
        ),
      ),
      SiteConfBtn(site),
      span({ class: "files-dir-label muted", title: dir }, dirLabel),
      span({ class: "files-head-grow" }),
      filesOpBtn("upload", "上传到当前目录", () => pickUpload(site)),
      filesOpBtn("filePlus", "新建文件", () => fsNewFile(site)),
      filesOpBtn("folderPlus", "新建文件夹", () => fsNewDir(site)),
    ]
    schedulePageMinWidth()
    return div({ class: "pane-head files-head" }, ...kids)
  }
}

/** Selection actions: vertical float on the right edge of the file list. */
function FilesSelectFloat(site) {
  return () => {
    void state.fsSelected.val
    void state.fsSelectMode.val
    void state.busy.val
    const sel = selectedEntries()
    const selN = sel.length
    if (!selN) return div({ class: "files-select-float off", "aria-hidden": "true" })
    const one = selN === 1 ? sel[0] : null
    const kids = [
      filesOpBtn("copy", "复制所选 (Ctrl/⌘C)", () => fsClipboardSet(site, "copy", null)),
      filesOpBtn("cut", "剪切所选 (Ctrl/⌘X)", () => fsClipboardSet(site, "cut", null)),
      filesOpBtn("zip", "压缩所选", () => fsZip(site, sel)),
      filesOpBtn("trash", "删除所选", () => fsDelete(site, sel)),
    ]
    if (one) {
      kids.push(filesOpBtn("pen", "重命名", () => fsRename(site, one)))
      if (!one.dir) kids.push(filesOpBtn("download", "下载", () => fsDownload(site, one)))
      if (!one.dir && isArchiveName(one.name)) kids.push(filesOpBtn("unzip", "解压", () => fsUnzip(site, one)))
    }
    kids.push(filesOpBtn("close", "取消多选", () => clearSelectMode()))
    return div({ class: "files-select-float", role: "toolbar", "aria-label": "已选操作" }, ...kids)
  }
}

function SiteFiles(name) {
  return div(
    { class: "files" },
    FilesPaneHead(name),
    EditorPaneHead(name),
    // Floats are children of .files so phone can hang them over the editor at the divider.
    FilesSelectFloat(name),
    ClipFloat(name),
    div(
      { class: "file-side" },
      div(
        {
          class: "file-scroll",
          ondragover: (e) => {
            e.preventDefault()
            e.currentTarget.classList.add("drag-over")
          },
          ondragleave: (e) => {
            if (!e.currentTarget.contains(e.relatedTarget)) e.currentTarget.classList.remove("drag-over")
          },
          ondrop: (e) => {
            e.preventDefault()
            e.currentTarget.classList.remove("drag-over")
            if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) {
              fsUpload(name, e.dataTransfer.files)
            }
          },
        },
        () => {
          void state.fsSelected.val
          void state.fsSelectMode.val
          void state.fsEntries.val
          void state.fsFile.val
          void state.fsDir.val
          const list = div({ class: "file-list" })
          list.addEventListener("contextmenu", (e) => {
            if (e.target === list || e.target.classList.contains("file-list")) openCtx(e, name, null)
          })

          const selected = new Set(state.fsSelected.val)
          const entries = state.fsEntries.val || []
          const atRoot = (state.fsDir.val || WWW_ROOT) === WWW_ROOT
          if (!atRoot) {
            list.appendChild(
              div(
                {
                  class: "file-row dir file-row-up",
                  onclick: () => goParentDir(name),
                  title: "返回上级",
                },
                span({ class: "file-check-spacer" }),
                div(
                  { class: "file-main" },
                  button({ class: "file-item", type: "button", onclick: (ev) => {
                    ev.stopPropagation()
                    goParentDir(name)
                  } }, "../"),
                  div({ class: "file-meta", "aria-hidden": "true" },
                    span({ class: "file-size" }, ""),
                    span({ class: "file-mtime" }, ""),
                  ),
                ),
              ),
            )
          }
          for (const e of entries) {
            const path = e.path
            const checked = selected.has(path)
            let suppressOpenAfterDrag = () => false
            const openRow = async (ev) => {
              if (suppressOpenAfterDrag()) return
              closeCtx()
              if (ev.shiftKey) {
                rangeSelect(path)
                state.fsSelectMode.val = true
                return
              }
              if (ev.ctrlKey || ev.metaKey) {
                toggleSelect(path, true)
                state.fsSelectMode.val = true
                return
              }
              if (e.dir) await loadDir(name, path, { clearFile: true })
              else await openFile(name, path)
            }
            const row = div({
              class:
                "file-row" +
                (e.dir ? " dir" : "") +
                (checked ? " marked" : "") +
                (!e.dir && state.fsFile.val === path ? " on" : ""),
              oncontextmenu: (ev) => openCtx(ev, name, e),
              onclick: (ev) => {
                if (ev.target.closest(".file-check")) return
                openRow(ev)
              },
            })
            suppressOpenAfterDrag = guardDragSelectClick(row)
            const box = input({
              type: "checkbox",
              class: "file-check",
              checked,
              onclick: (ev) => {
                ev.stopPropagation()
                toggleSelect(path, true)
                if (!state.fsSelectMode.val) state.fsSelectMode.val = true
                if (!state.fsSelected.val.length) clearSelectMode()
              },
            })
            const label = e.dir ? e.name + "/" : e.name
            const sizeText = e.dir ? "—" : formatSize(e.size) || "—"
            const timeText = formatMtime(e.mtime) || "—"
            const btn = button(
              {
                class: "file-item",
                type: "button",
                title: label,
                onclick: (ev) => {
                  ev.stopPropagation()
                  openRow(ev)
                },
              },
              label,
            )
            row.append(
              box,
              div(
                { class: "file-main" },
                btn,
                div(
                  { class: "file-meta", title: `${sizeText} · ${timeText}` },
                  span({ class: "file-size" }, sizeText),
                  span({ class: "file-mtime" }, timeText),
                ),
              ),
            )
            list.appendChild(row)
          }
          if (!entries.length) {
            list.appendChild(
              div({ class: "file-list-empty muted" }, "（空目录，只有 nginx.conf 配置）"),
            )
          }
          return list
        },
      ),
      div({ class: "file-drop-hint muted" }, "拖动上传文件"),
    ),
    () => {
      // Only remount when file identity changes — not on every keystroke (undo history).
      void state.fsRev.val
      const path = state.fsFile.val
      const kind = path ? state.fsKind.val : "empty"
      return FileEditor(name, path, kind)
    },
  )
}

async function openFileHistory(siteName, path) {
  try {
    const res = await api.fileHistory(siteName, path)
    const items = res.items || []
    if (!items.length) {
      await dlgAlert("还没有历史版本（保存后才会留下上一版）", "历史")
      return
    }
    await new Promise((resolve) => {
      const selected = van.state(items[0].id)
      const body = van.state("")
      const loading = van.state(true)
      const load = async (id) => {
        loading.val = true
        try {
          const one = await api.fileHistoryContent(siteName, path, id)
          body.val = one.content || ""
        } catch (e) {
          body.val = e.message || String(e)
        } finally {
          loading.val = false
        }
      }
      load(selected.val)
      state.dialog.val = {
        kind: "history",
        title: "历史 · " + path,
        items,
        selected,
        body,
        loading,
        load,
        resolve,
      }
    })
  } catch (e) {
    await dlgAlert(e.message || String(e), "历史")
  }
}

function FileEditor(siteName, path, kind) {
  let jar = null
  let editorEl = null
  if (!path) {
    liveTextEditor = null
    return div({ class: "editor-pane" }, div({ class: "preview empty" }))
  }
  if (kind === "image") {
    liveTextEditor = null
    const box = div({ class: "preview image" })
    const img = document.createElement("img")
    img.src = api.downloadURL(siteName, path) + "&t=" + Date.now()
    img.alt = path
    box.appendChild(img)
    const cap = div({ class: "preview-cap" }, path)
    return div({ class: "editor-pane" }, box, cap)
  }
  if (kind === "zip") {
    liveTextEditor = null
    const box = div({ class: "preview zip" })
    box.appendChild(div({ class: "preview-cap" }, path + " · 压缩包内容"))
    const list = div({ class: "zip-list" })
    for (const e of state.fsZipEntries.val || []) {
      list.appendChild(
        div(
          { class: "zip-item" + (e.dir ? " dir" : "") },
          span({ class: "grow" }, e.dir ? e.name + "/" : e.name),
          e.dir ? null : span({ class: "muted" }, formatSize(e.size)),
        ),
      )
    }
    if (!(state.fsZipEntries.val || []).length) {
      list.appendChild(div({ class: "muted" }, "（空或无法读取）"))
    }
    box.append(
      list,
      div(
        { class: "preview-ops" },
        button(
          {
            type: "button",
            onclick: () =>
              fsUnzip(siteName, {
                name: path.split("/").pop(),
                path,
                dir: false,
              }),
          },
          ico("unzip"),
          "解压",
        ),
      ),
    )
    return div({ class: "editor-pane" }, box)
  }
  if (kind === "binary") {
    liveTextEditor = null
    return div(
      { class: "editor-pane" },
      div(
        { class: "preview binary" },
        div({ class: "preview-cap" }, path),
        p({ class: "muted" }, "二进制文件，请下载查看"),
        button(
          {
            onclick: () => {
              const a = document.createElement("a")
              a.href = api.downloadURL(siteName, path)
              a.download = path.split("/").pop()
              a.click()
            },
          },
          ico("download"),
          "下载",
        ),
      ),
    )
  }
  const host = div({ class: "cm-host" })
  const pane = div({ class: "editor-pane" }, div({ class: "cm-wrap" }, host, EditorRailFloat(siteName)))
  const mount = () => {
    if (!host.isConnected) return
    if (host.querySelector(".codejar-editor")) return
    host.querySelectorAll(":scope > .editor-loading").forEach((n) => n.remove())
    if (!ensureLiteEditor.CodeJar || !window.hljs) {
      const tip = document.createElement("div")
      tip.className = "editor-loading"
      tip.textContent = "加载编辑器…"
      host.insertBefore(tip, host.firstChild)
      ensureLiteEditor()
        .then(() => {
          if (host.isConnected) mount()
        })
        .catch((e) => {
          tip.textContent = "编辑器加载失败"
          console.error(e)
        })
      return
    }
    const ed = document.createElement("div")
    editorEl = ed
    ed.className = "codejar-editor language-" + hlLangFor(path)
    ed.spellcheck = false
    ed.style.whiteSpace = "pre"
    ed.style.wordBreak = "keep-all"
    ed.style.overflowWrap = "normal"
    host.insertBefore(ed, host.firstChild)
    const lang = hlLangFor(path)
    const highlight = (editor) => {
      const code = editor.textContent || ""
      try {
        if (lang && lang !== "plaintext" && window.hljs.getLanguage(lang)) {
          editor.innerHTML = window.hljs.highlight(code, { language: lang, ignoreIllegals: true }).value
        } else {
          editor.textContent = code
        }
      } catch {
        editor.textContent = code
      }
    }
    jar = ensureLiteEditor.CodeJar(ed, highlight, { tab: "  " })
    // CodeJar defaults to pre-wrap; keep horizontal scroll / no soft wrap.
    ed.style.whiteSpace = "pre"
    ed.style.wordBreak = "keep-all"
    ed.style.overflowWrap = "normal"
    jar.updateCode(state.fsText.rawVal || "")
    const commentToggle = () => {
      if (!jar || !editorEl) return
      const pos = jar.save()
      editorEl.focus({ preventScroll: true })
      jar.recordHistory()
      const cur = jar.toString()
      const next = toggleLineComments(cur, path, pos.start, pos.end)
      jar.updateCode(next.text)
      state.fsText.val = next.text
      state.fsDirty.val = true
      jar.restore({ start: next.start, end: next.end, dir: pos.dir || "->" })
      jar.recordHistory()
    }
    liveTextEditor = {
      get: () => jar.toString(),
      set: (code) => {
        jar.updateCode(code)
        state.fsText.val = code
      },
      path,
      commentToggle,
    }
    jar.onUpdate((code) => {
      if (code !== state.fsText.val) {
        state.fsText.val = code
        state.fsDirty.val = true
      }
    })
    const insertEditorNewline = () => {
      const pos = jar.save()
      const code = jar.toString()
      const start = Math.min(pos.start, pos.end)
      const end = Math.max(pos.start, pos.end)
      const before = code.slice(0, start)
      const after = code.slice(end)
      const line = before.slice(before.lastIndexOf("\n") + 1)
      const indent = (line.match(/^[\t ]*/) || [""])[0]
      const nextIndent = indent + (/[({\[]$/.test(before) ? "  " : "")
      const insertion = "\n" + nextIndent
      let next = before + insertion + after
      if (nextIndent !== indent && /^[)}\]]/.test(after)) next = before + insertion + "\n" + indent + after
      jar.recordHistory()
      jar.updateCode(next)
      state.fsText.val = next
      state.fsDirty.val = true
      jar.restore({ start: start + insertion.length, end: start + insertion.length })
      jar.recordHistory()
    }
    // Own Enter at keydown so editor behavior never depends on the browser's
    // contenteditable implementation. Virtual keyboards without keydown fall
    // through to beforeinput below.
    let enterKeydownHandled = false
    ed.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" && e.keyCode !== 13 && e.which !== 13) return
      if (e.isComposing || e.keyCode === 229) return
      e.preventDefault()
      enterKeydownHandled = true
      insertEditorNewline()
      queueMicrotask(() => { enterKeydownHandled = false })
    }, true)
    ed.addEventListener("beforeinput", (e) => {
      if (e.defaultPrevented || (e.inputType !== "insertParagraph" && e.inputType !== "insertLineBreak" && !(e.inputType === "insertText" && (e.data === "\n" || e.data === "\r")))) return
      e.preventDefault()
      if (!enterKeydownHandled) insertEditorNewline()
    })
    ed.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === "s" || e.key === "S")) {
        e.preventDefault()
        saveCurrentFile(siteName)
        return
      }
      if ((e.ctrlKey || e.metaKey) && e.key === "/") {
        e.preventDefault()
        commentToggle()
      }
    })
  }
  queueMicrotask(mount)
  setTimeout(mount, 50)
  return pane
}

function pushLines(lines) {
  for (const line of lines || []) {
    const kind = line.startsWith("$ ")
      ? "cmd"
      : line.startsWith("FAIL") || line.startsWith("dns check")
        ? "err"
        : line.startsWith("OK ")
          ? "ok"
          : ""
    pushLog(line, kind)
  }
}

function formatDeployDiff(d) {
  const parts = []
  const conf = d.conf || {}
  if (conf.same) parts.push("nginx.conf — 无变化")
  else if (conf.missingRemote) parts.push("nginx.conf — 远端无（将新建）\n" + (conf.diff || ""))
  else parts.push("nginx.conf\n" + (conf.diff || "(changed)"))
  const www = d.www || []
  if (!www.length) parts.push("www — 无变化")
  else parts.push("www\n" + www.join("\n"))
  if (!d.changed) parts.push("\n无变更，仍要部署？")
  else parts.push("\n确认部署？")
  return parts.join("\n\n")
}

/** Deploy-time DNS result so 「再 SSL」can skip re-resolve and only do remote checks. */
const DEPLOY_DNS_TTL_MS = 15 * 60 * 1000
let deployDnsCache = null

function dnsHostItems(items) {
  return (items || []).filter(
    (item) => item.domain && !/^\d{1,3}(\.\d{1,3}){3}$/.test(item.domain) && !item.domain.includes(":"),
  )
}

function rememberDeployDns(name, dns) {
  const items = dns.items || []
  const hosts = dnsHostItems(items)
  deployDnsCache = {
    name,
    domains: dns.domains || [],
    expected: dns.expected || "",
    items,
    allOk: hosts.length > 0 && hosts.every((item) => item.ok),
    at: Date.now(),
  }
}

/** Fresh deploy DNS cache, or null. */
function takeDeployDnsCache(name) {
  const c = deployDnsCache
  if (!c || c.name !== name) return null
  if (Date.now() - c.at > DEPLOY_DNS_TTL_MS) return null
  return c
}

async function checkSSLAfterDeploy(name) {
  pushLog("部署成功，正在检查域名与 SSL…", "cmd")
  try {
    const dns = await api.dnsCheck(name)
    rememberDeployDns(name, dns)
    const domains = dns.domains || []
    const items = dns.items || []
    // Bare IPs stay in server_name for access, but are not LE names — ignore in SSL prompts.
    const hostItems = items.filter((item) => item.domain && !/^\d{1,3}(\.\d{1,3}){3}$/.test(item.domain) && !item.domain.includes(":"))
    if (!domains.length) {
      pushLog("部署成功。这个站还没配域名，先不提 SSL。", "cmd")
      return false
    }
    if (dns.sslCoversAll) {
      pushLog("部署成功。现有证书已盖住全部域名，不用再申请。", "cmd")
      return false
    }
    const failed = []
    for (const item of hostItems) {
      const actual = (item.actual || []).join(", ") || "无解析"
      const detail = item.error ? `${actual} — ${item.error}` : actual
      pushLog(`${item.ok ? "OK" : "FAIL"}  ${item.domain} → ${detail}`, item.ok ? "ok" : "err")
      if (!item.ok) failed.push(`${item.domain} → ${detail}`)
    }
    if (!hostItems.length || failed.length) {
      if (failed.length) {
        pushLog(`这些域名还没解析到这台机（${failed.length}）：`, "err")
        for (const line of failed) pushLog("  · " + line, "err")
        pushLog(
          `部署成功了，但解析还没指向 ${dns.expected || "（未填公网 IP）"}，先别申请 SSL。`,
          "cmd",
        )
      } else {
        pushLog("部署成功。没有可检查的域名，先不提 SSL。", "cmd")
      }
      return false
    }

    // Panel bookkeeping/conf often lag behind a real remote LE cert (migrate).
    // Prefer syncing that cert over a false "证书还缺" + full issue dialog.
    pushLog("解析没问题，正在查远端是否已有可用证书…", "cmd")
    try {
      const sync = await api.ssl(name, false, {
        skipPreflight: true,
        skipDns: true,
        syncExisting: true,
        dnsItems: items,
      })
      for (const line of sync.lines || []) pushLog(line, "cmd")
      if (sync.ok && sync.synced) {
        const days = sync.result && sync.result.daysLeft != null ? sync.result.daysLeft : "?"
        pushLog(`远端证书已覆盖全部域名（剩 ${days} 天），已同步 conf / 记账`, "ok")
        playSuccessSound()
        const confPath = state.fsFile.val === "nginx.conf" || (state.fsFile.val || "").endsWith("/nginx.conf")
        if (sync.conf && isCurrentSite(name) && !state.fsDirty.val && confPath) {
          if (liveTextEditor && (liveTextEditor.path === "nginx.conf" || liveTextEditor.path.endsWith("/nginx.conf"))) {
            liveTextEditor.set(sync.conf)
          } else {
            state.fsText.val = sync.conf
          }
          state.fsDirty.val = false
        }
        await refreshTree()
        return false
      }
    } catch (e) {
      pushLog(`远端证书探测失败：${e.message || e}，如需可再申请`, "cmd")
    }

    const missing = dns.sslMissing && dns.sslMissing.length ? dns.sslMissing : []
    let detail
    if (missing.length) {
      detail = `面板记账还缺这些名：\n${missing.join("\n")}`
      pushLog(`面板记账还缺：${missing.join(", ")}`, "ok")
    } else if (!dns.sslConfigured) {
      detail = "主控 conf 还没挂上证书路径（远端可能也没有可用证）。"
      pushLog(detail, "ok")
    } else {
      detail = "面板 SSL 记账与当前域名不一致。"
      pushLog(detail, "ok")
    }
    return await dlgConfirm(
      `部署成功。${detail}\n\n去检查并申请 SSL？`,
      "还可以办 SSL",
      { confirmLabel: "去申请", cancelLabel: "稍后" },
    )
  } catch (e) {
    deployDnsCache = null
    pushLog(`部署成功，但查解析失败：${e.message}。可稍后点「再SSL」。`, "err")
    return false
  }
}

function isSSHAuthFailure(errOrRes) {
  if (errOrRes && typeof errOrRes === "object") {
    if (errOrRes.errorCode === "ssh_auth") return true
    errOrRes = errOrRes.error || errOrRes.message || ""
  }
  return /SSH认证失败|保存的密码可能已变更|Permission denied|unable to authenticate/i.test(String(errOrRes || ""))
}

async function offerSSHPasswordRepair(name, errOrRes) {
  if (!isSSHAuthFailure(errOrRes)) return false
  try {
    const site = await api.getSite(name)
    const serverId = site && site.meta && site.meta.serverId
    if (!serverId) return false
    if (!(await dlgConfirm(
      "SSH 登录失败，保存的密码可能已变更。要输入当前密码并自动重装密钥吗？",
      "修复 SSH",
      { confirmLabel: "修复并重试", cancelLabel: "稍后" },
    ))) return false
    const password = await dlgPrompt("请输入这台服务器当前的 SSH 密码。修复成功后会更新面板保存的密码。", "", "修复 SSH", { password: true })
    if (!password) return false
    await api.installKey(serverId, password)
    pushLog("SSH 密钥已重装，准备重试原操作。", "ok")
    return true
  } catch (e) {
    pushLog(e.message || String(e), "err")
    return false
  }
}

async function doDeploy(name, allowSSHRepair = true) {
  state.busy.val = true
  let offerSSL = false
  try {
    pushLog(`deploy-diff ${name}`, "cmd")
    const diff = await api.deployDiff(name)
    if (!(await dlgConfirm(formatDeployDiff(diff), "部署"))) return
    pushLog(`deploy ${name}`, "cmd")
    let res = await api.deploy(name)
    pushLines(res.lines)
    if (!res.ok && allowSSHRepair && await offerSSHPasswordRepair(name, res)) {
      pushLog(`deploy retry ${name}`, "cmd")
      res = await api.deploy(name)
      pushLines(res.lines)
    }
    if (res.ok) {
      pushLog("deploy ok", "ok")
      playSuccessSound()
      if (isCurrentSite(name)) setSitePendingDeploy(false)
      await refreshTree()
      offerSSL = await checkSSLAfterDeploy(name)
    } else {
      pushLog(res.error || "deploy failed", "err")
      playErrorSound()
      await dlgAlert(res.error || "部署失败")
    }
  } catch (e) {
    pushLog(e.message, "err")
    if (allowSSHRepair && await offerSSHPasswordRepair(name, e)) {
      return await doDeploy(name, false)
    }
    playErrorSound()
    await dlgAlert(e.message)
  } finally {
    state.busy.val = false
  }
  if (offerSSL) await doSSL(name, false, { reuseDeployDns: true })
}

/** End every 「处理中 / 检查中 / busy」wait — failure, cancel, refresh, tab close. */
function abandonInFlightUI(reason = "已中断") {
  state.busy.val = false
  state.sslDlgBusy.val = false
  if (sslAbort) {
    try {
      sslAbort.abort()
    } catch (_) {}
    sslAbort = null
  }
  const check = state.sslCheck.val
  if (check && check.phase === "loading") {
    state.sslCheck.val = {
      phase: "ready",
      pre: check.pre || null,
      error: reason,
      preferForce: true,
    }
  }
}

function closeSSLDialog() {
  abandonInFlightUI("已关闭")
  state.sslDlg.val = null
  state.sslCheck.val = null
  sslManualDraft = { fullchain: "", key: "" }
}

async function applySSLResult(name, res, label) {
  pushLines(res.lines)
  const confPath = state.fsFile.val === "nginx.conf" || (state.fsFile.val || "").endsWith("/nginx.conf")
  if (res.conf && isCurrentSite(name) && !state.fsDirty.val && confPath) {
    if (liveTextEditor && (liveTextEditor.path === "nginx.conf" || liveTextEditor.path.endsWith("/nginx.conf"))) {
      liveTextEditor.set(res.conf)
    } else {
      state.fsText.val = res.conf
    }
    state.fsDirty.val = false
  }
  if (res.ok) {
    const r = res.result || {}
    if (r.skipped) pushLog(`ssl skipped (${r.daysLeft}d left)`, "ok")
    else pushLog(label || "ssl ok", "ok")
    playSuccessSound()
    closeSSLDialog()
    await refreshTree()
    if (isCurrentSite(name) && !state.fsDirty.val && state.fsFile.val === "nginx.conf") await openFile(name, "nginx.conf")
    return
  }
  pushLog(res.error || "ssl failed", "err")
  if (res.preflight) for (const line of res.preflight.lines || []) pushLog(line, "err")
  playErrorSound()
  await dlgAlert(res.error || "SSL 失败")
}

let successAudio = null
let errorAudio = null
function playSuccessSound() {
  try {
    if (!successAudio) successAudio = new Audio("/sounds/success.mp3")
    successAudio.currentTime = 0
    void successAudio.play().catch(() => {})
  } catch (_) {}
}
function playErrorSound() {
  try {
    if (!errorAudio) errorAudio = new Audio("/sounds/error.mp3")
    errorAudio.currentTime = 0
    void errorAudio.play().catch(() => {})
  } catch (_) {}
}

/**
 * Run SSL preflight into the open dialog.
 * reuseDeployDns: only for deploy→SSL jump (may skip DNS resolve when deploy just passed).
 * Manual 「再 SSL」/「重新检查」always pass reuseDeployDns=false for a full check.
 */
async function runSSLPreflight(name, { force = false, reuseDeployDns = false } = {}) {
  if (sslAbort) {
    try {
      sslAbort.abort()
    } catch (_) {}
  }
  sslAbort = new AbortController()
  const signal = sslAbort.signal
  state.sslCheck.val = { phase: "loading", pre: null, error: "", preferForce: !!force }
  const cached = reuseDeployDns ? takeDeployDnsCache(name) : null
  const skipDns = !!(cached && cached.allOk)
  if (skipDns) {
    pushLog(`ssl-preflight ${name}（部署时已通过，跳过 DNS）`, "cmd")
  } else {
    pushLog(`ssl-preflight ${name}`, "cmd")
  }
  try {
    const pre = await api.sslPreflight(
      name,
      signal,
      skipDns ? { skipDns: true, dnsItems: cached.items } : {},
    )
    if (signal.aborted || !state.sslDlg.val || state.sslDlg.val.name !== name) {
      if (state.sslDlg.val && state.sslDlg.val.name === name) abandonInFlightUI("已中断")
      return
    }
    for (const line of pre.lines || []) {
      pushLog(line, line.startsWith("OK") ? "ok" : line.startsWith("FAIL") ? "err" : "cmd")
    }
    state.sslCheck.val = {
      phase: "ready",
      pre,
      error: "",
      preferForce: !!force || !pre.ok,
    }
  } catch (e) {
    if (signal.aborted || e.name === "AbortError") {
      pushLog("ssl-preflight cancelled", "cmd")
      if (state.sslDlg.val && state.sslDlg.val.name === name) abandonInFlightUI("已中断")
      return
    }
    const msg = e.message || String(e)
    pushLog(msg, "err")
    if (await offerSSHPasswordRepair(name, e)) {
      state.sslDlg.val = null
      state.sslCheck.val = null
      return await doSSL(name, force, { reuseDeployDns })
    }
    if (state.sslDlg.val && state.sslDlg.val.name === name) {
      state.sslCheck.val = {
        phase: "ready",
        pre: null,
        error: msg,
        preferForce: !!force,
      }
    } else {
      abandonInFlightUI(msg)
    }
  } finally {
    if (sslAbort && sslAbort.signal === signal) sslAbort = null
    state.sslDlgBusy.val = false
  }
}

async function doSSL(name, force, opts = {}) {
  if (state.sslDlg.val) return
  sslManualDraft = { fullchain: "", key: "" }
  state.sslDlgBusy.val = false
  try {
    const pem = await api.sslPem(name)
    sslManualDraft = {
      fullchain: (pem && pem.fullchain) || "",
      key: (pem && pem.key) || "",
    }
  } catch (_) {}
  state.sslDlg.val = { name, preferForce: !!force, reuseDeployDns: !!opts.reuseDeployDns }
  await runSSLPreflight(name, { force: !!force, reuseDeployDns: !!opts.reuseDeployDns })
}

function SSLDialogHost() {
  return () => {
    const ui = state.sslDlg.val
    // Subscribe so footer buttons remount when check phase flips (fixes stuck disabled).
    void state.sslCheck.val
    void state.sslDlgBusy.val
    if (!ui) return div({ class: "dlg-layer off" })
    const checkNow = state.sslCheck.val
    const checking = !!(checkNow && checkNow.phase === "loading")
    const checkReady = !!(checkNow && checkNow.phase === "ready")

    const runRecheck = async () => {
      if (state.sslDlgBusy.val || checking) return
      // Manual recheck is always a full preflight (never reuse deploy DNS).
      await runSSLPreflight(ui.name, { force: !!ui.preferForce, reuseDeployDns: false })
    }

    const sslApplyOpts = (pre) => {
      const reuseDns = !!(pre && pre.ok && Array.isArray(pre.dnsItems) && pre.dnsItems.length)
      return {
        skipPreflight: true,
        skipDns: reuseDns,
        dnsItems: reuseDns ? pre.dnsItems : [],
      }
    }

    const runLE = async () => {
      const name = ui.name
      const check = state.sslCheck.val
      const pre = check && check.pre
      if (!check || check.phase === "loading") {
        await dlgAlert("还在检查，稍等或点「重新检查」")
        return
      }
      if (check.phase !== "ready") {
        await dlgAlert("请先等检查跑完")
        return
      }
      const useForce = !!(ui.preferForce || check.preferForce) || !(pre && pre.ok)
      if (!(pre && pre.ok)) {
        if (!(await dlgConfirm(
          "还有项没过。若刚改过解析，先点「重新检查」。\n仍要硬申 Let’s Encrypt？（容易失败）",
          "强制申请",
          { confirmLabel: "仍要申请", cancelLabel: "先回去检查" },
        ))) return
      }
      const applyOpts = sslApplyOpts(pre)
      try {
        state.sslDlgBusy.val = true
        pushLog(`ssl ${name}${useForce ? " (force)" : ""}${applyOpts.skipDns ? "（检查已过，直接申请）" : ""}`, "cmd")
        let res = await api.ssl(name, useForce, applyOpts)
        if (!res.ok && await offerSSHPasswordRepair(name, res)) {
          pushLog(`ssl retry ${name}${useForce ? " (force)" : ""}`, "cmd")
          res = await api.ssl(name, useForce, applyOpts)
        }
        await applySSLResult(name, res, "ssl ok")
      } catch (e) {
        if (await offerSSHPasswordRepair(name, e)) {
          try {
            pushLog(`ssl retry ${name}${useForce ? " (force)" : ""}`, "cmd")
            const res = await api.ssl(name, useForce, applyOpts)
            await applySSLResult(name, res, "ssl ok")
            return
          } catch (retryError) {
            e = retryError
          }
        }
        pushLog(e.message, "err")
        playErrorSound()
        await dlgAlert(e.message || String(e))
      } finally {
        state.sslDlgBusy.val = false
      }
    }

    const runManual = async () => {
      const name = ui.name
      const fullchain = (sslManualDraft.fullchain || "").trim()
      const key = (sslManualDraft.key || "").trim()
      if (!fullchain || !key) {
        await dlgAlert("请粘贴证书 PEM（fullchain）和私钥 PEM")
        return
      }
      const check = state.sslCheck.val
      const pre = check && check.pre
      if (check && check.phase === "loading") {
        await dlgAlert("还在检查，稍等或点「重新检查」")
        return
      }
      const useForce = !!(ui.preferForce || (check && check.preferForce)) || !(pre && pre.ok)
      if (!(pre && pre.ok)) {
        if (!(await dlgConfirm(
          "还有项没过。若刚改过解析，先点「重新检查」。\n仍要强制装上手动证书？",
          "强制安装",
          { confirmLabel: "仍要安装", cancelLabel: "先回去检查" },
        ))) return
      }
      try {
        state.sslDlgBusy.val = true
        pushLog(`ssl-manual ${name}（检查已过，直接安装）`, "cmd")
        let res = await api.sslManual(name, fullchain, key, useForce, { skipPreflight: true })
        if (!res.ok && await offerSSHPasswordRepair(name, res)) {
          pushLog(`ssl-manual retry ${name}`, "cmd")
          res = await api.sslManual(name, fullchain, key, useForce, { skipPreflight: true })
        }
        await applySSLResult(name, res, "手动证书已安装")
      } catch (e) {
        if (await offerSSHPasswordRepair(name, e)) {
          try {
            pushLog(`ssl-manual retry ${name}`, "cmd")
            const res = await api.sslManual(name, fullchain, key, useForce, { skipPreflight: true })
            await applySSLResult(name, res, "手动证书已安装")
            return
          } catch (retryError) {
            e = retryError
          }
        }
        pushLog(e.message, "err")
        playErrorSound()
        await dlgAlert(e.message || String(e))
      } finally {
        state.sslDlgBusy.val = false
      }
    }

    return div(
      {
        class: "dlg-layer dlg-layer-ssl",
        tabindex: "0",
        onclick: (e) => {
          if (e.target.classList.contains("dlg-layer") && !state.sslDlgBusy.val) closeSSLDialog()
        },
        onkeydown: (e) => {
          if (e.key === "Escape" && !state.sslDlgBusy.val) {
            e.preventDefault()
            closeSSLDialog()
          }
        },
      },
      div(
        { class: "dlg dlg-ssl" },
        div(
          { class: "dlg-head" },
          span({ class: "dlg-title" }, "SSL"),
          button(
            {
              class: "dlg-close",
              type: "button",
              title: "关闭 Esc",
              disabled: () => state.sslDlgBusy.val,
              onclick: () => closeSSLDialog(),
            },
            ico("close"),
          ),
        ),
        div(
          { class: "ssl-body" },
          div(
            { class: "ssl-manual" },
            div({ class: "ssl-manual-title" }, "手动安装证书（可选）"),
            p({ class: "muted ssl-manual-hint" }, "粘贴 fullchain（证书+链）与 privkey，安装到目标机，不走 Let’s Encrypt。已保存的会自动填入；改走 Let’s Encrypt 后备份仍保留，可再手动装回。"),
            div(
              { class: "ssl-pem-row" },
              div(
                { class: "ssl-pem-col" },
                label({}, "证书 PEM（fullchain）"),
                textarea({
                  class: "dlg-input dlg-textarea ssl-pem",
                  rows: 6,
                  placeholder: "-----BEGIN CERTIFICATE-----",
                  value: sslManualDraft.fullchain,
                  oninput: (e) => {
                    sslManualDraft.fullchain = e.target.value
                  },
                }),
              ),
              div(
                { class: "ssl-pem-col" },
                label({}, "私钥 PEM（privkey）"),
                textarea({
                  class: "dlg-input dlg-textarea ssl-pem",
                  rows: 6,
                  placeholder: "-----BEGIN PRIVATE KEY-----",
                  value: sslManualDraft.key,
                  oninput: (e) => {
                    sslManualDraft.key = e.target.value
                  },
                }),
              ),
            ),
          ),
          () => {
            const check = state.sslCheck.val
            if (!check || check.phase === "loading") {
              return div(
                { class: "dlg-msg ssl-preflight ssl-wait" },
                div({ class: "ssl-spinner", "aria-hidden": "true" }),
                p({}, "正在检查：解析、SSH、Nginx、80 端口…"),
                p({ class: "muted" }, "通常十几秒；左侧可先贴手动证书"),
              )
            }
            const pre = check.pre
            const checks = (pre && pre.checks) || []
            const checkText = check.error
              ? check.error
              : [
                  `这台机 IP：${(pre && pre.expected) || "-"}`,
                  `域名：${((pre && pre.domains) || []).join(", ") || "-"}`,
                  "",
                  ...checks.map((c) => `${c.ok ? "✓" : "✗"} ${c.name}${c.critical ? "" : "（参考，不挡申请）"}`),
                  ...checks.filter((c) => !c.ok).map((c) => `   └ ${c.detail}`),
                  "",
                  pre && pre.ok
                    ? "检查过了。点「申请」去办证书；或左侧贴证书后点「手动安装」。"
                    : "有关键项没过。可先「重新检查」；仍要硬来再点申请（容易失败）。",
                ].join("\n")
            return div({ class: "dlg-msg ssl-preflight" }, checkText)
          },
        ),
        div(
          { class: "dlg-actions ssl-actions" },
          button({
            class: "accent-soft",
            type: "button",
            disabled: state.sslDlgBusy.val || checking || !checkReady,
            onclick: runManual,
          }, state.sslDlgBusy.val ? "处理中…" : "手动安装"),
          button({
            type: "button",
            disabled: state.sslDlgBusy.val || checking,
            onclick: runRecheck,
          }, checking ? "检查中…" : "重新检查"),
          button({
            class: "accent",
            type: "button",
            disabled: state.sslDlgBusy.val || checking || !checkReady,
            onclick: runLE,
          }, state.sslDlgBusy.val ? "处理中…" : checking ? "检查中…" : "申请 Let’s Encrypt"),
        ),
      ),
    )
  }
}

// Two heights only: 0 = ~3 lines, 1 = expanded (default).
// Single source of truth: --log on <html> via applyLogStep (never zero it for billing).
const LOG_H = {
  desktop: { collapsed: 4.2, expanded: 12.6 },
  mobile: { collapsed: 2.2, expanded: 7.2 },
}

function logHeightEm(expanded) {
  const mobile = window.matchMedia("(max-width: 800px)").matches
  const table = mobile ? LOG_H.mobile : LOG_H.desktop
  return expanded ? table.expanded : table.collapsed
}

function scrollLogsToEnd() {
  const body = document.querySelector(".logs-body")
  if (!body) return
  body.scrollTop = body.scrollHeight
}

function applyLogStep(step) {
  const i = step ? 1 : 0
  state.logStep.val = i
  const em = logHeightEm(!!i)
  document.documentElement.style.setProperty("--log", `calc(${em}em + 6px)`)
  try {
    localStorage.setItem("ssp-log-step", String(i))
  } catch (_) {}
  // Desktop↔phone --log height change otherwise leaves scroll at the top.
  requestAnimationFrame(() => {
    requestAnimationFrame(scrollLogsToEnd)
  })
  return i
}

function toggleLogHeight() {
  applyLogStep(state.logStep.val ? 0 : 1)
}

;(function initLogStep() {
  let n = 1
  try {
    const raw = localStorage.getItem("ssp-log-step")
    if (raw != null && raw !== "") n = Number(raw)
  } catch (_) {}
  if (!Number.isFinite(n) || n < 0) n = 1
  // Migrate old 2/3 "更高" steps back to expanded.
  applyLogStep(n === 0 ? 0 : 1)
  try {
    const mq = window.matchMedia("(max-width: 800px)")
    const sync = () => applyLogStep(state.logStep.val)
    if (mq.addEventListener) mq.addEventListener("change", sync)
    else if (mq.addListener) mq.addListener(sync)
  } catch (_) {}
})()

function Logs() {
  return div(
    {
      class: () => "logs" + (state.logStep.val === 0 ? " collapsed" : ""),
    },
    div(
      { class: "logs-tools" },
      button({
        class: "logs-height-toggle",
        title: "切换日志高度（三行 / 展开）",
        "aria-label": () => (state.logStep.val === 0 ? "展开日志" : "收起日志"),
        onclick: () => toggleLogHeight(),
      }, () => ico(state.logStep.val === 0 ? "expand" : "collapse")),
      button({ class: "logs-clear", title: "清空", "aria-label": "清空日志", onclick: () => (state.logs.val = []) }, ico("trash")),
    ),
    () => {
      void state.logStep.val
      const body = div({ class: "logs-body" })
      for (const l of state.logs.val) {
        const row = div({ class: "log-line " + (l.kind || "") })
        row.textContent = `[${l.t}] ${l.line}`
        body.appendChild(row)
      }
      queueMicrotask(() => {
        body.scrollTop = body.scrollHeight
      })
      return body
    },
  )
}

function Shell() {
  // No side tree — overview is the index; every page is full-bleed.
  return div(
    {
      class: () => "shell" + (isSitesOverviewSel() ? " page-sites" : ""),
    },
    div(
      { class: "right" },
      Detail(),
      Logs(),
    ),
    () => CopyPickLayer(),
    () => SecurityLayer(),
    () => ServerDlgLayer(),
    CtxMenu(),
  )
}

async function refreshTree() {
  const t = await api.tree()
  state.tree.val = t
  state.sitesRoot.val = t.sitesRoot || ""
}

async function boot() {
  setUnauthorizedHandler(() => {
    state.authed.val = false
    routeReady = false
    setCsrf("")
  })
  try {
    const st = await api.status()
    state.hasPassword.val = !!st.hasPassword
    state.authed.val = !!st.authenticated
    if (st.csrf) setCsrf(st.csrf)
    if (st.sitesRoot) state.sitesRoot.val = st.sitesRoot
    if (st.authenticated) {
      await refreshTree()
      routeReady = true
      await applyRoute({ replace: true })
    }
  } finally {
    state.boot.val = false
    // Icons after paint — don't block overview on lucide.min.js
    queueMicrotask(() => { ensureLucide().catch(() => {}) })
  }
}

function onHistoryNav() {
  if (!routeReady || !state.authed.val) return
  if (routeLock) {
    routeNavQueued = true
    return
  }
  applyRoute({ replace: false })
}
window.addEventListener("popstate", onHistoryNav)
// location.hash = … fires hashchange (not popstate); smoke tests and bookmarks rely on it.
window.addEventListener("hashchange", onHistoryNav)

const app = document.getElementById("app")
van.add(
  app,
  () => {
    const main = state.boot.val
      ? div({ class: "gate" }, p({ class: "muted" }, "…"))
      : !state.authed.val
        ? Gate()
        : Shell()
    schedulePageMinWidth()
    return div({ class: "app-frame" }, main, DialogHost(), SSLDialogHost())
  },
)
window.addEventListener("resize", schedulePageMinWidth)
// Only watch direct app children (shell/gate swaps). subtree:true remeasured on every overview cell and felt like lag.
new MutationObserver(schedulePageMinWidth).observe(app, { childList: true, subtree: false })
// Tests / debugging can force a synchronous remeasure.
window.__sspSyncPageMinWidth = syncPageMinWidth

window.addEventListener("pagehide", () => {
  abandonInFlightUI("页面已离开")
})
window.addEventListener("beforeunload", (e) => {
  abandonInFlightUI("页面刷新或关闭")
  if (!state.fsDirty.val) return
  e.preventDefault()
  e.returnValue = ""
})

window.addEventListener("keydown", (e) => {
  const sel = state.sel.val
  const mod = e.ctrlKey || e.metaKey
  if (mod && e.key.toLowerCase() === "s") {
    if (!sel || sel.type !== "site" || state.fsKind.val !== "text" || !state.fsFile.val) return
    // Editor host already handles Ctrl/Cmd-S; skip to avoid double save/log.
    if (e.defaultPrevented) return
    if (e.target && e.target.closest && e.target.closest(".cm-host")) return
    e.preventDefault()
    saveCurrentFile(sel.name)
    return
  }
  if (!mod || !sel || sel.type !== "site") return
  if (shouldKeepNativeClipboard(e.target)) return
  const k = e.key.toLowerCase()
  if (k === "c" || k === "x") {
    // Require checkbox selection; do not steal native copy when nothing is checked.
    if (!selectedEntries().length) return
    e.preventDefault()
    fsClipboardSet(sel.name, k === "c" ? "copy" : "cut", null)
  } else if (k === "v") {
    if (!state.clip.val) return
    e.preventDefault()
    fsPaste(sel.name)
  }
})

document.addEventListener("click", (e) => {
  if (state.ctxMenu.val) closeCtx()
  if (state.chromeMenuOpen.val) state.chromeMenuOpen.val = false
})

boot()
