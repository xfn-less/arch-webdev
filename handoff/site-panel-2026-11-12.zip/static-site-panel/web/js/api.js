let csrf = ""
let onUnauthorized = null

export function setCsrf(v) {
  csrf = v || ""
}

export function getCsrf() {
  return csrf
}

/** Called once from the app shell so expired sessions bounce to the login screen. */
export function setUnauthorizedHandler(fn) {
  onUnauthorized = typeof fn === "function" ? fn : null
}

async function req(method, path, body, signal) {
  const headers = { Accept: "application/json" }
  if (body !== undefined) headers["Content-Type"] = "application/json"
  if (csrf && method !== "GET") headers["X-CSRF"] = csrf
  const res = await fetch(path, {
    method,
    headers,
    credentials: "same-origin",
    body: body === undefined ? undefined : JSON.stringify(body),
    signal,
  })
  const next = res.headers.get("X-CSRF")
  if (next) csrf = next
  const text = await res.text()
  let data = null
  try {
    data = text ? JSON.parse(text) : null
  } catch {
    data = { error: text || res.statusText }
  }
  if (!res.ok) {
    if (res.status === 401 && path !== "/api/status" && path !== "/api/login" && path !== "/api/setup" && onUnauthorized) {
      try {
        onUnauthorized()
      } catch (_) {}
    }
    const err = new Error((data && data.error) || res.statusText)
    err.status = res.status
    err.data = data
    throw err
  }
  return data
}

export const api = {
  status: () => req("GET", "/api/status"),
  captcha: () => req("GET", "/api/captcha"),
  setup: (password, captchaId, captchaNonce) =>
    req("POST", "/api/setup", { password, captchaId, captchaNonce }),
  login: (password, kick, captchaId, captchaNonce, confirm = false) =>
    req("POST", "/api/login", { password, kick, captchaId, captchaNonce, confirm: !!confirm }),
  logout: () => req("POST", "/api/logout", {}),
  changePassword: (oldPw, newPw) =>
    req("POST", "/api/password", { old: oldPw, new: newPw }),
  tree: () => req("GET", "/api/tree"),
  saveServer: (server) => req("POST", "/api/servers", server),
  deleteServer: (id) => req("DELETE", `/api/servers/${id}`),
  installKey: (id, password) =>
    req("POST", `/api/servers/${id}/install-key`, password ? { password } : {}),
  installNginx: (id, password) =>
    req("POST", `/api/servers/${id}/install-nginx`, password ? { password } : {}),
  nginxStatus: (id) => req("GET", `/api/servers/${id}/nginx-status`),
  getSite: (name) => req("GET", `/api/sites/${encodeURIComponent(name)}`),
  createSite: (title, serverId) => req("POST", "/api/sites", { title, serverId }),
  saveSite: (name, patch) => req("POST", `/api/sites/${encodeURIComponent(name)}`, patch),
  copySite: (name, title, serverId) =>
    req("POST", `/api/sites/${encodeURIComponent(name)}/copy`, {
      title,
      newName: title,
      ...(serverId ? { serverId } : {}),
    }),
  renameSite: (name, title) =>
    req("POST", `/api/sites/${encodeURIComponent(name)}/rename`, { title, newName: title }),
  deleteSite: (name) => req("DELETE", `/api/sites/${encodeURIComponent(name)}`),
  getConf: (name) => req("GET", `/api/sites/${encodeURIComponent(name)}/conf`),
  putConf: (name, conf) => req("PUT", `/api/sites/${encodeURIComponent(name)}/conf`, { conf }),
  listFiles: (name, path) =>
    req("GET", `/api/sites/${encodeURIComponent(name)}/files?path=${encodeURIComponent(path || "")}`),
  readFile: (name, path) =>
    req("GET", `/api/sites/${encodeURIComponent(name)}/file?path=${encodeURIComponent(path || "")}`),
  writeFile: (name, path, content) =>
    req("PUT", `/api/sites/${encodeURIComponent(name)}/file`, { path, content }),
  fileHistory: (name, path) =>
    req("GET", `/api/sites/${encodeURIComponent(name)}/file-history?path=${encodeURIComponent(path)}`),
  fileHistoryContent: (name, path, id) =>
    req(
      "GET",
      `/api/sites/${encodeURIComponent(name)}/file-history/content?path=${encodeURIComponent(path)}&id=${encodeURIComponent(id)}`,
    ),
  mkdir: (name, path) =>
    req("POST", `/api/sites/${encodeURIComponent(name)}/mkdir`, { path }),
  touch: (name, path) =>
    req("POST", `/api/sites/${encodeURIComponent(name)}/touch`, { path }),
  renamePath: (name, from, to) =>
    req("POST", `/api/sites/${encodeURIComponent(name)}/rename-path`, { from, to }),
  deletePath: (name, path) =>
    req("DELETE", `/api/sites/${encodeURIComponent(name)}/path?path=${encodeURIComponent(path)}`),
  uploadConflicts: (name, dir, names) =>
    req("POST", `/api/sites/${encodeURIComponent(name)}/upload-conflicts`, { dir, names }),
  upload: async (name, dir, file, conflict = "reject") => {
    const fd = new FormData()
    fd.append("dir", dir || "")
    fd.append("file", file)
    fd.append("conflict", conflict)
    const headers = { Accept: "application/json" }
    if (csrf) headers["X-CSRF"] = csrf
    const res = await fetch(`/api/sites/${encodeURIComponent(name)}/upload`, {
      method: "POST",
      headers,
      credentials: "same-origin",
      body: fd,
    })
    const next = res.headers.get("X-CSRF")
    if (next) csrf = next
    const data = await res.json().catch(() => ({}))
    if (!res.ok) throw new Error(data.error || res.statusText)
    return data
  },
  downloadURL: (name, path) =>
    `/api/sites/${encodeURIComponent(name)}/download?path=${encodeURIComponent(path || "")}`,
  zip: (name, paths, out) =>
    req("POST", `/api/sites/${encodeURIComponent(name)}/zip`, { paths, out }),
  zipList: (name, path) =>
    req("GET", `/api/sites/${encodeURIComponent(name)}/zip-list?path=${encodeURIComponent(path || "")}`),
  unzip: (name, path, dest, mode) =>
    req("POST", `/api/sites/${encodeURIComponent(name)}/unzip`, {
      path,
      dest: dest || "",
      mode: mode || "",
    }),
  deployDiff: (name) => req("GET", `/api/sites/${encodeURIComponent(name)}/deploy-diff`),
  deploy: (name) => req("POST", `/api/sites/${encodeURIComponent(name)}/deploy`, {}),
  setApkObfuscate: (name, enabled) =>
    req("POST", `/api/sites/${encodeURIComponent(name)}/apk-obfuscate`, { enabled: !!enabled }),
  setSiteDisabled: (name, disabled) =>
    req("POST", `/api/sites/${encodeURIComponent(name)}/disabled`, { disabled: !!disabled }),
  pastePaths: (toSite, body) =>
    req("POST", `/api/sites/${encodeURIComponent(toSite)}/paste`, body),
  dnsCheck: (name) => req("POST", `/api/sites/${encodeURIComponent(name)}/dns-check`, {}),
  sslPreflight: (name, signal, body = {}) =>
    req("POST", `/api/sites/${encodeURIComponent(name)}/ssl-preflight`, body || {}, signal),
  sslPem: (name) => req("GET", `/api/sites/${encodeURIComponent(name)}/ssl-pem`),
  ssl: (name, force, opts = {}) =>
    req("POST", `/api/sites/${encodeURIComponent(name)}/ssl`, {
      force: !!force,
      skipPreflight: !!opts.skipPreflight,
      skipDns: !!opts.skipDns,
      syncExisting: !!opts.syncExisting,
      dnsItems: opts.dnsItems || [],
    }),
  sslManual: (name, fullchain, key, force, opts = {}) =>
    req("POST", `/api/sites/${encodeURIComponent(name)}/ssl-manual`, {
      fullchain,
      key,
      force: !!force,
      skipPreflight: !!opts.skipPreflight,
    }),
  billingList: (snapshot) =>
    req("GET", `/api/billing${snapshot ? `?snapshot=${encodeURIComponent(snapshot)}` : ""}`),
  billingSync: () => req("POST", "/api/billing/sync", {}),
  billingSyncFailed: () => req("POST", "/api/billing/sync-failed", {}),
  billingRemind: () => req("POST", "/api/billing/remind", {}),
  billingRestore: (id) => req("POST", "/api/billing/restore", { id }),
  billingGetAccounts: () => req("GET", "/api/billing/accounts"),
  billingPutAccounts: (body) => req("PUT", "/api/billing/accounts", body),
  billingExportURL: (snapshot) =>
    `/api/billing/export${snapshot ? `?snapshot=${encodeURIComponent(snapshot)}` : ""}`,
}
