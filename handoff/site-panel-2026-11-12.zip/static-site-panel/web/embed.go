package web

import (
	"embed"
	"io/fs"
)

//go:embed index.html term.html styles.css js vendor sounds
var files embed.FS

var FS fs.FS = files
