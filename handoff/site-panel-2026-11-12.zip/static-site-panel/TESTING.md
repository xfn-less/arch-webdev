# 验证

```sh
go test -count=1 ./...
go test -race -count=1 ./...
go vet ./...
go build -o /tmp/ssp-test-panel ./cmd/panel
SSP_PANEL_BIN=/tmp/ssp-test-panel node --test scripts/test-*.mjs
python3 -B -m unittest discover -s scripts -p test_backup.py -v
python3 -B -m unittest discover -s scripts -p test_health.py -v
bash -n internal/deploy/apk-run.sh scripts/backup.sh scripts/health-lizhi.sh
python3 scripts/browser-smoke.py --binary /tmp/ssp-test-panel --out /tmp/ssp-ui-new-run
```

窄屏回归（`scripts/test-mobile-site-toolbar.mjs`，≤800px）：顶栏 switch/chrome 一行，居中 mid 落到第二行；`--page-min-width=0`，不整页横滚。站点页文件:编辑固定手机 1:2 / 电脑 1:3；选中操作竖条在列表右缘、滚动容器外。

浏览器测试需要 Firefox。使用合成账号、独立本机数据库和回环端口；不触及真实 TG/服务商/服务器。Firefox 无头窗口可能有最小宽度限制，结果记录实际 viewport。

```sh
# 真实 Nginx 用例默认跳过：
SSP_TEST_NGINX=/path/to/nginx go test -count=1 ./internal/deploy
python3 scripts/browser-smoke.py --binary /tmp/ssp-test-panel --out /tmp/ssp-ui-fresh
# 专项：
python3 scripts/browser-smoke.py --ui-audit --binary /tmp/ssp-test-panel --out /tmp/ssp-ui-audit
python3 scripts/browser-smoke.py --overview-only --binary /tmp/ssp-test-panel --out /tmp/ssp-overview
python3 scripts/browser-smoke.py --server-form-only --binary /tmp/ssp-test-panel --out /tmp/ssp-server-form
```

## 固定回归要点

- 鉴权与 CSRF；站点创建/改名/复制/删除；文件修改与路径越界拒绝。
- 解压合并保留无关文件、冲突预检、符号链接拒绝。
- APK 远端同名原地处理；失败/空输出不覆盖；临时文件清理。
- SSL 配置操作不触发 APK；过期手动证书拒绝；缺公钥时私钥不变；SSH 身份变化拒绝。
- TG 失败可重试；部分/全部抓取失败生成失败状态行，旧数据只经完整旧版本查看。
- 过期文件/SSL 响应不覆盖新选择或未保存编辑。
- 备份：整站恢复、未变复用、变化新包、上传失败不发布清单。

候选实例应用独立数据目录与端口，与正式会话隔离。staging ACME 受外部 CA/DNS 影响时，不能用单元测试冒充续期演练结论。

概览菜单专项 `--overview-only`：844/1280/1920px 电脑端鼠标移动验证右对齐悬停按钮、隐藏更多、全宽无外侧留白、主机两行与按钮顺序和 IP 字号；320/375/390/430/800px 验证手机入口、四个图标、独立悬浮、行高不变、末行可点击、外部点击/Escape/滚动收起、单菜单与复制入口。宽屏触屏由 `(any-pointer: coarse)` 保留更多入口。

`--ui-audit` 包含电脑标题无文件后缀、320/375/390/430/600/800px 长站名的两行顶栏及按钮可达性、编辑器 overscroll 配置。原生 iOS 回弹手感不以 Firefox 的 CSS 检查替代。

触屏字号回归：`--ui-audit` 检查 6 档窄屏的实际编辑器/输入层字体，实际创建 CodeMirror contenteditable 输入层并聚焦失焦，检查新建文件弹窗、账号及登录输入。Firefox 只能验证样式与焦点操作，不能代替 iPhone 软键盘收起后的缩放实测。宽屏触屏由 `(any-pointer: coarse)` 规则覆盖。

`test-terminal-title.mjs` 用假 WebSocket 验证名称/IP、连接先于元信息完成、断线/重连、查询失败回退、文本转义与未登录保护；不连接真实服务器。概览专项检查主机按钮右对齐与四个操作按钮透明背景。
