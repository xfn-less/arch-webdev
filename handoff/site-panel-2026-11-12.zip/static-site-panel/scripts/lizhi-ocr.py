#!/usr/bin/env python3
"""Read captcha PNG from stdin; print OCR text to stdout. Uses panel .venv-lizhi."""
import sys

try:
    import ddddocr
except ImportError:
    sys.stderr.write("ddddocr missing; use /www/site-panel/.venv-lizhi/bin/python\n")
    sys.exit(2)

raw = sys.stdin.buffer.read()
if not raw:
    sys.stderr.write("empty stdin\n")
    sys.exit(1)

ocr = ddddocr.DdddOcr(show_ad=False)
text = (ocr.classification(raw) or "").strip()
sys.stdout.write(text)
