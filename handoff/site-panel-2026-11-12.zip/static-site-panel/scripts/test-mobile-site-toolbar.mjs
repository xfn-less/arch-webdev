/**
 * Headless Firefox: mobile layout — header mid on a second row; permanent file
 * ops and editor actions share a compact row; selection float stays outside
 * the scrollport; fixed files:editor 1:2; no page sideways scroll.
 */
import assert from "node:assert/strict"
import { spawn } from "node:child_process"
import crypto from "node:crypto"
import fs from "node:fs"
import http from "node:http"
import net from "node:net"
import os from "node:os"
import path from "node:path"
import { fileURLToPath } from "node:url"

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..")
const binary = process.env.SSP_PANEL_BIN || path.join(root, "bin/panel-test")
const outDir = fs.mkdtempSync(path.join(os.tmpdir(), "ssp-mobile-toolbar-"))
const dataDir = path.join(outDir, "data")
const sitesDir = path.join(outDir, "sites")
fs.mkdirSync(dataDir)
fs.mkdirSync(sitesDir)

function freePort() {
  return new Promise((resolve, reject) => {
    const s = net.createServer()
    s.listen(0, "127.0.0.1", () => {
      const { port } = s.address()
      s.close(() => resolve(port))
    })
    s.on("error", reject)
  })
}

async function api(port, method, p, body, cookie, csrf) {
  // Use http.request so Set-Cookie is visible (fetch hides it).
  const payload = body === undefined ? null : JSON.stringify(body)
  const headers = { Accept: "application/json" }
  if (payload !== null) headers["Content-Type"] = "application/json"
  if (cookie) headers.Cookie = cookie
  if (csrf) headers["X-CSRF"] = csrf
  if (payload !== null) headers["Content-Length"] = Buffer.byteLength(payload)
  const { status, text, setCookie, nextCsrf } = await new Promise((resolve, reject) => {
    const req = http.request(
      { host: "127.0.0.1", port, path: p, method, headers },
      (res) => {
        const chunks = []
        res.on("data", (c) => chunks.push(c))
        res.on("end", () => {
          resolve({
            status: res.statusCode,
            text: Buffer.concat(chunks).toString("utf8"),
            setCookie: res.headers["set-cookie"] || [],
            nextCsrf: res.headers["x-csrf"] || csrf,
          })
        })
      },
    )
    req.on("error", reject)
    if (payload !== null) req.write(payload)
    req.end()
  })
  const data = text ? JSON.parse(text) : null
  const cookieHdr = (Array.isArray(setCookie) ? setCookie[0] : setCookie) || ""
  return {
    ok: status >= 200 && status < 300,
    status,
    data,
    cookie: String(cookieHdr).split(";")[0] || cookie,
    csrf: nextCsrf || (data && data.csrf) || csrf,
  }
}

function solveCaptcha(challenge, difficulty) {
  let nonce = 0
  const prefix = "0".repeat(difficulty)
  for (;;) {
    const dig = crypto.createHash("sha256").update(challenge + String(nonce)).digest("hex")
    if (dig.startsWith(prefix)) return nonce
    nonce++
  }
}

async function waitReady(port) {
  for (let i = 0; i < 80; i++) {
    try {
      await api(port, "GET", "/api/status")
      return
    } catch {
      await new Promise((r) => setTimeout(r, 50))
    }
  }
  throw new Error("panel not ready")
}

async function withFirefox(fn) {
  const marionette = await freePort()
  const profile = path.join(outDir, "ff-profile")
  fs.mkdirSync(profile)
  fs.writeFileSync(
    path.join(profile, "user.js"),
    `user_pref("marionette.port", ${marionette});\nuser_pref("browser.shell.checkDefaultBrowser", false);\n`,
  )
  const ffLog = fs.openSync(path.join(outDir, "firefox.log"), "w")
  const ff = spawn("firefox", ["--headless", "--no-remote", `--profile`, profile, "--marionette"], {
    stdio: ["ignore", ffLog, ffLog],
  })
  let sock
  for (let i = 0; i < 150; i++) {
    try {
      sock = net.connect({ host: "127.0.0.1", port: marionette })
      await new Promise((res, rej) => {
        sock.once("connect", res)
        sock.once("error", rej)
      })
      break
    } catch {
      await new Promise((r) => setTimeout(r, 100))
    }
  }
  if (!sock) {
    ff.kill()
    throw new Error("marionette connect failed")
  }
  const driver = makeDriver(sock)
  try {
    return await fn(driver)
  } finally {
    try {
      await driver.command("WebDriver:DeleteSession")
    } catch {}
    sock.destroy()
    ff.kill("SIGTERM")
  }
}

function makeDriver(sock) {
  let buf = Buffer.alloc(0)
  let counter = 0
  const queue = []
  sock.on("data", (chunk) => {
    buf = Buffer.concat([buf, chunk])
    for (;;) {
      const colon = buf.indexOf(":")
      if (colon < 0) return
      const size = Number(buf.subarray(0, colon).toString())
      if (buf.length < colon + 1 + size) return
      const payload = buf.subarray(colon + 1, colon + 1 + size)
      buf = buf.subarray(colon + 1 + size)
      const msg = JSON.parse(payload.toString())
      const cb = queue.shift()
      if (!cb) continue
      if (msg[2]) cb.reject(new Error(JSON.stringify(msg[2])))
      else cb.resolve(msg[3]?.value ?? msg[3])
    }
  })
  // swallow hello
  sock.once("data", () => {})
  return {
    async command(name, params = {}) {
      counter++
      const payload = Buffer.from(JSON.stringify([0, counter, name, params]))
      sock.write(Buffer.concat([Buffer.from(String(payload.length) + ":"), payload]))
      return new Promise((resolve, reject) => queue.push({ resolve, reject }))
    },
    js(script) {
      return this.command("WebDriver:ExecuteScript", { script, args: [], newSandbox: false })
    },
  }
}

const panelPort = await freePort()
const panelLog = fs.openSync(path.join(outDir, "panel.log"), "w")
const panel = spawn(
  binary,
  [
    "-listen",
    `127.0.0.1:${panelPort}`,
    "-data",
    dataDir,
    "-sites",
    sitesDir,
    "-template",
    path.join(root, "templates/spa.nginx.conf"),
  ],
  { stdio: ["ignore", panelLog, panelLog] },
)

try {
  await waitReady(panelPort)
  let { data: chal } = await api(panelPort, "GET", "/api/captcha")
  const nonce = solveCaptcha(chal.challenge, chal.difficulty)
  let { data: setup, cookie, csrf } = await api(panelPort, "POST", "/api/setup", {
    password: "mobile-toolbar-test",
    captchaId: chal.id,
    captchaNonce: nonce,
  })
  assert.equal(setup.ok, true)
  csrf = setup.csrf || csrf
  const srv = await api(
    panelPort,
    "POST",
    "/api/servers",
    { name: "t", host: "127.0.0.1", port: 22, user: "root", authType: "key" },
    cookie,
    csrf,
  )
  cookie = srv.cookie || cookie
  csrf = srv.csrf || csrf
  assert.equal(srv.ok, true)
  const site = await api(
    panelPort,
    "POST",
    "/api/sites",
    { title: "phone-demo", serverId: srv.data.id },
    cookie,
    csrf,
  )
  assert.equal(site.ok, true)
  const siteName = site.data.name
  const cookiePair = String(cookie || "")
  const eq = cookiePair.indexOf("=")
  assert.ok(eq > 0, "missing session cookie from setup: " + cookiePair)
  const token = cookiePair.slice(eq + 1)

  const metrics = await withFirefox(async (driver) => {
    await new Promise((r) => setTimeout(r, 400))
    await driver.command("WebDriver:NewSession", {
      capabilities: { alwaysMatch: { pageLoadStrategy: "eager" } },
    })
    await driver.command("WebDriver:SetWindowRect", { width: 390, height: 844 })
    await driver.command("WebDriver:Navigate", { url: `http://127.0.0.1:${panelPort}/` })
    await driver.command("WebDriver:AddCookie", {
      cookie: {
        name: "ssp_session",
        value: token,
        path: "/",
        domain: "127.0.0.1",
        secure: false,
      },
    })
    await driver.command("WebDriver:Navigate", {
      url: `http://127.0.0.1:${panelPort}/`,
    })
    await driver.command("WebDriver:Navigate", {
      url: `http://127.0.0.1:${panelPort}/#/sites`,
    })
    let overviewReady = false
    for (let i = 0; i < 50 && !overviewReady; i++) {
      overviewReady = await driver.js(`
        return !!document.querySelector('.sites-overview .sites-table')
          && !!document.querySelector('.sites-th-host .sites-th-count')
          && !!document.querySelector('.sites-th-site .sites-th-count')
      `)
      if (!overviewReady) await new Promise((r) => setTimeout(r, 100))
    }
    assert.equal(overviewReady, true, "mobile overview ready")
    const overviewCompact = await driver.js(`
      const ips=document.querySelector('.sites-th-host .sites-th-count');
      const sites=document.querySelector('.sites-th-site .sites-th-count');
      const add=document.querySelector('.page-header-chrome > button.accent');
      const title=document.querySelector('.sites-overview .page-header-mid');
      const logs=document.querySelector('.logs');
      const tools=logs&&logs.querySelectorAll('.logs-tools button');
      if(!ips||!sites||!add||!tools||tools.length!==2)return false;
      const tr=tools[0].getBoundingClientRect(),dr=tools[1].getBoundingClientRect();
      return !document.querySelector('.sites-mobile-count')
        && /台/.test(ips.textContent) && /站/.test(sites.textContent)
        && (!title||getComputedStyle(title).display==='none')
        && !tools[0].textContent.trim() && !!tools[0].querySelector('.ico')
        && dr.left-tr.right>=6 && parseFloat(getComputedStyle(logs.querySelector('.logs-body')).fontSize)<16;
    `)
    assert.equal(overviewCompact, true, "mobile overview summary and compact icon logs")
    await driver.command("WebDriver:Navigate", {
      url: `http://127.0.0.1:${panelPort}/#/billing`,
    })
    const billingReady = await driver.js(`
      const face=document.querySelector('.billing-snap-face');
      const btn=document.querySelector('.logs-height-toggle');
      return !!face && !!btn;
    `)
    assert.equal(billingReady, true, "billing controls ready")
    const versionIcon = await driver.js(`
      const face=document.querySelector('.billing-snap-face');
      return face.textContent.trim()==='版本' && !!face.querySelector('.ico');
    `)
    assert.equal(versionIcon, true, "version dropdown icon")
    await driver.js("document.querySelector('.logs-height-toggle').click()")
    await new Promise((r) => setTimeout(r, 80))
    const collapsedLog = await driver.js(`
      const btn=document.querySelector('.logs-height-toggle');
      return document.documentElement.style.getPropertyValue('--log').includes('2.2em')
        && btn.getAttribute('aria-label')==='展开日志';
    `)
    assert.equal(collapsedLog, true, "mobile logs collapse to two lines")
    await driver.js("document.querySelector('.logs-height-toggle').click()")
    await new Promise((r) => setTimeout(r, 80))
    await driver.command("WebDriver:Navigate", {
      url: `http://127.0.0.1:${panelPort}/#/site/${encodeURIComponent(siteName)}`,
    })
    let ready = false
    for (let i = 0; i < 100; i++) {
      ready = await driver.js(
        "return !!(document.querySelector('.site-top-bar .site-top-right') && document.querySelector('.files-head .files-conf-btn') && document.querySelector('.files-head .files-select-all') && document.querySelector('.editor-rail-float:not(.off)') && document.querySelector('.codejar-editor') && !document.querySelector('.site-view .page-header'))",
      )
      if (ready) break
      await new Promise((r) => setTimeout(r, 100))
    }
    if (!ready) {
      const dump = await driver.js(
        "return {hash:location.hash,authed:!!document.querySelector('.shell'),body:(document.body&&document.body.innerText||'').slice(0,300),rail:!!document.querySelector('.editor-rail-float')}",
      )
      throw new Error("site toolbar not ready: " + JSON.stringify(dump))
    }
    const collapsedN = await driver.js(
      "const r=document.querySelector('.editor-rail-float');return r?r.querySelectorAll('.editor-rail-top > .files-op').length:0",
    )
    const collapsedSeven = await driver.js(`
      const r=document.querySelector('.editor-rail-float');
      const top=r&&r.querySelector('.editor-rail-top');
      if(!r||!top) return false;
      const rr=r.getBoundingClientRect();
      const wrap=document.querySelector('.cm-wrap');
      const wr=wrap?wrap.getBoundingClientRect():null;
      const cs=getComputedStyle(top);
      return !!(wr && Math.abs(rr.top-wr.top)<=2 && Math.abs(rr.right-wr.right)<=2
        && cs.flexDirection==='row' && !r.classList.contains('open'));
    `)
    await driver.js(`
      const rail=document.querySelector('.editor-rail-float');
      const more=[...rail.querySelectorAll('button.files-op')].find(b=>(b.title||'').includes('更多'));
      if(more) more.click();
    `)
    let openN = 0
    for (let i = 0; i < 40; i++) {
      openN = await driver.js(
        "const r=document.querySelector('.editor-rail-float');return r&&r.classList.contains('open')?r.querySelectorAll('.files-op, .editor-rail-apk').length:0",
      )
      if (openN >= 5) break
      await new Promise((r) => setTimeout(r, 50))
    }
    const openSeven = await driver.js(`
      const r=document.querySelector('.editor-rail-float');
      const top=r&&r.querySelector('.editor-rail-top');
      const down=r&&r.querySelector('.editor-rail-down');
      if(!r||!top||!down||!r.classList.contains('open')) return false;
      const tr=top.getBoundingClientRect();
      const dr=down.getBoundingClientRect();
      const btn=top.querySelector('.files-op');
      const bw=btn?btn.getBoundingClientRect().width:0;
      // Down column is ~1 button wide and right-aligned under the expand cell (true 「7」).
      return Math.abs(dr.right-tr.right)<=2 && dr.width<=bw+10 && dr.left>=tr.left+bw-4
        && getComputedStyle(r).backgroundColor==='rgba(0, 0, 0, 0)';
    `)
    const rest = await driver.js(`
      const top = document.querySelector('.site-top-bar');
      const acts = document.querySelector('.site-top-bar .site-top-right');
      const fh = document.querySelector('.files-head');
      const conf = document.querySelector('.files-head .files-conf-btn');
      const edHead = document.querySelector('.editor-pane-head');
      const title = document.querySelector('.site-top-title');
      const back = document.querySelector('.site-top-bar .sites-back');
      const backLabel = back && back.querySelector('.sites-back-label');
      const flt = document.querySelector('.files-select-float');
      if (!top || !acts || !fh || !conf || !title) return { missing: true };
      const tb = top.getBoundingClientRect();
      const fr = fh.getBoundingClientRect();
      const tr = title.getBoundingClientRect();
      const br = back.getBoundingClientRect();
      const sel = fh.querySelector('.files-select-all');
      const dir = fh.querySelector('.files-dir-label');
      const confAfterSelect = !!(sel && conf && sel.compareDocumentPosition(conf) & Node.DOCUMENT_POSITION_FOLLOWING);
      const confBeforeDir = !!(dir && conf && conf.compareDocumentPosition(dir) & Node.DOCUMENT_POSITION_FOLLOWING);
      const files = document.querySelector('.files');
      const cols = files ? getComputedStyle(files).gridTemplateColumns.split(' ').filter(Boolean) : [];
      const ratio = cols.length >= 2 ? (parseFloat(cols[1]) / Math.max(parseFloat(cols[0]), 1)) : 0;
      const jar = document.querySelector('.codejar-editor');
      const jarCs = jar ? getComputedStyle(jar) : null;
      const check = document.querySelector('.files-select-all .file-check');
      const checkM = check ? parseFloat(getComputedStyle(check).marginLeft) : 0;
      const rowCheck = document.querySelector('.file-row .file-check');
      let checkAligned = !rowCheck || !check;
      if (rowCheck && check) {
        checkAligned = Math.abs(check.getBoundingClientRect().left - rowCheck.getBoundingClientRect().left) <= 2;
      }
      const rail = document.querySelector('.editor-rail-float');
      const wrap = document.querySelector('.cm-wrap');
      const ssl = acts.querySelector('.site-ssl-btn');
      const sslBg = ssl ? getComputedStyle(ssl).backgroundColor : '';
      const backBg = back ? getComputedStyle(back).backgroundColor : '';
      const backBox = back ? back.getBoundingClientRect() : null;
      const backSquare = !!(backBox && Math.abs(backBox.width - backBox.height) <= 2);
      const headBg = fh ? getComputedStyle(fh).backgroundColor : '';
      const deployShort = [...acts.querySelectorAll('.act-label-short')].map(n => n.textContent.trim());
      const fltCs = flt ? getComputedStyle(flt) : null;
      let floatLeftPct = 0;
      if (flt && files) {
        const wasOff = flt.classList.contains("off");
        flt.classList.remove("off");
        flt.style.visibility = "hidden";
        const filesR = files.getBoundingClientRect();
        const r = flt.getBoundingClientRect();
        floatLeftPct = filesR.width ? (r.left - filesR.left) / filesR.width : 0;
        flt.style.visibility = "";
        if (wasOff) flt.classList.add("off");
      }
      return {
        vw: innerWidth,
        deployCount: acts.children.length,
        deployLabels: deployShort,
        noGlobalHeader: !document.querySelector('.site-view .page-header'),
        oneTopBar: tb.height <= 56,
        titleLeft: getComputedStyle(title).textAlign === 'left' || tr.x <= br.right + 12,
        backIconOnly: !!(backLabel && getComputedStyle(backLabel).display === 'none'),
        backSquare,
        filesHeadFull: fr.left <= 4 && fr.right >= innerWidth - 4,
        confAfterSelect,
        confBeforeDir,
        edHeadHidden: !!(edHead && getComputedStyle(edHead).display === 'none'),
        hasFloat: !!flt,
        floatOff: !!(flt && flt.classList.contains('off')),
        floatCol: !!(flt && getComputedStyle(flt).flexDirection === 'column'),
        floatUnderFiles: !!(flt && files && files.contains(flt) && !document.querySelector('.file-side .files-select-float')),
        floatAtDivider: floatLeftPct >= 0.30 && floatLeftPct <= 0.38,
        floatNoTranslate: !!(fltCs && (fltCs.transform === 'none' || fltCs.transform === 'matrix(1, 0, 0, 1, 0, 0)')),
        railInWrap: !!(wrap && rail && wrap.contains(rail)),
        filesHasUpload: [...fh.querySelectorAll('button.files-op')].some(b => (b.title||'').includes('上传')),
        filesIcons: fh.querySelectorAll('button.files-op .ico').length,
        checkInset: checkM >= 8,
        checkAligned,
        ratioOk: ratio >= 1.5 && ratio <= 2.6,
        noWrap: !!(jarCs && jarCs.whiteSpace === 'pre' && jarCs.overflowWrap === 'normal'),
        sslTinted: !!sslBg && sslBg !== 'rgba(0, 0, 0, 0)' && sslBg !== 'transparent',
        backTinted: !!backBg && backBg !== 'rgba(0, 0, 0, 0)' && backBg !== 'transparent',
        headGray: !!headBg && headBg !== 'rgba(0, 0, 0, 0)',
        tbH: Math.round(tb.height),
        pageMin: parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--page-min-width")) || 0,
        bodyW: document.body.scrollWidth,
        pageScrolls: document.documentElement.scrollWidth > innerWidth + 1 || document.body.scrollWidth > innerWidth + 1,
      };
    `)
    return {
      ...rest,
      railCollapsedWas2: collapsedN === 2,
      railCollapsedSeven: !!collapsedSeven,
      railExpanded: openN >= 5,
      railOpenSeven: !!openSeven,
    }
  })

  assert.ok(metrics.vw <= 560, "viewport not phone-ish: " + metrics.vw)
  assert.ok(metrics.deployCount >= 2, "expected deploy+ssl: " + JSON.stringify(metrics))
  assert.deepEqual(metrics.deployLabels, ["先部署", "再SSL"], "phone deploy/ssl labels: " + JSON.stringify(metrics))
  assert.equal(metrics.noGlobalHeader, true, "no global header: " + JSON.stringify(metrics))
  assert.equal(metrics.oneTopBar, true, "top bar one row: " + JSON.stringify(metrics))
  assert.equal(metrics.titleLeft, true, "phone title left: " + JSON.stringify(metrics))
  assert.equal(metrics.backIconOnly, true, "phone back icon-only: " + JSON.stringify(metrics))
  assert.equal(metrics.backSquare, true, "phone back square: " + JSON.stringify(metrics))
  assert.equal(metrics.filesHeadFull, true, "files head full width: " + JSON.stringify(metrics))
  assert.equal(metrics.confAfterSelect, true, "conf after select: " + JSON.stringify(metrics))
  assert.equal(metrics.confBeforeDir, true, "conf before dir: " + JSON.stringify(metrics))
  assert.equal(metrics.edHeadHidden, true, "editor pane head hidden on phone: " + JSON.stringify(metrics))
  assert.equal(metrics.railCollapsedWas2, true, "rail starts with 2: " + JSON.stringify(metrics))
  assert.equal(metrics.railCollapsedSeven, true, "rail top-right 7: " + JSON.stringify(metrics))
  assert.equal(metrics.railExpanded, true, "rail expands: " + JSON.stringify(metrics))
  assert.equal(metrics.railOpenSeven, true, "rail open is true 7 not 2-col: " + JSON.stringify(metrics))
  assert.equal(metrics.railInWrap, true, "rail on editor wrap: " + JSON.stringify(metrics))
  assert.equal(metrics.hasFloat, true, "selection float present: " + JSON.stringify(metrics))
  assert.equal(metrics.floatOff, true, "selection float hidden empty: " + JSON.stringify(metrics))
  assert.equal(metrics.floatCol, true, "selection float vertical: " + JSON.stringify(metrics))
  assert.equal(metrics.floatUnderFiles, true, "float under .files: " + JSON.stringify(metrics))
  assert.equal(metrics.floatAtDivider, true, "float at divider: " + JSON.stringify(metrics))
  assert.equal(metrics.floatNoTranslate, true, "float hangs into editor: " + JSON.stringify(metrics))
  assert.equal(metrics.filesHasUpload, true, "files head upload: " + JSON.stringify(metrics))
  assert.ok(metrics.filesIcons >= 3, "files icons: " + JSON.stringify(metrics))
  assert.equal(metrics.checkInset, true, "checkbox inset: " + JSON.stringify(metrics))
  assert.equal(metrics.checkAligned, true, "select-all aligns with rows: " + JSON.stringify(metrics))
  assert.equal(metrics.ratioOk, true, "mobile ~1:2: " + JSON.stringify(metrics))
  assert.equal(metrics.noWrap, true, "no wrap: " + JSON.stringify(metrics))
  assert.equal(metrics.sslTinted, true, "ssl tint bg: " + JSON.stringify(metrics))
  assert.equal(metrics.backTinted, true, "overview tint bg: " + JSON.stringify(metrics))
  assert.equal(metrics.headGray, true, "files head gray: " + JSON.stringify(metrics))
  assert.ok(metrics.tbH > 24 && metrics.tbH <= 56, "compact top: " + metrics.tbH)
  assert.ok(metrics.pageMin < 2, "page-min 0: " + JSON.stringify(metrics))
  assert.equal(metrics.pageScrolls, false, "no page sideways scroll: " + JSON.stringify(metrics))
  assert.ok(metrics.bodyW <= metrics.vw + 2, "body fits: " + JSON.stringify(metrics))
  console.log(JSON.stringify({ ok: true, outDir, metrics }, null, 2))
} finally {
  panel.kill("SIGTERM")
}
