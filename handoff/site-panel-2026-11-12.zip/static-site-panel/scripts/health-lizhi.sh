#!/usr/bin/env bash
# Every 2h: controller + backup + socks + remote SSH ports. Quiet on OK; short TG on fail.
set -euo pipefail

ROOT="${SITE_PANEL_ROOT:-/www/site-panel}"
ACCOUNTS="${ROOT}/.data/lizhi-accounts.json"
DB="${SITE_PANEL_DB:-$ROOT/.data/panel.db}"
HEALTH_LAST="${SITE_PANEL_HEALTH_LAST:-$ROOT/.data/health-last}"
PROXY_URL="${LIZHI_SOCKS:-socks5h://127.0.0.1:17890}"
BACKUP_DIR="${SITE_PANEL_BACKUP_DIR:-/root/backups/site-panel}"

mkdir -p "$(dirname "$HEALTH_LAST")"

write_stamp() {
  # $1 = ok|fail  $2 = short message when fail
  local status="$1"
  local msg="${2:-}"
  printf '%s\t%s\t%s\n' "$(date +%s)" "$status" "$msg" >"$HEALTH_LAST"
}

# Same meta key as panel billing TG so morning/health/alerts replace each other.
TG_LAST_META_KEY="billing_tg_last_msg_id"

short_tg() {
  local text="$1"
  if [[ ! -f "$ACCOUNTS" ]] || ! command -v python3 >/dev/null; then
    return 0
  fi
  python3 - "$ACCOUNTS" "$DB" "$TG_LAST_META_KEY" "$text" <<'PY'
import json, sqlite3, sys, urllib.parse, urllib.request

accounts, db_path, meta_key, text = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
cfg = json.load(open(accounts))
tg = cfg.get("telegram") or {}
tok, chat = (tg.get("bot_token") or "").strip(), (tg.get("chat_id") or "").strip()
if not tok or not chat:
    sys.exit(0)

def tg_api(method, fields):
    data = urllib.parse.urlencode(fields).encode()
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{tok}/{method}",
        data=data,
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=15) as res:
        return json.loads(res.read().decode())

prev_id = 0
try:
    con = sqlite3.connect(db_path)
    row = con.execute("SELECT value FROM meta WHERE key = ?", (meta_key,)).fetchone()
    if row and str(row[0]).strip().isdigit():
        prev_id = int(str(row[0]).strip())
except Exception as e:
    print("tg meta read:", e, file=sys.stderr)
    con = None

try:
    out = tg_api("sendMessage", {
        "chat_id": chat,
        "text": text,
        "disable_web_page_preview": "true",
    })
except Exception as e:
    print("tg send:", e, file=sys.stderr)
    sys.exit(0)

msg_id = 0
try:
    msg_id = int((((out or {}).get("result") or {}).get("message_id")) or 0)
except Exception:
    msg_id = 0

if msg_id > 0 and con is not None:
    try:
        con.execute(
            "INSERT INTO meta(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (meta_key, str(msg_id)),
        )
        con.commit()
    except Exception as e:
        print("tg meta write:", e, file=sys.stderr)

if prev_id > 0 and prev_id != msg_id:
    try:
        tg_api("deleteMessage", {"chat_id": chat, "message_id": str(prev_id)})
    except Exception as e:
        print("tg delete:", e, file=sys.stderr)

if con is not None:
    con.close()
PY
}

clear_tg() {
  # Drop the last alert when health returns to OK (no new message).
  if [[ ! -f "$ACCOUNTS" ]] || [[ ! -f "$DB" ]] || ! command -v python3 >/dev/null; then
    return 0
  fi
  python3 - "$ACCOUNTS" "$DB" "$TG_LAST_META_KEY" <<'PY'
import json, sqlite3, sys, urllib.parse, urllib.request
accounts, db_path, meta_key = sys.argv[1], sys.argv[2], sys.argv[3]
cfg = json.load(open(accounts))
tg = cfg.get("telegram") or {}
tok, chat = (tg.get("bot_token") or "").strip(), (tg.get("chat_id") or "").strip()
if not tok or not chat:
    sys.exit(0)
try:
    con = sqlite3.connect(db_path)
    row = con.execute("SELECT value FROM meta WHERE key = ?", (meta_key,)).fetchone()
    prev = int(str(row[0]).strip()) if row and str(row[0]).strip().isdigit() else 0
    if prev > 0:
        data = urllib.parse.urlencode({"chat_id": chat, "message_id": str(prev)}).encode()
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{tok}/deleteMessage",
            data=data,
            method="POST",
        )
        try:
            urllib.request.urlopen(req, timeout=15).read()
        except Exception as e:
            print("tg clear:", e, file=sys.stderr)
        con.execute("DELETE FROM meta WHERE key = ?", (meta_key,))
        con.commit()
    con.close()
except Exception as e:
    print("tg clear meta:", e, file=sys.stderr)
PY
}

fail() {
  local msg="$1"
  write_stamp fail "$msg"
  echo "fail: $msg" >&2
  short_tg "$msg"
  exit 1
}

if ! systemctl is-active --quiet site-panel; then
  fail "面板异常"
fi
if ! curl -fsS -o /dev/null --max-time 10 http://127.0.0.1:8790/api/status; then
  fail "面板异常"
fi

if ! python3 - "$ROOT" "$BACKUP_DIR" <<'CHECK'
import shutil, sys, time
from pathlib import Path
if shutil.disk_usage(sys.argv[1]).free < 2 * 1024**3:
    sys.exit(1)
manifests = Path(sys.argv[2], "manifests")
latest = max((p.stat().st_mtime for p in manifests.glob("manifest-*.json")), default=0)
if time.time() - latest > 36 * 3600:
    sys.exit(1)
CHECK
then
  fail "备份失败"
fi

if ! systemctl is-active --quiet lizhi-socks; then
  fail "抓取失败"
fi
if ! curl -fsS -o /dev/null --max-time 20 --proxy "$PROXY_URL" \
  -A Mozilla "https://www.lizhidc.cn/login?action=email"; then
  fail "抓取失败"
fi

# Probe panel-managed SSH hosts (TCP only).
if [[ -f "$DB" ]] && command -v python3 >/dev/null; then
  bad="$(
    SITE_PANEL_ROOT="$ROOT" python3 - "$DB" <<'PY'
import os, sqlite3, socket, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed

con = sqlite3.connect(sys.argv[1])
try:
    rows = con.execute(
        "SELECT host, COALESCE(port,22), COALESCE(via_jump,0) FROM servers WHERE trim(host) != ''"
    ).fetchall()
except sqlite3.OperationalError:
    rows = [(h, p, 0) for h, p in con.execute(
        "SELECT host, COALESCE(port,22) FROM servers WHERE trim(host) != ''"
    ).fetchall()]
con.close()

# SSH on this host flaps behind its gateway. Do not page on it.
skip_hosts = {"180.97.215.102"}
rows = [row for row in rows if str(row[0]).strip() not in skip_hosts]

jump_host = (os.environ.get("SSP_JUMP_HOST") or "183.56.236.235").strip()
jump_user = (os.environ.get("SSP_JUMP_USER") or "root").strip()
root = (os.environ.get("SITE_PANEL_ROOT") or "/www/site-panel").strip()
jump_key = (os.environ.get("SSP_JUMP_IDENTITY") or f"{root}/.ssh/lizhi-socks_ed25519").strip()

def probe_direct(host, port):
    try:
        s = socket.create_connection((host, int(port or 22)), timeout=5)
        s.close()
        return True
    except Exception:
        return False

def probe_via_jump(host, port):
    import shlex
    port = int(port or 22)
    # One remote argv only — ssh joins extra args with spaces and breaks newlines.
    script = f"import socket;socket.create_connection(({host!r},{port}),timeout=5).close()"
    remote = "python3 -c " + shlex.quote(script)
    try:
        r = subprocess.run(
            [
                "ssh",
                "-i", jump_key,
                "-o", "BatchMode=yes",
                "-o", "IdentitiesOnly=yes",
                "-o", "ConnectTimeout=10",
                "-o", "StrictHostKeyChecking=accept-new",
                f"{jump_user}@{jump_host}",
                remote,
            ],
            capture_output=True,
            timeout=20,
        )
        return r.returncode == 0
    except Exception:
        return False

def probe(host, port, via_jump):
    check = probe_via_jump if via_jump else probe_direct
    for i in range(3):
        if check(host, port):
            return None
        if i < 2:
            time.sleep(1.5)
    return host

bad = []
with ThreadPoolExecutor(max_workers=8) as ex:
    futs = [ex.submit(probe, h, p, v) for h, p, v in rows]
    for f in as_completed(futs):
        h = f.result()
        if h:
            bad.append(h)
if bad:
    bad = bad[:3]
    print(",".join(bad))
PY
  )" || true
  if [[ -n "${bad:-}" ]]; then
    fail "面板异常,${bad}不可达"
  fi
fi

write_stamp ok
clear_tg
echo "ok"
exit 0
