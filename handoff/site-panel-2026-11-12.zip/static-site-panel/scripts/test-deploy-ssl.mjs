import test from "node:test"
import assert from "node:assert/strict"
import fs from "node:fs"
import vm from "node:vm"

const source = fs.readFileSync(new URL("../web/js/app.js", import.meta.url), "utf8")
const functions = source.slice(
  source.indexOf("/** Deploy-time DNS result"),
  source.indexOf("async function doSSL("),
)
const ready = { domains: ["a.example", "b.example"], sslCoversAll: false, ok: true, expected: "192.0.2.1", items: ["a.example", "b.example"].map(domain => ({ domain, ok: true, actual: ["192.0.2.1"] })) }

function harness({ deployed = true, dns = ready, dnsError, accept = true } = {}) {
  const events = [], logs = [], prompts = [], alerts = []
  const state = { busy: { val: false }, deployPending: { val: true } }
  const context = vm.createContext({
    state,
    api: {
      deployDiff: async () => ({}),
      deploy: async name => { events.push("deploy:" + name); return { ok: deployed, error: deployed ? "" : "SSH disconnected" } },
      dnsCheck: async name => { events.push("dns:" + name); if (dnsError) throw new Error(dnsError); return dns },
      ssl: async name => { events.push("ssl-sync:" + name); return { ok: true, synced: false, lines: [] } },
    },
    isCurrentSite: () => true, setSitePendingDeploy: on => { state.deployPending.val = on },
    refreshTree: async () => {}, pushLog: line => logs.push(line), pushLines: () => {}, formatDeployDiff: () => "diff",
    dlgConfirm: async (message, title, options) => { prompts.push({ message, title, options }); return title === "部署" || accept },
    dlgAlert: async message => alerts.push(message),
    doSSL: async name => { assert.equal(state.busy.val, false); events.push("ssl:" + name) },
    playSuccessSound: () => {},
    playErrorSound: () => {},
  })
  vm.runInContext(functions, context)
  return { run: () => context.doDeploy("s7"), events, logs, prompts, alerts, state }
}

test("successful deployment checks every domain then offers the existing SSL flow", async () => {
  const h = harness(); await h.run()
  assert.deepEqual(h.events, ["deploy:s7", "dns:s7", "ssl-sync:s7", "ssl:s7"])
  assert.ok(h.prompts[1].message.includes("SSL"))
  assert.equal(h.prompts[1].options.confirmLabel, "去申请")
  assert.equal(h.state.busy.val, false)
  assert.equal(h.state.deployPending.val, false)
})
test("declining the reminder never starts SSL", async () => {
  const h = harness({ accept: false }); await h.run()
  assert.deepEqual(h.events, ["deploy:s7", "dns:s7", "ssl-sync:s7"])
})
test("failed deployment never checks DNS or offers SSL", async () => {
  const h = harness({ deployed: false }); await h.run()
  assert.deepEqual(h.events, ["deploy:s7"])
  assert.deepEqual(h.alerts, ["SSH disconnected"])
})
test("one unresolved domain prevents the SSL reminder", async () => {
  const h = harness({ dns: { ...ready, ok: false, items: [ready.items[0], { domain: "b.example", ok: false, actual: [] }] } }); await h.run()
  assert.equal(h.prompts.length, 1)
  assert.deepEqual(h.events, ["deploy:s7", "dns:s7"])
  assert.ok(h.logs.some((line) => line.includes("这些域名还没解析到这台机（1）")))
  assert.ok(h.logs.some((line) => line.includes("b.example → 无解析")))
  assert.ok(h.logs.some((line) => line.includes("先别申请 SSL")))
})
test("no configured domains does not offer SSL", async () => {
  const h = harness({ dns: { ok: false, items: [] } }); await h.run()
  assert.equal(h.prompts.length, 1)
})
test("DNS request failure preserves successful deployment and releases busy state", async () => {
  const h = harness({ dnsError: "request timeout" }); await h.run()
  assert.equal(h.alerts.length, 0)
  assert.ok(h.logs.some(line => line.includes("部署成功，但查解析失败")))
  assert.equal(h.state.busy.val, false)
  assert.deepEqual(h.events, ["deploy:s7", "dns:s7"])
})

test("an already covered certificate suppresses the SSL prompt", async () => {
  const h = harness({ dns: { ...ready, sslCoversAll: true } }); await h.run()
  assert.equal(h.prompts.length, 1)
  assert.deepEqual(h.events, ["deploy:s7", "dns:s7"])
})

test("syncing an existing remote cert suppresses the SSL prompt", async () => {
  const events = [], logs = [], prompts = []
  const state = { busy: { val: false }, deployPending: { val: true }, fsFile: { val: "" }, fsDirty: { val: false }, fsText: { val: "" } }
  const context = vm.createContext({
    state,
    api: {
      deployDiff: async () => ({}),
      deploy: async name => { events.push("deploy:" + name); return { ok: true } },
      dnsCheck: async name => { events.push("dns:" + name); return ready },
      ssl: async name => {
        events.push("ssl-sync:" + name)
        return { ok: true, synced: true, lines: ["remote cert covers all"], result: { daysLeft: 88 }, conf: "server {}" }
      },
    },
    isCurrentSite: () => true, setSitePendingDeploy: on => { state.deployPending.val = on },
    refreshTree: async () => {}, pushLog: line => logs.push(line), pushLines: () => {}, formatDeployDiff: () => "diff",
    dlgConfirm: async (message, title) => { prompts.push({ message, title }); return title === "部署" },
    dlgAlert: async () => {},
    doSSL: async name => { events.push("ssl:" + name) },
    playSuccessSound: () => {},
    playErrorSound: () => {},
  })
  vm.runInContext(functions, context)
  await context.doDeploy("s7")
  assert.deepEqual(events, ["deploy:s7", "dns:s7", "ssl-sync:s7"])
  assert.equal(prompts.length, 1)
  assert.ok(logs.some(line => line.includes("已同步")))
})
