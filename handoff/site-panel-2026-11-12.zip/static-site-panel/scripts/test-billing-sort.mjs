import test from "node:test"
import assert from "node:assert/strict"
import fs from "node:fs"
import vm from "node:vm"
const source = fs.readFileSync(new URL("../web/js/app.js", import.meta.url), "utf8")
const context = vm.createContext({})
vm.runInContext(source.slice(source.indexOf("function sortBillingRows("), source.indexOf("function BillingView(")), context)
const rows = [
  { id: "long", daysLeft: 30, expireUnix: 10 },
  { id: "expired", daysLeft: -3, expireUnix: 10 },
  { id: "unknown", daysLeft: 0, expireUnix: 0 },
  { id: "soon", daysLeft: 2, expireUnix: 10 },
  { id: "tie", daysLeft: 2, expireUnix: 11 },
]
const ids = rows => Array.from(rows, row => row.id)
test("default preserves account order", () => {
  assert.deepEqual(ids(context.sortBillingRows(rows, "")), ids(rows))
})
test("numeric ascending includes negatives, keeps ties stable and puts unknown dates last", () => {
  assert.deepEqual(ids(context.sortBillingRows(rows, "asc")), ["expired", "soon", "tie", "long", "unknown"])
})
test("descending puts unknown dates last and does not mutate default order", () => {
  assert.deepEqual(ids(context.sortBillingRows(rows, "desc")), ["long", "soon", "tie", "expired", "unknown"])
  assert.deepEqual(ids(rows), ["long", "expired", "unknown", "soon", "tie"])
})
