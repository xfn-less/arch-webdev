"""Offline integration checks: python3 -m unittest discover -s scripts -p test_backup.py -v"""
import importlib.util
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import tarfile
import tempfile
import unittest

SCRIPTS = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("backup_sites", SCRIPTS / "backup-sites.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
retention_spec = importlib.util.spec_from_file_location("backup_retention", SCRIPTS / "backup-retention.py")
retention = importlib.util.module_from_spec(retention_spec)
retention_spec.loader.exec_module(retention)


class BackupTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.sites = self.root / "panel" / "sites"
        self.site = self.sites / "站点 A"
        (self.site / "www").mkdir(parents=True)
        (self.site / "www" / "index.html").write_text("original")
        (self.site / "www" / ".hidden").write_text("included")
        (self.site / "www" / "app.apk").write_bytes(b"apk\x00data")
        self.remote = self.root / "remote"
        self.remote.mkdir()
        self.out = self.root / "out"
        self.rclone = self.root / "rclone"
        self.rclone.write_text('''#!/usr/bin/env python3
import os, pathlib, shutil, sys
cmd, src, *args = sys.argv[1:]
if cmd == 'lsf':
    base = pathlib.Path(src)
    include = args[args.index('--include') + 1] if '--include' in args else 'site-archives/**'
    prefix = include.split('*', 1)[0].rstrip('/')
    for p in base.rglob('*'):
        if p.is_file() and p.relative_to(base).as_posix().startswith(prefix + '/'):
            print(p.relative_to(base).as_posix())
elif cmd == 'copyto':
    dst = pathlib.Path(args[0])
    if (dst.parent.parent / 'FAIL').exists() and dst.parent.name == 'site-archives':
        sys.exit(7)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
elif cmd == 'cat':
    print(pathlib.Path(src).read_text(), end='')
elif cmd == 'deletefile':
    pathlib.Path(src).unlink()
else:
    sys.exit(8)
''')
        self.rclone.chmod(0o700)

    def backup(self, stamp):
        module.backup(self.sites, self.out, str(self.remote), str(self.rclone), stamp, "config/test/config.tar.gz")

    def test_roundtrip_skip_and_changed_site(self):
        self.backup("first")
        archive = next((self.remote / "site-archives").iterdir())
        original_mtime = archive.stat().st_mtime_ns
        self.backup("second")
        self.assertEqual(len(list((self.remote / "site-archives").iterdir())), 1)
        self.assertEqual(archive.stat().st_mtime_ns, original_mtime)
        restored = self.root / "restored"
        restored.mkdir()
        with tarfile.open(archive) as tar:
            tar.extractall(restored, filter="data")
        self.assertEqual((restored / self.site.name / "www" / "app.apk").read_bytes(), b"apk\x00data")
        self.assertEqual((restored / self.site.name / "www" / ".hidden").read_text(), "included")
        import gzip, hashlib
        with gzip.open(archive, "rb") as src:
            digest = hashlib.sha256(src.read()).hexdigest()
        manifest = json.loads(next((self.remote / "site-manifests").iterdir()).read_text())
        self.assertEqual(digest, manifest["sites"][0]["tar_sha256"])
        (self.site / "www" / "index.html").write_text("changed")
        self.backup("third")
        self.assertEqual(len(list((self.remote / "site-archives").iterdir())), 2)

    def test_upload_failure_does_not_publish_manifest(self):
        (self.remote / "FAIL").touch()
        with self.assertRaises(subprocess.CalledProcessError):
            self.backup("failed")
        self.assertFalse((self.remote / "site-manifests").exists())
        self.assertFalse(list(self.out.glob("manifest-*.json")))

    def test_full_script_copies_committed_wal_and_key(self):
        panel = self.sites.parent
        data = panel / ".data"
        data.mkdir()
        (panel / ".ssh").mkdir()
        (panel / ".ssh" / "id_ed25519").write_text("test-only-fake-key")
        (data / "r2.env").write_text("DO_NOT_BACK_UP=secret")
        host = self.root / "host"
        (host / "nginx").mkdir(parents=True)
        (host / "cert" / "site-panel.xfnss.top").mkdir(parents=True)
        (host / "acme-home").mkdir()
        (host / "nginx" / "site-panel.conf").write_text("server {}")
        (host / "nginx" / "websocket.conf").write_text("map {}")
        (host / "cert" / "site-panel.xfnss.top" / "privkey.pem").write_text("test-only-cert-key")
        (host / "acme-home" / "account.key").write_text("test-only-acme-key")
        (host / "root-crontab").write_text("PATH=/usr/local/bin:/usr/bin:/bin\n30 3 * * * /www/site-panel/scripts/backup.sh\n")
        db = sqlite3.connect(data / "panel.db")
        self.addCleanup(db.close)
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA wal_autocheckpoint=0")
        db.execute("CREATE TABLE probe(value)")
        db.execute("INSERT INTO probe VALUES ('committed-in-wal')")
        db.commit()
        env = dict(os.environ, SITE_PANEL_ROOT=str(panel), RCLONE_BIN=str(self.rclone),
                   RCLONE_REMOTE=str(self.remote), R2_ACCESS_KEY_ID="test", R2_ENV_FILE="/nonexistent",
                   BACKUP_INCLUDE_HOST_CONFIG="1", PANEL_NGINX_VHOST=str(host / "nginx" / "site-panel.conf"),
                   PANEL_NGINX_WEBSOCKET=str(host / "nginx" / "websocket.conf"),
                   PANEL_TLS_DIR=str(host / "cert" / "site-panel.xfnss.top"),
                   PANEL_ACME_HOME=str(host / "acme-home"), PANEL_ROOT_CRONTAB_FILE=str(host / "root-crontab"))
        subprocess.run(["bash", str(SCRIPTS / "backup.sh"), str(self.out)], env=env,
                       check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        config = next((self.out / "config").glob("*.tar.gz"))
        restored = self.root / "config-restore"
        restored.mkdir()
        with tarfile.open(config) as tar:
            tar.extractall(restored, filter="data")
        with sqlite3.connect(restored / "data" / "panel.db") as backup_db:
            self.assertEqual(backup_db.execute("SELECT value FROM probe").fetchone()[0], "committed-in-wal")
            self.assertEqual(backup_db.execute("PRAGMA integrity_check").fetchone()[0], "ok")
        self.assertFalse((restored / "data" / "r2.env").exists())
        self.assertTrue((restored / ".ssh" / "id_ed25519").is_file())
        self.assertTrue((restored / "host-config" / "nginx" / "site-panel.conf").is_file())
        self.assertTrue((restored / "host-config" / "cert" / "site-panel.xfnss.top" / "privkey.pem").is_file())
        self.assertTrue((restored / "host-config" / "acme-home" / "account.key").is_file())
        self.assertIn("/www/site-panel/scripts/backup.sh", (restored / "host-config" / "panel-cron.txt").read_text())

    def test_retention_keeps_latest_complete_snapshots_and_referenced_archives(self):
        digests = ["a" * 64, "b" * 64, "c" * 64]
        for digest in digests:
            archive = self.remote / "site-archives" / (digest + ".tar.gz")
            archive.parent.mkdir(parents=True, exist_ok=True)
            archive.write_bytes(b"archive")
        for index, stamp, digest in [
            (1, "20261101-030000-1", digests[2]),
            (2, "20261102-030000-1", digests[0]),
            (3, "20261103-030000-1", digests[1]),
        ]:
            config = f"config/{stamp}/config-{stamp}.tar.gz"
            config_path = self.remote / config
            config_path.parent.mkdir(parents=True, exist_ok=True)
            config_path.write_bytes(b"config")
            manifest = {
                "format": 1, "stamp": stamp, "config": config,
                "sites": [{"name": "site", "archive": f"site-archives/{digest}.tar.gz", "tar_sha256": digest}],
            }
            manifest_path = self.remote / "site-manifests" / f"manifest-{stamp}-{index:08x}.json"
            manifest_path.parent.mkdir(parents=True, exist_ok=True)
            manifest_path.write_text(json.dumps(manifest))

        retention.retain(str(self.remote), str(self.rclone), 2)
        self.assertEqual(len(list((self.remote / "site-manifests").glob("*.json"))), 2)
        self.assertEqual(len(list((self.remote / "config").glob("*/*.tar.gz"))), 2)
        self.assertEqual(len(list((self.remote / "site-archives").glob("*.tar.gz"))), 2)
        self.assertTrue((self.remote / "site-archives" / (digests[0] + ".tar.gz")).exists())
        self.assertTrue((self.remote / "site-archives" / (digests[1] + ".tar.gz")).exists())
        self.assertFalse((self.remote / "site-archives" / (digests[2] + ".tar.gz")).exists())

    def test_retention_refuses_to_delete_when_manifest_reference_is_broken(self):
        path = self.remote / "site-manifests" / "manifest-broken-00000000.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({
            "format": 1, "stamp": "broken", "config": "config/missing/config-missing.tar.gz", "sites": [],
        }))
        with self.assertRaises(Exception):
            retention.retain(str(self.remote), str(self.rclone), 1)
        self.assertTrue(path.exists())


if __name__ == "__main__":
    unittest.main()
