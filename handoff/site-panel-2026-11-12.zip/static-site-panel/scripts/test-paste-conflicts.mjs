import test from "node:test"
import assert from "node:assert/strict"
import fs from "node:fs"
import vm from "node:vm"

const source = fs.readFileSync(new URL("../web/js/app.js", import.meta.url), "utf8")
const sharedAndPaste = source.slice(
  source.indexOf("/**\n * Shared name-conflict prompt"),
  source.indexOf("/** Clipboard actions:"),
)

function harness({ conflicts = [], choice = "overwrite", mode = "copy" } = {}) {
  const state = {
    fsDir: { val: "www" },
    busy: { val: false },
    clip: {
      val: {
        mode,
        site: "src",
        paths: ["www/a.txt", "www/b.txt"],
        labels: ["a.txt", "b.txt"],
      },
    },
  }
  const calls = { choices: [], pastes: [], logs: [] }
  const context = vm.createContext({
    state,
    WWW_ROOT: "www",
    api: {
      uploadConflicts: async (...args) => {
        calls.preflight = args
        return { conflicts }
      },
      pastePaths: async (...args) => {
        calls.pastes.push(args)
      },
    },
    dlgChoice: async (...args) => {
      calls.choices.push(args)
      return choice
    },
    dlgAlert: async () => {},
    pushLog: (...args) => calls.logs.push(args),
    isCurrentSite: () => true,
    setSitePendingDeploy: () => {},
    loadDir: async () => {},
    clearClipboard: () => {
      state.clip.val = null
      calls.cleared = true
    },
  })
  vm.runInContext(sharedAndPaste, context)
  return { context, calls, state, run: () => context.fsPaste("dst") }
}

test("paste without conflicts uses reject policy and keeps copy clipboard", async () => {
  const h = harness()
  await h.run()
  assert.equal(h.calls.choices.length, 0)
  assert.equal(h.calls.pastes[0][1].conflict, "reject")
  assert.equal(h.calls.pastes[0][1].mode, "copy")
  assert.ok(h.state.clip.val)
  assert.equal(h.calls.cleared, undefined)
})

test("paste file conflicts offer overwrite and rename", async () => {
  const h = harness({ conflicts: [{ name: "a.txt", directory: false }], choice: "overwrite" })
  await h.run()
  assert.match(h.calls.choices[0][0], /覆盖会替换同名文件/)
  assert.deepEqual([...h.calls.choices[0][2].map((o) => o.value)], ["rename", "overwrite"])
  assert.equal(h.calls.pastes[0][1].conflict, "overwrite")
})

test("paste directory conflicts cannot overwrite", async () => {
  const h = harness({ conflicts: [{ name: "a.txt", directory: true }], choice: "rename" })
  await h.run()
  assert.deepEqual([...h.calls.choices[0][2].map((o) => o.value)], ["rename"])
  assert.match(h.calls.choices[0][0], /不能用覆盖替换文件夹/)
})

test("cancel paste does not call API", async () => {
  const h = harness({ conflicts: [{ name: "a.txt", directory: false }], choice: null })
  await h.run()
  assert.equal(h.calls.pastes.length, 0)
  assert.ok(h.calls.logs.some(([line]) => line === "已取消粘贴"))
  assert.equal(h.state.busy.val, false)
})

test("successful cut paste clears clipboard", async () => {
  const h = harness({ mode: "cut" })
  await h.run()
  assert.equal(h.calls.cleared, true)
  assert.equal(h.state.clip.val, null)
})
