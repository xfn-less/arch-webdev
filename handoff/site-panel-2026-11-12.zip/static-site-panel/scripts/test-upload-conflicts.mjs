import test from "node:test"
import assert from "node:assert/strict"
import fs from "node:fs"
import vm from "node:vm"

const source = fs.readFileSync(new URL("../web/js/app.js", import.meta.url), "utf8")
const shared = source.slice(
  source.indexOf("/**\n * Shared name-conflict prompt"),
  source.indexOf("async function fsPaste("),
)
const upload = source.slice(source.indexOf("async function fsUpload("), source.indexOf("function fsDownload("))
const unzip = source.slice(source.indexOf("async function fsUnzip("), source.indexOf("function closeCtx("))

function harness({ conflicts = [], choice = "overwrite", zipMode = "keep", deferUpload = false } = {}) {
  const state = { fsDir: { val: "www" }, busy: { val: false } }
  const calls = { choices: [], uploads: [], logs: [], unzip: [], deletes: [] }
  const context = vm.createContext({
    state,
    WWW_ROOT: "www",
    joinPath: (dir, name) => (dir ? `${dir}/${name}` : name),
    api: {
      uploadConflicts: async (...args) => {
        calls.preflight = args
        return { conflicts }
      },
      upload: async (...args) => {
        calls.uploads.push(args)
        if (deferUpload) return new Promise((resolve) => { calls.finishUpload = () => resolve({ path: `www/${args[2].name}` }) })
        return { path: args[2].name === "same.txt" && args[3] === "rename" ? "www/same (2).txt" : `www/${args[2].name}` }
      },
      unzip: async (...args) => {
        calls.unzip.push(args)
        return { mode: args[3], dest: args[3] === "flat" ? "www" : "www/pack" }
      },
      deletePath: async (...args) => {
        calls.deletes.push(args)
      },
    },
    dlgChoice: async (...args) => {
      calls.choices.push(args)
      if (String(args[1] || "").includes("压缩包")) return zipMode
      return choice
    },
    dlgAlert: async () => {},
    pushLog: (...args) => calls.logs.push(args),
    isCurrentSite: () => false,
    setSitePendingDeploy: () => {},
    loadDir: async () => {},
    isArchiveName: (name) => /\.(zip|7z|rar|tgz|tbz2?|txz|tar(\.(gz|bz2|xz))?)$/i.test(name || ""),
    archiveBaseName: (name) => {
      const n = String(name || "")
      const m = n.match(/\.(tar\.(gz|bz2|xz)|tgz|tbz2?|txz|zip|7z|rar|tar)$/i)
      if (!m) return n || "unzipped"
      return n.slice(0, -m[0].length) || "unzipped"
    },
  })
  vm.runInContext(shared + upload + unzip, context)
  return { context, calls, state }
}

test("non-conflicting batch uploads without prompting and rejects races by default", async () => {
  const h = harness()
  await h.context.fsUpload("demo", [{ name: "a.txt" }, { name: "b.txt" }])
  assert.equal(h.calls.choices.length, 0)
  assert.deepEqual(h.calls.uploads.map((call) => call[3]), ["reject", "reject"])
})

test("upload logs preparation and per-file waiting state before the request finishes", async () => {
  const h = harness({ deferUpload: true, zipMode: "keep" })
  const pending = h.context.fsUpload("demo", [{ name: "large.bin" }])
  for (let i = 0; i < 10 && !h.calls.finishUpload; i++) await new Promise((resolve) => setImmediate(resolve))
  assert.equal(h.state.busy.val, true)
  assert.ok(h.calls.logs.some(([line]) => line.includes("准备上传 1 个文件")))
  assert.ok(h.calls.logs.some(([line]) => line.includes("检查目标目录")))
  assert.ok(h.calls.logs.some(([line]) => line.includes("上传中 (1/1) large.bin")))
  assert.equal(h.calls.logs.some(([line]) => line.startsWith("uploaded ")), false)
  h.calls.finishUpload()
  await pending
  assert.equal(h.state.busy.val, false)
  assert.ok(h.calls.logs.some(([line]) => line === "uploaded www/large.bin"))
  assert.ok(h.calls.logs.some(([line]) => line === "上传完成：1 个文件"))
})

test("file conflicts offer overwrite and automatic rename, with actual destination logged", async () => {
  const h = harness({ conflicts: [{ name: "same.txt", directory: false }], choice: "rename" })
  await h.context.fsUpload("demo", [{ name: "same.txt" }])
  assert.match(h.calls.choices[0][0], /覆盖会替换同名文件/)
  assert.deepEqual([...h.calls.choices[0][2].map((option) => option.value)], ["rename", "overwrite"])
  assert.equal(h.calls.uploads[0][3], "rename")
  assert.ok(h.calls.logs.some(([line]) => line === "uploaded www/same (2).txt"))
})

test("directory conflicts cannot choose overwrite", async () => {
  const h = harness({ conflicts: [{ name: "assets", directory: true }], choice: "rename" })
  await h.context.fsUpload("demo", [{ name: "assets" }])
  assert.deepEqual([...h.calls.choices[0][2].map((option) => option.value)], ["rename"])
  assert.match(h.calls.choices[0][0], /文件夹，文件不能覆盖文件夹/)
})

test("duplicate names in one batch are renamed instead of overwriting one another", async () => {
  const h = harness({ conflicts: [], choice: "rename" })
  await h.context.fsUpload("demo", [{ name: "same.txt" }, { name: "same.txt" }])
  assert.deepEqual([...h.calls.choices[0][2].map((option) => option.value)], ["rename"])
  assert.match(h.calls.choices[0][0], /本批有重名/)
  assert.deepEqual(h.calls.uploads.map((call) => call[3]), ["rename", "rename"])
})

test("cancel leaves a conflicting upload untouched", async () => {
  const h = harness({ conflicts: [{ name: "same.txt", directory: false }], choice: null })
  await h.context.fsUpload("demo", [{ name: "same.txt" }])
  assert.equal(h.calls.uploads.length, 0)
  assert.equal(h.state.busy.val, false)
  assert.ok(h.calls.logs.some(([line]) => line === "已取消上传"))
})

test("zip upload can keep the archive as-is", async () => {
  const h = harness({ zipMode: "keep" })
  await h.context.fsUpload("demo", [{ name: "pack.zip" }])
  assert.match(h.calls.choices[0][1], /压缩包/)
  assert.equal(h.calls.uploads.length, 1)
  assert.equal(h.calls.unzip.length, 0)
  assert.equal(h.calls.deletes.length, 0)
})

test("zip upload extract-to-folder then deletes the zip", async () => {
  const h = harness({ zipMode: "folder" })
  await h.context.fsUpload("demo", [{ name: "pack.zip" }])
  assert.deepEqual(h.calls.unzip[0], ["demo", "www/pack.zip", "", "folder"])
  assert.deepEqual(h.calls.deletes[0], ["demo", "www/pack.zip"])
  assert.ok(h.calls.logs.some(([line]) => /已删压缩包/.test(line)))
})

test("zip upload flatten then deletes the zip", async () => {
  const h = harness({ zipMode: "flat" })
  await h.context.fsUpload("demo", [{ name: "pack.zip" }])
  assert.deepEqual(h.calls.unzip[0], ["demo", "www/pack.zip", "", "flat"])
  assert.deepEqual(h.calls.deletes[0], ["demo", "www/pack.zip"])
})

test("unzip prompt explains same-name overwrite and merge behavior", async () => {
  const h = harness({ choice: "folder" })
  await h.context.fsUnzip("demo", { name: "pack.zip", path: "www/pack.zip" })
  assert.match(h.calls.choices[0][0], /已有同名文件时会直接覆盖/)
  assert.match(h.calls.choices[0][0], /其他文件保留/)
  assert.deepEqual(h.calls.unzip[0], ["demo", "www/pack.zip", "", "folder"])
})
