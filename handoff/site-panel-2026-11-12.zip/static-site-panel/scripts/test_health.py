"""Exercise 2h health checks without real SSH, HTTP or Telegram requests."""
import os
from pathlib import Path
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest

SCRIPT = Path(__file__).with_name("health-lizhi.sh")


class HealthTest(unittest.TestCase):
    def run_check(self, *, age=0, missing=False, inactive="", http_fail=False):
        with tempfile.TemporaryDirectory() as work:
            root = Path(work)
            tools = root / "bin"
            tools.mkdir()
            for name, body in {
                "systemctl": '#!/bin/sh\nfor arg; do [ "$arg" != "$HEALTH_INACTIVE" ] || exit 1; done\nexit 0\n',
                "curl": '#!/bin/sh\nfor arg; do if [ "$arg" = "http://127.0.0.1:8790/api/status" ] && [ "$HEALTH_HTTP_FAIL" = 1 ]; then exit 7; fi; done\nexit 0\n',
            }.items():
                path = tools / name
                path.write_text(body)
                path.chmod(0o755)
            manifests = root / "backup/manifests"
            manifests.mkdir(parents=True)
            if not missing:
                manifest = manifests / "manifest-fixture.json"
                manifest.write_text('{}')
                stamp = time.time() - age
                os.utime(manifest, (stamp, stamp))
            # No accounts file: the notification branch cannot contact TG.
            # No panel.db: skip remote host probes.
            env = dict(os.environ, SITE_PANEL_ROOT=str(root),
                       SITE_PANEL_BACKUP_DIR=str(root / "backup"),
                       SITE_PANEL_HEALTH_LAST=str(root / "health-last"),
                       HEALTH_INACTIVE=inactive, HEALTH_HTTP_FAIL=str(int(http_fail)),
                       PATH=str(tools) + os.pathsep + os.environ["PATH"])
            return subprocess.run(["bash", str(SCRIPT)], env=env, capture_output=True, text=True)

    def test_healthy(self):
        p = self.run_check()
        self.assertEqual(p.returncode, 0, p.stderr)
        self.assertEqual(p.stdout.strip(), 'ok')
        stamp = Path(os.environ.get("SITE_PANEL_HEALTH_LAST", ""))  # noqa: not set in parent
        # stamp path is inside temp; re-run writes it — check via stderr empty + ok
        self.assertEqual(p.stderr.strip(), '')

    def test_missing_or_stale_backup(self):
        for kwargs in ({'missing': True}, {'age': 37 * 3600}):
            with self.subTest(**kwargs):
                p = self.run_check(**kwargs)
                self.assertEqual(p.returncode, 1)
                self.assertIn('备份失败', p.stderr)

    def test_panel_or_proxy_inactive(self):
        cases = {
            'site-panel': '面板异常',
            'lizhi-socks': '抓取失败',
        }
        for name, msg in cases.items():
            with self.subTest(service=name):
                p = self.run_check(inactive=name)
                self.assertEqual(p.returncode, 1)
                self.assertIn(msg, p.stderr)

    def test_panel_http_failure(self):
        p = self.run_check(http_fail=True)
        self.assertEqual(p.returncode, 1)
        self.assertIn('面板异常', p.stderr)

    def test_low_disk(self):
        check = SCRIPT.read_text().split("<<'CHECK'\n", 1)[1].split('\nCHECK', 1)[0]
        prelude = 'import shutil, types\nshutil.disk_usage = lambda _: types.SimpleNamespace(free=1024)\n'
        p = subprocess.run([sys.executable, '-c', prelude + check, '/unused', '/unused'],
                           capture_output=True, text=True)
        self.assertEqual(p.returncode, 1)

    def test_writes_health_last(self):
        with tempfile.TemporaryDirectory() as work:
            root = Path(work)
            tools = root / "bin"
            tools.mkdir()
            for name, body in {
                "systemctl": '#!/bin/sh\nexit 0\n',
                "curl": '#!/bin/sh\nexit 0\n',
            }.items():
                path = tools / name
                path.write_text(body)
                path.chmod(0o755)
            manifests = root / "backup/manifests"
            manifests.mkdir(parents=True)
            (manifests / "manifest-fixture.json").write_text('{}')
            last = root / "health-last"
            env = dict(os.environ, SITE_PANEL_ROOT=str(root),
                       SITE_PANEL_BACKUP_DIR=str(root / "backup"),
                       SITE_PANEL_HEALTH_LAST=str(last),
                       PATH=str(tools) + os.pathsep + os.environ["PATH"])
            p = subprocess.run(["bash", str(SCRIPT)], env=env, capture_output=True, text=True)
            self.assertEqual(p.returncode, 0, p.stderr)
            parts = last.read_text().strip().split('\t')
            self.assertGreaterEqual(len(parts), 2)
            self.assertEqual(parts[1], 'ok')

    def test_via_jump_probe_is_one_shell_command(self):
        """The old probe passed a multi-line python -c through ssh and always failed."""
        with tempfile.TemporaryDirectory() as work:
            root = Path(work)
            tools = root / "bin"
            tools.mkdir()
            for name, body in {
                "systemctl": "#!/bin/sh\nexit 0\n",
                "curl": "#!/bin/sh\nexit 0\n",
            }.items():
                path = tools / name
                path.write_text(body)
                path.chmod(0o755)
            # Record the remote command and run it locally, the way ssh does.
            ssh_log = root / "ssh-args"
            fake_ssh = tools / "ssh"
            fake_ssh.write_text(
                "#!/bin/bash\n"
                "printf '%s\\0' \"$@\" >> \"$HEALTH_SSH_LOG\"\n"
                "printf '\\n' >> \"$HEALTH_SSH_LOG\"\n"
                "prev=\"\"\n"
                "for arg in \"$@\"; do prev=\"$arg\"; done\n"
                "case \"$prev\" in\n"
                "  *$'\n'*) echo \"newline in remote command\" >&2; exit 2 ;;\n"
                "esac\n"
                "bash -c \"$prev\"\n"
            )
            fake_ssh.chmod(0o755)
            listener = socket.socket()
            listener.bind(("127.0.0.1", 0))
            listener.listen(1)
            port = listener.getsockname()[1]
            db = root / "panel.db"
            con = sqlite3.connect(db)
            con.execute(
                "CREATE TABLE servers (host TEXT, port INTEGER, via_jump INTEGER)"
            )
            con.execute(
                "INSERT INTO servers(host, port, via_jump) VALUES ('127.0.0.1', ?, 1)",
                (port,),
            )
            con.commit()
            con.close()
            manifests = root / "backup/manifests"
            manifests.mkdir(parents=True)
            (manifests / "manifest-fixture.json").write_text("{}")
            last = root / "health-last"
            env = dict(
                os.environ,
                SITE_PANEL_ROOT=str(root),
                SITE_PANEL_DB=str(db),
                SITE_PANEL_BACKUP_DIR=str(root / "backup"),
                SITE_PANEL_HEALTH_LAST=str(last),
                HEALTH_SSH_LOG=str(ssh_log),
                SSP_JUMP_HOST="jump.invalid",
                SSP_JUMP_IDENTITY=str(root / "jump-key"),
                PATH=str(tools) + os.pathsep + os.environ["PATH"],
            )
            p = subprocess.run(["bash", str(SCRIPT)], env=env, capture_output=True, text=True)
            listener.close()
            self.assertEqual(p.returncode, 0, p.stderr + p.stdout)
            self.assertEqual(last.read_text().split("\t")[1], "ok")
            logged = ssh_log.read_text()
            self.assertIn("python3 -c", logged)
            self.assertNotIn("import socket,sys;", logged)


if __name__ == '__main__':
    unittest.main()
