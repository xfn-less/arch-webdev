#!/usr/bin/env python3
"""Keep the newest complete R2 recovery points and garbage-collect unreferenced data."""
import json
import re
import subprocess
import sys


ARCHIVE = re.compile(r"site-archives/[0-9a-f]{64}\.tar\.gz\Z")
STAMP = re.compile(r"\d{8}-\d{6}-\d+\Z")
CONFIG = re.compile(r"config/(\d{8}-\d{6}-\d+)/config-(\d{8}-\d{6}-\d+)\.tar\.gz\Z")
MANIFEST = re.compile(r"site-manifests/manifest-(\d{8}-\d{6}-\d+)-[0-9a-f]{8}\.json\Z")


def call(*args):
    return subprocess.run(args, check=True, stdout=subprocess.PIPE, text=True).stdout


def list_prefix(rclone, remote, prefix):
    out = call(rclone, "lsf", remote, "--recursive", "--files-only", "--s3-no-check-bucket",
               "--include", prefix + "**")
    return {line.strip().lstrip("/") for line in out.splitlines() if line.strip()}


def remove(rclone, remote, keys):
    for key in sorted(keys):
        call(rclone, "deletefile", remote + "/" + key, "--s3-no-check-bucket")
        print("retention_deleted=" + key, flush=True)


def retain(remote, rclone, keep):
    if keep < 1:
        raise ValueError("BACKUP_KEEP_REMOTE must be >= 1")
    manifests = list_prefix(rclone, remote, "site-manifests/")
    configs = list_prefix(rclone, remote, "config/")
    archives = list_prefix(rclone, remote, "site-archives/")

    records = []
    for key in manifests:
        match = MANIFEST.fullmatch(key)
        if not match:
            raise ValueError("unexpected manifest key; refusing cleanup: " + key)
        data = json.loads(call(rclone, "cat", remote + "/" + key))
        stamp = data.get("stamp")
        config = data.get("config")
        sites = data.get("sites")
        if data.get("format") != 1 or not isinstance(stamp, str) or not STAMP.fullmatch(stamp) or not isinstance(sites, list):
            raise ValueError("invalid recovery manifest; refusing cleanup: " + key)
        config_match = CONFIG.fullmatch(config) if isinstance(config, str) else None
        if not config_match or config_match.group(1) != stamp or config_match.group(2) != stamp:
            raise ValueError("invalid config reference; refusing cleanup: " + key)
        if match.group(1) != stamp:
            raise ValueError("manifest timestamp mismatch; refusing cleanup: " + key)
        if config not in configs:
            raise ValueError("manifest config missing; refusing cleanup: " + key)
        refs = set()
        for site in sites:
            archive = site.get("archive") if isinstance(site, dict) else None
            digest = site.get("tar_sha256") if isinstance(site, dict) else None
            if not isinstance(archive, str) or not ARCHIVE.fullmatch(archive):
                raise ValueError("invalid archive reference; refusing cleanup: " + key)
            if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
                raise ValueError("invalid archive digest; refusing cleanup: " + key)
            if archive != "site-archives/" + digest + ".tar.gz" or archive not in archives:
                raise ValueError("manifest archive missing or mismatched; refusing cleanup: " + key)
            refs.add(archive)
        records.append((stamp, key, config, refs))

    records.sort(key=lambda row: (row[0], row[1]), reverse=True)
    retained = records[:keep]
    if not retained:
        raise ValueError("no valid recovery manifest; refusing cleanup")

    keep_manifests = {row[1] for row in retained}
    keep_configs = {row[2] for row in retained}
    keep_archives = set().union(*(row[3] for row in retained))

    # Delete snapshots first, then their now-unreferenced data. Kept manifests
    # and every object reachable from them remain untouched.
    remove(rclone, remote, manifests - keep_manifests)
    remove(rclone, remote, configs - keep_configs)
    remove(rclone, remote, archives - keep_archives)
    print("retention_kept_manifests=" + str(len(retained)), flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 4:
        sys.exit("usage: backup-retention.py REMOTE RCLONE KEEP")
    try:
        retain(sys.argv[1], sys.argv[2], int(sys.argv[3]))
    except Exception as exc:
        sys.exit("backup retention failed: " + str(exc))
