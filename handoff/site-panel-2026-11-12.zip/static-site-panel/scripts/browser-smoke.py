import argparse,base64,hashlib,http.client,http.server,json,os,pathlib,socket,sqlite3,subprocess,threading,time,urllib.request
parser=argparse.ArgumentParser(description="Local-only UI smoke tests with synthetic accounts; requires Firefox.")
parser.add_argument('--binary',required=True)
parser.add_argument('--out',default='/tmp/ssp-browser-smoke')
parser.add_argument('--server-form-only',action='store_true',help='Check creation, cancellation and saving of the full server form locally.')
parser.add_argument('--overview-only',action='store_true',help='Only check compact phone overview layout with realistic local fixture names/domains.')
parser.add_argument('--ui-audit',action='store_true',help='Include exact-width phone and long-list diagnostics; may expose known UI defects.')
args=parser.parse_args()
ROOT=pathlib.Path(args.out);ROOT.mkdir(parents=True,exist_ok=True)
DATA=ROOT/'browser-data';DATA.mkdir(exist_ok=True);SITES=ROOT/'browser-sites';SITES.mkdir(exist_ok=True)
TEMPLATE=pathlib.Path(__file__).resolve().parents[1]/'templates/spa.nginx.conf'
if (DATA/'panel.db').exists():raise SystemExit('Choose a fresh --out directory; refusing to overwrite existing test state')
def port():
 s=socket.socket();s.bind(('127.0.0.1',0));p=s.getsockname()[1];s.close();return p
backend,frontend,marionette=port(),port(),port()
log=(ROOT/'browser-panel.log').open('w');panel=subprocess.Popen([args.binary,'-listen',f'127.0.0.1:{backend}','-data',str(DATA),'-sites',str(SITES),'-template',str(TEMPLATE)],stdout=log,stderr=log)
ff=None;results=[]
AUTH_HEADERS={}
def api(method,path,data=None):
 req=urllib.request.Request(f'http://127.0.0.1:{backend}'+path,data=None if data is None else json.dumps(data).encode(),method=method,headers={'Content-Type':'application/json',**AUTH_HEADERS})
 with urllib.request.urlopen(req,timeout=5) as response:return json.load(response),response.headers
class Proxy(http.server.BaseHTTPRequestHandler):
 def handle_request(self):
  length=int(self.headers.get('Content-Length',0));body=self.rfile.read(length) if length else None
  conn=http.client.HTTPConnection('127.0.0.1',backend,timeout=20)
  conn.request(self.command,self.path,body,{k:v for k,v in self.headers.items() if k.lower() not in ['host','connection','content-length']})
  response=conn.getresponse();data=response.read()
  self.send_response(response.status)
  for key,value in response.getheaders():
   if key.lower() not in ['content-length','connection','transfer-encoding']:self.send_header(key,value)
  self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data);conn.close()
 do_GET=handle_request;do_POST=handle_request;do_PUT=handle_request;do_DELETE=handle_request
 def log_message(self,*args):pass
class Driver:
 def __init__(self,sock):self.sock=sock;self.buffer=b'';self.counter=0;self.receive()
 def receive(self):
  while b':' not in self.buffer:self.buffer+=self.sock.recv(65536)
  size,rest=self.buffer.split(b':',1);size=int(size)
  while len(rest)<size:rest+=self.sock.recv(65536)
  self.buffer=rest[size:];return json.loads(rest[:size])
 def command(self,name,params=None):
  self.counter+=1;payload=json.dumps([0,self.counter,name,params or {}]).encode();self.sock.sendall(str(len(payload)).encode()+b':'+payload)
  message=self.receive()
  if message[2]:raise RuntimeError(message[2])
  result=message[3];return result.get('value',result) if isinstance(result,dict) else result
 def js(self,script):return self.command('WebDriver:ExecuteScript',{'script':script,'args':[],'newSandbox':False})
 def wait(self,script,timeout=15):
  start=time.monotonic()
  while time.monotonic()-start<timeout:
   result=self.js(script)
   if result:return result
   time.sleep(.1)
  raise RuntimeError('timeout: '+script)
 def shot(self,name):
  value=self.command('WebDriver:TakeScreenshot',{'full':False,'scroll':False});(ROOT/name).write_bytes(base64.b64decode(value))
def record(name,condition,detail=None):
 result={'test':name,'pass':bool(condition),'detail':detail};results.append(result);print(json.dumps(result,ensure_ascii=False),flush=True)
try:
 for _ in range(100):
  try:api('GET','/api/status');break
  except Exception:time.sleep(.05)
 challenge,_=api('GET','/api/captcha');nonce=0
 while not hashlib.sha256((challenge['challenge']+str(nonce)).encode()).hexdigest().startswith('0'*challenge['difficulty']):nonce+=1
 setup,headers=api('POST','/api/setup',{'password':'audit-only-password','captchaId':challenge['id'],'captchaNonce':nonce});token=headers['Set-Cookie'].split('=',1)[1].split(';',1)[0]
 AUTH_HEADERS.update({'Cookie':'ssp_session='+token,'X-CSRF':setup['csrf']})
 fixture_sites=[]
 for server_index,count in enumerate([1,2,1,2,1,3,3,4,4,0]):
  srv,_=api('POST','/api/servers',{'name':'' if server_index==0 else 'fixture-'+str(server_index),'note':'','host':'192.0.2.'+str(server_index+10),'publicIP':'192.0.2.'+str(server_index+10)})
  for i in range(count):
   site,_=api('POST','/api/sites',{'title':'fixture-'+str(server_index)+'-'+str(i),'serverId':srv['id']});fixture_sites.append(site['name'])
 selectable=SITES/fixture_sites[0]/'www'/'selection-fixture.txt';selectable.parent.mkdir(parents=True,exist_ok=True);selectable.write_text('FILE_SELECTION_FIXTURE')
 config={'telegram':{'bot_token':'','chat_id':''},'accounts':[{'name':'账号'+str(i),'email':'audit'+str(i)+'@example.test','password':'sample-password','group_ids':[305]} for i in range(1,13)]};(DATA/'lizhi-accounts.json').write_text(json.dumps(config))
 with sqlite3.connect(DATA/'panel.db') as db:
  # IPs match fixture servers (192.0.2.10+) so 站点/访问 columns can reuse panel sites.
  for i,days in enumerate([10,-3,2,0]):
   db.execute('INSERT INTO billing_assets(account_name,login_id,ip,ip_norm,days_left,expire_unix,note,status) VALUES(?,?,?,?,?,?,?,?)',('账号1','audit1@example.test','192.0.2.'+str(i+10),'192.0.2.'+str(i+10),days,int(time.time())+days*86400 if i!=3 else 0,'<img src=x onerror="window.auditXSS=1">','ok'))
 server=http.server.ThreadingHTTPServer(('127.0.0.1',frontend),Proxy);threading.Thread(target=server.serve_forever,daemon=True).start()
 profile=ROOT/'firefox-profile';profile.mkdir(exist_ok=True);(profile/'user.js').write_text(f'user_pref("marionette.port", {marionette});\nuser_pref("browser.shell.checkDefaultBrowser", false);\n')
 ff_log=(ROOT/'firefox.log').open('w');ff=subprocess.Popen(['firefox','--headless','--no-remote','--profile',str(profile),'--marionette'],stdout=ff_log,stderr=ff_log)
 for _ in range(150):
  try:sock=socket.create_connection(('127.0.0.1',marionette),timeout=1);sock.settimeout(30);break
  except OSError:time.sleep(.1)
 driver=Driver(sock);driver.command('WebDriver:NewSession',{'capabilities':{'alwaysMatch':{'pageLoadStrategy':'eager'}}})
 driver.command('WebDriver:SetWindowRect',{'width':1280,'height':900})
 driver.command('WebDriver:Navigate',{'url':f'http://127.0.0.1:{frontend}/'})
 driver.command('WebDriver:AddCookie',{'cookie':{'name':'ssp_session','value':token,'path':'/'}})
 driver.command('WebDriver:Navigate',{'url':f'http://127.0.0.1:{frontend}/?audit=1#/billing'})
 driver.wait('return document.querySelectorAll(".billing-table tbody tr").length===4')
 if args.server_form_only:
  driver.js('document.querySelector(".page-header-chrome button").click()');driver.wait('return document.querySelector(".server-form")')
  fields=driver.js('return [...document.querySelectorAll(".server-form input")].map(e=>e.value)')
  record('add IP opens complete empty form with SSH defaults',fields==['','22','root','',''],fields)
  tree,_=api('GET','/api/tree');record('opening form creates no record',len(tree['servers'])==10)
  driver.js('document.querySelector(".server-dlg-close").click()');time.sleep(.1)
  tree,_=api('GET','/api/tree');record('cancel creates no record',len(tree['servers'])==10)
  driver.js('document.querySelector(".page-header-chrome button").click()');driver.wait('return document.querySelector(".server-form")')
  driver.js('[...document.querySelectorAll(".server-dlg-foot button")].find(b=>b.textContent.includes("保存")).click()');driver.wait('return document.querySelector(".dlg-layer:not(.off)")')
  record('empty IP shows validation and keeps the form',driver.js('return document.querySelector(".dlg-layer:not(.off)").textContent.includes("请填写 IP")&&!!document.querySelector(".server-form")'))
  driver.js('document.querySelector(".dlg-layer:not(.off) .dlg-actions button").click()')
  driver.js('const values=["192.0.2.250","2222","deploy","fixture-password","new-full-form"];document.querySelectorAll(".server-form input").forEach((e,i)=>{e.value=values[i];e.dispatchEvent(new Event("input",{bubbles:true}))});[...document.querySelectorAll(".server-dlg-foot button")].find(b=>b.textContent.includes("保存")).click()')
  for _ in range(100):
   tree,_=api('GET','/api/tree')
   if len(tree['servers'])==11:break
   time.sleep(.05)
  time.sleep(.2);tree,_=api('GET','/api/tree');new=[v for v in tree['servers'] if v['host']=='192.0.2.250']
  record('one save including double click creates exactly one complete record',len(tree['servers'])==11 and len(new)==1 and new[0]['name']=='' and new[0]['note']=='new-full-form' and new[0]['port']==2222 and new[0]['user']=='deploy' and new[0]['hasPassword'])
  driver.js('const i=[...document.querySelectorAll(".server-form input")].at(-1);i.value="edited-form";i.dispatchEvent(new Event("input",{bubbles:true}));[...document.querySelectorAll(".server-dlg-foot button")].find(b=>b.textContent.includes("保存")).click()')
  for _ in range(100):
   tree,_=api('GET','/api/tree')
   if any(v['note']=='edited-form' for v in tree['servers']):break
   time.sleep(.05)
  record('saving the created form edits its existing record',len(tree['servers'])==11 and any(v['note']=='edited-form' for v in tree['servers']))
  driver.js('const i=[...document.querySelectorAll(".server-form input")].at(-1);i.value="";i.dispatchEvent(new Event("input",{bubbles:true}));[...document.querySelectorAll(".server-dlg-foot button")].find(b=>b.textContent.includes("保存")).click()')
  for _ in range(100):
   tree,_=api('GET','/api/tree')
   if any(v['host']=='192.0.2.250' and v['note']=='' for v in tree['servers']):break
   time.sleep(.05)
  record('optional remark can be cleared and remains blank',any(v['host']=='192.0.2.250' and v['name']=='' and v['note']=='' for v in tree['servers']))
  driver.command('WebDriver:SetWindowRect',{'width':390,'height':844});time.sleep(.1)
  driver.shot('mobile-full-server-form.png')
  (ROOT/'browser-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
  driver.command('WebDriver:DeleteSession')
  raise SystemExit(0 if all(r['pass'] for r in results) else 1)
 if args.overview_only:
  # Exercise real app rendering with local fixture metadata; no remote services.
  for index,name in enumerate(fixture_sites):
   title=['下载站','芝麻开门','前端入口','管理后台','静态站点'][index%5]
   api('POST','/api/sites/'+name+'/rename',{'title':title})
   api('PUT','/api/sites/'+name+'/domains',{'domains':['download-'+str(index)+'.example.test','www-'+str(index)+'.example.test']})
  driver.js('window.phoneFrame=document.createElement("iframe");phoneFrame.style="position:fixed;inset:0;width:390px;height:750px;border:0;z-index:99999";phoneFrame.src=location.origin+"/#/sites";document.body.appendChild(phoneFrame)')
  driver.wait('return phoneFrame.contentDocument.querySelectorAll(".sites-table tbody tr").length===22')
  driver.command('WebDriver:SetWindowRect',{'width':2048,'height':900})
  for width in [844,1280,1920]:
   driver.js('phoneFrame.style.width="'+str(width)+'px"');time.sleep(.15)
   desktop=driver.js('''const w=phoneFrame.contentWindow,d=w.document,t=d.querySelector('.sites-table'),r=d.querySelector('.sites-site-cell'),a=r.querySelector('.sites-site-acts'),b=r.querySelector('.sites-site-more'),host=d.querySelector('.sites-host-cell'),ip=d.querySelector('.sites-ip-btn');return {moreHidden:w.getComputedStyle(b).display==='none',actions:a.children.length,absolute:w.getComputedStyle(a).position==='absolute',padding:parseFloat(w.getComputedStyle(d.querySelector('.sites-table-wrap')).paddingLeft),tableWidth:t.getBoundingClientRect().width,left:t.getBoundingClientRect().left,siteFirst:host.firstElementChild.classList.contains('sites-host-site'),buttonsSwapped:host.firstElementChild.querySelector('.sites-host-act').title==='远程终端'&&host.lastElementChild.querySelector('.sites-host-act').title==='加站点',buttonsRight:[...host.querySelectorAll('.sites-host-line')].every(line=>Math.abs(line.querySelector('.sites-host-act').getBoundingClientRect().right-line.getBoundingClientRect().right)<2),transparent:w.getComputedStyle(a).backgroundColor==='rgba(0, 0, 0, 0)',ipSize:parseFloat(w.getComputedStyle(ip).fontSize),ipColor:w.getComputedStyle(ip).color,target:{x:r.getBoundingClientRect().left+12,y:r.getBoundingClientRect().top+12}};''')
   record('desktop '+str(width)+'px restores hover controls and full-width table',desktop['moreHidden'] and desktop['actions']==4 and desktop['absolute'] and desktop['padding']==0 and desktop['left']<2 and desktop['siteFirst'] and desktop['buttonsSwapped'] and desktop['buttonsRight'] and desktop['transparent'] and desktop['ipSize']>=14,desktop)
   record('desktop header omits server/site counts',driver.js('return !phoneFrame.contentDocument.querySelector(".sites-chrome-meta")'))
   no_note_ip=driver.js('''const d=phoneFrame.contentDocument,h=d.querySelector('.sites-host-cell-no-note'),ip=h&&h.querySelector('.sites-ip-btn'),hr=h&&h.getBoundingClientRect(),ir=ip&&ip.getBoundingClientRect();return {exists:!!ip,centered:!!(hr&&ir&&Math.abs((hr.top+hr.bottom-ir.top-ir.bottom)/2)<2),transform:ip&&getComputedStyle(ip).transform};''')
   record('server IP centers vertically when remark is empty',no_note_ip['exists'] and no_note_ip['centered'],no_note_ip)
   driver.command('WebDriver:PerformActions',{'actions':[{'type':'pointer','id':'audit-mouse','parameters':{'pointerType':'mouse'},'actions':[{'type':'pointerMove','duration':0,'x':int(desktop['target']['x']),'y':int(desktop['target']['y'])}]}]})
   driver.wait('const w=phoneFrame.contentWindow,a=w.document.querySelector(".sites-site-acts");return w.getComputedStyle(a).opacity==="1"')
   record('desktop '+str(width)+'px actions appear at right on hover',driver.js('const d=phoneFrame.contentDocument,r=d.querySelector(".sites-site-cell").getBoundingClientRect(),a=d.querySelector(".sites-site-acts").getBoundingClientRect();return Math.abs(a.right-r.right)<2'))
   driver.shot('desktop-overview-'+str(width)+'.png')
  for width in [320,375,390,430,800]:
   driver.js('phoneFrame.style.width="'+str(width)+'px"');time.sleep(.15)
   metrics=driver.js('''const w=phoneFrame.contentWindow,d=w.document;
    const box=e=>e.getBoundingClientRect();
    const hosts=[...d.querySelectorAll('.sites-td-host')];
    const singles=hosts.filter(e=>e.rowSpan===1).map(e=>box(e).height);
    const offsets=[...d.querySelectorAll('.sites-site-cell')].map(e=>{const a=box(e.querySelector('.site-nav-ico')||e.firstElementChild),b=box(e.querySelector('.sites-site-name'));return Math.abs((a.top+a.bottom-b.top-b.bottom)/2)});
    const wrap=d.querySelector('.sites-table-wrap');const mb=d.querySelector('.sites-site-more'),mbr=box(mb),moreReachable=mb.contains(d.elementFromPoint(mbr.x+mbr.width/2,mbr.y+mbr.height/2));wrap.scrollLeft=wrap.scrollWidth;
    const link=d.querySelector('.sites-td-links a'),lr=box(link),wr=box(wrap);
    return {width:w.innerWidth,pageWidth:d.documentElement.scrollWidth,headerHeight:box(d.querySelector('.page-header')).height,
     hostButtons:[...d.querySelectorAll('.sites-host-act')].map(e=>box(e).height),singleHostHeights:singles,alignment:Math.max(...offsets),
     groupBorders:hosts.map(e=>w.getComputedStyle(e).borderBottomWidth),moreReachable,linksReachable:(wrap.scrollWidth<=wrap.clientWidth+1||wrap.scrollLeft>0)&&lr.right>wr.left&&lr.left<wr.right};''')
   record('overview '+str(width)+'px stays compact and aligned',metrics['pageWidth']<=width+1 and metrics['headerHeight']<=72 and max(metrics['hostButtons'])<=26 and max(metrics['singleHostHeights'])<=76 and metrics['alignment']<3 and all(x=='2px' for x in metrics['groupBorders']) and (width>800 or metrics['linksReachable']) and metrics['moreReachable'],metrics)
   driver.js('phoneFrame.contentDocument.querySelector(".sites-table-wrap").scrollLeft=0');time.sleep(.1)
   driver.js('const d=phoneFrame.contentDocument;const r=d.querySelector(".sites-td-site").getBoundingClientRect();phoneFrame.contentWindow.menuBefore={height:r.height,table:d.querySelector(".sites-table").getBoundingClientRect().height};d.querySelector(".sites-site-more").click()')
   driver.wait('return phoneFrame.contentDocument.querySelectorAll(".sites-site-acts.is-floating button svg").length===4')
   metrics=driver.js('''const w=phoneFrame.contentWindow,d=w.document,c=d.querySelector('.sites-site-cell'),n=c.querySelector('.sites-site-name'),a=d.querySelector('.sites-site-acts.is-floating'),b=c.querySelector('.sites-site-more'),nr=n.getBoundingClientRect(),ar=a.getBoundingClientRect(),hit=d.elementFromPoint(nr.x+nr.width/2,nr.y+nr.height/2),bg=w.getComputedStyle(a).backgroundColor;return {expanded:b.getAttribute('aria-expanded'),count:a.children.length,floating:a.parentElement===d.body&&w.getComputedStyle(a).position==='fixed',solidChip:bg!=='rgba(0, 0, 0, 0)'&&bg!=='transparent'&&w.getComputedStyle(a).boxShadow!=='none',nameReachable:n.contains(hit),stable:Math.abs(c.closest('td').getBoundingClientRect().height-w.menuBefore.height)<1&&Math.abs(d.querySelector('.sites-table').getBoundingClientRect().height-w.menuBefore.table)<1,withinViewport:ar.left>=0&&ar.right<=w.innerWidth&&ar.top>=0&&ar.bottom<=w.innerHeight,buttonsReachable:[...a.children].every(e=>{const r=e.getBoundingClientRect();return e.contains(d.elementFromPoint(r.x+r.width/2,r.y+r.height/2))})};''')
   record('overview '+str(width)+'px menu floats without shifting rows or covering entrance',metrics['expanded']=='true' and metrics['count']==4 and metrics['floating'] and metrics['solidChip'] and metrics['stable'] and metrics['withinViewport'] and metrics['nameReachable'] and metrics['buttonsReachable'],metrics)
   driver.shot('overview-'+str(width)+'-menu.png')
   driver.js('phoneFrame.contentDocument.querySelector(".sites-site-more").click()')
   record('overview '+str(width)+'px more menu closes',driver.js('return !phoneFrame.contentDocument.querySelector(".sites-site-acts.is-floating")&&phoneFrame.contentDocument.querySelector(".sites-site-more").getAttribute("aria-expanded")==="false"'))
   driver.shot('overview-'+str(width)+'.png')
  driver.js('phoneFrame.style.width="390px"');time.sleep(.15)
  driver.js('const d=phoneFrame.contentDocument;d.querySelector(".sites-site-more").click();d.querySelector(".sites-table thead").click()')
  record('floating site menu closes on outside click',driver.js('return !phoneFrame.contentDocument.querySelector(".sites-site-acts.is-floating")'))
  driver.js('const w=phoneFrame.contentWindow;w.document.querySelector(".sites-site-more").click();w.dispatchEvent(new w.KeyboardEvent("keydown",{key:"Escape"}))')
  record('floating site menu closes on Escape',driver.js('return !phoneFrame.contentDocument.querySelector(".sites-site-acts.is-floating")'))
  driver.js('const d=phoneFrame.contentDocument;d.querySelector(".sites-site-more").click();d.querySelector(".sites-table-wrap").scrollTop=40');time.sleep(.1)
  record('floating site menu closes on table scroll',driver.js('return !phoneFrame.contentDocument.querySelector(".sites-site-acts.is-floating")'))
  driver.js('const d=phoneFrame.contentDocument;d.querySelector(".sites-table-wrap").scrollTop=0');time.sleep(.1)
  driver.js('const d=phoneFrame.contentDocument;d.querySelector(".sites-site-more").click();d.querySelectorAll(".sites-site-more")[1].click()')
  record('only one site menu opens at a time',driver.js('const d=phoneFrame.contentDocument;return d.querySelectorAll(".sites-site-acts.is-floating").length===1&&d.querySelectorAll(".sites-site-more")[0].getAttribute("aria-expanded")==="false"'))
  driver.js('phoneFrame.contentDocument.querySelector(".sites-site-acts.is-floating button[title=复制到]").click()')
  driver.wait('return !!phoneFrame.contentDocument.querySelector(".pick-layer:not(.off)")')
  record('floating copy action opens existing picker and closes menu',driver.js('return !phoneFrame.contentDocument.querySelector(".sites-site-acts.is-floating")'))
  driver.js('phoneFrame.contentDocument.querySelector(".pick-head button").click()')
  driver.js('const d=phoneFrame.contentDocument;const b=[...d.querySelectorAll(".sites-site-more")].at(-1);b.scrollIntoView({block:"center"})');time.sleep(.1)
  driver.js('const d=phoneFrame.contentDocument;[...d.querySelectorAll(".sites-site-more")].at(-1).click()')
  record('last row floating menu stays inside viewport and reachable',driver.js('const d=phoneFrame.contentDocument,a=d.querySelector(".sites-site-acts.is-floating"),r=a.getBoundingClientRect();return r.top>=0&&r.right<=390&&[...a.children].every(b=>{const p=b.getBoundingClientRect();return b.contains(d.elementFromPoint(p.x+p.width/2,p.y+p.height/2))})'))
  driver.js('phoneFrame.contentDocument.querySelector(".sites-table-wrap").scrollTop=0');time.sleep(.1)
  driver.js('phoneFrame.contentDocument.querySelector(".sites-ip-btn").click()');driver.wait('return phoneFrame.contentDocument.querySelector(".server-form")')
  record('compact overview server button still opens settings',True)
  selection=driver.js('''const w=phoneFrame.contentWindow,d=w.document,n=d.querySelector('.sites-site-name'),r=n.getBoundingClientRect(),opts={bubbles:true,cancelable:true,pointerId:1,pointerType:'mouse',isPrimary:true,button:0};n.dispatchEvent(new PointerEvent('pointerdown',{...opts,clientX:r.left+2,clientY:r.top+r.height/2}));n.dispatchEvent(new PointerEvent('pointermove',{...opts,clientX:r.right-2,clientY:r.top+r.height/2}));const sel=w.getSelection(),range=d.createRange();range.selectNodeContents(n);sel.removeAllRanges();sel.addRange(range);const text=sel.toString();n.dispatchEvent(new PointerEvent('pointerup',{...opts,clientX:r.right-2,clientY:r.top+r.height/2}));n.click();return {text,hash:w.location.hash,stillOverview:!!d.querySelector('.sites-table')&&!d.querySelector('.codejar-editor'),selectable:getComputedStyle(n).userSelect};''')
  record('dragging to select site name does not open site',selection['text'] and not selection['hash'].startswith('#/site/') and selection['stillOverview'] and selection['selectable']=='text',selection)
  driver.js('phoneFrame.contentWindow.getSelection().removeAllRanges();phoneFrame.contentDocument.querySelector(".server-dlg-close")?.click()')
  ip_selection=driver.js('''const w=phoneFrame.contentWindow,d=w.document,ip=d.querySelector('.sites-ip-btn'),r=ip.getBoundingClientRect(),opts={bubbles:true,cancelable:true,pointerId:1,pointerType:'mouse',isPrimary:true,button:0};ip.dispatchEvent(new PointerEvent('pointerdown',{...opts,clientX:r.left+2,clientY:r.top+r.height/2}));ip.dispatchEvent(new PointerEvent('pointermove',{...opts,clientX:r.right-2,clientY:r.top+r.height/2}));const sel=w.getSelection(),range=d.createRange();range.selectNodeContents(ip);sel.removeAllRanges();sel.addRange(range);const text=sel.toString();ip.dispatchEvent(new PointerEvent('pointerup',{...opts,clientX:r.right-2,clientY:r.top+r.height/2}));ip.click();return {text,noDialog:!d.querySelector('.server-dlg-layer:not(.off)'),selected:getComputedStyle(ip).userSelect};''')
  record('dragging to select IP does not open server settings',ip_selection['text'] and ip_selection['noDialog'] and ip_selection['selected']=='text',ip_selection)
  driver.js('phoneFrame.contentWindow.getSelection().removeAllRanges();phoneFrame.contentDocument.querySelector(".sites-ip-btn").click()');driver.wait('return !!phoneFrame.contentDocument.querySelector(".server-dlg-layer:not(.off)")')
  driver.js('phoneFrame.contentDocument.querySelector(".server-dlg-close").click();phoneFrame.contentDocument.querySelector(".sites-site-name").click()');driver.wait('return phoneFrame.contentDocument.querySelector(".codejar-editor")')
  record('compact overview site name still opens editor',True)
  driver.js('phoneFrame.contentWindow.location.hash="#/sites"');driver.wait('return phoneFrame.contentDocument.querySelector(".sites-table")')
  driver.js('const d=phoneFrame.contentDocument;d.querySelector(".sites-site-more").click();d.querySelector(".sites-site-acts button[title=删除]").click()')
  driver.wait('return !!phoneFrame.contentDocument.querySelector(".dlg-layer:not(.off)")')
  site_delete=driver.js('''const d=phoneFrame.contentDocument,l=d.querySelector('.dlg-layer:not(.off)'),box=l.querySelector('.dlg'),buttons=[...l.querySelectorAll('.dlg-actions button')];box.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true,cancelable:true}));return {message:l.textContent,stays:!!d.querySelector('.dlg-layer:not(.off)'),buttons:buttons.map(b=>b.textContent.trim())}''')
  record('site delete names target, recommends disabling, and ignores Enter',site_delete['stays'] and '建议不要删除' in site_delete['message'] and 'fixture-' in site_delete['message'],site_delete)
  driver.js('phoneFrame.contentDocument.querySelector(".dlg-layer:not(.off) .dlg-actions button:last-child").click()');driver.wait('return phoneFrame.contentDocument.querySelector(".dlg-layer:not(.off)").textContent.includes("再次确认删除站点")')
  site_second=driver.js('''const l=phoneFrame.contentDocument.querySelector('.dlg-layer:not(.off)'),b=[...l.querySelectorAll('.dlg-actions button')];l.querySelector('.dlg').dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true,cancelable:true}));return {labels:b.map(x=>x.textContent.trim()),dangerFirst:b[0].classList.contains('danger'),open:!!phoneFrame.contentDocument.querySelector('.dlg-layer:not(.off)')}''')
  record('site second delete confirmation puts danger action first and ignores Enter',site_second['dangerFirst'] and site_second['open'],site_second)
  driver.js('phoneFrame.contentDocument.querySelector(".dlg-layer:not(.off) .dlg-actions button:last-child").click()')
  driver.js('phoneFrame.contentDocument.querySelector(".sites-ip-btn").click()');driver.wait('return !!phoneFrame.contentDocument.querySelector(".server-dlg-layer:not(.off)")')
  driver.js('phoneFrame.contentDocument.querySelector(".server-dlg-foot button.danger").click()');driver.wait('return !!phoneFrame.contentDocument.querySelector(".dlg-layer:not(.off)")')
  driver.js('phoneFrame.contentDocument.querySelector(".dlg-layer:not(.off) .dlg-actions button:last-child").click()');driver.wait('return phoneFrame.contentDocument.querySelector(".dlg-layer:not(.off)").textContent.includes("再次确认删除服务器")')
  server_second=driver.js('''const l=phoneFrame.contentDocument.querySelector('.dlg-layer:not(.off)'),b=[...l.querySelectorAll('.dlg-actions button')];return {message:l.textContent,labels:b.map(x=>x.textContent.trim()),dangerFirst:b[0].classList.contains('danger')}''')
  record('server second delete confirmation identifies target and shows danger first',server_second['dangerFirst'] and '192.0.2.10' in server_second['message'],server_second)
  driver.js('phoneFrame.contentDocument.querySelector(".dlg-layer:not(.off) .dlg-actions button:last-child").click();phoneFrame.contentDocument.querySelector(".server-dlg-close").click()')
  (ROOT/'browser-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
  driver.command('WebDriver:DeleteSession')
  raise SystemExit(0 if all(r['pass'] for r in results) else 1)
 cols=driver.js('return Array.from(document.querySelectorAll(".billing-table th"), e=>e.textContent)');record('CSV header/order and inline open cell',cols==['面板备注','序号','账号','余额','ip','费用','到期','天 ↕','cycle','备注','status','带宽','地区','product','os'],cols)
 record('HTML fields rendered as text',driver.js('return !window.auditXSS && document.querySelector(".billing-table .note-text").textContent.startsWith("<img")'))
 record('billing open label falls back to the first site when remark is empty',driver.js('const r=[...document.querySelectorAll(".billing-table tbody tr")].find(r=>r.children[4].textContent==="192.0.2.10");return !!r&&r.querySelector(".panel-name").textContent==="fixture-0-0"&&r.querySelector(".panel-cell button").title.startsWith("fixture-0-0")'))
 driver.js('document.querySelector(".billing-sort").click()');time.sleep(.15);days=driver.js('return Array.from(document.querySelectorAll(".billing-table tbody tr"),e=>e.children[7].textContent)');record('click day ascending',days==['-3','2','10','—'],days)
 driver.js('document.querySelector(".billing-sort").click()');time.sleep(.15);days=driver.js('return Array.from(document.querySelectorAll(".billing-table tbody tr"),e=>e.children[7].textContent)');record('click day descending',days==['10','2','-3','—'],days)
 driver.js('Array.from(document.querySelectorAll(".page-header-mid button")).find(e=>e.textContent.includes("账号")).click()');driver.wait('return document.querySelectorAll(".billing-acct-row").length===12')
 driver.js('window.auditInput=document.querySelector(".billing-acct-row input");window.auditInput.focus();window.auditInput.value="edited-account";window.auditInput.dispatchEvent(new Event("input",{bubbles:true}))');time.sleep(.15)
 record('account typing retains focus and input node',driver.js('return document.activeElement===window.auditInput && window.auditInput.isConnected && window.auditInput.value==="edited-account"'))
 driver.js('Array.from(document.querySelectorAll(".billing-acct-acts button")).find(e=>e.textContent.includes("保存")).click()');driver.wait('return !document.querySelector(".billing-acct-layer:not(.off)")')
 saved=json.loads((DATA/'lizhi-accounts.json').read_text());record('account save persisted edited draft',saved['accounts'][0]['name']=='edited-account')
 driver.command('WebDriver:SetWindowRect',{'width':390,'height':844})
 driver.js('Array.from(document.querySelectorAll(".page-header-mid button")).find(e=>e.textContent.includes("账号")).click()');driver.wait('return document.querySelectorAll(".billing-acct-row").length===12')
 layout=driver.js('const b=document.querySelector(".billing-acct").getBoundingClientRect(), l=document.querySelector(".billing-acct-list");return {viewport:innerWidth,width:b.width,x:b.x,scroll:l.scrollWidth,client:l.clientWidth}')
 record('phone full screen modal and inner horizontal scroll',abs(layout['width']-layout['viewport'])<2 and layout['scroll']>layout['client'],layout);driver.shot('mobile-accounts.png')
 driver.js('document.querySelector(".billing-acct-list").scrollLeft=10000');record('phone row scroll reaches password/group controls',driver.js('return document.querySelector(".billing-acct-list").scrollLeft>0'))
 driver.js('document.querySelector(".billing-acct-head button").click()');time.sleep(.1);driver.shot('mobile-billing.png')
 # Mobile overview: mid on second row; no page sideways scroll.
 driver.js('location.hash="#/sites"');driver.wait('return !!document.querySelector(".sites-table")');time.sleep(.2)
 driver.js('if(window.__sspSyncPageMinWidth)window.__sspSyncPageMinWidth()')
 record('narrow viewport header matches current compact page layout',driver.js('''
const h=document.querySelector(".page-header");
const sw=document.querySelector(".page-header-switch");
const ch=document.querySelector(".page-header-chrome");
const mid=document.querySelector(".page-header-mid");
if(!h||!sw||!ch||!mid)return false;
const hr=h.getBoundingClientRect(),sr=sw.getBoundingClientRect(),cr=ch.getBoundingClientRect(),mr=mid.getBoundingClientRect();
const pageMin=parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--page-min-width"))||0;
const overview=document.querySelector(".sites-overview");
if(overview){const ips=overview.querySelector(".sites-th-host .sites-th-count"),sites=overview.querySelector(".sites-th-site .sites-th-count");return !!ips&&!!sites&&!overview.querySelector(".sites-mobile-count")&&getComputedStyle(mid).display==="none"&&hr.height<=44&&pageMin<2&&document.body.scrollWidth<=innerWidth+2}
return Math.abs(sr.top-cr.top)<4 && mr.top>=sr.bottom-2 && hr.height>40 && pageMin<2 && document.body.scrollWidth<=innerWidth+2
'''))
 record('phone has no side tree',driver.js('return !document.querySelector(".left")'))
 driver.js('location.hash="#/billing"');driver.wait('return !!document.querySelector(".billing-table")')
 # A local-only provider outage verifies the requested version boundary end to end.
 class FailedProvider(http.server.BaseHTTPRequestHandler):
  def do_GET(self):self.send_error(503,'synthetic failure')
  def log_message(self,*args):pass
 provider=http.server.ThreadingHTTPServer(('127.0.0.1',0),FailedProvider);threading.Thread(target=provider.serve_forever,daemon=True).start()
 (DATA/'lizhi-accounts.json').write_text(json.dumps({'accounts':[{'name':'failure-fixture','email':'failure@example.test','base_url':f'http://127.0.0.1:{provider.server_port}'}]}))
 driver.js('Array.from(document.querySelectorAll(".page-header-mid button")).find(e=>e.textContent.includes("抓取")).click()')
 driver.wait('return document.querySelectorAll(".billing-table tbody tr").length===1 && document.querySelector(".billing-table tbody").textContent.includes("失败，请看旧版")')
 record('failed fetch shows a new failure row instead of old machines',driver.js('const r=document.querySelector(".billing-table tbody tr");return r.textContent.includes("failure-fixture")&&r.textContent.includes("失败，请看旧版")&&!r.textContent.includes("192.0.2.")'))
 driver.wait('return !!document.querySelector(".dlg-layer:not(.off) .dlg-actions button")');driver.js('document.querySelector(".dlg-layer:not(.off) .dlg-actions button").click()')
 driver.js('const s=document.querySelector(".billing-snap-sel");s.value=[...s.options].find(o=>o.value!=="0").value;s.dispatchEvent(new Event("change",{bubbles:true}))')
 driver.wait('return document.querySelectorAll(".billing-table tbody tr").length===4')
 record('version selector still shows the complete previous fetch',driver.js('return [...document.querySelectorAll(".billing-table tbody tr")].every(r=>r.textContent.includes("192.0.2."))'))
 provider.shutdown();provider.server_close()
 driver.command('WebDriver:SetWindowRect',{'width':1280,'height':900})
 driver.js('location.hash="#/sites"');driver.wait('return document.querySelectorAll(".sites-table tbody tr").length>=1');time.sleep(.25)
 overview=driver.js('''
const rows=[...document.querySelectorAll(".sites-table tbody tr")];
const host=document.querySelector(".sites-td-host");
const termLine=document.querySelector(".sites-host-term");
const siteLine=document.querySelector(".sites-host-site");
const termAct=termLine&&termLine.querySelector("button.sites-host-act");
const siteAct=siteLine&&siteLine.querySelector("button.sites-host-act");
const siteMore=document.querySelector(".sites-site-more");
const desktopActs=document.querySelector(".sites-site-cell > .sites-site-acts");
const heads=[...document.querySelectorAll(".sites-table th")].map(e=>e.textContent.trim());
const wrap=document.querySelector(".sites-table-wrap");
const table=document.querySelector(".sites-table");
const site=document.querySelector(".sites-td-site");
const links=document.querySelector(".sites-td-links");
const hr=host&&host.getBoundingClientRect(),sr=site&&site.getBoundingClientRect(),lr=links&&links.getBoundingClientRect();
const endN=document.querySelectorAll("tr.sites-host-end").length;
const endTd=document.querySelector("tr.sites-host-end td:not(.sites-td-host)");
const hostBorder=host&&getComputedStyle(host).borderBottomWidth;
const endBorder=endTd&&getComputedStyle(endTd).borderBottomWidth;
return {
  rows:rows.length,ips:document.querySelectorAll(".sites-td-host").length,
  hasHost:!!host,
  sidePad:getComputedStyle(wrap).paddingLeft,
  pad:getComputedStyle(wrap).padding,
  hostActs:!!(termAct&&siteAct&&(termAct.textContent||"").includes("站点")&&(siteAct.textContent||"").includes("终端")),
  siteMenuVisible:!!desktopActs&&desktopActs.children.length===4,
  heads:heads.map((_,i)=>["IP","站点","SSL","访问"][i]),
  headerCounts:!!document.querySelector(".sites-th-host .sites-th-count")&&!!document.querySelector(".sites-th-site .sites-th-count"),
  minW:parseFloat(getComputedStyle(table).minWidth)||0,
  bodyW:document.body.scrollWidth,
  tableW:table.getBoundingClientRect().width,
  wrapW:wrap.getBoundingClientRect().width,
  hostW:hr?hr.width:0,siteW:sr?sr.width:0,linksW:lr?lr.width:0,
  stacked:!!(termLine&&siteLine&&siteLine.getBoundingClientRect().bottom<=termLine.getBoundingClientRect().top+2),
  clickName:!!document.querySelector(".sites-site-name.sites-clickable"),
  nameOnly:(()=>{
    const name=document.querySelector(".sites-site-name.sites-clickable");
    const td=name&&name.closest(".sites-td-site");
    if(!name||!td)return false;
    const nr=name.getBoundingClientRect(),tr=td.getBoundingClientRect();
    return nr.width<tr.width-24 && getComputedStyle(name).flexGrow==="0";
  })(),
  vMid:getComputedStyle(host||table).verticalAlign==="middle",
  hostEnds:endN,
  hostSep:endN>0 && hostBorder===endBorder && parseFloat(hostBorder)>=2
}
''')
 record('sites overview is a rowspan host/site table without outer padding',overview['rows']>=1 and overview['ips']>=1 and overview['hasHost'] and float(overview['sidePad'].replace('px',''))==0,overview)
 record('overview host act buttons; header counts; continuous group sep; v-middle',overview['hostActs'] and overview['siteMenuVisible'] and overview['headerCounts'] and overview['heads']==['IP','站点','SSL','访问'] and overview.get('stacked') and overview.get('clickName') and overview.get('nameOnly') and overview.get('vMid') and overview.get('hostSep'),overview)
 record('overview table is finite and host tighter than 站点/访问',overview.get('bodyW',0)<2200 and overview.get('tableW',0)<=overview.get('wrapW',0)+2 and overview.get('hostW',0)>0 and overview.get('siteW',0)>overview.get('hostW',0) and overview.get('linksW',0)>overview.get('hostW',0),overview)
 driver.js('location.hash="#/billing"');driver.wait('return !!document.querySelector(".billing-view")');driver.js('location.hash="#/sites"');driver.wait('return !!document.querySelector(".sites-table")')
 log_metrics=driver.js('const el=document.querySelector(".logs");return el?{height:el.getBoundingClientRect().height,bottom:el.getBoundingClientRect().bottom,viewport:innerHeight}:null')
 record('log pane remains visible after billing to sites navigation',log_metrics and log_metrics['height']>20 and log_metrics['bottom']<=log_metrics['viewport']+2,log_metrics)
 driver.js('location.hash="#/site/'+fixture_sites[0]+'"');driver.wait('return !!document.querySelector(".codejar-editor") && !!document.querySelector(".editor-head-save")',30)
 record('editor and icons use bundled local scripts',driver.js('return !!document.querySelector(".codejar-editor") && !!window.hljs && !!window.lucide && [...document.scripts].every(s=>!s.src||new URL(s.src).origin===location.origin)'))
 record('site toolbar has back-to-overview control',driver.js('const b=document.querySelector(".site-top-bar .sites-back");return !!(b && (b.textContent.includes("概览")||b.querySelector(".ico")))'))
 comment_result=driver.js('''
const ed=document.querySelector(".codejar-editor"),btn=[...document.querySelectorAll(".editor-pane-head button")].find(b=>(b.title||"").includes("注释选中行"));
if(!ed||!btn)return null;
const sel=getSelection(),range=document.createRange();range.selectNodeContents(ed);sel.removeAllRanges();sel.addRange(range);
const before=sel.toString().length,down=new MouseEvent("mousedown",{bubbles:true,cancelable:true});btn.dispatchEvent(down);btn.click();
return {before,after:sel.toString().length,collapsed:sel.isCollapsed,within:ed.contains(sel.anchorNode)&&ed.contains(sel.focusNode),prevented:down.defaultPrevented,
  selectionColor:getComputedStyle(ed,"::selection").backgroundColor,
  accentHoverRule:[...document.styleSheets].some(s=>{try{return [...s.cssRules].some(r=>r.selectorText===".editor-head-save.accent:hover:not(:disabled)")}catch{return false}})}
''')
 record('multi-line comment keeps editor selection and gray selection color',comment_result and comment_result['before']>10 and not comment_result['collapsed'] and comment_result['within'] and comment_result['prevented'] and comment_result['selectionColor'] in ['rgb(216, 216, 216)','rgb(86, 86, 86)'],comment_result)
 record('accent save button has explicit hover treatment',bool(comment_result and comment_result['accentHoverRule']))
 # Saved-but-undeployed red dot on 部署 (own deployPending state).
 driver.js('''
const ed=document.querySelector(".codejar-editor");
if(ed){ed.focus();ed.textContent += "\\n# pending-deploy-smoke";ed.dispatchEvent(new KeyboardEvent("keyup",{bubbles:true,key:"x"}));}
''')
 driver.wait('return !!document.querySelector(".editor-head-save") && !document.querySelector(".editor-head-save").disabled',10)
 driver.js('document.querySelector(".editor-head-save").click()')
 driver.wait('return !!document.querySelector(".site-top-right > button.accent .act-pending-dot.on")',10)
 record('deploy button shows pending red dot after save',driver.js('const d=document.querySelector(".site-top-right > button.accent .act-pending-dot");return !!(d && d.classList.contains("on") && getComputedStyle(d).opacity!=="0")'))
 record('site top bar + files head + desktop editor controls',driver.js('''
const top=document.querySelector(".site-top-bar");
const fh=document.querySelector(".files-head");
const acts=document.querySelector(".site-top-bar .site-top-right");
const editor=document.querySelector(".editor-pane-head");
const save=document.querySelector(".editor-head-save");
if(!top||!fh||!acts||!editor||!save)return false;
const titles=[...fh.querySelectorAll("button.files-op")].map(b=>b.title||"");
const icons=fh.querySelectorAll("button.files-op .ico").length;
const fr=fh.getBoundingClientRect(),tr=top.getBoundingClientRect();
return !document.querySelector(".site-view .page-header") && !!fh.querySelector(".files-conf-btn") &&
  fr.top>=tr.bottom-2 && titles.some(t=>t.includes("上传")) && titles.some(t=>t.includes("新建文件")) && icons>=3 &&
  editor.textContent.includes("注释") && !!editor.querySelector(".editor-head-apk") && acts.children.length>=2
'''))
 record('config page: single site top bar, no global header',driver.js('''
const top=document.querySelector(".site-top-bar");
const back=top&&top.querySelector(".sites-back");
const title=top&&top.querySelector(".site-top-title");
const acts=top&&top.querySelector(".site-top-right");
const conf=document.querySelector(".files-head .files-conf-btn");
const fh=document.querySelector(".files-head");
if(!top||!back||!title||!acts||!conf||!fh)return false;
const br=back.getBoundingClientRect(),tr=title.getBoundingClientRect(),ar=acts.getBoundingClientRect(),fr=fh.getBoundingClientRect(),tb=top.getBoundingClientRect();
return !document.querySelector(".site-view .page-header") && br.x<=tr.x && tr.x<=ar.x && fr.top>=tb.bottom-2 && !document.querySelector(".left")
'''))
 driver.js('location.hash="#/"');driver.wait('return !!document.querySelector(".sites-table")')
 record('hash #/ opens sites overview home',driver.js('return !!document.querySelector(".sites-overview") && !document.querySelector(".billing-view")'))
 driver.js('location.hash="#/billing"');driver.wait('return !!document.querySelector(".billing-table")')
 driver.wait('return !!document.querySelector(".billing-snap-face .ico svg.lucide-chevrons-up-down, .billing-snap-face .ico [data-lucide=chevrons-up-down]")',10)
 hdr=driver.js('''
const h=document.querySelector(".billing-view .page-header");
const sw=h&&h.querySelector(".page-header-switch");
const mid=h&&h.querySelector(".page-header-mid");
const ch=h&&h.querySelector(".page-header-chrome");
if(!h||!sw||!mid||!ch)return null;
const hr=h.getBoundingClientRect(),sr=sw.getBoundingClientRect(),mr=mid.getBoundingClientRect(),cr=ch.getBoundingClientRect();
return {
  oneRow:Math.abs(sr.top-mr.top)<4 && Math.abs(mr.top-cr.top)<4,
  pinkLeft:sr.x<=mr.x+2,
  chromeRight:cr.x>=mr.x,
  midHasActs:!![...mid.querySelectorAll("button")].find(e=>e.textContent.includes("抓取")),
  midNoLogsBtn:![...mid.querySelectorAll("button")].find(e=>(e.title||"").includes("日志")||(e.textContent||"").includes("日志")),
  snapFace:(mid.querySelector(".billing-snap-face")&&mid.querySelector(".billing-snap-face").textContent)||"",
  snapHasIcon:!!mid.querySelector(".billing-snap-face .ico"),
  snapExpandIcon:!!mid.querySelector(".billing-snap-face .ico svg.lucide-chevrons-up-down, .billing-snap-face .ico [data-lucide=chevrons-up-down]"),
  snapIconMarkup:mid.querySelector(".billing-snap-face .ico")?.innerHTML||"",
  snapLatest:!!(mid.querySelector(".billing-snap-sel option")&&mid.querySelector(".billing-snap-sel option").textContent.startsWith("最新")),
  snapHasStar:!!(mid.querySelector(".billing-snap-sel option")&&mid.querySelector(".billing-snap-sel option").textContent.includes("★")),
  snapAfterActs:(()=>{const snap=mid.querySelector(".billing-snap-wrap");const act=[...mid.querySelectorAll("button")].find(e=>e.textContent.includes("抓取"));if(!snap||!act)return false;return snap.getBoundingClientRect().x>act.getBoundingClientRect().x && mid.lastElementChild===snap})(),
  midMaxContent:(()=>{const max=getComputedStyle(mid).maxWidth;return (max==="none"||max==="") && mid.getBoundingClientRect().width<900})(),
  chromeIpFirst:!!(ch.querySelector("button.accent")&&ch.children[0]===ch.querySelector("button.accent")),
  h:Math.round(hr.height),
  logsVisible:(()=>{const el=document.querySelector(".logs");if(!el)return false;const r=el.getBoundingClientRect();return r.height>20&&getComputedStyle(el).display!=="none"})()
}
''')
 record('desktop billing: pink left, compact mid, 版本 expand icon after acts, bottom logs, no star, one row',hdr and hdr['oneRow'] and hdr['pinkLeft'] and hdr['chromeRight'] and hdr['midHasActs'] and hdr['midNoLogsBtn'] and hdr['logsVisible'] and hdr['snapFace']=='版本' and hdr['snapHasIcon'] and hdr['snapExpandIcon'] and hdr['snapLatest'] and not hdr['snapHasStar'] and hdr['snapAfterActs'] and hdr['midMaxContent'] and hdr['chromeIpFirst'] and hdr['h']<=40,hdr)
 driver.js('if(window.__sspSyncPageMinWidth)window.__sspSyncPageMinWidth()')
 time.sleep(.15)
 bill_scroll=driver.js('''
if(window.__sspSyncPageMinWidth)window.__sspSyncPageMinWidth();
const wrap=document.querySelector(".billing-scroll");
const table=document.querySelector(".billing-table");
const h=document.querySelector(".billing-view .page-header");
if(!wrap||!table||!h)return null;
const pageMin=parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--page-min-width"))||0;
const tw=table.scrollWidth, bw=document.body.scrollWidth, hw=h.getBoundingClientRect().width;
const tableScrolls=wrap.scrollWidth>=table.scrollWidth-2 && (tw>wrap.clientWidth+1 ? wrap.scrollWidth>wrap.clientWidth+1 : true);
return {
  pageMin, tw, bw, hw,
  tableInPane:tableScrolls,
  headerSized:pageMin>200 && pageMin<900 && hw>=pageMin-4,
  ok: pageMin>200 && pageMin<900 && tableScrolls && hw>=Math.min(pageMin,bw)-4
}
''')
 record('billing: page min from header; table scrolls in pane',bill_scroll and bill_scroll['ok'],bill_scroll)
 driver.shot('desktop-billing.png')
 open_btn=driver.js('const b=[...document.querySelectorAll(".billing-table .panel-cell button")].find(e=>e.textContent.includes("打开"));if(!b)return null;b.click();return true')
 if open_btn:
  driver.wait('return !!document.querySelector(".sites-overview") && !!document.querySelector(".sites-td-host.flash-host")',20)
  record('billing 打开 jumps to overview and flashes host',driver.js('''
const flash=document.querySelector(".sites-td-host.flash-host");
return !!document.querySelector(".sites-overview") && !document.querySelector(".billing-view") && !!flash && !!flash.dataset.serverId
'''))
 # Full UI sweep: overview/site/server-dialog/narrow layouts after recent chrome changes.
 driver.command('WebDriver:SetWindowRect',{'width':1280,'height':900})
 driver.js('location.hash="#/sites"');driver.wait('return !!document.querySelector(".sites-table")');time.sleep(.2)
 ov_ui=driver.js('''
const wrap=document.querySelector(".sites-table-wrap");
const h=document.querySelector(".sites-overview .page-header");
const sw=h&&h.querySelector(".page-header-switch");
const mid=h&&h.querySelector(".page-header-mid");
const ch=h&&h.querySelector(".page-header-chrome");
if(!wrap||!h||!sw||!mid||!ch)return null;
const cs=getComputedStyle(wrap),sr=sw.getBoundingClientRect(),mr=mid.getBoundingClientRect(),cr=ch.getBoundingClientRect();
const host=document.querySelector(".sites-td-host");
const site=document.querySelector(".sites-td-site"),links=document.querySelector(".sites-td-links");
return {
  pad:cs.padding,
  oneRow:Math.abs(sr.top-cr.top)<4,
  pinkLeft:sr.x<=mr.x+2,
  chromeRight:cr.x>=mr.x,
  noLeft:!document.querySelector(".left"),
  bodyW:document.body.scrollWidth,
  pageMin:parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--page-min-width"))||0,
  hostW:host?host.getBoundingClientRect().width:0,
  siteW:site?site.getBoundingClientRect().width:0,
  linksW:links?links.getBoundingClientRect().width:0,
}
''')
 record('desktop overview UI: no outer padding, header row, tight host col',ov_ui and float(ov_ui['pad'].split()[-1].replace('px',''))==0 and ov_ui['oneRow'] and ov_ui['pinkLeft'] and ov_ui['chromeRight'] and ov_ui['noLeft'] and ov_ui['bodyW']<2200 and ov_ui['pageMin']>200 and ov_ui['siteW']>ov_ui['hostW'] and ov_ui['linksW']>0,ov_ui)
 driver.shot('desktop-overview.png')
 driver.js('const b=document.querySelector(".sites-ip-btn:not([disabled])");if(b)b.click();return !!b')
 driver.wait('return !!document.querySelector(".server-dlg-layer:not(.off) .server-dlg")',20)
 server_dlg=driver.js('''
const layer=document.querySelector(".server-dlg-layer:not(.off)");
const dlg=layer&&layer.querySelector(".server-dlg");
const head=dlg&&dlg.querySelector(".server-dlg-head");
const form=dlg&&dlg.querySelector(".server-form");
if(!dlg||!head||!form)return null;
const init=[...dlg.querySelectorAll("button")].find(b=>(b.title||"").includes("安装 Nginx/rsync"));
return {
  overviewStill:!!document.querySelector(".sites-overview"),
  noServerPage:!document.querySelector(".server-view"),
  noSitesPane:!dlg.querySelector(".server-sites"),
  hasInit:!!init,
  hasForm:!!form.querySelector("input"),
}
''')
 record('server dialog: init+form only; no IP page / no 站点访问',server_dlg and server_dlg['overviewStill'] and server_dlg['noServerPage'] and server_dlg['noSitesPane'] and server_dlg['hasInit'] and server_dlg['hasForm'],server_dlg)
 driver.shot('desktop-server.png')
 driver.js('const c=document.querySelector(".server-dlg-close");if(c)c.click();return !!c')
 driver.wait('return !document.querySelector(".server-dlg-layer:not(.off)")')
 driver.js('location.hash="#/site/'+fixture_sites[0]+'"');driver.wait('return !!document.querySelector(".codejar-editor")',30)
 time.sleep(.15)
 driver.wait('return !!document.querySelector(".codejar-editor") && !!document.querySelector(".site-top-bar .site-top-right") && !!document.querySelector(".editor-head-save")')
 site_ui=driver.js('''
const fh=document.querySelector(".files-head");
const top=document.querySelector(".site-top-bar");
const acts=document.querySelector(".site-top-bar .site-top-right");
const editor=document.querySelector(".editor-pane-head");
const files=document.querySelector(".files");
const jar=document.querySelector(".codejar-editor");
const save=document.querySelector(".editor-head-save");
const conf=document.querySelector(".files-head .files-conf-btn");
if(!fh||!top||!acts||!editor||!files||!jar||!save||!conf)return null;
const fr=fh.getBoundingClientRect(),tr=top.getBoundingClientRect(),jr=jar.getBoundingClientRect();
const cols=getComputedStyle(files).gridTemplateColumns.split(" ").filter(Boolean);
const ratio=cols.length>=2 ? (parseFloat(cols[1])/Math.max(parseFloat(cols[0]),1)) : 0;
const jarCs=getComputedStyle(jar);
return {
  noGlobalHeader:!document.querySelector(".site-view .page-header"),
  confInFiles:!!conf,
  hasSaveFloat:!!save,
  menuOk:editor.textContent.includes("注释") && !!editor.querySelector(".editor-head-apk"),
  filesLeft:fr.x<jr.x && fr.top>=tr.bottom-2,
  filesHasUpload:[...fh.querySelectorAll("button.files-op")].some(b=>(b.title||"").includes("上传")),
  filesIcons:fh.querySelectorAll("button.files-op .ico").length,
  filesIconsFit:![...fh.querySelectorAll("button.files-op")].some(b=>b.getBoundingClientRect().right>fr.right+2),
  filesMin:parseFloat(cols[0])||0,
  hasSplit:!!document.querySelector(".files-split"),
  hasFloat:!!document.querySelector(".files-select-float"),
  floatCol:!!(document.querySelector(".files-select-float")&&getComputedStyle(document.querySelector(".files-select-float")).flexDirection==="column"),
  noRail:!document.querySelector(".files-ops-rail"),
  noWrap:jarCs.whiteSpace==="pre" && jarCs.overflowWrap==="normal",
  deployN:acts.children.length,
  oneRow:tr.height<=48,
  ratioOk:ratio>=2.2,
  bodyW:document.body.scrollWidth,
}
''')
 record('desktop site UI: single top bar + icon file ops + float select + 1:3',site_ui and site_ui['noGlobalHeader'] and site_ui['confInFiles'] and site_ui['hasSaveFloat'] and site_ui['menuOk'] and site_ui['filesLeft'] and site_ui['filesHasUpload'] and site_ui['filesIcons']>=3 and site_ui['filesIconsFit'] and site_ui['filesMin']>=100 and not site_ui['hasSplit'] and site_ui['hasFloat'] and site_ui['floatCol'] and site_ui['noRail'] and site_ui['noWrap'] and site_ui['deployN']>=2 and site_ui['oneRow'] and site_ui['ratioOk'] and site_ui['bodyW']<2200,site_ui)
 driver.wait('return [...document.querySelectorAll(".file-row .file-item")].some(e=>e.textContent.trim()==="selection-fixture.txt")')
 file_selection=driver.js('''const d=document,item=[...d.querySelectorAll('.file-row .file-item')].find(e=>e.textContent.trim()==='selection-fixture.txt'),row=item.closest('.file-row'),box=item.getBoundingClientRect(),editor=d.querySelector('.codejar-editor'),before=editor&&editor.textContent,opts={bubbles:true,cancelable:true,pointerId:1,pointerType:'mouse',isPrimary:true,button:0};row.dispatchEvent(new PointerEvent('pointerdown',{...opts,clientX:box.left+2,clientY:box.top+box.height/2}));row.dispatchEvent(new PointerEvent('pointermove',{...opts,clientX:box.right-2,clientY:box.top+box.height/2}));const s=getSelection(),r=d.createRange();r.selectNodeContents(item);s.removeAllRanges();s.addRange(r);const text=s.toString();row.dispatchEvent(new PointerEvent('pointerup',{...opts,clientX:box.right-2,clientY:box.top+box.height/2}));item.click();return {text,selectable:getComputedStyle(item).userSelect,before,active:[...d.querySelectorAll('.file-row.on .file-item')].map(e=>e.textContent.trim())};''')
 time.sleep(.2)
 after=driver.js('return document.querySelector(".codejar-editor")?.textContent||""')
 record('dragging to select a file name does not open the file',file_selection['text']=='selection-fixture.txt' and file_selection['selectable']=='text' and after==file_selection['before'] and 'selection-fixture.txt' not in file_selection['active'],{**file_selection,'after':after})
 click_opens=driver.js('''const d=document,item=[...d.querySelectorAll('.file-row .file-item')].find(e=>e.textContent.trim()==='selection-fixture.txt');getSelection().removeAllRanges();item.click();return true''')
 driver.wait('return [...document.querySelectorAll(".file-row.on .file-item")].some(e=>e.textContent.trim()==="selection-fixture.txt")')
 record('plain click still opens the file after drag-select',click_opens and 'FILE_SELECTION_FIXTURE' in (driver.js('return document.querySelector(".codejar-editor")?.textContent||""') or ''),True)
 driver.command('WebDriver:SetWindowRect',{'width':390,'height':844});time.sleep(.15)
 narrow_ui=driver.js('''
const h=document.querySelector(".site-top-bar");
const fh=document.querySelector(".files-head");
const list=document.querySelector(".file-list");
const ed=document.querySelector(".editor-rail-float:not(.off)");
const split=document.querySelector(".files-split");
const flt=document.querySelector(".files-select-float");
const files=document.querySelector(".files");
if(!h||!fh||!ed||!files)return null;
const hr=h.getBoundingClientRect(),fr=fh.getBoundingClientRect(),lr=list&&list.getBoundingClientRect(),er=ed.getBoundingClientRect();
const cols=files?getComputedStyle(files).gridTemplateColumns.split(" ").filter(Boolean):[];
const ratio=cols.length>=2?(parseFloat(cols[1])/Math.max(parseFloat(cols[0]),1)):0;
return {
  vw:innerWidth,
  headerHeight:hr.height,
  pageMin:parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--page-min-width"))||0,
  bodyW:document.body.scrollWidth,
  scrolls:document.documentElement.scrollWidth>innerWidth+1 || document.body.scrollWidth>innerWidth+1,
  noLeft:!document.querySelector(".left"),
  noPageHeader:!document.querySelector(".site-view .page-header"),
  noRail:!document.querySelector(".files-ops-rail"),
  railAtEditor:!!(ed&&ed.closest(".cm-wrap")&&er.right<=ed.closest(".cm-wrap").getBoundingClientRect().right+2),
  opsUpload:!!(fh&&[...fh.querySelectorAll("button.files-op")].some(b=>(b.title||"").includes("上传"))),
  hasSplit:!!split,
  hasFloat:!!flt,
  floatOff:!!(flt&&flt.classList.contains("off")),
  floatCol:!!(flt&&getComputedStyle(flt).flexDirection==="column"),
  ratioOk:ratio>=1.5 && ratio<=2.6,
  noWrap:!!(document.querySelector(".codejar-editor")&&getComputedStyle(document.querySelector(".codejar-editor")).whiteSpace==="pre"),
}
''')
 record('narrow site UI: single site bar, editor rail, 1:2, no wrap or page scroll',narrow_ui and narrow_ui['vw']<=560 and narrow_ui['pageMin']<2 and not narrow_ui['scrolls'] and narrow_ui['noLeft'] and narrow_ui['noPageHeader'] and narrow_ui['noRail'] and narrow_ui['railAtEditor'] and narrow_ui['opsUpload'] and not narrow_ui['hasSplit'] and narrow_ui['hasFloat'] and narrow_ui['floatOff'] and narrow_ui['floatCol'] and narrow_ui['ratioOk'] and narrow_ui['noWrap'] and narrow_ui['headerHeight']<=56,narrow_ui)
 driver.js('''
const rail=document.querySelector('.editor-rail-float');
const more=rail&&[...rail.querySelectorAll('button.files-op')].find(b=>(b.title||'').includes('更多'));
if(more)more.click();
 ''');driver.wait('return [...document.querySelectorAll(".editor-rail-float.open .editor-rail-down button")].some(b=>b.title==="注释")')
 phone_comment=driver.js('''
const ed=document.querySelector('.codejar-editor'),btn=document.querySelector('.editor-rail-float.open .editor-rail-down button[title="注释"]');
if(!ed||!btn)return null;
const sel=getSelection(),range=document.createRange();range.selectNodeContents(ed);sel.removeAllRanges();sel.addRange(range);
const down=new MouseEvent('mousedown',{bubbles:true,cancelable:true});btn.dispatchEvent(down);btn.click();
return {collapsed:sel.isCollapsed,within:ed.contains(sel.anchorNode)&&ed.contains(sel.focusNode),prevented:down.defaultPrevented,text:sel.toString().length,color:getComputedStyle(ed,'::selection').backgroundColor};
''')
 record('phone editor comment keeps selected lines',phone_comment and not phone_comment['collapsed'] and phone_comment['within'] and phone_comment['prevented'] and phone_comment['text']>10 and phone_comment['color'] in ['rgb(216, 216, 216)','rgb(86, 86, 86)'],phone_comment)
 driver.js('const b=[...document.querySelectorAll(".editor-rail-float button.files-op")].find(b=>(b.title||"").includes("保存"));if(b)b.click()');time.sleep(.2)
 driver.shot('narrow-site.png')
 driver.js('location.hash="#/sites"');driver.wait('return !!document.querySelector(".sites-table")');time.sleep(.15)
 driver.js('if(window.__sspSyncPageMinWidth)window.__sspSyncPageMinWidth()')
 narrow_ov=driver.js('''
const wrap=document.querySelector(".sites-table-wrap");
const h=document.querySelector(".sites-overview .page-header");
const sw=h&&h.querySelector(".page-header-switch");
const mid=h&&h.querySelector(".page-header-mid");
const ch=h&&h.querySelector(".page-header-chrome");
if(!wrap||!h||!sw||!mid||!ch)return null;
const sr=sw.getBoundingClientRect(),mr=mid.getBoundingClientRect(),cr=ch.getBoundingClientRect();
return {
  pad:getComputedStyle(wrap).padding,
  midSecond:mr.height===0 && !!document.querySelector(".sites-th-host .sites-th-count") && !!document.querySelector(".sites-th-site .sites-th-count"),
  switchChromeOne:Math.abs(sr.top-cr.top)<4,
  pageMin:parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--page-min-width"))||0,
  bodyW:document.body.scrollWidth,
  scrolls:document.documentElement.scrollWidth>innerWidth+1 || document.body.scrollWidth>innerWidth+1,
  wrapScrolls:wrap.scrollWidth>=wrap.clientWidth-1,
}
''')
 record('narrow overview UI: compact one-row header, table scrolls in pane',narrow_ov and narrow_ov['pad'] in ('0px','0') and narrow_ov['midSecond'] and narrow_ov['switchChromeOne'] and narrow_ov['pageMin']<2 and not narrow_ov['scrolls'] and narrow_ov['bodyW']<=520,narrow_ov)
 driver.shot('narrow-overview.png')
 driver.js('location.hash="#/billing"');driver.wait('return !!document.querySelector(".billing-view")');time.sleep(.1)
 narrow_bill=driver.js('''
const mid=document.querySelector(".billing-view .page-header-mid");
const snap=mid&&mid.querySelector(".billing-snap-wrap");
if(!mid||!snap)return null;
const mr=mid.getBoundingClientRect(),sr=snap.getBoundingClientRect();
return {rightAligned:Math.abs(sr.right-mr.right)<=6, snapRight:sr.right, midRight:mr.right};
''')
 record('narrow billing: version selector right-aligned in mid row',narrow_bill and narrow_bill['rightAligned'],narrow_bill)
 driver.command('WebDriver:SetWindowRect',{'width':1280,'height':900})
 driver.js('location.hash="#/site/'+fixture_sites[0]+'"');driver.wait('return !!document.querySelector(".codejar-editor")',30)
 driver.js('''window.auditEditor=document.querySelector(".codejar-editor");window.auditOriginal=window.auditEditor.textContent;window.auditEditor.focus();const r=document.createRange();r.selectNodeContents(window.auditEditor);r.collapse(false);getSelection().removeAllRanges();getSelection().addRange(r)''')
 driver.command('WebDriver:PerformActions',{'actions':[{'type':'key','id':'audit-enter','actions':[{'type':'keyDown','value':'\uE007'},{'type':'keyUp','value':'\uE007'}]}]})
 time.sleep(.15)
 enter_result=driver.js('''const e=document.querySelector(".codejar-editor");return {before:window.auditOriginal,after:e.textContent,lines:e.textContent.split("\\n").length};''')
 record('Enter inserts a line break in the editor',enter_result['lines']>enter_result['before'].split('\n').__len__(),enter_result)
 driver.js('''const e=window.auditEditor;e.textContent="alpha";e.focus();const r=document.createRange();r.setStart(e.firstChild,2);r.collapse(true);getSelection().removeAllRanges();getSelection().addRange(r)''')
 driver.command('WebDriver:PerformActions',{'actions':[{'type':'key','id':'audit-enter-middle','actions':[{'type':'keyDown','value':'\uE007'},{'type':'keyUp','value':'\uE007'}]}]})
 middle_enter=driver.js('return window.auditEditor.textContent')
 record('physical Enter inserts at the current caret',middle_enter=='al\npha',middle_enter)
 driver.js('''const e=window.auditEditor;e.focus();const r=document.createRange();r.selectNodeContents(e);r.collapse(false);getSelection().removeAllRanges();getSelection().addRange(r);const before=e.textContent.split("\\n").length;e.dispatchEvent(new InputEvent("beforeinput",{bubbles:true,cancelable:true,inputType:"insertParagraph"}));window.auditBeforeInputLines=before''')
 virtual_enter=driver.js('''const e=window.auditEditor;return {before:window.auditBeforeInputLines,after:e.textContent.split("\\n").length,text:e.textContent.slice(-20)}''')
 record('virtual keyboard paragraph input inserts a line break',virtual_enter['after']==virtual_enter['before']+1,virtual_enter)
 indent_result=driver.js('''const e=window.auditEditor;e.textContent="  alpha";e.focus();let r=document.createRange();r.selectNodeContents(e);r.collapse(false);getSelection().removeAllRanges();getSelection().addRange(r);e.dispatchEvent(new InputEvent("beforeinput",{bubbles:true,cancelable:true,inputType:"insertParagraph"}));return {text:e.textContent}''')
 record('virtual keyboard newline preserves current indentation',indent_result['text']=="  alpha\n  ",indent_result)
 brace_result=driver.js('''const e=window.auditEditor;e.textContent="if {}";e.focus();const n=e.firstChild,r=document.createRange();r.setStart(n,4);r.collapse(true);getSelection().removeAllRanges();getSelection().addRange(r);e.dispatchEvent(new InputEvent("beforeinput",{bubbles:true,cancelable:true,inputType:"insertParagraph"}));return {text:e.textContent}''')
 record('newline after an opening brace indents and moves the closing brace',brace_result['text']=="if {\n  \n}",brace_result)
 driver.js('window.auditEditor=document.querySelector(".codejar-editor");window.auditOriginal=window.auditEditor.textContent;window.auditEditor.focus();document.execCommand("insertText",false,"# audit typing\\n");')
 time.sleep(.15)
 record('editor typing updates the existing CodeJar node',driver.js('return document.querySelector(".codejar-editor")===window.auditEditor && window.auditEditor.textContent!==window.auditOriginal'))
 driver.js('window.auditEditor.textContent="# saved by browser audit\\n"+window.auditOriginal;window.auditEditor.dispatchEvent(new KeyboardEvent("keyup",{bubbles:true,key:"x"}));window.auditEditor.focus()')
 driver.command('WebDriver:PerformActions',{'actions':[{'type':'key','id':'audit-save','actions':[{'type':'keyDown','value':'\uE009'},{'type':'keyDown','value':'s'},{'type':'pause','duration':750},{'type':'keyUp','value':'s'},{'type':'keyUp','value':'\uE009'}]}]})
 for _ in range(100):
  if (SITES/fixture_sites[0]/'nginx.conf').read_text().startswith('# saved by browser audit'):break
  time.sleep(.05)
 record('Ctrl-S writes the actual editor contents', (SITES/fixture_sites[0]/'nginx.conf').read_text().startswith('# saved by browser audit'))
 time.sleep(.1)
 record('Ctrl-S leaves the save button clean',not driver.js('return document.querySelector(".editor-head-save").classList.contains("accent")'))
 record('nginx.conf save reports basic syntax check success',driver.js('return document.querySelector(".logs-body").textContent.includes("nginx.conf 基础检查通过并已保存")'))
 driver.shot('desktop-editor.png')
 paste_result=driver.js('''const e=window.auditEditor,text="server {\\n    server_name one.test two.test;\\n    location / {\\n        try_files $uri =404;\\n    }\\n}\\n",expected="prefix"+text+"-suffix";e.textContent="prefix-suffix";e.focus();const r=document.createRange();r.setStart(e.firstChild,6);r.collapse(true);getSelection().removeAllRanges();getSelection().addRange(r);const ev=new Event("paste",{bubbles:true,cancelable:true});Object.defineProperty(ev,"clipboardData",{value:{getData:()=>text}});e.dispatchEvent(ev);return {expected,actual:e.textContent,expectedLines:expected.split("\\n").length,actualLines:e.textContent.split("\\n").length}''')
 record('pasting multiline config preserves all line breaks',paste_result['actual']==paste_result['expected'],paste_result)
 driver.command('WebDriver:PerformActions',{'actions':[{'type':'key','id':'undo-paste','actions':[{'type':'keyDown','value':'\uE009'},{'type':'keyDown','value':'z'},{'type':'keyUp','value':'z'},{'type':'keyUp','value':'\uE009'}]}]})
 undo_paste=driver.js('return window.auditEditor.textContent')
 record('undo restores text replaced by multiline paste',undo_paste=='prefix-suffix',undo_paste)
 driver.command('WebDriver:PerformActions',{'actions':[{'type':'key','id':'redo-paste','actions':[{'type':'keyDown','value':'\uE009'},{'type':'keyDown','value':'\uE008'},{'type':'keyDown','value':'z'},{'type':'keyUp','value':'z'},{'type':'keyUp','value':'\uE008'},{'type':'keyUp','value':'\uE009'}]}]})
 redo_paste=driver.js('return window.auditEditor.textContent')
 record('redo restores multiline pasted text',redo_paste==paste_result['expected'],redo_paste)
 driver.js('''const e=window.auditEditor;e.textContent="edit";e.focus();const r=document.createRange();r.selectNodeContents(e);r.collapse(false);getSelection().removeAllRanges();getSelection().addRange(r)''')
 driver.command('WebDriver:PerformActions',{'actions':[{'type':'key','id':'type-for-undo','actions':[{'type':'keyDown','value':'x'},{'type':'keyUp','value':'x'}]}]})
 time.sleep(.4)
 typed_undo=driver.js('return window.auditEditor.textContent')
 record('typing updates editor text before undo',typed_undo=='editx',typed_undo)
 driver.command('WebDriver:PerformActions',{'actions':[{'type':'key','id':'undo-typed','actions':[{'type':'keyDown','value':'\uE009'},{'type':'keyDown','value':'z'},{'type':'keyUp','value':'z'},{'type':'keyUp','value':'\uE009'}]}]})
 typed_undo=driver.js('return window.auditEditor.textContent')
 record('undo restores text before a typed character',typed_undo=='edit',typed_undo)
 driver.command('WebDriver:PerformActions',{'actions':[{'type':'key','id':'redo-typed','actions':[{'type':'keyDown','value':'\uE009'},{'type':'keyDown','value':'\uE008'},{'type':'keyDown','value':'z'},{'type':'keyUp','value':'z'},{'type':'keyUp','value':'\uE008'},{'type':'keyUp','value':'\uE009'}]}]})
 typed_redo=driver.js('return window.auditEditor.textContent')
 record('redo restores a typed character',typed_redo=='editx',typed_redo)
 if args.ui_audit:
  record('desktop site title omits current filename',driver.js('return !document.querySelector(".site-top-title").textContent.includes(" / ")&&!document.querySelector(".site-top-title").textContent.includes("nginx.conf")'))
  api('POST','/api/sites/'+fixture_sites[0]+'/rename',{'title':'wbg.pmrjkx.cn 海风转发 一个很长很长的站点显示名称'})
  # Same-origin iframe provides exact CSS viewports below Firefox's 500px window minimum.
  driver.js('window.phoneFrame=document.createElement("iframe");phoneFrame.style="position:fixed;inset:0;width:390px;height:750px;border:0;z-index:99999";phoneFrame.src=location.origin+"/#/site/' +fixture_sites[0]+ '";document.body.appendChild(phoneFrame)')
  driver.wait('return phoneFrame.contentDocument.querySelector(".codejar-editor")')
  for width in [320,375,390,430,600,800]:
   driver.js('phoneFrame.style.width="'+str(width)+'px"');time.sleep(.15)
   metrics=driver.js('''const w=phoneFrame.contentWindow,d=w.document;
    const buttons=[...d.querySelectorAll('.site-top-bar button,.files-head button')];
    const blocked=buttons.filter(b=>{const r=b.getBoundingClientRect();if(!r.width)return false;const hit=d.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return !hit||!b.contains(hit)}).map(b=>{const r=b.getBoundingClientRect(),hit=d.elementFromPoint(r.x+r.width/2,r.y+r.height/2);return {title:b.title||b.textContent,hit:hit&&hit.outerHTML.slice(0,100),x:r.x,y:r.y,w:r.width,h:r.height}});
    return {width:w.innerWidth,pageWidth:d.documentElement.scrollWidth,blocked,small:buttons.filter(b=>b.getBoundingClientRect().height<26||b.getBoundingClientRect().width<26).map(b=>b.title||b.textContent)};''')
   record('exact phone '+str(width)+'px tool controls are reachable',not metrics['blocked'] and not metrics['small'] and metrics['pageWidth']<=width+1,metrics)
   header=driver.js('''const w=phoneFrame.contentWindow,d=w.document,h=d.querySelector('.site-top-bar'),t=h&&h.querySelector('.site-top-title'),nameEl=t&&t.querySelector('.site-top-title-name'),r=h&&h.getBoundingClientRect();const ellipEl=nameEl||t;return {height:r?r.height:0,title:(t&&t.textContent)||'',ellipsis:!!(ellipEl&&w.getComputedStyle(ellipEl).textOverflow==='ellipsis'&&ellipEl.scrollWidth>ellipEl.clientWidth),stacked:!!(t&&t.querySelector('.site-top-title-ip')&&nameEl),oneLine:!!(h&&[...h.children].every(c=>{const b=c.getBoundingClientRect();return b.top>=r.top-1&&b.bottom<=r.bottom+1})),noGlobal:!d.querySelector('.site-view .page-header')};''')
   record('phone '+str(width)+'px long title stays in one site top bar',header['height']<=56 and header['oneLine'] and header['noGlobal'] and ' / ' not in header['title'] and (width>=600 or header['ellipsis'] or header['stacked']),header)
   if width==390:driver.shot('phone-header-390.png')
   fonts=driver.js('''const w=phoneFrame.contentWindow,d=w.document;return {editor:parseFloat(w.getComputedStyle(d.querySelector('.codejar-editor')).fontSize),small:[...d.querySelectorAll('input:not([type=checkbox]):not([type=radio]),textarea,select,[contenteditable=true]')].filter(e=>parseFloat(w.getComputedStyle(e).fontSize)<16).map(e=>e.tagName+'.'+e.className)};''')
   record('phone '+str(width)+'px editor and input fonts avoid focus zoom',fonts['editor']>=16 and not fonts['small'],fonts)
  ce=driver.js('''const w=phoneFrame.contentWindow,d=w.document,input=d.querySelector('.codejar-editor');input.focus();const size=parseFloat(w.getComputedStyle(input).fontSize);input.blur();return size;''')
  record('CodeJar contenteditable uses nonzoom font size',ce>=16,ce)
  driver.js('phoneFrame.contentDocument.querySelector(".files-head button[title=新建文件]").click()');driver.wait('return phoneFrame.contentDocument.querySelector(".dlg-input")')
  prompt=driver.js('const w=phoneFrame.contentWindow,d=w.document,e=d.querySelector(".dlg-input");e.focus();const size=parseFloat(w.getComputedStyle(e).fontSize);e.blur();return {size,editorPresent:!!d.querySelector(".codejar-editor")};')
  record('prompt focus and blur keep nonzoom font and editor',prompt['size']>=16 and prompt['editorPresent'],prompt)
  driver.js('phoneFrame.contentDocument.querySelector(".dlg-actions button").click()')
  record('editor uses local native edge scrolling',driver.js('return phoneFrame.contentWindow.getComputedStyle(phoneFrame.contentDocument.querySelector(".cm-host")).overscrollBehaviorY==="contain"'))
  driver.js('const e=phoneFrame.contentDocument.querySelector(".codejar-editor");e.focus();e.textContent = "# phone save test\\n"+e.textContent;e.dispatchEvent(new KeyboardEvent("keyup",{bubbles:true,key:"x"}))')
  driver.wait('return !phoneFrame.contentDocument.querySelector(".editor-rail-save").disabled')
  driver.js('phoneFrame.contentDocument.querySelector(".editor-rail-save").click()')
  for _ in range(100):
   if (SITES/fixture_sites[0]/'nginx.conf').read_text().startswith('# phone save test'):break
   time.sleep(.05)
  record('phone save button writes the edited file',(SITES/fixture_sites[0]/'nginx.conf').read_text().startswith('# phone save test'))
  # Check selected-file actions remain reachable after scrolling a long list.
  for i in range(70):(SITES/fixture_sites[0]/'www'/('fixture-%03d.txt'%i)).write_text('test')
  driver.js('phoneFrame.src=phoneFrame.src');driver.wait('return phoneFrame.contentDocument.querySelectorAll(".file-check").length>=70')
  driver.js('phoneFrame.contentDocument.querySelector(".file-check").click()');time.sleep(.15)
  metrics=driver.js('''const d=phoneFrame.contentDocument,s=d.querySelector('.file-scroll');s.scrollTop=s.scrollHeight;
  const b=d.querySelector('.files-select-float button');const r=b.getBoundingClientRect(),p=s.getBoundingClientRect();return {top:r.top,scrollTop:s.scrollTop,paneTop:p.top,reachable:r.bottom>p.top&&r.top<p.bottom};''')
  record('selected file tools stay visible while scrolling',metrics['reachable'],metrics)
  driver.js('phoneFrame.contentWindow.location.hash="#/"');driver.wait('return phoneFrame.contentDocument.querySelector(".sites-ip-btn")')
  time.sleep(.5)
  record('overview opens at the top without delayed auto-scroll',driver.js('return phoneFrame.contentDocument.querySelector(".sites-table-wrap").scrollTop===0'))
  driver.js('const p=phoneFrame.contentDocument.querySelector(".sites-table-wrap");p.scrollTop=200;p.scrollLeft=40;phoneFrame.savedPosition={top:p.scrollTop,left:p.scrollLeft}')
  time.sleep(.1)
  driver.js('phoneFrame.contentDocument.querySelector(".sites-ip-btn").click()');driver.wait('return phoneFrame.contentDocument.querySelector(".server-form input")')
  metrics=driver.js('''const w=phoneFrame.contentWindow,d=w.document;return {smallInputs:[...d.querySelectorAll('.server-form input')].map(e=>({size:parseFloat(w.getComputedStyle(e).fontSize),type:e.type})).filter(e=>e.size<16)};''')
  record('phone server inputs avoid iOS focus zoom',not metrics['smallInputs'],metrics)
  driver.js('const d=phoneFrame.contentDocument,i=[...d.querySelectorAll(".server-form input")].at(-1);i.value="phone-scroll-fixture";i.dispatchEvent(new Event("input",{bubbles:true}));[...d.querySelectorAll(".server-dlg-foot button")].find(b=>b.textContent.includes("保存")).click()')
  driver.wait('return [...phoneFrame.contentDocument.querySelectorAll(".sites-name-text")].some(e=>e.textContent==="phone-scroll-fixture")')
  time.sleep(.5)
  metrics=driver.js('const p=phoneFrame.contentDocument.querySelector(".sites-table-wrap");return {top:p.scrollTop,left:p.scrollLeft,before:phoneFrame.savedPosition}')
  record('overview keeps reading position after server save refresh',abs(metrics['top']-metrics['before']['top'])<=10 and metrics['left']==metrics['before']['left'] and metrics['top']>0,metrics)
  driver.js('phoneFrame.contentDocument.querySelector(".server-dlg-close").click();phoneFrame.contentWindow.location.hash="#/billing"');driver.wait('return phoneFrame.contentDocument.querySelector(".billing-view")')
  driver.js('Array.from(phoneFrame.contentDocument.querySelectorAll(".page-header-mid button")).find(e=>e.textContent.includes("账号")).click()');driver.wait('return phoneFrame.contentDocument.querySelector(".billing-acct")')
  for width in [320,375,390,430]:
   driver.js('phoneFrame.style.width="'+str(width)+'px"');time.sleep(.1)
   metrics=driver.js('''const w=phoneFrame.contentWindow,d=w.document,b=d.querySelector('.billing-acct').getBoundingClientRect(),l=d.querySelector('.billing-acct-list');return {width:w.innerWidth,modalWidth:b.width,pageWidth:d.documentElement.scrollWidth,scroll:l.scrollWidth,client:l.clientWidth};''')
   record('exact phone '+str(width)+'px account modal fits and scrolls',abs(metrics['modalWidth']-width)<2 and metrics['pageWidth']<=width+1 and metrics['scroll']>metrics['client'],metrics)
 if args.ui_audit:
  record('account inputs use nonzoom font size',driver.js('const w=phoneFrame.contentWindow;return [...w.document.querySelectorAll(".billing-acct input:not([type=checkbox])")].every(e=>parseFloat(w.getComputedStyle(e).fontSize)>=16)'))
  api('POST','/api/logout',{})
  driver.js('phoneFrame.style.width="390px";phoneFrame.src=location.origin+"/?zoom-login=1#/sites"');driver.wait('return phoneFrame.contentDocument.querySelector(".gate input")')
  record('login inputs use nonzoom font size',driver.js('const w=phoneFrame.contentWindow,d=w.document;return [...d.querySelectorAll(".gate input")].every(e=>parseFloat(w.getComputedStyle(e).fontSize)>=16)&&!d.querySelector("meta[name=viewport]").content.includes("user-scalable=no")'))
 (ROOT/'browser-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 driver.command('WebDriver:DeleteSession')
finally:
 if ff:ff.terminate();ff.wait(timeout=10)
 panel.terminate();panel.wait(timeout=10)

if not results or not all(result["pass"] for result in results):raise SystemExit(1)
