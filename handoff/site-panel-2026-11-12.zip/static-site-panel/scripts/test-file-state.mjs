import test from "node:test"
import assert from "node:assert/strict"
import fs from "node:fs"
import vm from "node:vm"
const source = fs.readFileSync(new URL("../web/js/app.js", import.meta.url), "utf8")
const opening = source.slice(source.indexOf("let fileRequest ="), source.indexOf("function parentPath("))
const saving = source.slice(source.indexOf("function formatConfCheck("), source.indexOf("function joinPath("))
function harness() {
 const state = Object.fromEntries(Object.entries({busy:false,sel:{type:"site",name:"a"},fsFile:"",fsKind:"text",fsDirty:false,fsText:"",fsZipEntries:[],fsRev:0,deployPending:false,siteMeta:{meta:{pendingDeploy:false}}}).map(([k,v])=>[k,{val:v}]))
 const pending = new Map()
 const context = vm.createContext({state, CONF_PATH:"nginx.conf", fileKind:()=>"text", pushLog:()=>{}, syncRoute:()=>{}, refreshTree:async()=>{}, confirmDiscard:async()=>true,
  api:{readFile:(site,path)=>new Promise((resolve,reject)=>pending.set(path,{resolve,reject})),writeFile:()=>new Promise(resolve=>pending.set("save",{resolve}))}})
 vm.runInContext(source.slice(source.indexOf("function setSitePendingDeploy("),source.indexOf("/**\n * Overview clickable"))+opening+saving,context)
 return {state,pending,context}
}
test("a delayed file response cannot overwrite a later selection", async()=>{
 const h=harness(),first=h.context.openFile("a","first.txt",true),second=h.context.openFile("a","second.txt",true)
 h.pending.get("second.txt").resolve({path:"second.txt",content:"second"});await second
 h.pending.get("first.txt").resolve({path:"first.txt",content:"first"});await first
 assert.equal(h.state.fsFile.val,"second.txt");assert.equal(h.state.fsText.val,"second")
})
test("a delayed response cannot overwrite another site's editor",async()=>{
 const h=harness(),pending=h.context.openFile("a","nginx.conf",true)
 h.state.sel.val={type:"site",name:"b"};h.state.fsText.val="site b"
 h.pending.get("nginx.conf").resolve({content:"site a"});await pending
 assert.equal(h.state.fsText.val,"site b")
})
test("saving an earlier draft does not clear newer unsaved edits",async()=>{
 const h=harness();h.state.fsFile.val="index.html";h.state.fsText.val="first";h.state.fsDirty.val=true
 const pending=h.context.saveCurrentFile("a");h.state.fsText.val="new edit"
 h.pending.get("save").resolve({});await pending
 assert.equal(h.state.fsDirty.val,true)
})

test('keyboard save cannot change master files during a deploy or SSL operation',async()=>{
 const h=harness();h.state.busy.val=true;h.state.fsFile.val='index.html';h.state.fsText.val='draft';h.state.fsDirty.val=true
 await h.context.saveCurrentFile('a')
 assert.equal(h.pending.has('save'),false);assert.equal(h.state.fsDirty.val,true);assert.equal(h.state.fsText.val,'draft')
})

test('a second save of a newer draft is written after the first finishes',async()=>{
 const h=harness();h.state.fsFile.val='index.html';h.state.fsText.val='first';h.state.fsDirty.val=true
 const writes=[];h.context.api.writeFile=(site,path,content)=>new Promise(resolve=>writes.push({site,path,content,resolve}))
 const first=h.context.saveCurrentFile('a');h.state.fsText.val='second';const second=h.context.saveCurrentFile('a')
 writes[0].resolve({});await first;await new Promise(resolve=>setImmediate(resolve))
 assert.equal(writes.length,2);assert.equal(writes[1].content,'second');writes[1].resolve({});await second;assert.equal(h.state.fsDirty.val,false)
})
