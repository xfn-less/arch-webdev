#!/usr/bin/env python3
"""Whole-site, content-addressed archives. Publish the manifest only after uploads succeed."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import uuid


def run(*args):
    return subprocess.run(args, check=True, text=True, stdout=subprocess.PIPE).stdout


def inventory(site):
    result = []
    def visit(path):
        st = path.lstat()
        result.append((str(path.relative_to(site)), st.st_mode, st.st_size,
                       st.st_mtime_ns, st.st_ctime_ns, st.st_ino))
        if path.is_dir() and not path.is_symlink():
            for child in sorted(path.iterdir()):
                visit(child)
    visit(site)
    return result


def make_tar(site, target):
    before = inventory(site)
    with tarfile.open(target, "w", format=tarfile.PAX_FORMAT) as archive:
        for rel, *_ in before:
            path = site if rel == "." else site / rel
            info = archive.gettarinfo(str(path), arcname=site.name + ("/" + rel if rel != "." else ""))
            if not (info.isfile() or info.isdir() or info.issym() or info.islnk()):
                raise RuntimeError("Unsupported file type: " + str(path))
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            info.mtime = 0
            info.pax_headers = {}
            if info.isfile():
                with path.open("rb") as source:
                    archive.addfile(info, source)
            else:
                archive.addfile(info)
    if before != inventory(site):
        raise RuntimeError("Site changed while archiving; retry after edits/jobs finish: " + site.name)
    with target.open("rb") as source:
        digest = hashlib.sha256()
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
        return digest.hexdigest()


def backup(sites, output, remote, rclone, stamp, config_key):
    if not sites.is_dir():
        raise RuntimeError("Sites directory missing: " + str(sites))
    # List once per backup, rather than issuing a remote check for every source file.
    # The root prefix already exists after the config upload; first run has no archives.
    known = set(run(rclone, "lsf", remote, "--recursive", "--files-only",
                    "--include", "site-archives/**", "--fast-list", "--s3-no-check-bucket").splitlines())
    manifest = {"format": 1, "stamp": stamp, "config": config_key, "sites": []}
    output.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="site-panel-pack-", dir=output) as work:
        work = Path(work)
        for site in sorted(sites.iterdir()):
            if site.is_symlink():
                raise RuntimeError("Site root must not be a symlink: " + site.name)
            if not site.is_dir():
                continue
            raw = work / "site.tar"
            digest = make_tar(site, raw)
            key = "site-archives/" + digest + ".tar.gz"
            if key not in known:
                compressed = work / "site.tar.gz"
                with raw.open("rb") as source, compressed.open("wb") as target:
                    with gzip.GzipFile(filename="", fileobj=target, mode="wb", mtime=0, compresslevel=6) as gz:
                        shutil.copyfileobj(source, gz)
                run(rclone, "copyto", str(compressed), remote + "/" + key,
                    "--ignore-times", "--s3-no-check-bucket", "--s3-no-head", "--s3-no-head-object")
                known.add(key)
                compressed.unlink()
                print("site_uploaded=" + site.name, flush=True)
            else:
                print("site_unchanged=" + site.name, flush=True)
            manifest["sites"].append({"name": site.name, "archive": key, "tar_sha256": digest})
            raw.unlink()
        filename = "manifest-" + stamp + "-" + uuid.uuid4().hex[:8] + ".json"
        staged = work / filename
        staged.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
        run(rclone, "copyto", str(staged), remote + "/site-manifests/" + filename,
            "--ignore-times", "--s3-no-check-bucket", "--s3-no-head", "--s3-no-head-object")
        os.replace(staged, output / filename)
        print("manifest_r2=" + remote + "/site-manifests/" + filename, flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 7:
        sys.exit("usage: backup-sites.py SITES OUT REMOTE RCLONE STAMP CONFIG_KEY")
    os.umask(0o077)
    backup(Path(sys.argv[1]), Path(sys.argv[2]), *sys.argv[3:7])
