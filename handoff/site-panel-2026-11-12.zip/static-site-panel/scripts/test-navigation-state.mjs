import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import vm from 'node:vm'
const source=fs.readFileSync(new URL('../web/js/app.js',import.meta.url),'utf8')
function harness(){
 const values={deployPending:false,sel:null,siteMeta:null,fsDir:'www',fsFile:'',fsText:'',fsDirty:false,fsKind:'empty',fsZipEntries:[],fsSelected:[],fsEntries:[],fsSelectMode:false,fsRev:0}
 const state=Object.fromEntries(Object.entries(values).map(([k,v])=>[k,{val:v}]))
 const sites=new Map(),dirs=new Map(),opened=[]
 const ctx=vm.createContext({state,WWW_ROOT:'www',CONF_PATH:'nginx.conf',confirmDiscard:async()=>true,pushLog:()=>{},syncRoute:()=>{},clampWWWDir:p=>p,
  api:{getSite:name=>new Promise(resolve=>sites.set(name,resolve)),listFiles:(site,path)=>new Promise(resolve=>dirs.set(site+':'+path,resolve))},openFile:async(site,path)=>opened.push([site,path])})
 // Include only this workflow's state, functions and their current-site predicate.
 const openStart=source.indexOf('let siteRequest =')>=0?source.indexOf('let siteRequest ='):source.indexOf('async function openSite(')
 vm.runInContext(source.slice(openStart,source.indexOf('/** Open a file or enter a directory'))+source.slice(source.indexOf('function sortEntries('),source.indexOf('function clearSelectMode('))+source.slice(source.indexOf('function isCurrentSite('),source.indexOf('async function openFile(')),ctx)
 return {state,ctx,sites,dirs,opened}
}
const tick=()=>new Promise(resolve=>setImmediate(resolve))
test('late site metadata cannot replace the newly selected site',async()=>{
 const h=harness(),a=h.ctx.openSite('a',{fromRoute:true}),b=h.ctx.openSite('b',{fromRoute:true})
 h.sites.get('b')({meta:{name:'b'}});await tick();h.dirs.get('b:www')({entries:[]});await b
 h.sites.get('a')({meta:{name:'a'}});await tick();if(h.dirs.has('a:www'))h.dirs.get('a:www')({entries:[]});await a
 assert.equal(h.state.siteMeta.val.meta.name,'b');assert.deepEqual(h.opened,[['b','nginx.conf']])
})
test('late directory listing cannot overwrite a newer directory',async()=>{
 const h=harness();h.state.sel.val={type:'site',name:'a'}
 const first=h.ctx.loadDir('a','www/old'),second=h.ctx.loadDir('a','www/new')
 h.dirs.get('a:www/new')({entries:[{name:'new',path:'www/new/new'}]});await second
 h.dirs.get('a:www/old')({entries:[{name:'old',path:'www/old/old'}]});await first
 assert.equal(h.state.fsDir.val,'www/new');assert.equal(h.state.fsEntries.val[0].name,'new')
})
test('leaving a site discards its outstanding directory response',async()=>{
 const h=harness();h.state.sel.val={type:'site',name:'a'}
 const p=h.ctx.loadDir('a','www/old',{clearFile:true});h.state.sel.val={type:'billing'};h.state.fsText.val='keep'
 h.dirs.get('a:www/old')({entries:[]});await p;assert.equal(h.state.fsText.val,'keep')
})
