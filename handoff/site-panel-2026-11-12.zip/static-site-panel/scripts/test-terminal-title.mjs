import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import vm from 'node:vm'
const html=fs.readFileSync(new URL('../web/term.html',import.meta.url),'utf8')
const script=html.slice(html.lastIndexOf('<script>')+8,html.lastIndexOf('</script>'))
const tick=()=>new Promise(resolve=>setImmediate(resolve))
async function harness(authenticated=true){
 const elements=Object.fromEntries(['title','term','btnReconnect'].map(id=>[id,{textContent:''}]))
 const sockets=[],requests=[];let resolveLabel,rejectLabel
 const metadata=new Promise((resolve,reject)=>{resolveLabel=resolve;rejectLabel=reject})
 class Terminal { loadAddon(){} open(){} onData(){} focus(){} writeln(){} write(){} reset(){} }
 class Socket {static OPEN=1;constructor(url){this.url=url;sockets.push(this)}send(){}close(){this.onclose?.()}}
 const document={title:'远程终端',getElementById:id=>elements[id]}
 const window={Terminal,FitAddon:class{fit(){}},addEventListener(){}}
 vm.runInNewContext(script,{window,document,URLSearchParams,TextEncoder,Uint8Array,WebSocket:Socket,location:{search:'?server=7',protocol:'https:',host:'panel.example'},fetch:url=>{requests.push(url);return url==='/api/status'?Promise.resolve({json:async()=>({authenticated})}):metadata}})
 await tick()
 return {elements,sockets,requests,document,resolveLabel,rejectLabel}
}
test('terminal connects before metadata and keeps server name/IP through status changes',async()=>{
 const h=await harness();assert.equal(h.sockets.length,1);assert.equal(h.sockets[0].url,'wss://panel.example/api/servers/7/term')
 h.sockets[0].onopen();h.resolveLabel({ok:true,json:async()=>[{id:7,name:'香港主机',host:'192.0.2.7',publicIP:'198.51.100.7'}]});await tick()
 assert.equal(h.document.title,'香港主机 · 198.51.100.7 | 远程终端');assert.equal(h.elements.title.textContent,'已连接 · 香港主机 · 198.51.100.7')
 h.sockets[0].onclose();assert.ok(h.elements.title.textContent.startsWith('已断开 · 香港主机'))
 h.elements.btnReconnect.onclick();assert.equal(h.sockets.length,2);assert.ok(h.elements.title.textContent.includes('香港主机'))
})
test('metadata failure preserves the existing terminal connection and ID fallback',async()=>{
 const h=await harness();h.rejectLabel(new Error('offline'));await tick();h.sockets[0].onopen()
 assert.equal(h.document.title,'server #7 | 远程终端');assert.equal(h.elements.title.textContent,'已连接 · server #7')
})
test('server labels are text and duplicate IP/name is shown once',async()=>{
 const h=await harness();h.resolveLabel({ok:true,json:async()=>[{id:7,name:'<img src=x>',host:'<img src=x>'}]});await tick()
 assert.equal(h.document.title,'<img src=x> | 远程终端');assert.equal(h.elements.title.textContent,'连接中 · <img src=x>')
})
test('unauthenticated terminal does not fetch servers or connect',async()=>{
 const h=await harness(false);assert.equal(h.sockets.length,0);assert.deepEqual(h.requests,['/api/status']);assert.ok(h.elements.title.textContent.startsWith('未登录'))
})
