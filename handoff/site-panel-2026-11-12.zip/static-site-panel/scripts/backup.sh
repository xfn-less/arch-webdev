#!/usr/bin/env bash
# 分两类备份（推荐每日跑一次）：
#   1) config — .data + systemd + 各站 nginx.conf/cron（小，适合频繁改配置）
#   2) sites — 每站整包（含 apk），内容相同不上传；清单最后发布
# 凭据: /www/site-panel/.data/r2.env
set -euo pipefail
umask 077
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
command -v python3 >/dev/null
command -v flock >/dev/null

ROOT="${SITE_PANEL_ROOT:-/www/site-panel}"
OUT_DIR="${1:-/root/backups/site-panel}"
ENV_FILE="${R2_ENV_FILE:-$ROOT/.data/r2.env}"
STAMP="$(date +%Y%m%d-%H%M%S-%N)"
KEEP_CONFIG_LOCAL="${BACKUP_KEEP_CONFIG_LOCAL:-3}"
KEEP_REMOTE="${BACKUP_KEEP_REMOTE:-3}"
[[ "$KEEP_CONFIG_LOCAL" =~ ^[1-9][0-9]*$ ]] || { echo "BACKUP_KEEP_CONFIG_LOCAL must be a positive integer" >&2; exit 2; }
[[ "$KEEP_REMOTE" =~ ^[1-9][0-9]*$ ]] || { echo "BACKUP_KEEP_REMOTE must be a positive integer" >&2; exit 2; }
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

mkdir -p "$OUT_DIR"
exec 9>"$OUT_DIR/.backup.lock"
flock -n 9 || { echo "backup already running" >&2; exit 1; }
mkdir -p "$OUT_DIR/config" "$WORK/tree/data" "$WORK/tree/site-conf" "$WORK/tree/systemd"

if [[ -f "$ENV_FILE" ]]; then
  # shellcheck disable=SC1090
  set -a
  source "$ENV_FILE"
  set +a
fi
BUCKET="${R2_BUCKET:-site-panel}"
REMOTE="${RCLONE_REMOTE:-r2:$BUCKET}"
if [[ -z "${RCLONE_BIN:-}" ]]; then
  if [[ -x /usr/local/bin/rclone ]]; then
    RCLONE_BIN=/usr/local/bin/rclone
  else
    RCLONE_BIN=rclone
  fi
fi
have_r2=0
if command -v "$RCLONE_BIN" >/dev/null 2>&1 && [[ -n "${R2_ACCESS_KEY_ID:-}" || -f /root/.config/rclone/rclone.conf ]]; then
  have_r2=1
fi

# ---------- 1) config 小包 ----------
if [[ -d "$ROOT/.data" ]]; then
  tar -C "$ROOT/.data" -cf - \
    --exclude='r2.env' \
    --exclude='panel.db' \
    --exclude='panel.db-shm' \
    --exclude='panel.db-wal' \
    --exclude='*.tmp' \
    . | tar -C "$WORK/tree/data" -xf -
fi

# Python SQLite backup API includes committed WAL data without stopping the panel.
python3 - "$ROOT/.data/panel.db" "$WORK/tree/data/panel.db" <<'PYSQL'
import sqlite3
import sys
from pathlib import Path
source = Path(sys.argv[1]).resolve()
if not source.is_file():
    raise SystemExit("panel.db missing; refusing incomplete config backup")
with sqlite3.connect(source.as_uri() + "?mode=ro", uri=True, timeout=30) as src:
    with sqlite3.connect(sys.argv[2]) as dst:
        src.backup(dst)
        if dst.execute("PRAGMA integrity_check").fetchall() != [("ok",)]:
            raise SystemExit("database backup failed integrity_check")
PYSQL

# Default deployment identity and templates are needed on a replacement controller.
for d in .ssh templates; do
  if [[ -d "$ROOT/$d" ]]; then
    cp -a "$ROOT/$d" "$WORK/tree/$d"
  fi
done

# 只抽各站「配置向」文件，不含 www / apk
if [[ -d "$ROOT/sites" ]]; then
  while IFS= read -r -d '' conf; do
    rel="${conf#"$ROOT/sites/"}"
    dest="$WORK/tree/site-conf/$rel"
    mkdir -p "$(dirname "$dest")"
    cp -a "$conf" "$dest"
  done < <(find "$ROOT/sites" -maxdepth 2 -type f \( \
      -name 'nginx.conf' -o -name 'cron' -o -name 'cron.log' \
    \) -print0 2>/dev/null)
fi

for u in site-panel.service lizhi-socks.service; do
  [[ -f "/etc/systemd/system/$u" ]] && cp -a "/etc/systemd/system/$u" "$WORK/tree/systemd/" || true
done

# The controller's public TLS entrypoint is outside the panel data directory.
# Include only the panel vhost/cert and its renewal state, not other host sites.
INCLUDE_HOST_CONFIG="${BACKUP_INCLUDE_HOST_CONFIG:-0}"
[[ "$ROOT" == /www/site-panel ]] && INCLUDE_HOST_CONFIG="${BACKUP_INCLUDE_HOST_CONFIG:-1}"
if [[ "$INCLUDE_HOST_CONFIG" == 1 ]]; then
  NGINX_VHOST="${PANEL_NGINX_VHOST:-/www/server/panel/vhost/nginx/site-panel.xfnss.top.conf}"
  NGINX_WEBSOCKET="${PANEL_NGINX_WEBSOCKET:-/www/server/panel/vhost/nginx/0.websocket.conf}"
  PANEL_CERT_DIR="${PANEL_TLS_DIR:-/www/server/panel/vhost/cert/site-panel.xfnss.top}"
  ACME_HOME="${PANEL_ACME_HOME:-/root/.acme.sh}"
  [[ -f "$NGINX_VHOST" && -f "$NGINX_WEBSOCKET" && -d "$PANEL_CERT_DIR" && -d "$ACME_HOME" ]] || {
    echo "controller TLS recovery files missing; refusing incomplete backup" >&2
    exit 2
  }
  mkdir -p "$WORK/tree/host-config/nginx" "$WORK/tree/host-config/cert"
  cp -a "$NGINX_VHOST" "$WORK/tree/host-config/nginx/"
  cp -a "$NGINX_WEBSOCKET" "$WORK/tree/host-config/nginx/"
  cp -a "$PANEL_CERT_DIR" "$WORK/tree/host-config/cert/"
  cp -a "$ACME_HOME" "$WORK/tree/host-config/acme-home"
  if [[ -n "${PANEL_ROOT_CRONTAB_FILE:-}" ]]; then
    CRONTAB_INPUT="$PANEL_ROOT_CRONTAB_FILE"
    cat "$CRONTAB_INPUT"
  else
    crontab -l 2>/dev/null || true
  fi | grep -E '(^PATH=|/www/site-panel/scripts/(backup\.sh|health-lizhi\.sh)|/root/\.acme\.sh.*acme\.sh --cron)' \
    > "$WORK/tree/host-config/panel-cron.txt" || true
fi

{
  echo "stamp=$STAMP"
  echo "host=$(hostname 2>/dev/null || true)"
  echo "kind=config"
  [[ -x "$ROOT/bin/panel" ]] && echo "panel_mtime=$(stat -c %y "$ROOT/bin/panel" 2>/dev/null || true)"
  systemctl is-active site-panel 2>/dev/null | sed 's/^/site-panel=/' || true
  systemctl is-active lizhi-socks 2>/dev/null | sed 's/^/lizhi-socks=/' || true
} >"$WORK/tree/BACKUP.txt"

CONFIG_ARCHIVE="$OUT_DIR/config/config-$STAMP.tar.gz"
tar -C "$WORK/tree" -czf "$CONFIG_ARCHIVE" .
chmod 600 "$CONFIG_ARCHIVE"
echo "config_local=$CONFIG_ARCHIVE size=$(du -h "$CONFIG_ARCHIVE" | awk '{print $1}')"

if [[ "$have_r2" -ne 1 ]]; then
  echo "R2 unavailable; local config saved, remote backup incomplete" >&2
  exit 2
fi
KEY="config/$STAMP/config-$STAMP.tar.gz"
"$RCLONE_BIN" copyto "$CONFIG_ARCHIVE" "$REMOTE/$KEY" \
  --s3-no-check-bucket --s3-no-head --s3-no-head-object
echo "config_r2=$REMOTE/$KEY"

# No archive/manifest deletion here: older manifests must remain restorable.
python3 "$SCRIPT_DIR/backup-sites.py" "$ROOT/sites" "$OUT_DIR/manifests" \
  "$REMOTE" "$RCLONE_BIN" "$STAMP" "$KEY"

# Retain the newest complete recovery points. The collector validates every
# manifest and computes archive references before deleting any remote object.
python3 "$SCRIPT_DIR/backup-retention.py" "$REMOTE" "$RCLONE_BIN" "$KEEP_REMOTE"

# Only prune local configuration after the complete remote backup succeeded.
python3 - "$OUT_DIR/config" "$KEEP_CONFIG_LOCAL" <<'PYKEEP'
from pathlib import Path
import sys
keep = int(sys.argv[2])
if keep < 1:
    raise SystemExit("BACKUP_KEEP_CONFIG_LOCAL must be >= 1")
for path in sorted(Path(sys.argv[1]).glob("config-*.tar.gz"), reverse=True)[keep:]:
    path.unlink()
manifest_dir = Path(sys.argv[1]).parent / "manifests"
for path in sorted(manifest_dir.glob("manifest-*.json"), reverse=True)[keep:]:
    path.unlink()
PYKEEP
echo "backup_success=$STAMP"
