// One-shot: pull 芝麻开门 Baota sites onto panel master and deploy.Sync (no SSL, apk untouched).
package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"github.com/xfn/static-site-panel/internal/deploy"
	"github.com/xfn/static-site-panel/internal/secretbox"
	"github.com/xfn/static-site-panel/internal/store"
)

const serverID = int64(8)

type siteSpec struct {
	Title   string
	Domains []string
	Remote  string // baota wwwroot
	Conf    string
}

func main() {
	dataDir := env("DATA", "/www/site-panel/.data")
	sitesRoot := env("SITES", "/www/site-panel/sites")
	keyPath := env("SSH_KEY", "/www/site-panel/.ssh/id_ed25519")

	specs := []siteSpec{
		{
			Title:   "zmb.oxoexy.cn",
			Domains: []string{"zmb.oxoexy.cn", "bnn.oxoexy.cn", "nzm.oxoexy.cn"},
			Remote:  "/www/wwwroot/wap.pepgct.cn/",
			Conf:    confSPAProxyAPI("zmb.oxoexy.cn", []string{"zmb.oxoexy.cn", "bnn.oxoexy.cn", "nzm.oxoexy.cn"}),
		},
		{
			Title:   "wap.pepgct.cn",
			Domains: []string{"jfd.oxoexy.cn", "vnos.oxoexy.cn", "cne.oxoexy.cn"},
			Remote:  "/www/wwwroot/wap.pepgct.cn/",
			Conf:    confSPAProxyAPI("wap.pepgct.cn", []string{"jfd.oxoexy.cn", "vnos.oxoexy.cn", "cne.oxoexy.cn"}),
		},
		{
			Title:   "web.pepgct.cn",
			Domains: []string{"web.qdrbxa.cn", "web.pepgct.cn"},
			Remote:  "/www/wwwroot/web.pepgct.cn/",
			Conf:    confSPAStatic("web.pepgct.cn", []string{"web.qdrbxa.cn", "web.pepgct.cn"}),
		},
		{
			Title:   "zxkf.pepgct.cn",
			Domains: []string{"jeokf.oxoexy.cn", "chat.oxoexy.cn"},
			Remote:  "/www/wwwroot/zxkf.pepgct.cn/",
			Conf:    confFullProxy("zxkf.pepgct.cn", []string{"jeokf.oxoexy.cn", "chat.oxoexy.cn"}),
		},
	}

	box, err := secretbox.LoadOrCreate(filepath.Join(dataDir, "ssh.aes"))
	if err != nil {
		log.Fatal(err)
	}
	st, err := store.Open(filepath.Join(dataDir, "panel.db"))
	if err != nil {
		log.Fatal(err)
	}
	defer st.Close()
	st.SetPasswordCodec(box)

	ctx := context.Background()
	srv, err := st.GetServer(ctx, serverID)
	if err != nil {
		log.Fatal("server 8: ", err)
	}
	if srv.AuthType == "key" && srv.AuthValue == "" {
		srv.AuthValue = keyPath
	}
	log.Printf("target %s@%s:%d auth=%s", srv.User, srv.Host, srv.Port, srv.AuthType)

	for _, sp := range specs {
		site, err := st.AllocSite(ctx, sp.Title, serverID)
		if err != nil {
			log.Fatal("alloc ", sp.Title, ": ", err)
		}
		log.Printf("allocated %s → %s", sp.Title, site.Name)
		dir := filepath.Join(sitesRoot, site.Name)
		www := filepath.Join(dir, "www")
		if err := os.MkdirAll(www, 0o755); err != nil {
			log.Fatal(err)
		}
		log.Printf("rsync %s → master %s", sp.Remote, www)
		if err := rsyncPull(keyPath, srv, sp.Remote, www+"/"); err != nil {
			log.Fatal(err)
		}
		rootRemote := "/www/sites/" + site.Name + "/www"
		body := strings.ReplaceAll(sp.Conf, "__ROOT__", rootRemote)
		if err := os.WriteFile(filepath.Join(dir, "nginx.conf"), []byte(body), 0o644); err != nil {
			log.Fatal(err)
		}
		log.Printf("deploy.Sync %s (apk=%v)", site.Name, site.ApkObfuscate)
		dctx, cancel := context.WithTimeout(ctx, 10*time.Minute)
		res, err := deploy.Sync(dctx, deploy.Options{
			SitesRoot:    sitesRoot,
			SiteName:     site.Name,
			RemoteWWW:    rootRemote,
			RemoteConf:   "/etc/nginx/conf.d/" + site.Name + ".conf",
			Server:       srv,
			ApkObfuscate: site.ApkObfuscate, // leave as stored (default off)
		}, func(s string) { log.Println(" ", s) })
		cancel()
		if err != nil {
			log.Fatalf("deploy %s: %v\n%+v", site.Name, err, res)
		}
		log.Printf("ok %s skippedConf=%v reloaded=%v", site.Name, res.SkippedConf, res.Reloaded)
	}
	log.Println("done — SSL not requested; Baota vhosts untouched")
}

func env(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

func rsyncPull(key string, srv store.Server, remotePath, localPath string) error {
	port := srv.Port
	if port == 0 {
		port = 22
	}
	user := srv.User
	if user == "" {
		user = "root"
	}
	target := fmt.Sprintf("%s@%s:%s", user, srv.Host, remotePath)
	args := []string{
		"-a", "--delete", "-e",
		fmt.Sprintf("ssh -i %s -o BatchMode=yes -o StrictHostKeyChecking=accept-new -p %d", key, port),
		target, localPath,
	}
	cmd := exec.Command("rsync", args...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

func domainBlock(domains []string) string {
	return "    # >>> 域名\n    server_name " + strings.Join(domains, " ") + ";\n    # <<< 域名\n"
}

func sslStub() string {
	return `    # >>> SSL（面板自动生成，勿手改）
    # ssl_certificate     /path/to/fullchain.pem;
    # ssl_certificate_key /path/to/privkey.pem;
    # <<< SSL
`
}

func confSPAProxyAPI(label string, domains []string) string {
	_ = label
	return `server {
    listen 80;
    # listen 443 ssl http2;

` + domainBlock(domains) + `
` + sslStub() + `
    root __ROOT__;
    index index.html;

    server_tokens off;
    client_max_body_size 64m;
    gzip off;

    sub_filter_once off;
    sub_filter_types text/html text/css application/javascript text/javascript application/json;
    sub_filter 'https://zmjk.velino.cn' '/api';
    sub_filter 'http://zmjk.velino.cn' '/api';
    sub_filter 'wss://zmjk.velino.cn' 'wss://$host/ws';
    sub_filter 'ws://zmjk.velino.cn' 'wss://$host/ws';

    location ^~ /.well-known/acme-challenge/ {
        root __ROOT__;
        default_type text/plain;
    }

    location /api/ {
        proxy_pass http://webapi.qrvix.cn/;
        proxy_set_header Host webapi.qrvix.cn;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 300s;
        proxy_send_timeout 300s;
    }

    location /ws/ {
        proxy_pass http://webapi.qrvix.cn/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host webapi.qrvix.cn;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }

    location = /ws {
        proxy_pass http://webapi.qrvix.cn;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host webapi.qrvix.cn;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }

    location / {
        try_files $uri $uri/ /index.html;
        expires off;
        add_header Cache-Control "no-cache";
    }
}
`
}

func confSPAStatic(label string, domains []string) string {
	_ = label
	return `server {
    listen 80;
    # listen 443 ssl http2;

` + domainBlock(domains) + `
` + sslStub() + `
    root __ROOT__;
    index index.html;

    server_tokens off;
    client_max_body_size 64m;

    location ^~ /.well-known/acme-challenge/ {
        root __ROOT__;
        default_type text/plain;
    }

    location / {
        try_files $uri $uri/ /index.html;
        expires off;
        add_header Cache-Control "no-cache";
    }
}
`
}

func confFullProxy(label string, domains []string) string {
	_ = label
	return `server {
    listen 80;
    # listen 443 ssl http2;

` + domainBlock(domains) + `
` + sslStub() + `
    root __ROOT__;
    index index.html;

    server_tokens off;
    client_max_body_size 64m;

    location ^~ /.well-known/acme-challenge/ {
        root __ROOT__;
        default_type text/plain;
    }

    location / {
        proxy_pass http://154.198.50.120:8090;
        proxy_http_version 1.1;
        proxy_set_header Host 154.198.50.120:8090;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_ssl_server_name on;
        proxy_ssl_name 154.198.50.120:8090;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }
}
`
}
