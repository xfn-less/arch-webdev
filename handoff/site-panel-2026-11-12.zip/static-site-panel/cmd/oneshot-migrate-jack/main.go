// Prepare MYX2 杰克 220.167.103.189 (server 10). No cutover, no SSL, APK untouched.
package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"github.com/xfn/static-site-panel/internal/deploy"
	"github.com/xfn/static-site-panel/internal/secretbox"
	"github.com/xfn/static-site-panel/internal/store"
)

const serverID = int64(10)

type siteSpec struct {
	Title   string
	Remote  string
	Domains []string
	Conf    func(root string) string
}

func main() {
	dataDir := env("DATA", "/www/site-panel/.data")
	sitesRoot := env("SITES", "/www/site-panel/sites")
	keyPath := env("SSH_KEY", "/www/site-panel/.ssh/id_ed25519")

	specs := []siteSpec{
		{
			Title:   "dmy2.pojaax.cn",
			Remote:  "/www/wwwroot/dmy2.pojaax.cn",
			Domains: []string{"dmy2.pojaax.cn", "dx2y.pojaax.cn", "do2s.pojaax.cn", "drj2.pojaax.cn"},
			Conf:    confStaticSPA,
		},
		{
			Title:   "kfff.pojaax.cn",
			Remote:  "/www/wwwroot/kfff.pojaax.cn",
			Domains: []string{"kfff.pojaax.cn"},
			Conf:    confKfffProxy,
		},
		{
			Title:   "wmx.pojaax.cn",
			Remote:  "/www/wwwroot/wmx.pojaax.cn",
			Domains: []string{"wmx.pojaax.cn", "wfl.pojaax.cn", "220.167.103.189", "vie.pojaax.cn", "vru.pojaax.cn"},
			Conf:    confWmx,
		},
	}

	box, err := secretbox.LoadOrCreate(filepath.Join(dataDir, "ssh.aes"))
	if err != nil {
		log.Fatal(err)
	}
	st, err := store.Open(filepath.Join(dataDir, "panel.db"))
	if err != nil {
		log.Fatal(err)
	}
	defer st.Close()
	st.SetPasswordCodec(box)

	ctx := context.Background()
	srv, err := st.GetServer(ctx, serverID)
	if err != nil {
		log.Fatal("server 10: ", err)
	}
	if srv.AuthType == "key" && srv.AuthValue == "" {
		srv.AuthValue = keyPath
	}
	log.Printf("target %s@%s auth=%s", srv.User, srv.Host, srv.AuthType)

	// ensure rsync on remote for Sync
	if err := runSSH(keyPath, srv, "command -v rsync >/dev/null || (export DEBIAN_FRONTEND=noninteractive; apt-get update -qq && apt-get install -y -qq rsync)"); err != nil {
		log.Fatal("install rsync: ", err)
	}

	for _, sp := range specs {
		site, err := st.AllocSite(ctx, sp.Title, serverID)
		if err != nil {
			log.Fatal("alloc ", sp.Title, ": ", err)
		}
		log.Printf("allocated %s → %s", sp.Title, site.Name)
		dir := filepath.Join(sitesRoot, site.Name)
		www := filepath.Join(dir, "www")
		if err := os.MkdirAll(www, 0o755); err != nil {
			log.Fatal(err)
		}
		log.Printf("tar-pull %s → %s", sp.Remote, www)
		if err := tarPull(keyPath, srv, sp.Remote, www); err != nil {
			log.Fatal(err)
		}
		// Keep apk_processor.py on master when the old site had APK tooling / root apk,
		// so the file list shows which sites used it (obfuscate switch stays off).
		if err := ensureMasterApkProcessor(www, keyPath, srv, sp.Remote); err != nil {
			log.Printf("apk processor note %s: %v", site.Name, err)
		}
		rootRemote := "/www/sites/" + site.Name + "/www"
		body := sp.Conf(rootRemote)
		// inject domains into marker if template uses placeholder
		body = strings.ReplaceAll(body, "__DOMAINS__", strings.Join(sp.Domains, " "))
		if err := os.WriteFile(filepath.Join(dir, "nginx.conf"), []byte(body), 0o644); err != nil {
			log.Fatal(err)
		}
		log.Printf("deploy.Sync %s apk=%v", site.Name, site.ApkObfuscate)
		dctx, cancel := context.WithTimeout(ctx, 5*time.Minute)
		res, err := deploy.Sync(dctx, deploy.Options{
			SitesRoot:    sitesRoot,
			SiteName:     site.Name,
			RemoteWWW:    rootRemote,
			RemoteConf:   "/etc/nginx/conf.d/" + site.Name + ".conf",
			Server:       srv,
			ApkObfuscate: site.ApkObfuscate,
		}, func(s string) { log.Println(" ", s) })
		cancel()
		if err != nil {
			log.Fatalf("deploy %s: %v", site.Name, err)
		}
		log.Printf("ok %s skippedConf=%v reloaded=%v", site.Name, res.SkippedConf, res.Reloaded)
	}
	log.Println("done — Baota still live; wait for cutover")
}

func domainSSL(root string) string {
	return fmt.Sprintf(`    listen 80;
    # listen 443 ssl http2;

    # >>> 域名
    server_name __DOMAINS__;
    # <<< 域名

    # >>> SSL（面板自动生成，勿手改）
    # ssl_certificate     /path/to/fullchain.pem;
    # ssl_certificate_key /path/to/privkey.pem;
    # <<< SSL

    root %s;
    index index.html;

    server_tokens off;
    client_max_body_size 64m;

    location ^~ /.well-known/acme-challenge/ {
        root %s;
        default_type text/plain;
    }
`, root, root)
}

func confStaticSPA(root string) string {
	return `server {
` + domainSSL(root) + `
    location / {
        try_files $uri $uri/ /index.html;
        expires off;
        add_header Cache-Control "no-cache";
    }
}
`
}

func confKfffProxy(root string) string {
	return `server {
` + domainSSL(root) + `
    location / {
        proxy_pass http://45.194.37.145:8090;
        proxy_http_version 1.1;
        proxy_set_header Host 45.194.37.145:8090;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_ssl_server_name on;
        proxy_ssl_name 45.194.37.145:8090;
    }
}
`
}

func confWmx(root string) string {
	return fmt.Sprintf(`server {
    listen 80;
    listen 10000;
    # listen 443 ssl http2;

    # >>> 域名
    server_name __DOMAINS__;
    # <<< 域名

    # >>> SSL（面板自动生成，勿手改）
    # ssl_certificate     /path/to/fullchain.pem;
    # ssl_certificate_key /path/to/privkey.pem;
    # <<< SSL

    root %s;
    index index.html;

    server_tokens off;
    client_max_body_size 64m;

    location ^~ /.well-known/acme-challenge/ {
        root %s;
        default_type text/plain;
    }

    location ^~ /api/ {
        proxy_pass http://45.194.37.145:8080/api/;
        proxy_set_header Host 45.194.37.145:8080;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_ssl_server_name on;
        proxy_ssl_name 45.194.37.145:8080;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    location = /api {
        proxy_pass http://45.194.37.145:8080/api;
        proxy_set_header Host 45.194.37.145:8080;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_ssl_server_name on;
        proxy_ssl_name 45.194.37.145:8080;
    }
    location ^~ /uploads/ {
        proxy_pass http://45.194.37.145:8080/uploads/;
        proxy_set_header Host 45.194.37.145:8080;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_ssl_server_name on;
        proxy_ssl_name 45.194.37.145:8080;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    location = /uploads {
        proxy_pass http://45.194.37.145:8080/uploads;
        proxy_set_header Host 45.194.37.145:8080;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_ssl_server_name on;
        proxy_ssl_name 45.194.37.145:8080;
    }

    location / {
        try_files $uri $uri/ /index.html;
        expires off;
        add_header Cache-Control "no-cache";
    }
}
`, root, root)
}

func ensureMasterApkProcessor(localWWW, key string, srv store.Server, remoteDir string) error {
	proc := filepath.Join(localWWW, "apk_processor.py")
	if st, err := os.Stat(proc); err == nil && st.Size() > 0 {
		return nil
	}
	// Prefer the file that already lived on the Baota site (if any).
	remoteProc := strings.TrimRight(remoteDir, "/") + "/apk_processor.py"
	if err := scpPull(key, srv, remoteProc, proc); err == nil {
		return nil
	}
	// Else, if root has a .apk, drop the panel-embedded processor as a marker on master only.
	hasAPK := false
	entries, _ := os.ReadDir(localWWW)
	for _, e := range entries {
		n := strings.ToLower(e.Name())
		if !e.IsDir() && strings.HasSuffix(n, ".apk") && !strings.HasSuffix(n, "-out.apk") {
			hasAPK = true
			break
		}
	}
	if !hasAPK {
		return nil
	}
	src := env("APK_PROCESSOR_SRC", "/www/site-panel/internal/deploy/apk_processor.py")
	if _, err := os.Stat(src); err != nil {
		// on panel host the source may not exist; try known backup leftover path pattern — skip quietly
		return fmt.Errorf("no baota processor and no local embed at %s", src)
	}
	in, err := os.ReadFile(src)
	if err != nil {
		return err
	}
	return os.WriteFile(proc, in, 0o644)
}

func scpPull(key string, srv store.Server, remotePath, localPath string) error {
	port := srv.Port
	if port == 0 {
		port = 22
	}
	user := srv.User
	if user == "" {
		user = "root"
	}
	cmd := exec.Command("scp", "-i", key, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
		"-P", fmt.Sprintf("%d", port),
		fmt.Sprintf("%s@%s:%s", user, srv.Host, remotePath), localPath)
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

func tarPull(key string, srv store.Server, remoteDir, localWWW string) error {
	port := srv.Port
	if port == 0 {
		port = 22
	}
	user := srv.User
	if user == "" {
		user = "root"
	}
	target := fmt.Sprintf("%s@%s", user, srv.Host)
	ssh := exec.Command("ssh", "-i", key, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
		"-p", fmt.Sprintf("%d", port), target, fmt.Sprintf("tar -C %s -czf - .", remoteDir))
	tar := exec.Command("tar", "-C", localWWW, "-xzf", "-")
	pr, pw, err := os.Pipe()
	if err != nil {
		return err
	}
	ssh.Stdout = pw
	ssh.Stderr = os.Stderr
	tar.Stdin = pr
	tar.Stdout = os.Stdout
	tar.Stderr = os.Stderr
	if err := ssh.Start(); err != nil {
		return err
	}
	if err := tar.Start(); err != nil {
		_ = ssh.Process.Kill()
		return err
	}
	_ = pw.Close()
	errTar := tar.Wait()
	errSSH := ssh.Wait()
	_ = pr.Close()
	if errSSH != nil {
		return fmt.Errorf("ssh tar: %w", errSSH)
	}
	return errTar
}

func runSSH(key string, srv store.Server, remoteCmd string) error {
	port := srv.Port
	if port == 0 {
		port = 22
	}
	user := srv.User
	if user == "" {
		user = "root"
	}
	cmd := exec.Command("ssh", "-i", key, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
		"-p", fmt.Sprintf("%d", port), fmt.Sprintf("%s@%s", user, srv.Host), remoteCmd)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

func env(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}
