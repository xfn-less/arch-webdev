package main

import (
	"context"
	"log"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"github.com/xfn/static-site-panel/internal/confmark"
	"github.com/xfn/static-site-panel/internal/secretbox"
	"github.com/xfn/static-site-panel/internal/sitesfs"
	"github.com/xfn/static-site-panel/internal/sslcert"
	"github.com/xfn/static-site-panel/internal/store"
)

func main() {
	dataDir := "/www/site-panel/.data"
	sitesRoot := "/www/site-panel/sites"
	keyPath := "/www/site-panel/.ssh/id_ed25519"
	jobs := []struct {
		Name, CertDir string
	}{
		{"s35", "/www/server/panel/vhost/cert/dllt.aaunmb.cn"},
		{"s36", "/www/server/panel/vhost/cert/down.dwrhvij.cn"},
		{"s37", "/www/server/panel/vhost/cert/web.dwrhvij.cn"},
		{"s38", "/www/server/panel/vhost/cert/wlt.aaunmb.cn"},
	}
	box, err := secretbox.LoadOrCreate(filepath.Join(dataDir, "ssh.aes"))
	must(err)
	st, err := store.Open(filepath.Join(dataDir, "panel.db"))
	must(err)
	defer st.Close()
	st.SetPasswordCodec(box)
	ctx := context.Background()
	srv, err := st.GetServer(ctx, 13)
	must(err)
	if srv.AuthValue == "" {
		srv.AuthValue = keyPath
	}
	for _, j := range jobs {
		log.Printf("SSL %s from %s", j.Name, j.CertDir)
		fc := remoteCat(keyPath, srv.Host, j.CertDir+"/fullchain.pem")
		key := remoteCat(keyPath, srv.Host, j.CertDir+"/privkey.pem")
		dctx, cancel := context.WithTimeout(ctx, 3*time.Minute)
		res, err := sslcert.InstallManual(dctx, sslcert.Options{
			SitesRoot: sitesRoot, SiteName: j.Name,
			RemoteWWW: "/www/sites/" + j.Name + "/www", RemoteConf: "/etc/nginx/conf.d/" + j.Name + ".conf", Server: srv,
		}, fc, key, func(s string) { log.Println(" ", s) })
		cancel()
		must(err)
		confBody, _ := sitesfs.ReadConf(sitesRoot, j.Name)
		domains, _ := confmark.Domains(confBody)
		notAfter := int64(0)
		if !res.NotAfter.IsZero() {
			notAfter = res.NotAfter.Unix()
		}
		must(st.SetSiteSSL(ctx, j.Name, srv.ID, sslcert.DomainsKey(sslcert.CertHostnames(domains)), notAfter))
		log.Printf("ok %s days=%d", j.Name, res.DaysLeft)
	}
}

func remoteCat(key, host, path string) string {
	cmd := exec.Command("ssh", "-i", key, "-o", "BatchMode=yes", "root@"+host, "cat "+shellQuote(path))
	out, err := cmd.Output()
	must(err)
	return strings.TrimSpace(string(out)) + "\n"
}
func shellQuote(s string) string { return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'" }
func must(err error) {
	if err != nil {
		log.Fatal(err)
	}
}
