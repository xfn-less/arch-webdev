// One-shot: login first lizhi account and show how balance HTML looks now.
package main

import (
	"encoding/json"
	"fmt"
	"os"
	"regexp"
	"strings"

	"github.com/xfn/static-site-panel/internal/lizhi"
)

func main() {
	path := "/www/site-panel/.data/lizhi-accounts.json"
	if len(os.Args) > 1 {
		path = os.Args[1]
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		fatal(err)
	}
	var cfg struct {
		Proxy    string          `json:"proxy"`
		Accounts []lizhi.Account `json:"accounts"`
	}
	if err := json.Unmarshal(raw, &cfg); err != nil {
		fatal(err)
	}
	if len(cfg.Accounts) == 0 {
		fatal(fmt.Errorf("no accounts"))
	}
	a := cfg.Accounts[0]
	fmt.Printf("account=%s base=%s proxy=%s\n", a.Name, a.Base(), cfg.Proxy)
	cli, err := lizhi.NewClient(a.Base(), cfg.Proxy)
	if err != nil {
		fatal(err)
	}
	if err := cli.Login(a); err != nil {
		fatal(fmt.Errorf("login: %w", err))
	}
	bal, err := cli.FetchBalance()
	fmt.Printf("FetchBalance=%q err=%v\n", bal, err)

	html, err := cli.FetchClientAreaHTML()
	if err != nil {
		fatal(err)
	}
	fmt.Printf("clientarea_len=%d login_page=%v\n", len(html), strings.Contains(html, "邮箱登录"))
	for _, pat := range []string{
		`balance-info`, `cost-balanceDetails`, `余额`, `credit`, `userinfo`, `finance`,
	} {
		fmt.Printf("contains %q: %v\n", pat, strings.Contains(html, pat))
	}
	// Print short windows around 余额 / ¥ / money-looking h1/span
	reWindows := []*regexp.Regexp{
		regexp.MustCompile(`(?s).{0,60}余额.{0,160}`),
		regexp.MustCompile(`(?s)class="[^"]*balance[^"]*".{0,200}`),
		regexp.MustCompile(`(?s)<h[1-3][^>]*>\s*¥?\s*[\d.,]+\s*</h[1-3]>`),
		regexp.MustCompile(`(?s)data-[a-zA-Z-]*balance[a-zA-Z-]*="[^"]*"`),
	}
	for i, re := range reWindows {
		ms := re.FindAllString(html, 5)
		fmt.Printf("--- window[%d] hits=%d\n", i, len(ms))
		for _, s := range ms {
			fmt.Println(compact(s))
		}
	}
	_ = os.WriteFile("/tmp/lizhi-clientarea.html", []byte(html), 0600)
	fmt.Println("wrote /tmp/lizhi-clientarea.html")
}

func compact(s string) string {
	s = regexp.MustCompile(`\s+`).ReplaceAllString(s, " ")
	if len(s) > 240 {
		return s[:240] + "…"
	}
	return s
}

func fatal(err error) {
	fmt.Fprintln(os.Stderr, err)
	os.Exit(1)
}
