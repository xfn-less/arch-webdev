// Ops helper: try SyncAccount for the first N accounts (default 1).
package main

import (
	"fmt"
	"os"
	"strconv"

	"github.com/xfn/static-site-panel/internal/lizhi"
)

func main() {
	path := "/www/site-panel/.data/lizhi-accounts.json"
	if len(os.Args) > 1 {
		path = os.Args[1]
	}
	cfg, err := lizhi.LoadConfig(path)
	if err != nil {
		fmt.Println("config:", err)
		os.Exit(1)
	}
	proxy := cfg.Proxy
	if proxy == "" {
		proxy = "socks5h://127.0.0.1:17890"
	}
	n := 1
	if len(os.Args) > 2 {
		n, _ = strconv.Atoi(os.Args[2])
	}
	if n < 1 {
		n = 1
	}
	if n > len(cfg.Accounts) {
		n = len(cfg.Accounts)
	}
	fail := 0
	for i := 0; i < n; i++ {
		a := cfg.Accounts[i]
		assets, err := lizhi.SyncAccount(a, 20, func(s string) { fmt.Println(" ", s) }, proxy)
		if err != nil {
			fmt.Printf("FAIL %s: %v\n", a.Name, err)
			fail++
			continue
		}
		fmt.Printf("OK %s assets=%d\n", a.Name, len(assets))
	}
	if fail > 0 {
		os.Exit(1)
	}
}
