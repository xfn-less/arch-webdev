package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"time"

	"github.com/xfn/static-site-panel/internal/confmark"
	"github.com/xfn/static-site-panel/internal/deploy"
	"github.com/xfn/static-site-panel/internal/secretbox"
	"github.com/xfn/static-site-panel/internal/sitesfs"
	"github.com/xfn/static-site-panel/internal/store"
)

func main() {
	dataDir := env("DATA", "/www/site-panel/.data")
	sitesRoot := env("SITES", "/www/site-panel/sites")
	box, err := secretbox.LoadOrCreate(filepath.Join(dataDir, "ssh.aes"))
	if err != nil {
		log.Fatal(err)
	}
	st, err := store.Open(filepath.Join(dataDir, "panel.db"))
	if err != nil {
		log.Fatal(err)
	}
	defer st.Close()
	st.SetPasswordCodec(box)

	ctx := context.Background()
	sites, err := st.ListSites(ctx)
	if err != nil {
		log.Fatal(err)
	}
	for _, site := range sites {
		conf, err := sitesfs.ReadConf(sitesRoot, site.Name)
		if err != nil {
			log.Printf("skip %s: %v", site.Name, err)
			continue
		}
		if !confmark.SSLConfigured(conf) {
			log.Printf("skip %s: no SSL", site.Name)
			continue
		}
		next := confmark.EnsureHTTPSRedirect(conf)
		if next == conf {
			log.Printf("ok %s: redirect already present", site.Name)
		} else {
			if err := sitesfs.WriteConf(sitesRoot, site.Name, next); err != nil {
				log.Fatal(site.Name, err)
			}
			log.Printf("wrote redirect %s", site.Name)
		}
		if site.ServerID == 0 {
			log.Printf("skip deploy %s: unbound", site.Name)
			continue
		}
		srv, err := st.GetServer(ctx, site.ServerID)
		if err != nil {
			log.Printf("skip deploy %s: %v", site.Name, err)
			continue
		}
		if srv.AuthType == "key" && srv.AuthValue == "" {
			srv.AuthValue = "/www/site-panel/.ssh/id_ed25519"
		}
		dctx, cancel := context.WithTimeout(ctx, 2*time.Minute)
		_, err = deploy.SyncConf(dctx, deploy.Options{
			SitesRoot:  sitesRoot,
			SiteName:   site.Name,
			RemoteWWW:  "/www/sites/" + site.Name + "/www",
			RemoteConf: "/etc/nginx/conf.d/" + site.Name + ".conf",
			Server:     srv,
		}, func(s string) { log.Println(" ", site.Name, s) })
		cancel()
		if err != nil {
			log.Printf("DEPLOY FAIL %s: %v", site.Name, err)
			continue
		}
		log.Printf("deployed %s", site.Name)
	}
	fmt.Println("DONE")
}

func env(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}
