package main

import (
	"context"
	"errors"
	"flag"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"syscall"
	"time"

	"github.com/xfn/static-site-panel/internal/auth"
	"github.com/xfn/static-site-panel/internal/billing"
	"github.com/xfn/static-site-panel/internal/httpapi"
	"github.com/xfn/static-site-panel/internal/secretbox"
	"github.com/xfn/static-site-panel/internal/store"
	"github.com/xfn/static-site-panel/web"
)

const (
	apkObfuscateMigrateKey = "migrate.apk_obfuscate_v1"
	sessionTTLMigrateKey   = "migrate.session_ttl_v1"
)

// One-shot: historical sites that already used the APK workflow keep the toggle on.
func migrateApkObfuscateFlags(ctx context.Context, st *store.Store, sitesRoot string) error {
	_ = sitesRoot
	if _, err := st.Meta(ctx, apkObfuscateMigrateKey); err == nil {
		return nil
	} else if err != nil && !errors.Is(err, store.ErrNotFound) {
		return err
	}
	// Already applied on production; keep key write for fresh DBs with no prior sites.
	return st.SetMeta(ctx, apkObfuscateMigrateKey, "1")
}

// Drop old 7-day absolute sessions once so the idle/max policy applies on next login.
func migrateSessionTTL(ctx context.Context, st *store.Store) error {
	if _, err := st.Meta(ctx, sessionTTLMigrateKey); err == nil {
		return nil
	} else if err != nil && !errors.Is(err, store.ErrNotFound) {
		return err
	}
	_ = st.ClearSession(ctx)
	return st.SetMeta(ctx, sessionTTLMigrateKey, "1")
}

func main() {
	listen := flag.String("listen", "127.0.0.1:8790", "listen address")
	dataDir := flag.String("data", "./.data", "data directory")
	sites := flag.String("sites", "./sites", "sites parent directory")
	templatePath := flag.String("template", "./templates/spa.nginx.conf", "new-site nginx template")
	secureCookie := flag.Bool("secure-cookie", false, "set Secure on session cookie")
	lizhiAccounts := flag.String("lizhi-accounts", "", "lizhi accounts JSON (default: <data>/lizhi-accounts.json)")
	flag.Parse()

	sitesRoot, err := httpapi.AbsSitesRoot(*sites)
	if err != nil {
		slog.Error("sites root", "err", err)
		os.Exit(1)
	}
	if err := os.MkdirAll(*dataDir, 0o700); err != nil {
		slog.Error("data dir", "err", err)
		os.Exit(1)
	}
	if err := os.Chmod(*dataDir, 0o700); err != nil {
		slog.Error("data dir permissions", "err", err)
		os.Exit(1)
	}
	dbPath := filepath.Join(*dataDir, "panel.db")
	st, err := store.Open(dbPath)
	if err != nil {
		slog.Error("db", "err", err)
		os.Exit(1)
	}
	defer st.Close()

	box, err := secretbox.LoadOrCreate(filepath.Join(*dataDir, "ssh.aes"))
	if err != nil {
		slog.Error("secret key", "err", err)
		os.Exit(1)
	}
	st.SetPasswordCodec(box)

	if err := migrateApkObfuscateFlags(context.Background(), st, sitesRoot); err != nil {
		slog.Warn("apk obfuscate migrate", "err", err)
	}
	if err := migrateSessionTTL(context.Background(), st); err != nil {
		slog.Warn("session ttl migrate", "err", err)
	}

	tpl, err := os.ReadFile(*templatePath)
	if err != nil {
		slog.Error("template", "err", err)
		os.Exit(1)
	}

	accountsPath := *lizhiAccounts
	if accountsPath == "" {
		accountsPath = filepath.Join(*dataDir, "lizhi-accounts.json")
	}
	bill := &billing.Service{Store: st, AccountsPath: accountsPath}

	authm := auth.New(st, *secureCookie)
	handler := httpapi.New(httpapi.Config{
		Frontend:          web.FS,
		Store:             st,
		Auth:              authm,
		SitesRoot:         sitesRoot,
		NginxTemplate:     string(tpl),
		NginxTemplatePath: *templatePath,
		Billing:           bill,
	})

	srv := &http.Server{
		Addr:              *listen,
		Handler:           handler,
		ReadHeaderTimeout: 10 * time.Second,
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	bill.StartBackground(ctx)
	go func() {
		<-ctx.Done()
		shCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		_ = srv.Shutdown(shCtx)
	}()

	slog.Info("listening", "addr", *listen, "sites", sitesRoot, "db", dbPath, "lizhi", accountsPath)
	if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		slog.Error("serve", "err", err)
		os.Exit(1)
	}
}
