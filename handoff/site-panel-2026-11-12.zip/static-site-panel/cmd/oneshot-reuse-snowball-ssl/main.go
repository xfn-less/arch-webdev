// Reuse Baota LE certs for snowball s27/s28 as panel manual SSL. No reissue.
package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"github.com/xfn/static-site-panel/internal/confmark"
	"github.com/xfn/static-site-panel/internal/secretbox"
	"github.com/xfn/static-site-panel/internal/sitesfs"
	"github.com/xfn/static-site-panel/internal/sslcert"
	"github.com/xfn/static-site-panel/internal/store"
)

func main() {
	dataDir := env("DATA", "/www/site-panel/.data")
	sitesRoot := env("SITES", "/www/site-panel/sites")
	keyPath := env("SSH_KEY", "/www/site-panel/.ssh/id_ed25519")

	jobs := []struct {
		Site   string
		Remote string // Baota cert dir on target
	}{
		{"s27", "/www/server/panel/vhost/cert/jsxq.vgqzgj.cn"},
		{"s28", "/www/server/panel/vhost/cert/220.167.104.233_8001"},
	}

	box, err := secretbox.LoadOrCreate(filepath.Join(dataDir, "ssh.aes"))
	must(err)
	st, err := store.Open(filepath.Join(dataDir, "panel.db"))
	must(err)
	defer st.Close()
	st.SetPasswordCodec(box)

	ctx := context.Background()
	srv, err := st.GetServer(ctx, 11)
	must(err)
	if srv.AuthValue == "" {
		srv.AuthValue = keyPath
	}

	for _, j := range jobs {
		log.Printf("== %s from %s ==", j.Site, j.Remote)
		fullchain, err := remoteCat(keyPath, srv, j.Remote+"/fullchain.pem")
		must(err)
		key, err := remoteCat(keyPath, srv, j.Remote+"/privkey.pem")
		must(err)

		dctx, cancel := context.WithTimeout(ctx, 3*time.Minute)
		res, err := sslcert.InstallManual(dctx, sslcert.Options{
			SitesRoot:  sitesRoot,
			SiteName:   j.Site,
			RemoteWWW:  "/www/sites/" + j.Site + "/www",
			RemoteConf: "/etc/nginx/conf.d/" + j.Site + ".conf",
			Server:     srv,
		}, fullchain, key, func(s string) { log.Println(" ", s) })
		cancel()
		must(err)

		confBody, _ := sitesfs.ReadConf(sitesRoot, j.Site)
		domains, _ := confmark.Domains(confBody)
		notAfter := int64(0)
		if !res.NotAfter.IsZero() {
			notAfter = res.NotAfter.Unix()
		}
		must(st.SetSiteSSL(ctx, j.Site, srv.ID, sslcert.DomainsKey(sslcert.CertHostnames(domains)), notAfter))
		log.Printf("ok %s primary=%s days=%d", j.Site, res.Primary, res.DaysLeft)
	}
	log.Println("done")
}

func remoteCat(key string, srv store.Server, path string) (string, error) {
	port := srv.Port
	if port == 0 {
		port = 22
	}
	user := srv.User
	if user == "" {
		user = "root"
	}
	cmd := exec.Command("ssh", "-i", key, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
		"-p", fmt.Sprintf("%d", port), fmt.Sprintf("%s@%s", user, srv.Host), "cat "+shellQuote(path))
	out, err := cmd.Output()
	if err != nil {
		return "", fmt.Errorf("cat %s: %w", path, err)
	}
	s := strings.TrimSpace(string(out))
	if s == "" {
		return "", fmt.Errorf("empty %s", path)
	}
	return s + "\n", nil
}

func shellQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'"
}

func must(err error) {
	if err != nil {
		log.Fatal(err)
	}
}

func env(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}
