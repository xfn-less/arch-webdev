// Restore deleted 220.167.104.233:10000 site on server 11, then caller does cutover.
package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"time"

	"github.com/xfn/static-site-panel/internal/deploy"
	"github.com/xfn/static-site-panel/internal/secretbox"
	"github.com/xfn/static-site-panel/internal/store"
)

func main() {
	dataDir := env("DATA", "/www/site-panel/.data")
	sitesRoot := env("SITES", "/www/site-panel/sites")
	keyPath := env("SSH_KEY", "/www/site-panel/.ssh/id_ed25519")
	box, err := secretbox.LoadOrCreate(filepath.Join(dataDir, "ssh.aes"))
	must(err)
	st, err := store.Open(filepath.Join(dataDir, "panel.db"))
	must(err)
	defer st.Close()
	st.SetPasswordCodec(box)
	ctx := context.Background()
	srv, err := st.GetServer(ctx, 11)
	must(err)
	if srv.AuthValue == "" {
		srv.AuthValue = keyPath
	}
	site, err := st.AllocSite(ctx, "220.167.104.233:10000", 11)
	must(err)
	log.Printf("allocated %s", site.Name)
	dir := filepath.Join(sitesRoot, site.Name)
	www := filepath.Join(dir, "www")
	must(os.MkdirAll(www, 0o755))
	root := "/www/sites/" + site.Name + "/www"
	conf := fmt.Sprintf(`server {
    listen 10000;
    # listen 443 ssl http2;

    # >>> 域名
    server_name 220.167.104.233;
    # <<< 域名

    # >>> SSL（面板自动生成，勿手改）
    # ssl_certificate     /path/to/fullchain.pem;
    # ssl_certificate_key /path/to/privkey.pem;
    # <<< SSL

    root %s;
    index index.html;

    server_tokens off;
    client_max_body_size 64m;

    location ^~ /.well-known/acme-challenge/ {
        root %s;
        default_type text/plain;
    }

    location / {
        proxy_pass http://45.192.169.244:8080;
        proxy_http_version 1.1;
        proxy_set_header Host $http_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $http_host;
        proxy_set_header X-Forwarded-Port $server_port;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_connect_timeout 60s;
        proxy_send_timeout 3600s;
        proxy_read_timeout 3600s;
    }
}
`, root, root)
	must(os.WriteFile(filepath.Join(dir, "nginx.conf"), []byte(conf), 0o644))
	dctx, cancel := context.WithTimeout(ctx, 3*time.Minute)
	defer cancel()
	res, err := deploy.Sync(dctx, deploy.Options{
		SitesRoot: sitesRoot, SiteName: site.Name, RemoteWWW: root,
		RemoteConf: "/etc/nginx/conf.d/" + site.Name + ".conf", Server: srv, ApkObfuscate: site.ApkObfuscate,
	}, func(s string) { log.Println(" ", s) })
	must(err)
	log.Printf("ok %s reloaded=%v", site.Name, res.Reloaded)
	fmt.Println(site.Name)
}

func must(err error) {
	if err != nil {
		log.Fatal(err)
	}
}

func env(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}
