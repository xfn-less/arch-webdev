// One-shot: prepare api.kbzomh.cn on 大业盘 (server 9). No cutover, no SSL, APK untouched.
package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"time"

	"github.com/xfn/static-site-panel/internal/deploy"
	"github.com/xfn/static-site-panel/internal/secretbox"
	"github.com/xfn/static-site-panel/internal/store"
)

const serverID = int64(9)

func main() {
	dataDir := env("DATA", "/www/site-panel/.data")
	sitesRoot := env("SITES", "/www/site-panel/sites")
	keyPath := env("SSH_KEY", "/www/site-panel/.ssh/id_ed25519")

	box, err := secretbox.LoadOrCreate(filepath.Join(dataDir, "ssh.aes"))
	if err != nil {
		log.Fatal(err)
	}
	st, err := store.Open(filepath.Join(dataDir, "panel.db"))
	if err != nil {
		log.Fatal(err)
	}
	defer st.Close()
	st.SetPasswordCodec(box)

	ctx := context.Background()
	srv, err := st.GetServer(ctx, serverID)
	if err != nil {
		log.Fatal("server 9: ", err)
	}
	if srv.AuthType == "key" && srv.AuthValue == "" {
		srv.AuthValue = keyPath
	}
	log.Printf("target %s@%s auth=%s", srv.User, srv.Host, srv.AuthType)

	site, err := st.AllocSite(ctx, "api.kbzomh.cn", serverID)
	if err != nil {
		log.Fatal("alloc: ", err)
	}
	log.Printf("allocated %s", site.Name)

	dir := filepath.Join(sitesRoot, site.Name)
	www := filepath.Join(dir, "www")
	if err := os.MkdirAll(www, 0o755); err != nil {
		log.Fatal(err)
	}

	log.Printf("tar-pull /www/wwwroot/api.kbzomh.cn → %s", www)
	if err := tarPull(keyPath, srv, "/www/wwwroot/api.kbzomh.cn", www); err != nil {
		log.Fatal(err)
	}

	rootRemote := "/www/sites/" + site.Name + "/www"
	if err := os.WriteFile(filepath.Join(dir, "nginx.conf"), []byte(confAPIKBZOMH(rootRemote)), 0o644); err != nil {
		log.Fatal(err)
	}

	log.Printf("deploy.Sync %s (apk=%v) — baota untouched", site.Name, site.ApkObfuscate)
	dctx, cancel := context.WithTimeout(ctx, 5*time.Minute)
	defer cancel()
	res, err := deploy.Sync(dctx, deploy.Options{
		SitesRoot:    sitesRoot,
		SiteName:     site.Name,
		RemoteWWW:    rootRemote,
		RemoteConf:   "/etc/nginx/conf.d/" + site.Name + ".conf",
		Server:       srv,
		ApkObfuscate: site.ApkObfuscate,
	}, func(s string) { log.Println(" ", s) })
	if err != nil {
		log.Fatalf("deploy: %v\n%+v", err, res)
	}
	log.Printf("ok %s skippedConf=%v reloaded=%v — stop before cutover", site.Name, res.SkippedConf, res.Reloaded)
}

func confAPIKBZOMH(root string) string {
	return fmt.Sprintf(`# dual upstream ~50/50; Host/SNI must match chosen backend
split_clients "${remote_addr}${request_uri}${msec}" $api_upstream {
    50%%     finlark_backend;
    *       uhgddiv_backend;
}

map $api_upstream $api_backend_host {
    finlark_backend   api.finlark.cn;
    uhgddiv_backend   api.uhgddiv.com;
    default           api.finlark.cn;
}

upstream finlark_backend {
    server api.finlark.cn:443 max_fails=3 fail_timeout=30s;
    keepalive 16;
}

upstream uhgddiv_backend {
    server api.uhgddiv.com:443 max_fails=3 fail_timeout=30s;
    keepalive 16;
}

server {
    listen 80;
    # listen 443 ssl http2;

    # >>> 域名
    server_name api.kbzomh.cn;
    # <<< 域名

    # >>> SSL（面板自动生成，勿手改）
    # ssl_certificate     /path/to/fullchain.pem;
    # ssl_certificate_key /path/to/privkey.pem;
    # <<< SSL

    root %s;
    index index.html;

    server_tokens off;
    client_max_body_size 64m;

    location ^~ /.well-known/acme-challenge/ {
        root %s;
        default_type text/plain;
    }

    location / {
        proxy_http_version 1.1;
        proxy_pass https://$api_upstream;

        proxy_ssl_server_name on;
        proxy_ssl_name $api_backend_host;
        proxy_ssl_protocols TLSv1.2 TLSv1.3;
        proxy_ssl_verify off;

        proxy_set_header Host $api_backend_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
        proxy_set_header Connection "";

        proxy_connect_timeout 30s;
        proxy_send_timeout 300s;
        proxy_read_timeout 300s;

        proxy_next_upstream error timeout http_502 http_503 http_504;
        proxy_next_upstream_tries 2;
    }
}
`, root, root)
}

func tarPull(key string, srv store.Server, remoteDir, localWWW string) error {
	port := srv.Port
	if port == 0 {
		port = 22
	}
	user := srv.User
	if user == "" {
		user = "root"
	}
	target := fmt.Sprintf("%s@%s", user, srv.Host)
	ssh := exec.Command("ssh",
		"-i", key,
		"-o", "BatchMode=yes",
		"-o", "StrictHostKeyChecking=yes",
		"-p", fmt.Sprintf("%d", port),
		target,
		fmt.Sprintf("tar -C %s -czf - .", remoteDir),
	)
	tar := exec.Command("tar", "-C", localWWW, "-xzf", "-")
	pr, pw, err := os.Pipe()
	if err != nil {
		return err
	}
	ssh.Stdout = pw
	ssh.Stderr = os.Stderr
	tar.Stdin = pr
	tar.Stdout = os.Stdout
	tar.Stderr = os.Stderr
	if err := ssh.Start(); err != nil {
		return err
	}
	if err := tar.Start(); err != nil {
		_ = ssh.Process.Kill()
		return err
	}
	_ = pw.Close()
	errTar := tar.Wait()
	errSSH := ssh.Wait()
	_ = pr.Close()
	if errSSH != nil {
		return fmt.Errorf("ssh tar: %w", errSSH)
	}
	if errTar != nil {
		return fmt.Errorf("local tar: %w", errTar)
	}
	return nil
}

func env(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}
