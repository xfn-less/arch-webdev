// One-shot / ops: install unknown-Host catch-all on every server in panel.db.
package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/xfn/static-site-panel/internal/deploy"
	"github.com/xfn/static-site-panel/internal/secretbox"
	"github.com/xfn/static-site-panel/internal/store"
)

func main() {
	dataDir := flag.String("data", "/www/site-panel/.data", "panel data directory")
	only := flag.String("only", "", "optional comma-separated server ids")
	forcePassword := flag.Bool("force-password", false, "use stored SSH password even when auth_type=key")
	flag.Parse()

	ctx := context.Background()
	st, err := store.Open(filepath.Join(*dataDir, "panel.db"))
	if err != nil {
		fatal(err)
	}
	defer st.Close()
	box, err := secretbox.LoadOrCreate(filepath.Join(*dataDir, "ssh.aes"))
	if err != nil {
		fatal(err)
	}
	st.SetPasswordCodec(box)

	servers, err := st.ListServers(ctx)
	if err != nil {
		fatal(err)
	}
	allow := map[int64]bool{}
	if strings.TrimSpace(*only) != "" {
		for _, p := range strings.Split(*only, ",") {
			p = strings.TrimSpace(p)
			if p == "" {
				continue
			}
			var id int64
			if _, err := fmt.Sscanf(p, "%d", &id); err != nil {
				fatal(fmt.Errorf("bad id %q", p))
			}
			allow[id] = true
		}
	}

	var failed int
	for _, srv := range servers {
		if len(allow) > 0 && !allow[srv.ID] {
			continue
		}
		name := srv.Name
		if name == "" {
			name = srv.Host
		}
		fmt.Printf("==> #%d %s (%s)\n", srv.ID, name, srv.Host)
		if *forcePassword && strings.TrimSpace(srv.Password) != "" {
			srv.AuthType = "password"
		}
		cctx, cancel := context.WithTimeout(ctx, 2*time.Minute)
		err := deploy.EnsureDefaultCatchAll(cctx, srv, func(s string) { fmt.Println("  ", s) })
		cancel()
		if err != nil {
			fmt.Printf("FAIL: %v\n", err)
			failed++
			continue
		}
		fmt.Println("OK")
	}
	if failed > 0 {
		os.Exit(1)
	}
}

func fatal(err error) {
	fmt.Fprintln(os.Stderr, err)
	os.Exit(1)
}
