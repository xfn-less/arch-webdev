// Migrate 真格 智阔 103.36.222.33 (server 12): prepare + cutover + reuse Baota certs (incl. commercial).
package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"github.com/xfn/static-site-panel/internal/confmark"
	"github.com/xfn/static-site-panel/internal/deploy"
	"github.com/xfn/static-site-panel/internal/secretbox"
	"github.com/xfn/static-site-panel/internal/sitesfs"
	"github.com/xfn/static-site-panel/internal/sslcert"
	"github.com/xfn/static-site-panel/internal/store"
)

const serverID = int64(12)

type siteSpec struct {
	Title   string
	Remote  string // empty = skip tar
	Domains []string
	CertDir string // Baota cert dir; empty = no SSL
	Conf    func(root string) string
}

func main() {
	dataDir := env("DATA", "/www/site-panel/.data")
	sitesRoot := env("SITES", "/www/site-panel/sites")
	keyPath := env("SSH_KEY", "/www/site-panel/.ssh/id_ed25519")

	specs := []siteSpec{
		{
			Title:   "zkchat.geefpmu.cn 智阅客服转发",
			Remote:  "",
			Domains: []string{"zkchat.geefpmu.cn"},
			CertDir: "/www/server/panel/vhost/cert/zkchat.geefpmu.cn",
			Conf:    confZkchat,
		},
		{
			Title:   "down.geefpmu.cn 智阅 下载",
			Remote:  "/www/wwwroot/down.geefpmu.cn",
			Domains: []string{"down.geefpmu.cn"},
			CertDir: "/www/server/panel/vhost/cert/down.geefpmu.cn",
			Conf:    confStaticSPA,
		},
		{
			Title:   "103.36.222.33:10000 智阅 转发",
			Remote:  "",
			Domains: []string{"103.36.222.33"},
			Conf:    confIP10000,
		},
		{
			Title:   "down.ouqvpa.cn 真格 下载",
			Remote:  "/www/wwwroot/down.ouqvpa.cn",
			Domains: []string{"down.ouqvpa.cn", "vow.ouqvpa.cn", "wof.ouqvpa.cn"},
			CertDir: "/www/server/panel/vhost/cert/down.ouqvpa.cn",
			Conf:    confStaticSPA,
		},
	}

	box, err := secretbox.LoadOrCreate(filepath.Join(dataDir, "ssh.aes"))
	must(err)
	st, err := store.Open(filepath.Join(dataDir, "panel.db"))
	must(err)
	defer st.Close()
	st.SetPasswordCodec(box)

	ctx := context.Background()
	srv, err := st.GetServer(ctx, serverID)
	must(err)
	if srv.AuthType == "key" && srv.AuthValue == "" {
		srv.AuthValue = keyPath
	}
	log.Printf("target %s@%s", srv.User, srv.Host)

	must(runSSH(keyPath, srv, "command -v rsync >/dev/null || (export DEBIAN_FRONTEND=noninteractive; apt-get update -qq && apt-get install -y -qq rsync)"))
	must(runSSH(keyPath, srv, "mkdir -p /etc/nginx/conf.d /www/sites"))

	var allocated []string
	for _, sp := range specs {
		site, err := st.AllocSite(ctx, sp.Title, serverID)
		must(err)
		log.Printf("allocated %s → %s", sp.Title, site.Name)
		allocated = append(allocated, site.Name)

		dir := filepath.Join(sitesRoot, site.Name)
		www := filepath.Join(dir, "www")
		must(os.MkdirAll(www, 0o755))
		if sp.Remote != "" {
			log.Printf("tar-pull %s", sp.Remote)
			must(tarPull(keyPath, srv, sp.Remote, www))
		} else {
			log.Printf("skip tar %s", site.Name)
		}
		rootRemote := "/www/sites/" + site.Name + "/www"
		body := strings.ReplaceAll(sp.Conf(rootRemote), "__DOMAINS__", strings.Join(sp.Domains, " "))
		must(os.WriteFile(filepath.Join(dir, "nginx.conf"), []byte(body), 0o644))

		dctx, cancel := context.WithTimeout(ctx, 5*time.Minute)
		_, err = deploy.Sync(dctx, deploy.Options{
			SitesRoot: sitesRoot, SiteName: site.Name, RemoteWWW: rootRemote,
			RemoteConf: "/etc/nginx/conf.d/" + site.Name + ".conf", Server: srv, ApkObfuscate: site.ApkObfuscate,
		}, func(s string) { log.Println(" ", s) })
		cancel()
		must(err)
		log.Printf("synced %s", site.Name)
	}

	log.Println("== cutover ==")
	must(runSSHScript(keyPath, srv, cutoverScript()))

	for i, sp := range specs {
		if sp.CertDir == "" {
			continue
		}
		name := allocated[i]
		log.Printf("== SSL %s from %s ==", name, sp.CertDir)
		fullchain, err := remoteCat(keyPath, srv, sp.CertDir+"/fullchain.pem")
		must(err)
		key, err := remoteCat(keyPath, srv, sp.CertDir+"/privkey.pem")
		must(err)
		dctx, cancel := context.WithTimeout(ctx, 3*time.Minute)
		res, err := sslcert.InstallManual(dctx, sslcert.Options{
			SitesRoot: sitesRoot, SiteName: name,
			RemoteWWW: "/www/sites/" + name + "/www", RemoteConf: "/etc/nginx/conf.d/" + name + ".conf", Server: srv,
		}, fullchain, key, func(s string) { log.Println(" ", s) })
		cancel()
		must(err)
		confBody, _ := sitesfs.ReadConf(sitesRoot, name)
		domains, _ := confmark.Domains(confBody)
		notAfter := int64(0)
		if !res.NotAfter.IsZero() {
			notAfter = res.NotAfter.Unix()
		}
		must(st.SetSiteSSL(ctx, name, srv.ID, sslcert.DomainsKey(sslcert.CertHostnames(domains)), notAfter))
		log.Printf("ssl ok %s days=%d", name, res.DaysLeft)
	}

	log.Println("done")
}

func domainSSL(root string) string {
	return fmt.Sprintf(`    listen 80;
    # listen 443 ssl http2;

    # >>> 域名
    server_name __DOMAINS__;
    # <<< 域名

    # >>> SSL（面板自动生成，勿手改）
    # ssl_certificate     /path/to/fullchain.pem;
    # ssl_certificate_key /path/to/privkey.pem;
    # <<< SSL

    root %s;
    index index.html;

    server_tokens off;
    client_max_body_size 64m;

    location ^~ /.well-known/acme-challenge/ {
        root %s;
        default_type text/plain;
    }
`, root, root)
}

func confStaticSPA(root string) string {
	return `server {
` + domainSSL(root) + `
    location / {
        try_files $uri $uri/ /index.html;
        expires off;
        add_header Cache-Control "no-cache";
    }
}
`
}

func confZkchat(root string) string {
	return `server {
` + domainSSL(root) + `
    location / {
        proxy_pass http://154.198.50.73:8090;
        proxy_http_version 1.1;
        proxy_set_header Host 154.198.50.73:8090;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_connect_timeout 60s;
        proxy_send_timeout 3600s;
        proxy_read_timeout 3600s;
    }
}
`
}

func confIP10000(root string) string {
	return fmt.Sprintf(`server {
    listen 10000;
    # listen 443 ssl http2;

    # >>> 域名
    server_name __DOMAINS__;
    # <<< 域名

    # >>> SSL（面板自动生成，勿手改）
    # ssl_certificate     /path/to/fullchain.pem;
    # ssl_certificate_key /path/to/privkey.pem;
    # <<< SSL

    root %s;
    index index.html;

    server_tokens off;
    client_max_body_size 64m;

    location ^~ /.well-known/acme-challenge/ {
        root %s;
        default_type text/plain;
    }

    location / {
        proxy_pass http://154.198.50.73:8080;
        proxy_http_version 1.1;
        proxy_set_header Host 154.198.50.73:8080;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_connect_timeout 60s;
        proxy_send_timeout 3600s;
        proxy_read_timeout 3600s;
    }
}
`, root, root)
}

func cutoverScript() string {
	return `set -euo pipefail
TS=$(date +%Y%m%d-%H%M%S)
mkdir -p /root/zhige-cutover-$TS
cp -a /www/server/nginx/conf/nginx.conf /root/zhige-cutover-$TS/

for f in zkchat.geefpmu.cn down.geefpmu.cn down.ouqvpa.cn 103.36.222.33; do
  conf=/www/server/panel/vhost/nginx/$f.conf
  if [ -f "$conf" ]; then
    cp -a "$conf" /root/zhige-cutover-$TS/
    mv -f "$conf" "$conf.off-panel-$TS"
    echo "off $f"
  fi
done

if ! grep -qE 'include[[:space:]]+/etc/nginx/conf\.d/\*\.conf' /www/server/nginx/conf/nginx.conf; then
  sed -i 's|include /www/server/panel/vhost/nginx/\*\.conf;|include /www/server/panel/vhost/nginx/*.conf;\ninclude /etc/nginx/conf.d/*.conf;|' /www/server/nginx/conf/nginx.conf
fi
grep -n 'conf.d\|vhost/nginx/\*\.conf' /www/server/nginx/conf/nginx.conf
ls -la /etc/nginx/conf.d/
/www/server/nginx/sbin/nginx -t -c /www/server/nginx/conf/nginx.conf

/etc/init.d/nginx stop || true
for i in $(seq 1 20); do
  ss -lntp | grep -E ':80 |:443 |:10000 ' >/dev/null || break
  sleep 1
done

update-rc.d nginx disable 2>/dev/null || true
systemctl disable nginx 2>/dev/null || true
/etc/init.d/bt stop || true
update-rc.d bt disable 2>/dev/null || true
systemctl disable bt 2>/dev/null || true
systemctl disable --now bt btpanel 2>/dev/null || true

cat > /etc/systemd/system/panel-nginx.service <<'UNIT'
[Unit]
Description=Panel Nginx (Baota binary + panel conf.d)
After=network-online.target
Wants=network-online.target

[Service]
Type=forking
PIDFile=/www/server/nginx/logs/nginx.pid
ExecStartPre=/bin/rm -f /www/server/nginx/logs/nginx.pid
ExecStartPre=/www/server/nginx/sbin/nginx -t -c /www/server/nginx/conf/nginx.conf
ExecStart=/www/server/nginx/sbin/nginx -c /www/server/nginx/conf/nginx.conf
ExecReload=/www/server/nginx/sbin/nginx -s reload
ExecStop=/bin/kill -s QUIT $MAINPID
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable panel-nginx
systemctl start panel-nginx
sleep 1
systemctl is-active panel-nginx
ss -lntp | grep -E ':80|:443|:10000' || true
echo CUTOVER_OK
`
}

func remoteCat(key string, srv store.Server, path string) (string, error) {
	port := srv.Port
	if port == 0 {
		port = 22
	}
	user := srv.User
	if user == "" {
		user = "root"
	}
	cmd := exec.Command("ssh", "-i", key, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
		"-p", fmt.Sprintf("%d", port), fmt.Sprintf("%s@%s", user, srv.Host), "cat "+shellQuote(path))
	out, err := cmd.Output()
	if err != nil {
		return "", fmt.Errorf("cat %s: %w", path, err)
	}
	s := strings.TrimSpace(string(out))
	if s == "" {
		return "", fmt.Errorf("empty %s", path)
	}
	return s + "\n", nil
}

func tarPull(key string, srv store.Server, remoteDir, localWWW string) error {
	port := srv.Port
	if port == 0 {
		port = 22
	}
	user := srv.User
	if user == "" {
		user = "root"
	}
	target := fmt.Sprintf("%s@%s", user, srv.Host)
	ssh := exec.Command("ssh", "-i", key, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
		"-p", fmt.Sprintf("%d", port), target, fmt.Sprintf("tar -C %s -czf - .", remoteDir))
	tar := exec.Command("tar", "-C", localWWW, "-xzf", "-")
	pr, pw, err := os.Pipe()
	if err != nil {
		return err
	}
	ssh.Stdout = pw
	ssh.Stderr = os.Stderr
	tar.Stdin = pr
	tar.Stdout = os.Stdout
	tar.Stderr = os.Stderr
	if err := ssh.Start(); err != nil {
		return err
	}
	if err := tar.Start(); err != nil {
		_ = ssh.Process.Kill()
		return err
	}
	_ = pw.Close()
	errTar := tar.Wait()
	errSSH := ssh.Wait()
	_ = pr.Close()
	if errSSH != nil {
		return fmt.Errorf("ssh tar: %w", errSSH)
	}
	return errTar
}

func runSSH(key string, srv store.Server, remoteCmd string) error {
	port := srv.Port
	if port == 0 {
		port = 22
	}
	user := srv.User
	if user == "" {
		user = "root"
	}
	cmd := exec.Command("ssh", "-i", key, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
		"-p", fmt.Sprintf("%d", port), fmt.Sprintf("%s@%s", user, srv.Host), remoteCmd)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

func runSSHScript(key string, srv store.Server, script string) error {
	port := srv.Port
	if port == 0 {
		port = 22
	}
	user := srv.User
	if user == "" {
		user = "root"
	}
	cmd := exec.Command("ssh", "-i", key, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
		"-p", fmt.Sprintf("%d", port), fmt.Sprintf("%s@%s", user, srv.Host), "bash", "-s")
	cmd.Stdin = strings.NewReader(script)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

func shellQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'"
}

func must(err error) {
	if err != nil {
		log.Fatal(err)
	}
}

func env(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}
