// Migrate 鼎鑫 隆泰 220.167.104.132 (server 13): prepare + cutover to apt nginx + reuse Baota certs.
// Skips riv/rsdk (Baota "stop" pages).
package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"github.com/xfn/static-site-panel/internal/confmark"
	"github.com/xfn/static-site-panel/internal/deploy"
	"github.com/xfn/static-site-panel/internal/secretbox"
	"github.com/xfn/static-site-panel/internal/sitesfs"
	"github.com/xfn/static-site-panel/internal/sslcert"
	"github.com/xfn/static-site-panel/internal/store"
)

const serverID = int64(13)

type siteSpec struct {
	Title   string
	Remote  string
	Domains []string
	CertDir string
	Conf    func(root string) string
}

func main() {
	dataDir := env("DATA", "/www/site-panel/.data")
	sitesRoot := env("SITES", "/www/site-panel/sites")
	keyPath := env("SSH_KEY", "/www/site-panel/.ssh/id_ed25519")

	specs := []siteSpec{
		{
			Title:   "dllt.aaunmb.cn 鼎鑫 下载",
			Remote:  "/www/wwwroot/dllt.aaunmb.cn",
			Domains: []string{"dllt.aaunmb.cn", "dlon.aaunmb.cn"},
			CertDir: "/www/server/panel/vhost/cert/dllt.aaunmb.cn",
			Conf:    confStaticSPA,
		},
		{
			Title:   "dxky 鼎鑫 下载",
			Remote:  "/www/wwwroot/down.dwrhvij.cn",
			Domains: []string{"dxky2.dwrhvij.cn", "dxky1.dwrhvij.cn"},
			CertDir: "/www/server/panel/vhost/cert/down.dwrhvij.cn",
			Conf:    confStaticSPA,
		},
		{
			Title:   "jxk.dwrhvij.cn 鼎鑫 web 转发",
			Remote:  "/www/wwwroot/web.dwrhvij.cn",
			Domains: []string{"jxk.dwrhvij.cn", "jxy.dwrhvij.cn", "220.167.104.132"},
			CertDir: "/www/server/panel/vhost/cert/web.dwrhvij.cn",
			Conf:    confWebProxy,
		},
		{
			Title:   "wlt.aaunmb.cn 鼎鑫 转发",
			Remote:  "/www/wwwroot/wlt.aaunmb.cn",
			Domains: []string{"wlt.aaunmb.cn", "vlt.aaunmb.cn", "220.167.104.132"},
			CertDir: "/www/server/panel/vhost/cert/wlt.aaunmb.cn",
			Conf:    confWltProxy,
		},
	}

	box, err := secretbox.LoadOrCreate(filepath.Join(dataDir, "ssh.aes"))
	must(err)
	st, err := store.Open(filepath.Join(dataDir, "panel.db"))
	must(err)
	defer st.Close()
	st.SetPasswordCodec(box)

	ctx := context.Background()
	srv, err := st.GetServer(ctx, serverID)
	must(err)
	if srv.AuthType == "key" && srv.AuthValue == "" {
		srv.AuthValue = keyPath
	}
	log.Printf("target %s@%s", srv.User, srv.Host)

	must(runSSH(keyPath, srv, "command -v rsync >/dev/null || (export DEBIAN_FRONTEND=noninteractive; apt-get update -qq && apt-get install -y -qq rsync)"))
	must(runSSH(keyPath, srv, "mkdir -p /etc/nginx/conf.d /www/sites"))

	var allocated []string
	for _, sp := range specs {
		site, err := st.AllocSite(ctx, sp.Title, serverID)
		must(err)
		log.Printf("allocated %s → %s", sp.Title, site.Name)
		allocated = append(allocated, site.Name)

		dir := filepath.Join(sitesRoot, site.Name)
		www := filepath.Join(dir, "www")
		must(os.MkdirAll(www, 0o755))
		if sp.Remote != "" {
			log.Printf("tar-pull %s", sp.Remote)
			must(tarPull(keyPath, srv, sp.Remote, www))
		}
		rootRemote := "/www/sites/" + site.Name + "/www"
		body := strings.ReplaceAll(sp.Conf(rootRemote), "__DOMAINS__", strings.Join(sp.Domains, " "))
		must(os.WriteFile(filepath.Join(dir, "nginx.conf"), []byte(body), 0o644))

		dctx, cancel := context.WithTimeout(ctx, 5*time.Minute)
		_, err = deploy.Sync(dctx, deploy.Options{
			SitesRoot: sitesRoot, SiteName: site.Name, RemoteWWW: rootRemote,
			RemoteConf: "/etc/nginx/conf.d/" + site.Name + ".conf", Server: srv, ApkObfuscate: site.ApkObfuscate,
		}, func(s string) { log.Println(" ", s) })
		cancel()
		must(err)
		log.Printf("synced %s", site.Name)
	}

	log.Println("== cutover apt nginx ==")
	must(runSSHScript(keyPath, srv, cutoverAptScript(allocated)))

	for i, sp := range specs {
		if sp.CertDir == "" {
			continue
		}
		name := allocated[i]
		log.Printf("== SSL %s from %s ==", name, sp.CertDir)
		fullchain, err := remoteCat(keyPath, srv, sp.CertDir+"/fullchain.pem")
		must(err)
		key, err := remoteCat(keyPath, srv, sp.CertDir+"/privkey.pem")
		must(err)
		dctx, cancel := context.WithTimeout(ctx, 3*time.Minute)
		res, err := sslcert.InstallManual(dctx, sslcert.Options{
			SitesRoot: sitesRoot, SiteName: name,
			RemoteWWW: "/www/sites/" + name + "/www", RemoteConf: "/etc/nginx/conf.d/" + name + ".conf", Server: srv,
		}, fullchain, key, func(s string) { log.Println(" ", s) })
		cancel()
		must(err)
		confBody, _ := sitesfs.ReadConf(sitesRoot, name)
		domains, _ := confmark.Domains(confBody)
		notAfter := int64(0)
		if !res.NotAfter.IsZero() {
			notAfter = res.NotAfter.Unix()
		}
		must(st.SetSiteSSL(ctx, name, srv.ID, sslcert.DomainsKey(sslcert.CertHostnames(domains)), notAfter))
		log.Printf("ssl ok %s days=%d", name, res.DaysLeft)
	}

	log.Println("done sites:", strings.Join(allocated, " "))
}

func domainSSL(root string) string {
	return fmt.Sprintf(`    listen 80;
    # listen 443 ssl http2;

    # >>> 域名
    server_name __DOMAINS__;
    # <<< 域名

    # >>> SSL（面板自动生成，勿手改）
    # ssl_certificate     /path/to/fullchain.pem;
    # ssl_certificate_key /path/to/privkey.pem;
    # <<< SSL

    root %s;
    index index.html;

    server_tokens off;
    client_max_body_size 64m;

    location ^~ /.well-known/acme-challenge/ {
        root %s;
        default_type text/plain;
    }
`, root, root)
}

func confStaticSPA(root string) string {
	return `server {
` + domainSSL(root) + `
    location / {
        try_files $uri $uri/ /index.html;
        expires off;
        add_header Cache-Control "no-cache";
    }
}
`
}

func confWebProxy(root string) string {
	return fmt.Sprintf(`server {
    listen 80;
    listen 10000;
    # listen 443 ssl http2;

    # >>> 域名
    server_name __DOMAINS__;
    # <<< 域名

    # >>> SSL（面板自动生成，勿手改）
    # ssl_certificate     /path/to/fullchain.pem;
    # ssl_certificate_key /path/to/privkey.pem;
    # <<< SSL

    root %s;
    index index.html;

    server_tokens off;
    client_max_body_size 64m;

    location ^~ /.well-known/acme-challenge/ {
        root %s;
        default_type text/plain;
    }

    location ~ ^/(api|uploads)(/|$) {
        proxy_pass http://45.194.37.172:8080;
        proxy_http_version 1.1;
        proxy_set_header Host 45.194.37.172:8080;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        proxy_cache off;
    }

    location ~* \.(html?|js|mjs|css|gif|jpe?g|png|bmp|webp|avif|svg|ico|woff2?|ttf)$ {
        try_files $uri =404;
        expires off;
        add_header Cache-Control "no-cache";
    }

    location / {
        try_files $uri $uri/ /index.html;
        expires off;
        add_header Cache-Control "no-cache";
    }
}
`, root, root)
}

func confWltProxy(root string) string {
	return fmt.Sprintf(`server {
    listen 80;
    listen 10003;
    # listen 443 ssl http2;

    # >>> 域名
    server_name __DOMAINS__;
    # <<< 域名

    # >>> SSL（面板自动生成，勿手改）
    # ssl_certificate     /path/to/fullchain.pem;
    # ssl_certificate_key /path/to/privkey.pem;
    # <<< SSL

    root %s;
    index index.html;

    server_tokens off;
    client_max_body_size 64m;

    location ^~ /.well-known/acme-challenge/ {
        root %s;
        default_type text/plain;
    }

    location ~ ^/(api|uploads)(/|$) {
        proxy_pass http://45.192.170.35:8080;
        proxy_http_version 1.1;
        proxy_set_header Host 45.192.170.35:8080;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        proxy_cache off;
    }

    location ~* \.(html?|js|mjs|css|gif|jpe?g|png|bmp|webp|avif|svg|ico|woff2?|ttf)$ {
        try_files $uri =404;
        expires off;
        add_header Cache-Control "no-cache";
    }

    location / {
        try_files $uri $uri/ /index.html;
        expires off;
        add_header Cache-Control "no-cache";
    }
}
`, root, root)
}

func cutoverAptScript(siteNames []string) string {
	var confChecks strings.Builder
	for _, n := range siteNames {
		confChecks.WriteString(fmt.Sprintf("test -f /etc/nginx/conf.d/%s.conf\n", n))
	}
	return `set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
TS=$(date +%Y%m%d-%H%M%S)
mkdir -p /root/dingxin-cutover-$TS
cp -a /www/server/nginx/conf/nginx.conf /root/dingxin-cutover-$TS/ 2>/dev/null || true

for f in dllt.aaunmb.cn down.dwrhvij.cn web.dwrhvij.cn wlt.aaunmb.cn riv.dwrhvij.cn rsdk.dwrhvij.cn; do
  conf=/www/server/panel/vhost/nginx/$f.conf
  if [ -f "$conf" ]; then
    cp -a "$conf" /root/dingxin-cutover-$TS/
    mv -f "$conf" "$conf.off-panel-$TS"
    echo "off $f"
  fi
done

` + confChecks.String() + `
if [ ! -f /etc/nginx/conf.d/00-default.conf ]; then
  printf '%s\n' 'server { listen 80 default_server; listen [::]:80 default_server; server_name _; return 204; }' > /etc/nginx/conf.d/00-default.conf
fi
rm -f /etc/nginx/sites-enabled/default

# Stop Baota nginx + panel first so apt can bind 80/443 (do not uninstall)
/etc/init.d/nginx stop 2>/dev/null || true
systemctl stop panel-nginx 2>/dev/null || true
systemctl disable panel-nginx 2>/dev/null || true
pkill -f /www/server/nginx/sbin/nginx 2>/dev/null || true
sleep 1
for i in $(seq 1 25); do
  ss -lntp | grep -E ':80 |:443 |:10000 |:10003 ' >/dev/null || break
  pkill -f /www/server/nginx/sbin/nginx 2>/dev/null || true
  sleep 0.5
done

/etc/init.d/bt stop 2>/dev/null || true
update-rc.d bt disable 2>/dev/null || true
systemctl disable --now bt btpanel 2>/dev/null || true

# Install apt nginx after ports are free
apt-get update -qq
apt-get -y -o Dpkg::Options::="--force-confnew" install -y nginx
dpkg --configure -a || true
test -x /usr/sbin/nginx

if grep -Rql --include='*.conf' 'http2 on;' /etc/nginx/conf.d/ 2>/dev/null; then
  python3 - <<'PY'
from pathlib import Path
import re
for p in Path("/etc/nginx/conf.d").glob("*.conf"):
    t=p.read_text()
    n=t.replace("\n    http2 on;\n","\n").replace("\n    http2 on;","\n")
    n=re.sub(r"(?m)^(\s*listen\s+443\s+ssl)\s*;", r"\1 http2;", n)
    if n!=t: p.write_text(n)
PY
fi

# apt postinst may recreate sites-enabled/default — remove after install
rm -f /etc/nginx/sites-enabled/default
/usr/sbin/nginx -t
ln -sfn /usr/sbin/nginx /usr/bin/nginx
ln -sfn /usr/sbin/nginx /bin/nginx
systemctl enable nginx
systemctl restart nginx
sleep 1
systemctl is-active nginx
echo -n "master="; ps -o args= -C nginx | head -1
ss -lntp | grep -E ':80|:443|:10000|:10003' || true
echo CUTOVER_OK
`
}

func remoteCat(key string, srv store.Server, path string) (string, error) {
	port := srv.Port
	if port == 0 {
		port = 22
	}
	user := srv.User
	if user == "" {
		user = "root"
	}
	cmd := exec.Command("ssh", "-i", key, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
		"-p", fmt.Sprintf("%d", port), fmt.Sprintf("%s@%s", user, srv.Host), "cat "+shellQuote(path))
	out, err := cmd.Output()
	if err != nil {
		return "", fmt.Errorf("cat %s: %w", path, err)
	}
	s := strings.TrimSpace(string(out))
	if s == "" {
		return "", fmt.Errorf("empty %s", path)
	}
	return s + "\n", nil
}

func tarPull(key string, srv store.Server, remoteDir, localWWW string) error {
	port := srv.Port
	if port == 0 {
		port = 22
	}
	user := srv.User
	if user == "" {
		user = "root"
	}
	target := fmt.Sprintf("%s@%s", user, srv.Host)
	ssh := exec.Command("ssh", "-i", key, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
		"-p", fmt.Sprintf("%d", port), target, fmt.Sprintf("tar -C %s -czf - .", shellQuote(remoteDir)))
	tar := exec.Command("tar", "-C", localWWW, "-xzf", "-")
	pr, pw, err := os.Pipe()
	if err != nil {
		return err
	}
	ssh.Stdout = pw
	ssh.Stderr = os.Stderr
	tar.Stdin = pr
	tar.Stdout = os.Stdout
	tar.Stderr = os.Stderr
	if err := ssh.Start(); err != nil {
		return err
	}
	if err := tar.Start(); err != nil {
		_ = ssh.Process.Kill()
		return err
	}
	_ = pw.Close()
	errTar := tar.Wait()
	errSSH := ssh.Wait()
	_ = pr.Close()
	if errSSH != nil {
		return fmt.Errorf("ssh tar: %w", errSSH)
	}
	return errTar
}

func runSSH(key string, srv store.Server, remoteCmd string) error {
	port := srv.Port
	if port == 0 {
		port = 22
	}
	user := srv.User
	if user == "" {
		user = "root"
	}
	cmd := exec.Command("ssh", "-i", key, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
		"-p", fmt.Sprintf("%d", port), fmt.Sprintf("%s@%s", user, srv.Host), remoteCmd)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

func runSSHScript(key string, srv store.Server, script string) error {
	port := srv.Port
	if port == 0 {
		port = 22
	}
	user := srv.User
	if user == "" {
		user = "root"
	}
	cmd := exec.Command("ssh", "-i", key, "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
		"-p", fmt.Sprintf("%d", port), fmt.Sprintf("%s@%s", user, srv.Host), "bash", "-s")
	cmd.Stdin = strings.NewReader(script)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

func shellQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'"
}

func must(err error) {
	if err != nil {
		log.Fatal(err)
	}
}

func env(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}
