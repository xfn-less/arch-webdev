// One-shot billing sync against the panel data dir (no HTTP).
package main

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"github.com/xfn/static-site-panel/internal/billing"
	"github.com/xfn/static-site-panel/internal/store"
)

func main() {
	data := "/www/site-panel/.data"
	if len(os.Args) > 1 {
		data = os.Args[1]
	}
	st, err := store.Open(filepath.Join(data, "panel.db"))
	if err != nil {
		fatal(err)
	}
	defer st.Close()
	svc := &billing.Service{Store: st, AccountsPath: filepath.Join(data, "lizhi-accounts.json")}
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Minute)
	defer cancel()
	if err := svc.Sync(ctx, func(line string) { fmt.Println(line) }); err != nil {
		fatal(err)
	}
}

func fatal(err error) {
	fmt.Fprintln(os.Stderr, err)
	os.Exit(1)
}
