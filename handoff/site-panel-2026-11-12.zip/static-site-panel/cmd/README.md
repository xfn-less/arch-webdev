# Commands

`panel` is the long-running application and the only command used for normal releases.

`oneshot-*` directories contain historical, task-specific migration or repair programs. They remain in source control for audit and reproducibility; they are not part of the normal panel deployment workflow.
