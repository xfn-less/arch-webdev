# 部署与备份

生产目录：`/www/site-panel`。面板本机监听，经 Nginx 反代到 `https://site-panel.xfnss.top/`。

## 目录

```text
/www/site-panel/
  bin/panel
  sites/                 # 站点主控副本
  templates/
  scripts/
    backup.sh            # 每日 config 小包 + 各站整包
    backup-sites.py      # 整站内容寻址归档，须与 backup.sh 一同部署
    health-lizhi.sh      # 荔枝 SOCKS 探活
  .data/                 # chmod 700；内含密钥
    panel.db
    lizhi-accounts.json  # 荔枝账号 / TG / proxy
    r2.env               # R2（勿进 git）
    ssh.aes
```

systemd：

- `site-panel` — 面板
- `lizhi-socks` — SSH SOCKS `127.0.0.1:17890`（抓荔枝）

> 文件管理在面板内完成；不要再启用旧的 `site-panel-files` 服务。

## 更新面板

先构建并在独立候选实例验收，再把新二进制上传为 `bin/panel.next`。保留当前二进制副本；在同一文件系统内替换后重启 `site-panel`。不要先停止服务再上传文件。

更新面板不会部署目标站点，也不应重启目标 Nginx。前端包含在二进制内。


前端已 `embed`，一般不必单独同步 `web/`。

## 荔枝出口

香港主控直连荔枝会 `PROTOCOL_ERROR`。需：

1. `lizhi-socks.service` → 国内机 SOCKS（显式密钥，已纳入面板备份目录）：
   ```text
   ssh -i /www/site-panel/.ssh/lizhi-socks_ed25519 … -D 127.0.0.1:17890 root@<国内机>
   ```
   - 部署密钥：`/www/site-panel/.ssh/id_ed25519`（`panel@site-panel`）
   - SOCKS 密钥：`/www/site-panel/.ssh/lizhi-socks_ed25519`（与原 `/root/.ssh/id_ed25519` 同材；指纹见该目录 `README.txt`）
2. `.data/lizhi-accounts.json` 含 `"proxy": "socks5://127.0.0.1:17890"`

## 备份 → R2（桶名 `site-panel`）

凭据：`.data/r2.env` + `/root/.config/rclone/rclone.conf`（权限 600）。

Token 需对该桶有 **Object Read & Write**（Workers R2 Storage Bucket Item Read/Write）。  
对象级 Token **不能** `ListBuckets`，属正常。

cron（主机时区 Asia/Shanghai，每天凌晨 03:30 备份）：

```cron
PATH=/usr/local/bin:/usr/bin:/bin
30 3 * * * /www/site-panel/scripts/backup.sh /root/backups/site-panel >> /var/log/site-panel-backup.log 2>&1
5 */2 * * * /www/site-panel/scripts/health-lizhi.sh >> /var/log/site-panel-health.log 2>&1
```

### 整站归档

依赖：Python 3.8+（含 sqlite3）、GNU tar/date、flock、rclone。更新时同时部署
`scripts/backup.sh`、`scripts/backup-sites.py` 和 `scripts/backup-retention.py`。cron 入口不变。

| 类型 | R2 路径 | 说明 |
|------|---------|------|
| config | `config/<stamp>/config-<stamp>.tar.gz` | SQLite 一致性快照、.data（不含 r2.env）、面板 `.ssh`、templates/systemd/站点配置，以及主面板 Nginx vhost、WebSocket map、TLS 证书和 acme.sh 续期状态/相关 cron |
| 整站包 | `site-archives/<sha256>.tar.gz` | 每个站点完整目录，含 www/APK/隐藏文件/conf/cron；内容不变不重复压缩上传 |
| 恢复清单 | `site-manifests/manifest-<stamp>-<id>.json` | 本次所有站点对应的归档、原始 tar SHA256、配套 config 路径；全部上传成功后才发布 |

每次在本机生成稳定的 tar 并计算内容摘要，统一文件时间和所有者信息，避免仅时间变化导致重复上传。
只在 R2 没有对应归档时才压缩和上传。每次做远程归档对象列表查询，仍可能分页，但不再逐个站点文件做远程检查。
本地会完整读取每站内容，需要容纳最大单站原始 tar 和压缩包的临时磁盘空间。
站点打包期间检测到修改会报错，请在编辑和站点定时任务结束后重试；这不是文件系统瞬时快照。
日志也在整站包内，日志变化同样触发新包。

远程上传失败返回非零；缺失 R2、数据库或 sites 目录也视为失败。相同输出目录使用 flock 避免重叠运行。
完整备份成功后执行保留策略：主机本地 config 包与清单各保留最近 3 份；R2 保留最近 3 份完整恢复清单及其引用的 config 和站点归档。归档按内容寻址，多个恢复点可共用同一个站点包。清理程序先验证全部清单和对象引用；发现损坏或缺失时拒绝删除。不要给共享归档设置按创建日期删除的生命周期。

旧 `sites-live/`、`sites-history/` 不再写入。2026-11-06 清空旧 R2 对象并重建。清理演练和完整恢复演练通过后，曾暂存的旧 374 对象副本 `/root/backups/site-panel/r2-before-reset-20261106/` 已删除，不参与日常恢复。新备份记录见 [项目收尾验收](./docs/acceptance/2026-11-06-project-closeout/release.log)。
R2 恢复材料含部署私钥、主面板 TLS 私钥、ACME 账号状态和账号凭据，按敏感数据管理。SOCKS 使用的其它路径密钥、主机 SSH 配置、R2 凭据及主机系统/面板版 Nginx 安装包仍需单独托管。

### 恢复

先选一个已成功上传的 `site-manifests/manifest-*.json` 并下载。清单中的 `config` 和每站 `archive`
是该次恢复所需的确切对象路径。

```sh
rclone copyto r2:site-panel/site-manifests/<manifest文件名>.json /tmp/manifest.json --s3-no-check-bucket
# 根据清单 config 字段下载配套包
rclone copyto r2:site-panel/config/<stamp>/config-<stamp>.tar.gz /tmp/config.tgz --s3-no-check-bucket
mkdir -p /tmp/panel-restore/config /tmp/panel-restore/sites
tar -C /tmp/panel-restore/config -xzf /tmp/config.tgz
# 对清单中的每个站点重复：下载、校验解压后的 tar SHA256，再解压
rclone copyto r2:site-panel/site-archives/<sha256>.tar.gz /tmp/site.tgz --s3-no-check-bucket
gzip -dc /tmp/site.tgz | sha256sum
# 上一行必须匹配该站的 tar_sha256；不匹配就停止
tar -C /tmp/panel-restore/sites -xzf /tmp/site.tgz
```

在隔离目录检查数据库 `PRAGMA integrity_check`、站点内容及权限后，再停面板做替换。
配置包中的 `data/` 对应 `.data/`，`.ssh/`、`templates/` 应恢复到面板根目录；`host-config/nginx/` 的主面板 vhost/map、`host-config/cert/site-panel.xfnss.top/` 的证书和 `host-config/acme-home/` 的续期状态分别恢复到原位置。`host-config/panel-cron.txt` 只含面板备份/健康检查和 ACME 续期行，核对后合并进 root crontab，不要覆盖其他任务。主机版 Nginx、面板二进制和系统依赖需从受信来源安装；systemd 单元需检查后安装。
不要在面板运行时直接覆盖 SQLite 数据库；替换时须一并处理旧 WAL/SHM，避免混用旧库文件。
恢复站点应整体替换为已验证目录，避免与现场旧文件混合。tar 使用统一所有者，恢复后按服务账号设置权限。
最后验证主面板启动、HTTPS 反代、SSH 部署、SOCKS 抓取和 TG，再恢复定时任务。恢复演练记录见 `docs/acceptance/`；不向真实 TG 发送测试通知。

## 运维备忘

| 项 | 位置 |
|----|------|
| 面板登录密码 | 首次设置；库内哈希 |
| 面板会话 | 空闲 2 小时失效（有操作顺延）；最长 24 小时须重登；单会话互挤 |
| 荔枝 / TG | `.data/lizhi-accounts.json` |
| R2 | `.data/r2.env` + rclone.conf |
| SSH 密码 | 库内加密，解密钥 `.data/ssh.aes` |
| 默认部署私钥 | `/www/site-panel/.ssh/id_ed25519` |
| 荔枝 SOCKS 私钥 | `/www/site-panel/.ssh/lizhi-socks_ed25519`（随 config 备份） |

## 健康检查

```sh
systemctl is-active site-panel lizhi-socks
/www/site-panel/scripts/health-lizhi.sh
curl -sS -o /dev/null -w '%{http_code}\n' --socks5-hostname 127.0.0.1:17890 \
  -A Mozilla 'https://www.lizhidc.cn/login?action=email'
```

## 运维约定

- 初始化面向 Debian/Ubuntu：安装 Nginx、rsync、Python；顺带 fail2ban（仅 sshd）与 sshd 连接限制（MaxAuthTries/LoginGraceTime/MaxStartups）。不管 ufw/其它端口。不关密码登录（面板重装钥还要用）。再次初始化会重跑最新脚本。申请 SSL 时安装 certbot 并启用续期 timer/hook。
- **芝麻开门（CentOS）** 继续复用宝塔 Nginx / `panel-nginx`，不跑 Debian 初始化或更换其 Nginx。
- 完整部署同步文件与配置；SSL 操作只下发证书和配置，不重新执行 APK。手动证书备份始终保留；切到 Let’s Encrypt 不删除主控 `ssl/` 原 PEM。
- 部署与「初始化」都会确保 `/etc/nginx/conf.d/00-ssp-default.conf`：未知 Host 走 `default_server`，HTTP `return 444`，HTTPS 优先 `ssl_reject_handshake`（不支持则 444）。业务站 conf 不进面板站点列表；禁域名只需从该站 `server_name` 删除并部署。
- APK：站点开关「.apk文件自动混淆」+ www 根目录源 apk；`apk_processor.py` 内置在面板二进制，部署时下发到站点目录外。部署末尾与每 30 分钟 cron 共用 `.panel-apk-run` 原地覆盖同名文件；勿手改 cron。
- SSH：主机密钥变化时自动更新该主机的 `known_hosts` 条目。部署、SSL、APK、终端等连接遇到认证前的 KEX/banner 短暂断连，会最多自动重试 3 次；不会重放远端命令失败。密钥认证失败且保存了密码时，终端和部署会自动尝试重装公钥并重试；密码失效时，在终端、部署或 SSL 操作当前页面输入新密码即可重装并重试。服务器设置里的“重装密钥”也可主动执行修复。systemd 无 HOME 时按运行账号解析目录。
- 备份 cron 只运行现行 `backup.sh`，配套 `backup-sites.py` 必须一起更新。旧 R2 对象保留。编辑器/图标随二进制内置，部署时不访问 CDN。
- 每 2 小时 `health-lizhi.sh` 检查面板进程/HTTP、主控剩余空间（至少 2 GiB）、最近完整 R2 备份（36 小时内）、抓取代理、以及面板登记主机的 SSH 端口；正常不发 TG，异常只发短句（如「面板异常」「备份失败」「抓取失败」）。结果写入 `.data/health-last` 供早报复用。备份成功依据为 R2 上传全部完成后落盘的本地清单，目录默认 `/root/backups/site-panel`，可通过 `SITE_PANEL_BACKUP_DIR` 覆盖。健康日志见 `/var/log/site-panel-health.log`。

现场与验收边界见 [PROJECT_STATUS.md](./PROJECT_STATUS.md)、[PRODUCTION_REVIEW.md](./PRODUCTION_REVIEW.md)。
