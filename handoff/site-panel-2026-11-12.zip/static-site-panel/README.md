# Static Site Panel

单管理员用的多机 Nginx 静态站 / SPA 控制面板：主控保存整站原件，经 SSH 下发到目标机；面板内编辑文件、管理域名与 SSL、跑固定 APK 混淆流程，并汇总荔枝续费。

- 产品约定：[DESIGN.md](./DESIGN.md)
- 生产部署 / 备份 / R2：[DEPLOY.md](./DEPLOY.md)
- 当前现场：[PROJECT_STATUS.md](./PROJECT_STATUS.md)
- 验证命令：[TESTING.md](./TESTING.md)
- 验收边界：[PRODUCTION_REVIEW.md](./PRODUCTION_REVIEW.md)

## 本地跑

```sh
go run ./cmd/panel -listen 127.0.0.1:8790 -sites ./sites -data ./.data
```

浏览器打开 http://127.0.0.1:8790 ，首次设密码。前端经 `go:embed` 打进二进制，改 `web/` 后需重新 `go build`。

## 备份 / 健康

```sh
./scripts/backup.sh /path/to/backup-dir
./scripts/health-lizhi.sh   # 每 2h：面板/备份/SOCKS/主机端口；异常短句 TG
```

细节见 [DEPLOY.md](./DEPLOY.md)。
